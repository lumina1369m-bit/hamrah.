#!/usr/bin/env node
/* راستی‌آزمایی اصلاح نشست ۳۰ روزه + جریان بازگشت مترجم:
   ۱) سرور موقت با پایگاه‌دادهٔ موقت  ۲) verify باید expires_in=2592000 بدهد
   ۳) /translator/status بعد از verify کار کند  ۴) سینتکس اسکریپت‌های درون translator/index.html */
const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');
const os = require('os');

const ROOT = '/home/z/my-project/upload/hamrah_extracted/hamrah-main';
const DB = path.join(os.tmpdir(), 'hz_sessfix_' + Date.now() + '.sqlite');
const PORT = 8099;
let failures = 0;
const ok = (name, cond) => { console.log((cond ? 'PASS' : 'FAIL') + '  ' + name); if (!cond) failures++; };

// ---------- ۴) سینتکس اسکریپت‌های درون HTML ----------
(function checkInline() {
  const html = fs.readFileSync(path.join(ROOT, 'translator/index.html'), 'utf8');
  const blocks = [...html.matchAll(/<script(?![^>]*src=)[^>]*>([\s\S]*?)<\/script>/g)];
  blocks.forEach((m, i) => {
    try { new Function(m[1]); ok('inline-script#' + (i + 1) + ' syntax', true); }
    catch (e) { ok('inline-script#' + (i + 1) + ' syntax (' + e.message + ')', false); }
  });
  ok('resumeAfterLogin present', html.includes('function resumeAfterLogin'));
  ok('verifyNow uses resumeAfterLogin', /state\.completed\[1\] = true; state\.step = 2;[\s\S]{0,200}?resumeAfterLogin\(\)/.test(html));
  ok('boot uses resumeAfterLogin', html.includes('if (H.requireSession(state)) { resumeAfterLogin(); }'));
  ok('devSkip stable phone', html.includes("localStorage.getItem('hz.devPhone')"));
})();

// ---------- سرور موقت ----------
const srv = spawn('node', ['server.js'], {
  cwd: path.join(ROOT, 'server'),
  env: Object.assign({}, process.env, { HZ_DEV: '1', HZ_ADMIN_PASSWORD: 'x', HZ_DB: DB, PORT: String(PORT) }),
  stdio: ['ignore', 'pipe', 'pipe']
});
srv.stderr.on('data', (d) => process.stderr.write('[srv] ' + d));

const base = 'http://127.0.0.1:' + PORT;
const api = (m, p, body, tok) => fetch(base + '/api' + p, {
  method: m, headers: Object.assign({ 'Content-Type': 'application/json' }, tok ? { Authorization: 'Bearer ' + tok, 'X-Auth-Token': tok } : {}),
  body: body ? JSON.stringify(body) : undefined
}).then(async (r) => ({ status: r.status, data: await r.json().catch(() => ({})) }));

const wait = (ms) => new Promise((r) => setTimeout(r, ms));
const PHONE = '912' + String(Math.floor(1000000 + Math.random() * 8999999));

(async () => {
  for (let i = 0; i < 60; i++) { try { await api('GET', '/config'); break; } catch (e) { await wait(300); } }
  const code = await api('POST', '/auth/request-code', { phone: PHONE, role: 'translator' });
  ok('request-code 200', code.status === 200);
  const v = await api('POST', '/auth/verify', { phone: PHONE, role: 'translator', code: '123456' });
  ok('verify 200', v.status === 200);
  ok('expires_in == 2592000 (۳۰ روز)', v.data && v.data.expires_in === 2592000);
  const st = await api('GET', '/translator/status', null, v.data.token);
  ok('translator/status 200', st.status === 200 && st.data && typeof st.data.status === 'string');
  // سند پایه: نشست باید در پایگاه‌داده با انقضای ~۳۰ روز ذخیره شده باشد
  const Database = require(path.join(ROOT, 'server/node_modules/better-sqlite3'));
  const db = new Database(DB, { readonly: true });
  const row = db.prepare('SELECT expires_at FROM sessions ORDER BY expires_at DESC LIMIT 1').get();
  const days = (row.expires_at - Date.now()) / 86400000;
  ok('session row ~30 days (' + days.toFixed(1) + ')', days > 29 && days < 31);
  db.close();
  console.log(failures ? '\nRESULT: FAILED (' + failures + ')' : '\nRESULT: ALL PASS');
  srv.kill('SIGKILL'); try { fs.unlinkSync(DB); } catch (e) {}
  process.exit(failures ? 1 : 0);
})().catch((e) => { console.error('HARNESS ERROR', e); srv.kill('SIGKILL'); process.exit(2); });
