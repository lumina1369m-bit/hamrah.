#!/usr/bin/env bash
# پیش‌نمایش پایدار پلتفرم همراه روی پورت ۳۰۰۰ (اپ مسافر + اپ مترجم + پنل مدیریت).
# رمز ورود پنل: hamrah-preview-2026
# سرور در حلقهٔ نگهبان اجرا می‌شود: اگر کرش محیطی better-sqlite3 آن را کشت، بلافاصله برمی‌گردد.
set -u
ROOT="/home/z/my-project/upload/hamrah_extracted/hamrah-main"
: > /tmp/hz_preview.log
# کشتن دقیق پروسهٔ گوش‌دهنده به ۳۰۰۰ (pkill -f کار نمی‌کند چون PORT متغیر محیط است نه cmdline)
OLDPID=$(ss -ltnp 2>/dev/null | grep ':3000 ' | grep -oP 'pid=\K[0-9]+' | head -1)
[ -n "$OLDPID" ] && kill -9 "$OLDPID" 2>/dev/null
sleep 0.6
# نگهبانِ جداشده: double-fork + setsid تا با پایان نشست شل زنده بماند
( setsid bash -c '
while true; do
  (cd "'"$ROOT"'/server" && exec env HZ_DEV=1 HZ_ADMIN_PASSWORD=hamrah-preview-2026 PORT=3000 node server.js >> /tmp/hz_preview.log 2>&1)
  echo "[supervise] پیش‌نمایش خارج شد؛ راه‌اندازی مجدد..." >> /tmp/hz_preview.log
  sleep 1
done' > /dev/null 2>&1 & )
for i in $(seq 1 30); do curl -s -o /dev/null "http://127.0.0.1:3000/api/config" && break; sleep 0.5; done
if curl -s -o /dev/null "http://127.0.0.1:3000/api/config"; then
  echo "PREVIEW_UP http://127.0.0.1:3000"
  echo "  مسافر:    /traveler/index.html"
  echo "  مترجم:    /translator/index.html"
  echo "  پنل مدیر: /admin/index.html  (رمز: hamrah-preview-2026)"
else
  echo "PREVIEW_FAILED"; tail -20 /tmp/hz_preview.log; exit 1
fi
