#!/usr/bin/env node
/* مقایسهٔ هش‌های CSP سرور با هشِ واقعی بلوک‌های <script> و هندلرهای on* در translator/index.html */
const crypto = require('crypto');
const fs = require('fs');
const { execSync } = require('child_process');

const FILE = '/home/z/my-project/upload/hamrah_extracted/hamrah-main/translator/index.html';
const html = fs.readFileSync(FILE, 'utf8');

// هش هدر CSP از سرور زندهٔ ۳۰۰۰
const hdr = execSync('curl -sI http://127.0.0.1:3000/translator/index.html | grep -i content-security-policy').toString();
const serverHashes = new Set([...hdr.matchAll(/sha256-([A-Za-z0-9+/=]+)/g)].map((m) => m[1]));
console.log('سرور روی پورت ۳۰۰۰ است — هش‌های هدر:', serverHashes.size);

const localHashes = [];
for (const m of html.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script>/gi)) {
  if (/\bsrc\s*=/i.test(m[1])) continue;
  const h = crypto.createHash('sha256').update(m[2], 'utf8').digest('base64');
  localHashes.push({ h, preview: m[2].trim().slice(0, 60).replace(/\s+/g, ' ') });
}
const decodeEntities = (s) => s
  .replace(/&#x([0-9a-fA-F]+);/g, (_, h) => String.fromCodePoint(parseInt(h, 16)))
  .replace(/&#([0-9]+);/g, (_, d) => String.fromCodePoint(Number(d)))
  .replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>')
  .replace(/&amp;/g, '&');
for (const m of html.matchAll(/\son[a-z]+\s*=\s*"([^"]*)"/g)) {
  const h = crypto.createHash('sha256').update(decodeEntities(m[1]), 'utf8').digest('base64');
  localHashes.push({ h, preview: 'on-handler: ' + m[1].slice(0, 50) });
}

let missing = 0;
for (const { h, preview } of localHashes) {
  const okh = serverHashes.has(h);
  if (!okh) { missing++; console.log('MISSING هش محلی در هدر نیست:', h, '⇐', preview); }
}
console.log(missing === 0 ? 'همهٔ هش‌های محلی در هدر هستند' : 'تعداد هش غایب: ' + missing);
// و برعکس: هش‌های هدر که از فایل فعلی نمی‌آیند (مثلن از فایل‌های دیگر ریشه‌ها)
