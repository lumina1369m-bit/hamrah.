#!/usr/bin/env python3
# بازتولید جریان ورود مترجم برای یافتن خطای resumeAfterLogin — چاپ کنسول و خطاهای صفحه
import asyncio, sys, random
from playwright.async_api import async_playwright

BASE = sys.argv[1] if len(sys.argv) > 1 else 'http://127.0.0.1:8081'

async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(args=['--no-sandbox'])
        ctx = await b.new_context(viewport={'width': 390, 'height': 900})
        await ctx.route(lambda u: 'unpkg.com' in u or 'cdn.' in u or 'fonts.' in u, lambda r: r.abort())
        pg = await ctx.new_page()
        pg.on('pageerror', lambda e: print('PAGEERROR:', str(e)[:300]))
        pg.on('console', lambda m: print('CONSOLE[' + m.type + ']:', m.text[:200]))
        # متن شرایط را قبل از لود صفحه ثبت می‌کنیم تا hzCfg آن را بگیرد
        adm = await ctx.request.post(BASE + '/api/admin/login', data={'password': 'test-admin-pass'})
        assert adm.ok, adm.status()
        atok = (await adm.json())['token']
        await ctx.request.put(BASE + '/api/admin/settings', headers={'Authorization': 'Bearer ' + atok},
                              data={'translator_terms_text': 'شرایط آزمون.'})
        await pg.goto(BASE + '/translator/index.html'); await pg.wait_for_timeout(700)
        await pg.click('#openTermsBtn'); await pg.wait_for_timeout(200)
        await pg.locator('#infoModal button', has_text='بستن').first.click(); await pg.wait_for_timeout(150)
        await pg.fill('#mobileInput', '9' + str(random.randint(100000000, 999999999)))
        await pg.check('#c-age'); await pg.check('#c-terms')
        await pg.click('#sendOtpBtn'); await pg.wait_for_timeout(400)
        boxes = pg.locator('#step-panel-1 input[type=text]')
        for i, d in enumerate('123456'): await boxes.nth(i).fill(d)
        await pg.wait_for_timeout(1500)
        active = await pg.evaluate("[...document.querySelectorAll('.step-content')].filter(x=>x.classList.contains('active')).map(x=>x.id)")
        print('ACTIVE PANEL:', active)
        st = await pg.evaluate("JSON.parse(localStorage.getItem('hz.translator.v1')||'{}').status")
        step = await pg.evaluate("JSON.parse(localStorage.getItem('hz.translator.v1')||'{}').step")
        tok = await pg.evaluate("!!JSON.parse(localStorage.getItem('hz.translator.v1')||'{}').token")
        print('STATE status=', st, 'step=', step, 'token?', tok)
        # سناریوی ۲: تأیید آزمایشی حساب → بارگذاری دوبارهٔ index → باید مستقیم به میز کار (app.html) برود
        await ctx.request.post(BASE + '/api/dev/approve-translator',
                               headers={'Authorization': 'Bearer ' + await pg.evaluate("JSON.parse(localStorage.getItem('hz.translator.v1')||'{}').token")})
        await pg.goto(BASE + '/translator/index.html'); await pg.wait_for_timeout(1500)
        print('AFTER RELOAD URL:', pg.url)
        await b.close()

asyncio.run(main())
