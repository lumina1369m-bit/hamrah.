#!/usr/bin/env bash
# هارنس سریع پنل: سرور ۸۰۸۱ با پایگاه دادهٔ موقت + تست‌های سروری مرتبط + ۵ تست UI پنل.
# استفاده: bash /home/z/my-project/scripts/run_admin_suite.sh
set -u
ROOT="/home/z/my-project/upload/hamrah_extracted/hamrah-main"
SERVER_DIR="$ROOT/server"; TESTS_DIR="$ROOT/tests"
if curl -s -o /dev/null "http://127.0.0.1:8081/api/config"; then echo "پورت 8081 اشغال است"; exit 2; fi
DB_TMP="$(mktemp -u /tmp/hz_admin_XXXX).sqlite"
SRV_LOG=/tmp/hz_admin_server.log
# نگهبان: کرش محیطی better-sqlite3 سرور را وسط سویت نمی‌کشد؛ با همان DB بلافاصله برمی‌گردد.
srvloop() {
  while true; do
    (cd "$SERVER_DIR" && exec env HZ_DEV=1 HZ_ADMIN_PASSWORD=test-admin-pass HZ_DB="$DB_TMP" PORT=8081 node server.js >> "$SRV_LOG" 2>&1)
    echo "[supervise] سرور 8081 خارج شد؛ راه‌اندازی مجدد..." >> "$SRV_LOG"
    sleep 1
  done
}
( srvloop ) &
SPID=$!
trap 'kill $SPID 2>/dev/null; pkill -P $SPID 2>/dev/null; sleep 0.4; rm -f "$DB_TMP" "$DB_TMP-wal" "$DB_TMP-shm"' EXIT
for i in $(seq 1 20); do curl -s -o /dev/null "http://127.0.0.1:8081/api/config" && break; sleep 0.5; done
fail=0
run() { echo "== $*"; if timeout 300 "$@" > /tmp/hz_last_test.log 2>&1; then tail -4 /tmp/hz_last_test.log; else echo "   FAILED (tail):"; tail -12 /tmp/hz_last_test.log; fail=1; fi; }
cd "$TESTS_DIR"
run env BASE=http://127.0.0.1:8081 node "$SERVER_DIR/test/api.test.js"
run env BASE=http://127.0.0.1:8081 node "$SERVER_DIR/test/features_cities_security.test.js"
run env BASE=http://127.0.0.1:8081 node "$SERVER_DIR/test/coverage_notify.test.js"
run env BASE=http://127.0.0.1:8081 node "$SERVER_DIR/test/admin_rbac.test.js"
run env BASE=http://127.0.0.1:8081 node "$SERVER_DIR/test/admin_finance_ops.test.js"
run env BASE=http://127.0.0.1:8081 node "$SERVER_DIR/test/change_flow.test.js"
run python3 admin_ui.py
run python3 admin_docs_ui.py
run python3 admin_slots_ui.py
run python3 admin_editors_ui.py
run python3 admin_system_ui.py http://127.0.0.1:8081
echo "SUITE: $([ $fail = 0 ] && echo PASS || echo FAIL)"
exit $fail
