'use strict';
/*
 * سرور توسعه‌ی همراه (مسافر و مترجم)
 * - فایل‌های استاتیک هر دو اپ را سرو می‌کند: /traveler/ و /translator/
 * - API احراز هویت با کد پیامکی، وضعیت مترجم و ماموریت‌ها را با SQLite نگه می‌دارد
 *
 * وضعیت پیامک: هنوز سرویس پیامک انتخاب نشده است. تا وقتی HZ_DEV=1 باشد کد ثابت «123456»
 * استفاده می‌شود و تأیید کارشناس/ماموریت‌های آزمایشی هم فعال‌اند. در حالت غیر-توسعه،
 * ارسال کد به سرویس پیامک نیاز دارد و بدون پیکربندی با خطای 503 پاسخ می‌دهد.
 */
const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const Database = require('better-sqlite3');
// اعلان فوری (Web Push): وابستگی web-push؛ اگر ماژول در دسترس نبود، پلتفرم بدون پوش ادامه می‌دهد
let webpush = null;
try { webpush = require('web-push'); } catch (e) { console.warn('[push] web-push بارگذاری نشد؛ اعلان فوری غیرفعال است.'); }
const { makeLimiter, clientIp, securityHeaders, productionErrors, isWeakAdminPassword } = require('./lib/security');
const { FEATURES, FEATURE_KEYS, resolveFeatures, validateFeaturePatch } = require('./lib/features');
const { createSmsSender } = require('./lib/sms');

const PORT = Number(process.env.PORT || 8080);
const DEV = process.env.HZ_DEV === '1';
const DB_PATH = process.env.HZ_DB || path.join(__dirname, 'data', 'hamzaban.sqlite');
const APP_ROOT = path.resolve(__dirname, '..');
const STATIC_ROOTS = { '/traveler/': path.join(APP_ROOT, 'traveler'), '/translator/': path.join(APP_ROOT, 'translator'), '/admin/': path.join(APP_ROOT, 'admin') };

// رمزگشایی امن URL: ورودی بدفرم (مثل %zz یا %00) به‌جای استثنای رمزگشایی که پروسه را
// می‌اندازد (unhandledRejection)، null برمی‌گرداند تا هندلر ۴۰۰ بدهد (بازبینی: یافتهٔ بحرانی ۱).
function safeDecode(s) {
  try { return decodeURIComponent(s); } catch (e) { return null; }
}

// ---------- هش‌های CSP (یافتهٔ ۷) ----------
// 'unsafe-inline' از script-src حذف می‌شود؛ به‌جایش هش sha256 همهٔ بلوک‌های <script> درون‌خطی
// و کد همهٔ هندلرهای on* در فایل‌های HTML، هنگام راه‌اندازی محاسبه و با 'unsafe-hashes'
// در CSP قرار می‌گیرد. اسکریپت تزریقی/دستکاری‌شده دیگر اجرا نمی‌شود.
// مرورگر کد هندلر را پس از رمزگشایی موجودیت هش می‌کند؛ پس هش روی متن رمزگشایی‌شده محاسبه می‌شود.
function computeScriptHashes() {
  const decodeEntities = (s) => s
    .replace(/&#x([0-9a-fA-F]+);/g, (_, h) => String.fromCodePoint(parseInt(h, 16)))
    .replace(/&#([0-9]+);/g, (_, d) => String.fromCodePoint(Number(d)))
    .replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>')
    .replace(/&amp;/g, '&');
  const hashes = new Set();
  const add = (code) => { if (code && code.trim()) hashes.add(crypto.createHash('sha256').update(code, 'utf8').digest('base64')); };
  for (const root of Object.values(STATIC_ROOTS)) {
    let names = [];
    try { names = fs.readdirSync(root).filter((f) => f.endsWith('.html')); } catch (e) { continue; }
    for (const name of names) {
      let html = '';
      try { html = fs.readFileSync(path.join(root, name), 'utf8'); } catch (e) { continue; }
      for (const m of html.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script>/gi)) {
        if (/\bsrc\s*=/i.test(m[1])) continue;
        add(m[2]); // محتوای اسکریپت مثل مرورگر خام هش می‌شود (بدون رمزگشایی موجودیت)
      }
      for (const m of html.matchAll(/\son[a-z]+\s*=\s*"([^"]*)"/g)) add(decodeEntities(m[1]));
      for (const m of html.matchAll(/\son[a-z]+\s*=\s*'([^']*)'/g)) add(decodeEntities(m[1]));
    }
  }
  return [...hashes];
}
const SCRIPT_HASHES = computeScriptHashes();
// تازگی هش‌ها (آسیب‌شناسی ۲۰۲۶-۱۰-۲۶): ویرایش HTML بعد از استارت سرور، هش‌های CSP را
// کهنه می‌کند و مرورگر اسکریپت درون‌خطی نو را بلاک می‌کند (اپ ظاهر می‌شود ولی هیچ
// دکمه‌ای کار نمی‌کند). دو راهکار خودکار (فراخوانی fs در مسیر هر درخواست و fs.watch)
// در بازتولیدهای pay_ui با کرش متناوب better-sqlite3 همراه بود و کنار گذاشته شد؛
// نسخهٔ پایدار همان هش‌های استارت است + قاعدهٔ اجرایی: «بعد از هر ویرایش HTML، سرور
// پیش‌نمایش را ری‌استارت کن» (run_all.sh و اسکریپت‌های تست خودشان سرور تازه می‌سازند).
// زمینهٔ درخواست ادمین: برای اینکه هر رکورد audit بداند «چه کسی» انجام داده،
// هندلر مسیرهای /api/admin داخل این زمینه اجرا می‌شود و audit() از آن هویت می‌خواند.
const ADMIN_CTX = new (require('async_hooks').AsyncLocalStorage)();

// ثابت‌های پیکربندی (در پنل مدیریت یا قانون تعریف می‌شوند؛ اینجا فقط مقدار اولیه‌اند)
const CONFIG = {
  OTP_TTL_SEC: 120,          // مدت اعتبار کد و زمان ارسال مجدد (سند مترجم)
  OTP_RESEND_SEC: 120,
  OTP_MAX_ATTEMPTS: 5,       // سند: ۵ تلاش ناموفق
  OTP_LOCK_SEC: 10 * 60,     // سند: قفل ۱۰ دقیقه‌ای
  SESSION_HOURS: 720,        // نشست ۳۰ روزه — گزارش کاربر: با نشست ۱۲ ساعته هر بار باید از صفر وارد می‌شد
  DEV_CODE: '123456',
};

// بررسی ایمنی پیکربندی در حالت انتشار، پیش از ساخت پایگاه داده و کلید مدارک انجام می‌شود تا
// سرور با تنظیمات ناامن اصلاً بالا نیاید (fail closed). این بررسی باید همین‌جا و زود انجام شود؛
// وگرنه خروج زودهنگامِ نبودِ HZ_DOC_KEY در بخش مدارک جلوی پیام یکپارچه‌ی «پیکربندی ناامن» را می‌گیرد.
if (require.main === module) {
  const cfgErrors = productionErrors(process.env);
  if (cfgErrors.length) { console.error('پیکربندی ناامن؛ سرور بالا نمی‌آید:\n - ' + cfgErrors.join('\n - ')); process.exit(1); }
}

// فرستنده‌ی پیامک از متغیرهای محیطی ساخته می‌شود (lib/sms.js)؛ تا وقتی شرکت و کلید تنظیم نشده،
// در حالت غیرتوسعه پاسخ 503 sms_provider_not_configured داده می‌شود.
const SMS = createSmsSender(process.env);

fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  phone TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('traveler','translator')),
  created_at INTEGER NOT NULL,
  UNIQUE(phone, role)
);
CREATE TABLE IF NOT EXISTS otp_codes (
  phone TEXT NOT NULL,
  role TEXT NOT NULL,
  code_hash TEXT NOT NULL,
  expires_at INTEGER NOT NULL,
  created_at INTEGER NOT NULL,
  attempts INTEGER NOT NULL DEFAULT 0,
  locked_until INTEGER,
  PRIMARY KEY (phone, role)
);
CREATE TABLE IF NOT EXISTS sessions (
  token_hash TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  expires_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS translators (
  user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  status TEXT NOT NULL DEFAULT 'registered',
  updated_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS translator_documents (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'uploaded',
  mime TEXT NOT NULL,
  size INTEGER NOT NULL,
  blob BLOB NOT NULL,
  reject_reason TEXT,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS missions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  translator_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  code TEXT NOT NULL,
  purpose TEXT,
  traveler_name TEXT,
  place TEXT,
  start_at INTEGER NOT NULL,
  total INTEGER NOT NULL DEFAULT 0,
  net INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'accepted'
);
CREATE TABLE IF NOT EXISTS bookings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  traveler_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  payload TEXT NOT NULL,
  created_at INTEGER NOT NULL
);
`);

// ستون‌های آنلاین و زبان‌ها برای مترجم (اگر قبلاً نبودند)
for (const sql of [
  "ALTER TABLE translators ADD COLUMN online INTEGER NOT NULL DEFAULT 0",
  "ALTER TABLE translators ADD COLUMN langs TEXT NOT NULL DEFAULT '[\"fa\",\"ar\",\"en\"]'",
  "ALTER TABLE translators ADD COLUMN gender TEXT",
  "ALTER TABLE translators ADD COLUMN accept_any INTEGER NOT NULL DEFAULT 1",
  "ALTER TABLE translators ADD COLUMN traveler_gender_pref TEXT NOT NULL DEFAULT 'any'",
  "ALTER TABLE translators ADD COLUMN score INTEGER NOT NULL DEFAULT 100",
]) { try { db.exec(sql); } catch (e) { /* ستون از قبل وجود دارد */ } }
db.exec(`
CREATE TABLE IF NOT EXISTS reservations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  traveler_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind TEXT NOT NULL CHECK (kind IN ('instant','scheduled')),
  origin_lang TEXT NOT NULL,
  dest_lang TEXT NOT NULL,
  field TEXT NOT NULL DEFAULT 'tourism',
  place TEXT NOT NULL DEFAULT '',
  notes TEXT NOT NULL DEFAULT '',
  traveler_name TEXT NOT NULL DEFAULT '',
  gender_pref TEXT NOT NULL DEFAULT 'any',
  scheduled_at INTEGER,
  status TEXT NOT NULL,
  translator_id INTEGER REFERENCES users(id),
  matched_at INTEGER,
  search_started_at INTEGER NOT NULL,
  total INTEGER NOT NULL,
  net INTEGER NOT NULL,
  cancel_after_match INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS mission_cancellations (
  reservation_id INTEGER NOT NULL REFERENCES reservations(id) ON DELETE CASCADE,
  translator_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at INTEGER NOT NULL,
  PRIMARY KEY (reservation_id, translator_id)
);
CREATE TABLE IF NOT EXISTS offers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  reservation_id INTEGER NOT NULL REFERENCES reservations(id) ON DELETE CASCADE,
  translator_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  status TEXT NOT NULL DEFAULT 'pending',
  expires_at INTEGER NOT NULL,
  created_at INTEGER NOT NULL,
  decided_at INTEGER
);
`);

// ستون‌های تازه‌ی رزرو (بعد از ساخت جدول)
for (const sql of [
  "ALTER TABLE reservations ADD COLUMN traveler_gender TEXT",
  "ALTER TABLE reservations ADD COLUMN hours INTEGER NOT NULL DEFAULT 1",
  "ALTER TABLE reservations ADD COLUMN car INTEGER NOT NULL DEFAULT 0",
  "ALTER TABLE reservations ADD COLUMN party INTEGER NOT NULL DEFAULT 1",
  "ALTER TABLE reservations ADD COLUMN finished_at INTEGER",
  "ALTER TABLE reservations ADD COLUMN pay_method TEXT",
  "ALTER TABLE reservations ADD COLUMN traveler_paid INTEGER NOT NULL DEFAULT 0",
  "ALTER TABLE reservations ADD COLUMN translator_confirmed INTEGER NOT NULL DEFAULT 0",
  "ALTER TABLE reservations ADD COLUMN pay_state TEXT",
  "CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL)",
  "ALTER TABLE translators ADD COLUMN profile TEXT",
  "ALTER TABLE translators ADD COLUMN fields TEXT NOT NULL DEFAULT '[\"tourism\",\"pilgrimage\"]'",
  "ALTER TABLE translators ADD COLUMN interview TEXT",
  "CREATE TABLE IF NOT EXISTS translator_notifications (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, doc_id INTEGER, kind TEXT NOT NULL, created_at INTEGER NOT NULL, UNIQUE(doc_id, kind))",
  "CREATE TABLE IF NOT EXISTS interview_slots (id INTEGER PRIMARY KEY AUTOINCREMENT, starts_at INTEGER NOT NULL, booked_user_id INTEGER REFERENCES users(id) ON DELETE SET NULL, room_token TEXT, status TEXT NOT NULL DEFAULT 'open', created_at INTEGER NOT NULL)",
  "ALTER TABLE translator_notifications ADD COLUMN ref TEXT",
  "CREATE TABLE IF NOT EXISTS translator_interviews (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, result TEXT NOT NULL, created_at INTEGER NOT NULL)",
  "ALTER TABLE translator_documents ADD COLUMN expires_at INTEGER",
  "ALTER TABLE reservations ADD COLUMN base INTEGER",
  "ALTER TABLE reservations ADD COLUMN tax INTEGER",
  "ALTER TABLE reservations ADD COLUMN service_code TEXT",
  "ALTER TABLE reservations ADD COLUMN service_started_at INTEGER",
  "ALTER TABLE reservations ADD COLUMN translator_arrived_at INTEGER",
  "ALTER TABLE reservations ADD COLUMN service_code_attempts INTEGER NOT NULL DEFAULT 0",
  "ALTER TABLE reservations ADD COLUMN finish_requested_at INTEGER",
  "ALTER TABLE reservations ADD COLUMN finished_by TEXT",
  "ALTER TABLE reservations ADD COLUMN lat REAL",
  "ALTER TABLE reservations ADD COLUMN lng REAL",
  "CREATE TABLE IF NOT EXISTS admin_sessions (token_hash TEXT PRIMARY KEY, expires_at INTEGER NOT NULL)",
  // پرداخت درگاهی: هر تلاش پرداخت آنلاین یک ردیف با کد رهگیری یکتای درگاه (authority)
  "CREATE TABLE IF NOT EXISTS gateway_payments (id INTEGER PRIMARY KEY AUTOINCREMENT, reservation_id INTEGER NOT NULL REFERENCES reservations(id) ON DELETE CASCADE, provider TEXT NOT NULL, authority TEXT UNIQUE NOT NULL, amount INTEGER NOT NULL, status TEXT NOT NULL DEFAULT 'pending', created_at INTEGER NOT NULL, paid_at INTEGER, ref_id TEXT, raw TEXT)",
  // اشتراک‌های اعلان فوری مرورگر (Web Push) — هر endpoint یکتا است؛ منقضی/۴۰۴ حذف می‌شود
  "CREATE TABLE IF NOT EXISTS push_subscriptions (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, role TEXT NOT NULL, endpoint TEXT UNIQUE NOT NULL, p256dh TEXT NOT NULL, auth TEXT NOT NULL, user_agent TEXT, created_at INTEGER NOT NULL, last_sent_at INTEGER, last_error TEXT)",
  // اعلان‌های ثبت‌شدهٔ مسافر (تطبیق، لغو مترجم، پرداخت) — شکاف ۵ سفر مسافر
  "CREATE TABLE IF NOT EXISTS traveler_notifications (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, reservation_id INTEGER, kind TEXT NOT NULL, text TEXT NOT NULL, created_at INTEGER NOT NULL)",
  "CREATE INDEX IF NOT EXISTS idx_push_subscriptions_user ON push_subscriptions(user_id)",
  "CREATE INDEX IF NOT EXISTS idx_traveler_notifications_user ON traveler_notifications(user_id)",
  // ایندکس‌های کارایی sweep (یافتهٔ ۸): موتور تطبیق و اعلان‌ها در هر درخواست تغییر وضعیت اجرا می‌شوند؛
  // بدون ایندکس، هر بار اسکن کامل جدول‌ها بود که با رشد داده، تأخیر پاسخ را بالا می‌برد.
  "CREATE INDEX IF NOT EXISTS idx_translator_documents_status_expires ON translator_documents(status, expires_at)",
  "CREATE INDEX IF NOT EXISTS idx_interview_slots_status_starts ON interview_slots(status, starts_at)",
  "CREATE INDEX IF NOT EXISTS idx_reservations_status ON reservations(status)",
  "CREATE INDEX IF NOT EXISTS idx_offers_status ON offers(status, reservation_id)",
  "CREATE INDEX IF NOT EXISTS idx_sessions_expires ON sessions(expires_at)",
  "CREATE INDEX IF NOT EXISTS idx_admin_sessions_expires ON admin_sessions(expires_at)",
  // مبلغ‌گذاری پایان زودهنگام: ساعات صورتحساب‌شده + مبلغ اولیهٔ توافق‌شده برای شفافیت پرونده
  "ALTER TABLE reservations ADD COLUMN billed_hours INTEGER",
  "ALTER TABLE reservations ADD COLUMN list_total INTEGER",
  // موقعیت مکانی اختیاری مترجم (اشتراک موقعیت) — تطبیق شعاعی + نقشهٔ زندهٔ پنل
  "ALTER TABLE translators ADD COLUMN lat REAL",
  "ALTER TABLE translators ADD COLUMN lng REAL",
  "ALTER TABLE translators ADD COLUMN loc_at INTEGER",
  "ALTER TABLE translators ADD COLUMN share_loc INTEGER NOT NULL DEFAULT 0",
  // بدهی نقدی مترجم به پلتفرم: سهم پلتفرم از رزروهای نقدی که پولش دست مترجم مانده
  "CREATE TABLE IF NOT EXISTS debt_payments (id INTEGER PRIMARY KEY AUTOINCREMENT, translator_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, amount INTEGER NOT NULL, note TEXT, admin TEXT, created_at INTEGER NOT NULL)",
  "CREATE INDEX IF NOT EXISTS idx_debt_payments_translator ON debt_payments(translator_id)",
]) { try { db.exec(sql); } catch (e) { /* ستون از قبل وجود دارد */ } }

// مهاجرت تکسونومی حوزه‌ها (احراز صلاحیت واقعی — CAP): رزروهای قدیمیِ «general» به حوزهٔ پایهٔ «tourism»
// می‌روند و تعرفه‌های قدیمی به نقشهٔ پنج‌حوزه‌ای (زیارتی مستقل، «اداری» به تخصص «legal») تبدیل می‌شود.
try {
  db.prepare(`UPDATE translators SET fields = REPLACE(fields, '"general"', '"tourism"') WHERE fields LIKE '%"general"%'`).run();
  db.prepare(`UPDATE reservations SET field = 'tourism' WHERE field = 'general'`).run();
  const tariffRaw = db.prepare("SELECT value FROM settings WHERE key = 'hourly_tariffs'").get();
  const oldTariffs = tariffRaw ? JSON.parse(tariffRaw.value) : null;
  if (oldTariffs && oldTariffs.general !== undefined && oldTariffs.legal === undefined) {
    db.prepare('INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value').run('hourly_tariffs', JSON.stringify({
      tourism: Number(oldTariffs.tourism) || 1350000, pilgrimage: Number(oldTariffs.pilgrimage) || 1400000,
      medical: Number(oldTariffs.medical) || 1685000, business: Number(oldTariffs.business) || 1950000,
      legal: Number(oldTariffs.general) || 1450000,
    }));
  }
} catch (e) { /* پایگاه دادهٔ تازه — نیازی نیست */ }

db.exec(`
CREATE TABLE IF NOT EXISTS change_requests (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  reservation_id INTEGER NOT NULL REFERENCES reservations(id) ON DELETE CASCADE,
  changes TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  expires_at INTEGER NOT NULL,
  created_at INTEGER NOT NULL,
  decided_at INTEGER
);
CREATE TABLE IF NOT EXISTS extension_requests (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  reservation_id INTEGER NOT NULL REFERENCES reservations(id) ON DELETE CASCADE,
  extra_hours INTEGER NOT NULL,
  extra_base INTEGER NOT NULL,
  extra_tax INTEGER NOT NULL,
  extra_net INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  expires_at INTEGER NOT NULL,
  created_at INTEGER NOT NULL,
  decided_at INTEGER
);
`);

// ---------- شهرها، ممیزی و ستون‌های جدید (سند: شهرها از پنل مدیر فعال/غیرفعال می‌شوند) ----------
db.exec(`
CREATE TABLE IF NOT EXISTS cities (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name_fa TEXT NOT NULL UNIQUE,
  name_en TEXT NOT NULL DEFAULT '',
  province TEXT NOT NULL DEFAULT '',
  lat REAL NOT NULL,
  lng REAL NOT NULL,
  radius_km INTEGER NOT NULL DEFAULT 30,
  traveler_enabled INTEGER NOT NULL DEFAULT 1,
  translator_enabled INTEGER NOT NULL DEFAULT 1,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS audit_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  created_at INTEGER NOT NULL,
  action TEXT NOT NULL,
  detail TEXT NOT NULL DEFAULT '{}'
);
`);
for (const sql of [
  'ALTER TABLE reservations ADD COLUMN city_id INTEGER REFERENCES cities(id)',
  'ALTER TABLE translators ADD COLUMN city_id INTEGER REFERENCES cities(id)',
  "ALTER TABLE interview_slots ADD COLUMN note TEXT NOT NULL DEFAULT ''",
  // خط زمانی هر رزرو (بریف آیتم ۴): گذارهای مهم کسب‌وکار برای پیگیری پشتیبانی و حسابرسی
  `CREATE TABLE IF NOT EXISTS reservation_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    reservation_id INTEGER NOT NULL REFERENCES reservations(id) ON DELETE CASCADE,
    event TEXT NOT NULL,
    actor TEXT NOT NULL DEFAULT 'system',
    detail TEXT NOT NULL DEFAULT '{}',
    created_at INTEGER NOT NULL
  )`,
  'CREATE INDEX IF NOT EXISTS idx_reservation_events_rid ON reservation_events(reservation_id, id)',
  // ---------- نسل دوم پنل مدیریت: حساب کارمندان، نشست صاحب‌دار، مسدودسازی و audit با هویت ----------
  `CREATE TABLE IF NOT EXISTS admin_users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL DEFAULT '',
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'ops',
    is_active INTEGER NOT NULL DEFAULT 1,
    created_at INTEGER NOT NULL,
    last_login_at INTEGER
  )`,
  'ALTER TABLE admin_sessions ADD COLUMN admin_user_id INTEGER',
  'ALTER TABLE users ADD COLUMN blocked INTEGER NOT NULL DEFAULT 0',
  'ALTER TABLE audit_log ADD COLUMN actor TEXT',
  'CREATE INDEX IF NOT EXISTS idx_reservations_created ON reservations(created_at)',
  'CREATE INDEX IF NOT EXISTS idx_reservations_traveler ON reservations(traveler_id)',
  'CREATE INDEX IF NOT EXISTS idx_reservations_translator ON reservations(translator_id)',
  'CREATE INDEX IF NOT EXISTS idx_change_requests_status ON change_requests(status, id)',
]) { try { db.exec(sql); } catch (e) { /* ستون از قبل وجود دارد */ } }
// شهرهای نمونه فقط وقتی جدول خالی است؛ مدیر می‌تواند نام و مختصات را تغییر دهد یا غیرفعال کند
const CITY_SEED = [
  ['تهران', 'Tehran', 'تهران', 35.6892, 51.3890],
  ['مشهد', 'Mashhad', 'خراسان رضوی', 36.2605, 59.6168],
  ['اصفهان', 'Isfahan', 'اصفهان', 32.6546, 51.6680],
  ['شیراز', 'Shiraz', 'فارس', 29.5918, 52.5836],
  ['تبریز', 'Tabriz', 'آذربایجان شرقی', 38.0962, 46.2738],
  ['کرج', 'Karaj', 'البرز', 35.8327, 50.9915],
];
if (!db.prepare('SELECT COUNT(*) AS n FROM cities').get().n) {
  const ins = db.prepare('INSERT INTO cities (name_fa, name_en, province, lat, lng, radius_km, created_at, updated_at) VALUES (?, ?, ?, ?, ?, 30, ?, ?)');
  for (const c of CITY_SEED) ins.run(c[0], c[1], c[2], c[3], c[4], Date.now(), Date.now());
}
// وضعیت‌های «باز» رزرو: هنوز مترجم ندارند؛ هنگام غیرفعال‌کردن شهر لغو می‌شوند
const UNMATCHED = ['searching', 'waiting_schedule', 'matching', 'unmatched_ask', 'no_match'];
const UNMATCHED_SQL = UNMATCHED.map((s) => `'${s}'`).join(',');

const now = () => Date.now();
const sha256 = (s) => crypto.createHash('sha256').update(s).digest('hex');
const randomToken = () => crypto.randomBytes(32).toString('base64url');

// ---------- ابزار پاسخ ----------
function send(res, status, body, headers = {}) {
  const data = body === undefined ? '' : JSON.stringify(body);
  res.writeHead(status, Object.assign({ 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' }, headers));
  res.end(data);
}
function readJson(req, limit = 64 * 1024) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on('data', (c) => { size += c.length; if (size > limit) { reject(Object.assign(new Error('payload_too_large'), { status: 413 })); req.destroy(); } else chunks.push(c); });
    req.on('end', () => {
      if (!chunks.length) return resolve({});
      try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8'))); }
      catch (e) { reject(Object.assign(new Error('bad_json'), { status: 400 })); }
    });
    req.on('error', reject);
  });
}

// ---------- اعتبارسنجی ----------
// موبایل ایران: ۹ رقم بعد از ۰ که با ۹ شروع می‌شود (ورودی فارسی/عربی هم پذیرفته می‌شود)
function normalizePhone(raw, role) {
  const ascii = String(raw || '').replace(/[۰-۹]/g, (d) => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d))
    .replace(/[٠-٩]/g, (d) => '٠١٢٣٤٥٦٧٨٩'.indexOf(d));
  const digits = ascii.replace(/\D/g, '');
  // شماره‌ی ایرانی: ۹xxxxxxxxx (هر سه نقش)
  const m = digits.match(/^(?:0098|98|0)?(9\d{9})$/);
  if (m) return m[1];
  // سایر کشورها (فقط مسافر): با علامت + و کد کشور؛ مترجم فقط ایرانی است
  if (role === 'traveler' && /^\s*\+/.test(ascii) && digits.length >= 8 && digits.length <= 15) return '+' + digits;
  return null;
}
const ROLES = new Set(['traveler', 'translator']);
const STATUSES = new Set(['registered', 'in_progress', 'pending_review', 'active_general', 'active_specialized', 'rejected', 'suspended', 'deleted']);

// ---------- نشست ----------
function userTokenOf(req) {
  // پیش‌نمایش ممکن است هدر Authorization را رد کند؛ توکن از X-Auth-Token هم خوانده می‌شود
  const h = req.headers.authorization || '';
  const m = h.match(/^Bearer\s+(.+)$/i);
  return m ? m[1] : (req.headers['x-auth-token'] ? String(req.headers['x-auth-token']).trim() : '');
}
function currentUser(req) {
  const tok = userTokenOf(req);
  if (!tok) return null;
  const row = db.prepare(`SELECT u.id, u.phone, u.role, s.expires_at FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token_hash = ?`).get(sha256(tok));
  if (!row) return null;
  if (row.expires_at < now()) { db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(sha256(tok)); return null; }
  return row;
}
function requireUser(req, res, role) {
  const u = currentUser(req);
  if (!u) { send(res, 401, { error: 'unauthorized' }); return null; }
  if (role && u.role !== role) { send(res, 403, { error: 'forbidden_role' }); return null; }
  return u;
}

// ---------- مسیرهای API ----------
const routes = [];
const route = (method, pattern, handler) => {
  const keys = [];
  const re = new RegExp('^' + pattern.replace(/:(\w+)/g, (_, k) => { keys.push(k); return '([^/]+)'; }) + '$');
  routes.push({ method, pattern, re, keys, handler });
};

route('POST', '/api/auth/request-code', async (req, res) => {
  const ip = clientIp(req);
  const otpGate = RL.otpIp.check(ip);
  if (!otpGate.ok) return send(res, 429, { error: 'too_many_requests', retry_after: otpGate.retryAfter });
  RL.otpIp.fail(ip);
  const body = await readJson(req);
  const phone = normalizePhone(body.phone, body.role);
  if (!phone) return send(res, 400, { error: 'invalid_phone' });
  if (!ROLES.has(body.role)) return send(res, 400, { error: 'invalid_role' });
  const prev = db.prepare('SELECT created_at, locked_until FROM otp_codes WHERE phone = ? AND role = ?').get(phone, body.role);
  if (prev && prev.locked_until && prev.locked_until > now()) {
    return send(res, 423, { error: 'locked', retry_after: Math.ceil((prev.locked_until - now()) / 1000) });
  }
  if (prev && now() - prev.created_at < CONFIG.OTP_RESEND_SEC * 1000) {
    return send(res, 429, { error: 'resend_wait', retry_after: Math.ceil((prev.created_at + CONFIG.OTP_RESEND_SEC * 1000 - now()) / 1000) });
  }
  let code;
  if (DEV) code = CONFIG.DEV_CODE;
  else {
    if (!SMS.configured) return send(res, 503, { error: 'sms_provider_not_configured' });
    // کد تصادفی واقعی فقط وقتی ساخته و ارسال می‌شود که پیامک‌دهنده وصل باشد؛ اول ارسال، بعد ذخیره‌ی هش.
    code = String(crypto.randomInt(100000, 1000000));
    try { await SMS.send(phone, code); }
    catch (e) {
      console.error('[sms]', e && e.message ? e.message : e);
      return send(res, 503, { error: e && e.code === 'unsupported_phone' ? 'sms_unsupported_phone' : 'sms_send_failed' });
    }
  }
  db.prepare(`INSERT INTO otp_codes (phone, role, code_hash, expires_at, created_at, attempts, locked_until)
              VALUES (?, ?, ?, ?, ?, 0, NULL)
              ON CONFLICT(phone, role) DO UPDATE SET code_hash = excluded.code_hash, expires_at = excluded.expires_at,
              created_at = excluded.created_at, attempts = 0, locked_until = NULL`)
    .run(phone, body.role, sha256(phone + ':' + body.role + ':' + code), now() + CONFIG.OTP_TTL_SEC * 1000, now());
  send(res, 200, { ok: true, expires_in: CONFIG.OTP_TTL_SEC, resend_in: CONFIG.OTP_RESEND_SEC });
});

route('POST', '/api/auth/verify', async (req, res) => {
  const ip = clientIp(req);
  const vGate = RL.verifyFail.check(ip);
  if (!vGate.ok) return send(res, 429, { error: 'too_many_attempts', retry_after: vGate.retryAfter });
  const body = await readJson(req);
  const phone = normalizePhone(body.phone, body.role);
  if (!phone || !ROLES.has(body.role)) return send(res, 400, { error: 'invalid_input' });
  const code = String(body.code || '').replace(/[۰-۹]/g, (d) => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d)).replace(/\D/g, '');
  const row = db.prepare('SELECT * FROM otp_codes WHERE phone = ? AND role = ?').get(phone, body.role);
  if (!row) return send(res, 400, { error: 'no_code_requested' });
  if (row.locked_until && row.locked_until > now()) return send(res, 423, { error: 'locked', retry_after: Math.ceil((row.locked_until - now()) / 1000) });
  if (row.expires_at < now()) return send(res, 410, { error: 'code_expired' });
  if (sha256(phone + ':' + body.role + ':' + code) !== row.code_hash) {
    const attempts = row.attempts + 1;
    if (attempts >= CONFIG.OTP_MAX_ATTEMPTS) {
      db.prepare('UPDATE otp_codes SET attempts = 0, locked_until = ? WHERE phone = ? AND role = ?').run(now() + CONFIG.OTP_LOCK_SEC * 1000, phone, body.role);
      return send(res, 423, { error: 'locked', retry_after: CONFIG.OTP_LOCK_SEC });
    }
    db.prepare('UPDATE otp_codes SET attempts = ? WHERE phone = ? AND role = ?').run(attempts, phone, body.role);
    RL.verifyFail.fail(ip);
    return send(res, 401, { error: 'wrong_code', attempts_left: CONFIG.OTP_MAX_ATTEMPTS - attempts });
  }
  db.prepare('DELETE FROM otp_codes WHERE phone = ? AND role = ?').run(phone, body.role);
  // ورود موفق شمارندهٔ شکست‌های IP را صفر می‌کند تا تایپ اشتباه کاربر واقعی،
  // سقف شکست را برای ده دقیقه مسموم نگذارد (یافتهٔ ۱۰)
  RL.verifyFail.reset(ip);
  db.prepare('INSERT OR IGNORE INTO users (phone, role, created_at) VALUES (?, ?, ?)').run(phone, body.role, now());
  const user = db.prepare('SELECT id, phone, role FROM users WHERE phone = ? AND role = ?').get(phone, body.role);
  if (user.role === 'translator') db.prepare('INSERT OR IGNORE INTO translators (user_id, status, updated_at) VALUES (?, ?, ?)').run(user.id, 'registered', now());
  const token = randomToken();
  db.prepare('INSERT INTO sessions (token_hash, user_id, expires_at) VALUES (?, ?, ?)').run(sha256(token), user.id, now() + CONFIG.SESSION_HOURS * 3600 * 1000);
  send(res, 200, { token, user: { id: user.id, role: user.role, phone: user.phone }, expires_in: CONFIG.SESSION_HOURS * 3600 });
});

// ---------- اعلان فوری: اشتراک مرورگر (Web Push) ----------
// کلید عمومی VAPID برای pushManager.subscribe (کاربر واردشده)
route('GET', '/api/push/vapid', async (req, res) => {
  const u = currentUser(req);
  if (!u) return send(res, 401, { error: 'unauthorized' });
  const d = vapidDetails();
  if (!webpush || !d) return send(res, 503, { error: 'push_disabled' });
  send(res, 200, { publicKey: d.publicKey });
});
// ثبت/به‌روزرسانی اشتراک — endpoint کلید یکتایی است؛ سقف ۸ اشتراک برای هر کاربر
route('POST', '/api/push/subscribe', async (req, res) => {
  const u = currentUser(req);
  if (!u) return send(res, 401, { error: 'unauthorized' });
  const b = await readJson(req).catch(() => null);
  const endpoint = b && clip(String(b.endpoint || ''), 500);
  const p256dh = b && b.keys && clip(String(b.keys.p256dh || ''), 200);
  const auth = b && b.keys && clip(String(b.keys.auth || ''), 100);
  if (!endpoint || !/^https:\/\//.test(endpoint) || !p256dh || !auth) return send(res, 400, { error: 'invalid_subscription' });
  db.prepare(`INSERT INTO push_subscriptions (user_id, role, endpoint, p256dh, auth, user_agent, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(endpoint) DO UPDATE SET user_id = excluded.user_id, role = excluded.role,
      p256dh = excluded.p256dh, auth = excluded.auth, user_agent = excluded.user_agent, last_error = NULL`)
    .run(u.id, u.role, endpoint, p256dh, auth, clip(String(req.headers['user-agent'] || ''), 200), now());
  // سقف تعداد: قدیمی‌ترین‌های اضافی حذف می‌شوند
  db.prepare(`DELETE FROM push_subscriptions WHERE user_id = ? AND id NOT IN
    (SELECT id FROM push_subscriptions WHERE user_id = ? ORDER BY id DESC LIMIT 8)`).run(u.id, u.id);
  audit('push.subscribe', { uid: u.id });
  send(res, 200, { ok: true });
});
// حذف اشتراک (خروج از حساب یا لغو اجازه)
route('POST', '/api/push/unsubscribe', async (req, res) => {
  const u = currentUser(req);
  if (!u) return send(res, 401, { error: 'unauthorized' });
  const b = await readJson(req).catch(() => ({}));
  const endpoint = b && clip(String(b.endpoint || ''), 500);
  if (!endpoint) return send(res, 400, { error: 'invalid_endpoint' });
  db.prepare('DELETE FROM push_subscriptions WHERE user_id = ? AND endpoint = ?').run(u.id, endpoint);
  send(res, 200, { ok: true });
});

// پرچم محیط: فقط برای نمایش دکمه‌ی آزمایشی در اپ مترجم. کد ثابت به کلاینت داده نمی‌شود.
route('GET', '/api/config', async (req, res) => {
  send(res, 200, { dev: DEV, payments: { CASH: PAYMENTS.CASH, ONLINE: PAYMENTS.ONLINE, provider: gatewayProvider() }, charter_text: getSetting('charter_text'),
    translator_terms_text: getSetting('translator_terms_text'), translator_nda_text: getSetting('translator_nda_text'),
    translator_help_text: getSetting('translator_help_text'), traveler_terms_text: getSetting('traveler_terms_text'), support_phone: getSetting('support_phone'),
    tariffs: { hourly: getJsonSetting('hourly_tariffs'), car_fee_per_hour: getSetting('car_fee_per_hour'),
      tax_percent: getSetting('tax_percent'), cancel_fee_percent: getSetting('cancel_fee_percent') },
    language_pairs: getJsonSetting('language_pairs').filter((x) => x.enabled),
    features: featuresNow(),
    cities: db.prepare('SELECT id, name_fa, name_en, lat, lng FROM cities WHERE traveler_enabled = 1 ORDER BY id').all(),
    translator_cities: db.prepare('SELECT id, name_fa, name_en FROM cities WHERE translator_enabled = 1 ORDER BY id').all(),
    default_city_id: defaultCityId() });
});

route('GET', '/api/auth/me', async (req, res) => {
  const u = requireUser(req, res);
  if (!u) return;
  send(res, 200, { id: u.id, role: u.role, phone: u.phone });
});

// Idempotent single-device logout; use the same header rules as authentication.
route('POST', '/api/auth/logout', async (req, res) => {
  const tok = userTokenOf(req);
  if (tok) db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(sha256(tok));
  send(res, 200, { ok: true });
});

// Only the authenticated account may revoke its sessions. Never accept a target ID.
route('POST', '/api/auth/logout-all', async (req, res) => {
  const u = requireUser(req, res); if (!u) return;
  db.prepare('DELETE FROM sessions WHERE user_id = ?').run(u.id);
  send(res, 200, { ok: true });
});

// حذف حساب کاربر (مسافر یا مترجم): وقتی کارِ باز ندارد، حساب و داده‌هایش واقعاً از پایگاه داده پاک می‌شود.
// رزروِ باز یعنی در جستجو/تطبیق/تطبیق‌یافته، یا پایان‌یافته‌ای که هنوز تسویه نشده است؛ پیشنهادِ باز مترجم هم باز محسوب می‌شود.
// سابقه‌ی رزروهای تمام‌شده‌ی مترجمِ حذف‌شده بی‌نام نگه داشته می‌شود تا حساب‌وکتاب مالی به هم نریزد؛ نوبت مصاحبه‌ی گرفته‌شده آزاد می‌شود.
route('DELETE', '/api/auth/account', async (req, res) => {
  const u = requireUser(req, res); if (!u) return;
  const ACTIVE = "('searching','waiting_schedule','matching','unmatched_ask','matched')";
  // «refunded» هم بسته‌شده است: پس از تصمیم مدیر، پروندهٔ مالی این رزرو تمام شده و جلوی حذف حساب را نمی‌گیرد.
  const openAsTraveler = db.prepare(`SELECT COUNT(*) AS n FROM reservations WHERE traveler_id = ? AND (status IN ${ACTIVE} OR (status = 'finished' AND (pay_state IS NULL OR pay_state NOT IN ('settled','refunded'))))`).get(u.id).n;
  const openAsTranslator = db.prepare(`SELECT COUNT(*) AS n FROM reservations WHERE translator_id = ? AND (status IN ${ACTIVE} OR (status = 'finished' AND (pay_state IS NULL OR pay_state NOT IN ('settled','refunded'))))`).get(u.id).n;
  const openOffers = db.prepare("SELECT COUNT(*) AS n FROM offers WHERE translator_id = ? AND status = 'pending'").get(u.id).n;
  if (openAsTraveler + openAsTranslator + openOffers > 0) return send(res, 409, { error: 'active_items' });
  db.transaction(() => {
    db.prepare('UPDATE reservations SET translator_id = NULL, translator_arrived_at = NULL WHERE translator_id = ?').run(u.id);
    db.prepare("UPDATE interview_slots SET booked_user_id = NULL, status = 'open' WHERE booked_user_id = ? AND status = 'booked'").run(u.id);
    db.prepare('DELETE FROM users WHERE id = ?').run(u.id);
  })();
  audit('account.delete', { role: u.role });
  send(res, 200, { ok: true });
});

route('GET', '/api/translator/status', async (req, res) => {
  const u = requireUser(req, res, 'translator'); if (!u) return;
  const t = db.prepare('SELECT status FROM translators WHERE user_id = ?').get(u.id);
  send(res, 200, { status: t ? t.status : 'registered' });
});

// وضعیت چهار بُعد صلاحیت مترجم، از روی مدارک و ثبت‌نام واقعی (نه متن ثابت)
// نوبت‌های مصاحبه: فقط زمان‌های آزاد واقعی سامانه (سند ۵). مدیر نوبت می‌سازد.
route('GET', '/api/admin/interview-slots', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  const rows = db.prepare(`SELECT s.id, s.starts_at, s.status, s.booked_user_id, u.phone AS phone
    FROM interview_slots s LEFT JOIN users u ON u.id = s.booked_user_id
    WHERE s.starts_at > ? OR s.status = 'booked' ORDER BY s.starts_at LIMIT 200`).all(now() - INTERVIEW_MIN * 60000);
  send(res, 200, { slots: rows.map((r) => ({ id: r.id, starts_at: new Date(r.starts_at).toISOString(), status: r.status, booked_user_id: r.booked_user_id, phone: r.phone || null })) });
});

route('POST', '/api/admin/interview-slots', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  if (!requirePerm(req, res, 'interviews.manage')) return;
  const b = await readJson(req);
  const at = typeof b.starts_at === 'string' || typeof b.starts_at === 'number' ? new Date(b.starts_at).getTime() : NaN;
  if (!Number.isFinite(at)) return send(res, 400, { error: 'invalid_time' });
  if (at <= now()) return send(res, 400, { error: 'time_in_past' });
  const note = typeof b.note === 'string' ? b.note.trim().slice(0, 300) : '';
  const r = db.prepare("INSERT INTO interview_slots (starts_at, status, created_at, note) VALUES (?, 'open', ?, ?)").run(at, now(), note);
  audit('interview.slot_create', { id: Number(r.lastInsertRowid) });
  send(res, 201, { ok: true, id: Number(r.lastInsertRowid) });
});

// عدم حضور: نوبت آزاد می‌شود و مترجم می‌تواند دوباره نوبت بگیرد (سند ۵)
route('POST', '/api/admin/interview-slots/:id/no-show', async (req, res, url, params) => {
  if (!requireAdmin(req, res)) return;
  if (!requirePerm(req, res, 'interviews.manage')) return;
  const id = parseId(params.id);
  const sl = id && db.prepare("SELECT id, status FROM interview_slots WHERE id = ?").get(id);
  if (!sl) return send(res, 404, { error: 'not_found' });
  if (sl.status !== 'booked') return send(res, 409, { error: 'not_booked', status: sl.status });
  db.prepare("UPDATE interview_slots SET status = 'no_show' WHERE id = ?").run(id);
  send(res, 200, { ok: true, status: 'no_show' });
});

// مترجم: نوبت‌های آزاد و نوبت فعلی خودش
route('GET', '/api/translator/interview-slots', async (req, res) => {
  const u = requireUser(req, res, 'translator'); if (!u) return;
  const t = now();
  const slots = db.prepare("SELECT id, starts_at FROM interview_slots WHERE status = 'open' AND starts_at > ? ORDER BY starts_at LIMIT 50").all(t);
  const mine = db.prepare("SELECT id, starts_at, note FROM interview_slots WHERE status = 'booked' AND booked_user_id = ? AND starts_at > ? ORDER BY starts_at LIMIT 1")
    .get(u.id, t - INTERVIEW_MIN * 60000);
  send(res, 200, { slots: slots.map((s) => ({ id: s.id, starts_at: new Date(s.starts_at).toISOString() })),
    booking: mine ? { id: mine.id, starts_at: new Date(mine.starts_at).toISOString(), note: mine.note || '' } : null });
});

route('POST', '/api/translator/interview-slots/:id/book', async (req, res, url, params) => {
  const u = requireUser(req, res, 'translator'); if (!u) return;
  if (!requireFeature(res, 'interview_scheduling')) return;
  const id = parseId(params.id);
  const t = db.prepare('SELECT langs, interview FROM translators WHERE user_id = ?').get(u.id);
  if (!t) return send(res, 404, { error: 'not_found' });
  if (JSON.parse(t.langs || '[]').length === 0) return send(res, 409, { error: 'languages_required' });
  if (t.interview === 'pass') return send(res, 409, { error: 'already_passed' });
  const mine = db.prepare("SELECT id FROM interview_slots WHERE status = 'booked' AND booked_user_id = ? AND starts_at > ?").get(u.id, now() - INTERVIEW_MIN * 60000);
  if (mine) return send(res, 409, { error: 'already_booked' });
  const sl = id && db.prepare('SELECT id, starts_at, status FROM interview_slots WHERE id = ?').get(id);
  if (!sl) return send(res, 404, { error: 'not_found' });
  if (sl.status !== 'open') return send(res, 409, { error: 'slot_taken' });
  if (sl.starts_at <= now()) return send(res, 409, { error: 'slot_past' });
  const r = db.prepare("UPDATE interview_slots SET status = 'booked', booked_user_id = ? WHERE id = ? AND status = 'open'").run(u.id, id);
  if (r.changes !== 1) return send(res, 409, { error: 'slot_taken' });
  send(res, 200, { ok: true, id, starts_at: new Date(sl.starts_at).toISOString() });
});

route('GET', '/api/translator/notifications', async (req, res) => {
  const u = requireUser(req, res, 'translator'); if (!u) return;
  sweep();
  const rows = db.prepare(`SELECT n.id, n.kind, n.ref, n.created_at, d.kind AS doc_kind FROM translator_notifications n
    LEFT JOIN translator_documents d ON d.id = n.doc_id WHERE n.user_id = ? ORDER BY n.id DESC LIMIT 20`).all(u.id);
  send(res, 200, { notifications: rows.map((r) => ({ id: r.id, kind: r.kind, doc_kind: r.doc_kind,
    doc_name: DOC_NAME_FA[r.doc_kind] || r.doc_kind || '', created_at: new Date(r.created_at).toISOString(),
    text: r.kind === 'custom' ? (r.ref || 'پیام از پشتیبانی')
      : r.kind === 'debt_new' ? 'بدهی سهم پلتفرم بابت رزرو نقدی #' + (r.ref || '') + ' ثبت شد؛ تا تسویه، درخواست جدیدی نمی‌بینید. از بخش مالی میز کار پیگیری کنید.'
      : r.kind === 'debt_paid' ? 'پرداخت بدهی به مبلغ ' + (r.ref || '') + ' تومان ثبت شد؛ باقیمانده را از بخش مالی ببینید.'
      : r.kind === 'booking_cancelled' ? 'مسافر، رزرو را لغو کرد؛ این ماموریت از فهرست شما حذف شد و طبق قوانین، کارمزد لغو بعد از تطبیق اعمال می‌شود.'
      : r.kind === 'doc_rejected' ? 'مدرک «' + (DOC_NAME_FA[r.doc_kind] || r.doc_kind || '') + '» رد شد: ' + (r.ref || 'بدون دلیل') + '. مدرک اصلاح‌شده ارسال کنید.'
      : r.kind === 'expired' ? 'اعتبار مدرک شما تمام شده است؛ مدرک جدید ارسال کنید.'
      : r.kind === 'interview_reminder' ? 'یادآوری مصاحبه‌ی زبان: زمان و هماهنگی نوبت را در بخش مصاحبه ببینید.'
      : 'اعتبار مدرک شما ۳۰ روز دیگر یا کمتر تمام می‌شود.' })) });
});

route('GET', '/api/translator/capability', async (req, res) => {
  const u = requireUser(req, res, 'translator'); if (!u) return;
  const t = db.prepare('SELECT user_id, status, langs, fields, profile, interview FROM translators WHERE user_id = ?').get(u.id);
  if (!t) return send(res, 200, { status: 'registered', dimensions: null, ladder: null });
  const approved = new Set(db.prepare(`SELECT kind FROM translator_documents WHERE user_id = ? AND status = 'approved'
    AND (expires_at IS NULL OR expires_at >= ?)`).all(u.id, now()).map((r) => r.kind));
  const profile = JSON.parse(t.profile || '{}');
  const IDENTITY = ['nid_card', 'selfie', 'address_proof', 'drug_free', 'criminal_record'];
  const identityMissing = IDENTITY.filter((k) => !approved.has(k));
  const langsOk = JSON.parse(t.langs || '[]').length > 0 && !['registered', 'in_progress'].includes(t.status);
  const cert = langCertOk({ user_id: u.id }); // ردیف SELECT شده user_id ندارد؛ از نشست مترجم می‌آید
  const selected = JSON.parse(t.fields || '[]').map((f) => FIELD_ALIAS[f] || f);
  // مدارک در انتظار بررسی: برای پیام «ارسال شد، منتظر تأیید» به‌جای «ارسال نکنید»
  const pendingOf = (kind) => !!db.prepare("SELECT 1 FROM translator_documents WHERE user_id = ? AND kind = ? AND status = 'pending'").get(u.id, kind);
  // نردبان گیت‌ها: هر حوزه با «انتخاب‌شده» و «باز» — پایه با انتخاب باز می‌شود، تخصص با مدرک زبان
  const ladder = {
    workspace: String(t.status || '').indexOf('active_') === 0,
    interview: t.interview || null,
    lang_cert: cert,
    car_ready: carReady(t, 1),
    fields: FIELDS_ORDER.map((f) => ({ code: f, base: BASE_FIELDS.has(f),
      selected: selected.includes(f), active: selected.includes(f) && (BASE_FIELDS.has(f) || cert) })),
  };
  send(res, 200, { status: t.status, pending_docs: { lang_cert: pendingOf('lang_cert'), car_docs: pendingOf('car_docs'), licence: pendingOf('licence') }, dimensions: {
    identity: { ok: identityMissing.length === 0, missing: identityMissing },
    language: { ok: langsOk && t.interview === 'pass', langs: JSON.parse(t.langs || '[]'), interview: t.interview || null },
    car: { registered: profile.car === true, active: carReady(t, 1), model: profile.car_model || '', capacity: profile.car_capacity || null },
    specialized: { ok: cert, gate: 'lang_cert' },
  }, ladder });
});

// فقط در حالت توسعه: همه‌ی مترجمان آفلاین شوند تا تست‌ها به مترجم‌های باقی‌مانده وابسته نباشند
route('POST', '/api/dev/offline-all', async (req, res) => {
  if (!DEV) return send(res, 404, { error: 'not_found' });
  db.prepare('UPDATE translators SET online = 0').run();
  // رزروهای جستجوی باقی‌مانده از تست‌های قبلی هم بسته شوند تا پیشنهادها را ندزدند
  db.prepare("UPDATE reservations SET status = 'cancelled', updated_at = ? WHERE status IN ('searching','waiting_schedule','matching','unmatched_ask','no_match')").run(now());
  db.prepare("UPDATE offers SET status = 'expired', decided_at = ? WHERE status = 'pending'").run(now());
  send(res, 200, { ok: true });
});

// فقط در حالت توسعه: شبیه‌سازی تأیید کارشناس انسانی (سند ۷.۳)
// فقط حالت توسعه: همه‌ی مدارک این مترجم را منقضی می‌کند (برای تست خاموش شدن حالت خودرو)
route('POST', '/api/dev/expire-docs', async (req, res) => {
  if (!DEV) return send(res, 404, { error: 'not_found' });
  const u = requireUser(req, res, 'translator'); if (!u) return;
  db.prepare('UPDATE translator_documents SET expires_at = ? WHERE user_id = ?').run(now() - DAY_MS, u.id);
  send(res, 200, { ok: true });
});

// فقط حالت توسعه: شبیه‌سازی گذر زمان خدمت برای تست صورت‌حسابِ پایان زودهنگام
route('POST', '/api/dev/shift-service-start', async (req, res) => {
  if (!DEV) return send(res, 404, { error: 'not_found' });
  const u = requireUser(req, res, 'traveler'); if (!u) return;
  const b = await readJson(req);
  const id = parseId(b.reservation_id);
  const r = id && db.prepare('SELECT id FROM reservations WHERE id = ? AND traveler_id = ? AND service_started_at IS NOT NULL').get(id, u.id);
  if (!r) return send(res, 404, { error: 'not_found' });
  const minutes = Math.max(0, Math.min(Number(b.minutes_ago) || 0, 60 * 24 * 7));
  db.prepare('UPDATE reservations SET service_started_at = service_started_at - ? WHERE id = ?').run(minutes * 60000, id);
  send(res, 200, { ok: true });
});

route('POST', '/api/dev/approve-translator', async (req, res) => {
  if (!DEV) return send(res, 404, { error: 'not_found' });
  const u = requireUser(req, res, 'translator'); if (!u) return;
  const b = await readJson(req).catch(() => ({}));
  // اصلاح باگ گزارش کاربر: این مسیر قبلاً همهٔ ۵ حوزه را روی انتخاب مترجم می‌کوبید و مدرک زبان را هم خودجوش تأیید می‌کرد؛
  // اکنون انتخابِ خودِ مترجم از ثبت‌نام حفظ می‌شود و فقط با آرگومان صریح بازنویسی/باز می‌شود (برای تست‌ها).
  let fieldsSql = null;
  if (Array.isArray(b.fields)) {
    const wanted = pick(b.fields.map((f) => FIELD_ALIAS[f] || f), REG_FIELDS);
    if (wanted.length) fieldsSql = JSON.stringify(wanted);
  }
  const existing = db.prepare('SELECT user_id FROM translators WHERE user_id = ?').get(u.id);
  if (!existing) {
    db.prepare(`INSERT INTO translators (user_id, status, fields, interview, updated_at) VALUES (?, 'active_general', ?, 'pass', ?)`)
      .run(u.id, fieldsSql || '["tourism","pilgrimage"]', now());
  } else {
    db.prepare(`UPDATE translators SET status = CASE WHEN status LIKE 'active_%' THEN status ELSE 'active_general' END,
        interview = CASE WHEN interview = 'pass' THEN interview ELSE 'pass' END,
        fields = COALESCE(?, fields), updated_at = ? WHERE user_id = ?`).run(fieldsSql, now(), u.id);
  }
  // گیت تخصص (مدرک زبان) فقط با درخواست صریح بدنه باز می‌شود — نه خودجوش
  if (b.lang_cert === true && !db.prepare("SELECT 1 FROM translator_documents WHERE user_id = ? AND kind = 'lang_cert' AND status = 'approved'").get(u.id)) {
    db.prepare(`INSERT INTO translator_documents (user_id, kind, status, mime, size, blob, created_at, updated_at)
                VALUES (?, 'lang_cert', 'approved', 'application/pdf', 4, ?, ?, ?)`).run(u.id, encryptDoc(Buffer.from('%PDF-')), now(), now());
  }
  db.prepare('UPDATE translators SET city_id = COALESCE(city_id, ?) WHERE user_id = ?').run(defaultCityId(), u.id);
  const t = db.prepare('SELECT status FROM translators WHERE user_id = ?').get(u.id);
  send(res, 200, { status: t.status });
});


// فقط در حالت توسعه: افزودن ماموریت آزمایشی برای مترجم فعال
route('POST', '/api/dev/missions', async (req, res) => {
  if (!DEV) return send(res, 404, { error: 'not_found' });
  const u = requireUser(req, res, 'translator'); if (!u) return;
  const b = await readJson(req);
  const startAt = Date.parse(b.startAt);
  if (!b.code || !Number.isFinite(startAt)) return send(res, 400, { error: 'invalid_mission' });
  const info = db.prepare(`INSERT INTO missions (translator_id, code, purpose, traveler_name, place, start_at, total, net, status)
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`)
    .run(u.id, String(b.code), String(b.purpose || ''), String(b.travelerName || ''), String(b.place || ''), startAt,
      Number(b.total || 0), Number(b.net || 0), b.status === 'pending_invite' ? 'pending_invite' : 'accepted');
  send(res, 201, { id: info.lastInsertRowid });
});



// ---------- فایل‌های استاتیک ----------
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.json': 'application/json', '.webmanifest': 'application/manifest+json', '.svg': 'image/svg+xml', '.png': 'image/png',
  '.jpg': 'image/jpeg', '.woff2': 'font/woff2', '.woff': 'font/woff', '.ttf': 'font/ttf', '.map': 'application/json' };

function serveStatic(req, res, pathname) {
  for (const prefix of Object.keys(STATIC_ROOTS)) {
    if (!pathname.startsWith(prefix)) continue;
    const decoded = safeDecode(pathname.slice(prefix.length));
    // ورودی بدفرم یا دارای بایت صفر: ۴۰۰ به‌جای کرش (safeDecode) و به‌جای خطای fs.stat
    if (decoded === null || decoded.includes('\0')) { res.writeHead(400, { 'Content-Type': 'text/plain; charset=utf-8' }); return res.end('bad request'); }
    let rel = decoded;
    if (rel === '' || rel.endsWith('/')) rel += 'index.html';
    const root = STATIC_ROOTS[prefix];
    const file = path.normalize(path.join(root, rel));
    if (!file.startsWith(root + path.sep)) { res.writeHead(403); return res.end('forbidden'); }
    fs.stat(file, (err, st) => {
      if (err || !st.isFile()) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); return res.end('not found'); }
      // اعتبارسنجی مشروط با ETag (یافتهٔ ۱۳): به‌جای ارسال کامل فایل در هر درخواست با no-cache،
      // نسخهٔ تغییرنکرده با ۳۰۴ و بدون بدنه پاسخ می‌گیرد؛ تازگی مثل قبل تضمین می‌شود.
      const etag = '"' + st.size.toString(36) + '-' + Math.round(st.mtimeMs).toString(36) + '"';
      const baseHeaders = { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-cache', 'ETag': etag };
      if (req.headers['if-none-match'] === etag) { res.writeHead(304, baseHeaders); return res.end(); }
      res.writeHead(200, baseHeaders);
      fs.createReadStream(file).pipe(res);
    });
    return;
  }
  if (pathname === '/') {
    const page = `<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>همراه — انتخاب بخش</title>
<style>body{font-family:system-ui,sans-serif;background:#eef2f6;margin:0;padding:24px;color:#161c23}h1{font-size:20px}
.g{display:grid;gap:12px;max-width:420px}a{display:block;padding:16px;border-radius:14px;background:#006a61;color:#fff;text-decoration:none;font-weight:bold}
a.s{background:#005182}p{font-size:13px;color:#555}</style></head><body>
<h1>همراه — انتخاب بخش</h1>
<div class="g">
<a href="/traveler/index.html">اپ مسافر</a>
<a class="s" href="/translator/index.html">اپ مترجم</a>
<a href="/admin/index.html">پنل مدیر</a>
</div>
<p>پنل مدیر فقط از طریق همین سرور باز می‌شود.</p>
</body></html>`;
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' }); return res.end(page);
  }
  res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); res.end('not found');
}

// ---------- سرور ----------
// ---------- زمان‌بندی و مبالغ (مقدار نمونه؛ تعرفه و مهلت‌ها در پنل مدیریت تعیین می‌شوند) ----------
const SCALE = Number(process.env.HZ_TIME_SCALE) || 1; // فقط برای تست سریع (مثلاً 0.01)
const TIMING = {
  OFFER_MS: 60 * 1000 * SCALE,                    // مهلت پذیرش مترجم
  INSTANT_SEARCH_MS: 10 * 60 * 1000 * SCALE,      // سقف جستجوی فوری
  SCHEDULE_MIN_LEAD_MS: 2 * 3600 * 1000 * SCALE,  // حداقل فاصله‌ی رزرو زمان‌دار تا قرار
  SCHEDULE_MATCH_BEFORE_MS: 60 * 60 * 1000 * SCALE, // شروع تطبیق یک ساعت قبل
  SCHEDULE_ASK_BEFORE_MS: 15 * 60 * 1000 * SCALE,   // پرسش «تلاش دوباره یا لغو؟»
};
// ---------- تنظیمات قابل تغییر (پنل ادمین) ----------
// فقط مقادیری که مدیر به‌طور منظم تغییر می‌دهد اینجا هستند. مقادیر ثابت (مثل مهلت‌های ۶۰ ثانیه و ۱۰ دقیقه) در کد می‌مانند.
const SETTING_DEFS = {
  translator_share_percent: { v: 80, type: 'int', min: 0, max: 100, label: 'سهم مترجم از خدمت (٪)' },
  cancel_fee_percent: { v: 20, type: 'int', min: 0, max: 100, label: 'کارمزد لغو بعد از تطبیق (٪)' },
  tax_percent: { v: 0, type: 'int', min: 0, max: 100, label: 'نرخ مالیات (٪) — هنوز تعیین نشده' },
  cash_enabled: { v: 1, type: 'bool', label: 'پرداخت نقدی فعال باشد' },
  online_enabled: { v: 0, type: 'bool', label: 'پرداخت آنلاین فعال باشد' },
  payment_provider: { v: 'instant', type: 'enum', values: ['instant', 'simulated', 'zarinpal'], label: 'روش پرداخت آنلاین: instant تسویهٔ فوری (تا راه‌اندازی درگاه)، simulated درگاه شبیه‌سازی‌شدهٔ داخلی، zarinpal درگاه واقعی زرین‌پال' },
  zarinpal_merchant_id: { v: '', type: 'text', max: 64, label: 'شناسهٔ پذیرندهٔ زرین‌پال (UUID) — برای حالت zarinpal الزامی است' },
  zarinpal_sandbox: { v: 1, type: 'bool', label: 'زرین‌پال سندباکس باشد (محیط آزمایشی؛ خاموش = پرداخت واقعی)' },
  payment_callback_base: { v: '', type: 'text', max: 200, label: 'آدرس پایهٔ بازگشت درگاه (مثل https://hamrah.example) — خالی = دامنهٔ خود سرور' },
  default_city_id: { v: 1, type: 'int', min: 1, max: 1000000000, label: 'شهر پیش‌فرض (وقتی اپ شهری نمی‌فرستد)' },
  settlement_period: { v: 'daily', type: 'enum', values: ['daily', 'weekly'], label: 'دوره‌ی تسویه با شبا' },
  translator_terms_text: { v: '', type: 'text', max: 20000, label: 'متن شرایط همکاری مترجم (گام ۱)' },
  translator_nda_text: { v: '', type: 'text', max: 20000, label: 'متن تعهدنامه‌ی محرمانگی (NDA) مترجم (گام ۵)' },
  charter_text: { v: '', type: 'text', max: 20000, label: 'متن منشور اخلاقی مترجم (گام ۵، ضمیمه‌ی تعهدنامه)' },
  translator_help_text: { v: '', type: 'text', max: 20000, label: 'متن راهنمای مترجم (دکمه‌ی راهنما و پشتیبانی)' },
  support_phone: { v: '', type: 'text', max: 100, label: 'شماره‌ی تلفن پشتیبانی (مسافر و مترجم)' },
  traveler_terms_text: { v: '', type: 'text', max: 20000, label: 'متن قوانین و ضوابط همراهی تشریفاتی (اپ مسافر)' },
  car_fee_per_hour: { v: 350000, type: 'int', min: 0, max: 100000000000, label: 'هزینه‌ی خودرو در هر ساعت (تومان)' },
  hourly_tariffs: { v: '{"tourism":1350000,"pilgrimage":1400000,"medical":1685000,"business":1950000,"legal":1450000}', type: 'json', max: 2000,
    label: 'تعرفه‌ی ساعتی هر حوزه (تومان): tourism, pilgrimage, medical, business, legal',
    validate: (o) => {
      if (!o || typeof o !== 'object' || Array.isArray(o)) return null;
      const out = {};
      for (const k of ['tourism', 'pilgrimage', 'medical', 'business', 'legal']) {
        const n = Number(o[k]);
        if (!Number.isInteger(n) || n < 0 || n > 1e11) return null;
        out[k] = n;
      }
      return out;
    } },
  language_pairs: { v: '[{"code":"ar-fa","label":"عربی ⟷ فارسی","note":"خلیجی، عراقی و فصیح","langs":["ar","fa"],"enabled":true},{"code":"en-fa","label":"انگلیسی ⟷ فارسی","note":"مکالمه‌ی تخصصی و اداری","langs":["en","fa"],"enabled":true},{"code":"tr-fa","label":"ترکی استانبولی ⟷ فارسی","note":"","langs":["tr","fa"],"enabled":true},{"code":"fr-fa","label":"فرانسوی ⟷ فارسی","note":"","langs":["fr","fa"],"enabled":true},{"code":"ru-fa","label":"روسی ⟷ فارسی","note":"","langs":["ru","fa"],"enabled":true},{"code":"zh-fa","label":"چینی ماندارین ⟷ فارسی","note":"","langs":["zh","fa"],"enabled":true}]', type: 'json', max: 20000,
    label: 'جفت‌زبان‌های ثبت‌نام مترجم (کد، برچسب، توضیح، دو زبان، فعال یا غیرفعال)',
    validate: (a) => {
      if (!Array.isArray(a) || a.length < 1 || a.length > 12) return null;
      const seen = new Set(); const out = [];
      for (const x of a) {
        if (!x || typeof x !== 'object') return null;
        const code = String(x.code || '').trim();
        const label = String(x.label || '').trim();
        const note = String(x.note || '').trim();
        if (!/^[a-z]{2}-[a-z]{2}$/.test(code) || seen.has(code) || !label || label.length > 60 || note.length > 120) return null;
        if (!Array.isArray(x.langs) || x.langs.length !== 2 || x.langs[0] === x.langs[1]) return null;
        if (!x.langs.every((l) => LANG_CODES.includes(l))) return null;
        if (typeof x.enabled !== 'boolean') return null;
        seen.add(code);
        out.push({ code, label, note, langs: x.langs.slice(), enabled: x.enabled });
      }
      return out;
    } },
};
const LANG_CODES = ['fa', 'ar', 'en', 'tr', 'fr', 'ru', 'zh'];
function settingRaw(key) {
  const row = db.prepare('SELECT value FROM settings WHERE key = ?').get(key);
  return row ? row.value : null;
}
function getSetting(key) {
  const def = SETTING_DEFS[key];
  const raw = settingRaw(key);
  if (raw === null) return def.v;
  if (def.type === 'int') return Number(raw);
  if (def.type === 'bool') return raw === '1';
  return raw;
}
function getJsonSetting(key) {
  try { return JSON.parse(getSetting(key)); } catch (e) { return JSON.parse(SETTING_DEFS[key].v); }
}
// validate returns normalized string value or null
function normalizeSetting(key, value) {
  const def = SETTING_DEFS[key];
  if (!def) return null;
  if (def.type === 'int') {
    const n = Number(value);
    if (!Number.isInteger(n) || n < def.min || n > def.max) return null;
    return String(n);
  }
  if (def.type === 'bool') return value === true || value === 1 || value === '1' ? '1' : (value === false || value === 0 || value === '0' ? '0' : null);
  if (def.type === 'enum') return def.values.includes(value) ? String(value) : null;
  if (def.type === 'text') return typeof value === 'string' && value.length <= def.max ? value : null;
  if (def.type === 'json') {
    let o = value;
    if (typeof value === 'string') { try { o = JSON.parse(value); } catch (e) { return null; } }
    const norm = def.validate(o);
    if (norm === null) return null;
    const txt = JSON.stringify(norm);
    return txt.length <= def.max ? txt : null;
  }
  return null;
}

// مقادیر پویا: همیشه از پایگاه داده خوانده می‌شوند تا تغییر مدیر فوراً اعمال شود
const PRICING = {
  get TRANSLATOR_SHARE() { return getSetting('translator_share_percent') / 100; },
  get CANCEL_FEE_PERCENT() { return getSetting('cancel_fee_percent'); },
  get TAX_PERCENT() { return getSetting('tax_percent'); },
  // کف صورتحساب: حتی اگر خدمت کمتر از یک ساعت طول کشیده باشد، مبلغ پایه یک ساعت محاسبه می‌شود
  MIN_BILL_H: 1,
};
const PAYMENTS = {
  get CASH() { return getSetting('cash_enabled'); },
  get ONLINE() { return getSetting('online_enabled'); },
};

// ---------- ورود مدیر ----------
// رمز آغازین مدیر از متغیر محیطی HZ_ADMIN_PASSWORD خوانده می‌شود؛ اگر تنظیم نشده باشد، پنل بسته است.
// مدیر می‌تواند بعداً از داخل پنل رمز را عوض کند؛ در آن صورت هش ذخیره‌شده در پایگاه داده معتبر است و بر مقدار محیطی مقدم می‌شود.
const ADMIN_PASSWORD = process.env.HZ_ADMIN_PASSWORD || '';
function hashAdminPassword(pw) {
  const salt = crypto.randomBytes(16).toString('hex');
  return 'scrypt:' + salt + ':' + crypto.scryptSync(String(pw), salt, 64).toString('hex');
}
function verifyAdminPassword(pw) {
  const stored = settingRaw('admin_password_hash');
  if (stored) {
    const parts = String(stored).split(':');
    if (parts.length !== 3 || parts[0] !== 'scrypt') return false;
    const given = crypto.scryptSync(String(pw || ''), parts[1], 64);
    const want = Buffer.from(parts[2], 'hex');
    return given.length === want.length && crypto.timingSafeEqual(given, want);
  }
  if (!ADMIN_PASSWORD) return false;
  const given = crypto.createHash('sha256').update(String(pw || '')).digest();
  const want = crypto.createHash('sha256').update(ADMIN_PASSWORD).digest();
  return crypto.timingSafeEqual(given, want);
}
// ---------- حساب اولیهٔ صاحب پلتفرم (مهاجرت از رمز تک‌کاربرهٔ نسل اول) ----------
// اگر جدول کارمندان خالی باشد، حساب «owner» با همان رمز فعلی ساخته می‌شود:
// اول هش ذخیره‌شدهٔ پنل (اگر مدیر رمز را عوض کرده باشد) و در غیر این صورت رمز محیطی.
if (!db.prepare('SELECT COUNT(*) AS n FROM admin_users').get().n) {
  const storedHash = settingRaw('admin_password_hash');
  const seedHash = storedHash && String(storedHash).startsWith('scrypt:') ? String(storedHash)
    : (ADMIN_PASSWORD ? hashAdminPassword(ADMIN_PASSWORD) : null);
  if (seedHash) {
    db.prepare("INSERT INTO admin_users (username, name, password_hash, role, is_active, created_at) VALUES ('owner', 'صاحب پلتفرم', ?, 'owner', 1, ?)")
      .run(seedHash, now());
  }
}
// محدودکننده‌ی تلاش: فقط شکست‌ها شمرده می‌شوند (ضد حدس رمز و کد)
const RL = {
  adminFail: makeLimiter({ max: Number(process.env.HZ_RL_ADMIN_MAX) || 10, windowMs: 15 * 60 * 1000 }),
  otpIp: makeLimiter({ max: Number(process.env.HZ_RL_OTP_MAX) || 300, windowMs: 10 * 60 * 1000 }),
  verifyFail: makeLimiter({ max: Number(process.env.HZ_RL_VERIFY_MAX) || 100, windowMs: 10 * 60 * 1000 }),
};
const FRAME_ANCESTORS = process.env.HZ_FRAME_ANCESTORS || "'self' https://*.e2b.app";
const ADMIN_SESSION_MS = 8 * 3600 * 1000;
// نشانهٔ مدیر از سرصفحه‌ی Authorization یا X-Admin-Token خوانده می‌شود (برخی واسطه‌ها Authorization را حذف می‌کنند)
function adminTokenOf(req) {
  const m = (req.headers.authorization || '').match(/^Bearer\s+(.+)$/i);
  if (m) return m[1];
  const x = req.headers['x-admin-token'];
  return typeof x === 'string' && x ? x : null;
}
function adminUserOf(req) {
  const tok = adminTokenOf(req);
  if (!tok) return null;
  const row = db.prepare(`SELECT u.id, u.username, u.name, u.role, u.is_active, s.expires_at FROM admin_sessions s
    LEFT JOIN admin_users u ON u.id = s.admin_user_id WHERE s.token_hash = ?`).get(sha256(tok));
  if (!row) return null;
  if (row.expires_at < now()) { db.prepare('DELETE FROM admin_sessions WHERE token_hash = ?').run(sha256(tok)); return null; }
  if (!row.is_active) return null; // کارمند غیرفعال‌شده حتی با توکن زنده مجاز نیست
  return row;
}
function adminOf(req) { return !!adminUserOf(req); }
function requireAdmin(req, res) {
  if (!ADMIN_PASSWORD) { send(res, 404, { error: 'not_found' }); return false; }
  if (!adminOf(req)) { send(res, 401, { error: 'unauthorized' }); return false; }
  return true;
}
// ---------- نقش‌های کارمندان پنل و مجوزهای هر نقش (نسل دوم پنل) ----------
// owner همه‌چیز؛ بقیه فقط مجوزهای نقش خودشان. گارد در سرور اعمال می‌شود، نه فقط مخفی‌شدن منو.
const ADMIN_ROLES = { owner: 'صاحب پلتفرم', ops: 'کارشناس عملیات', recruiter: 'کارشناس جذب مترجم', finance: 'کارشناس مالی', support: 'پشتیبانی' };
const ADMIN_PERMS = {
  'bookings.manage': ['owner', 'ops'],          // رفع قفل کد امنیتی
  'dispatch.manage': ['owner', 'ops'],          // کنسول اعزام
  'travelers.manage': ['owner', 'ops'],         // مسدودسازی/رفع مسدودی مسافر
  'translators.manage': ['owner', 'recruiter'], // تایید/رد نهایی + تعلیق/بازفعال‌سازی
  'interviews.manage': ['owner', 'recruiter'],  // اسلات مصاحبه + نتیجه + غیبت
  'docs.manage': ['owner', 'recruiter'],        // تصمیم مدارک
  'finance.manage': ['owner', 'finance'],       // تسویهٔ دستی + حل اختلاف
  'features.manage': ['owner'],                 // کلیدهای پلتفرم
  'cities.manage': ['owner', 'ops'],            // شهرها و پوشش سرویس
  'settings.manage': ['owner'],                 // تنظیمات (تعرفه، کارمزد، متون)
  'staff.manage': ['owner'],                    // کارمندان و نقش‌ها
  'reports.view': ['owner', 'ops', 'finance'],  // گزارش‌ها و خروجی CSV
  'audit.view': ['owner', 'ops'],               // دفتر رویدادها
};
function requirePerm(req, res, perm) {
  const u = adminUserOf(req);
  const allowed = ADMIN_PERMS[perm] || ['owner'];
  if (!u || !allowed.includes(u.role)) { send(res, 403, { error: 'forbidden', need: perm }); return false; }
  return true;
}

route('POST', '/api/admin/login', async (req, res) => {
  if (!ADMIN_PASSWORD) return send(res, 404, { error: 'not_found' });
  const ip = clientIp(req);
  const gate = RL.adminFail.check(ip);
  if (!gate.ok) return send(res, 429, { error: 'too_many_attempts', retry_after: gate.retryAfter });
  const b = await readJson(req);
  // نسل دوم: هر کارمند حساب خودش را دارد. اگر نام کاربری نیاید «owner» فرض می‌شود
  // تا ورود تک‌رمزی قدیمی (رمز محیطی) همچنان کار کند.
  const username = typeof b.username === 'string' && b.username.trim() ? b.username.trim().slice(0, 40) : 'owner';
  const acc = db.prepare('SELECT * FROM admin_users WHERE username = ?').get(username);
  let ok = false;
  if (acc && String(acc.password_hash).startsWith('scrypt:')) {
    const parts = String(acc.password_hash).split(':');
    const given = crypto.scryptSync(String(b.password || ''), parts[1], 64);
    const want = Buffer.from(parts[2], 'hex');
    ok = given.length === want.length && crypto.timingSafeEqual(given, want);
  }
  if (!ok) { RL.adminFail.fail(ip); return send(res, 401, { error: 'bad_password' }); }
  if (!acc.is_active) { RL.adminFail.fail(ip); return send(res, 403, { error: 'account_disabled' }); }
  RL.adminFail.reset(ip);
  db.prepare('UPDATE admin_users SET last_login_at = ? WHERE id = ?').run(now(), acc.id);
  const token = crypto.randomBytes(32).toString('hex');
  db.prepare('INSERT INTO admin_sessions (token_hash, expires_at, admin_user_id) VALUES (?, ?, ?)').run(sha256(token), now() + ADMIN_SESSION_MS, acc.id);
  audit('admin.login', { username: acc.username, role: acc.role });
  send(res, 200, { token, expires_in: ADMIN_SESSION_MS / 1000, role: acc.role, name: acc.name });
});

route('POST', '/api/admin/logout', async (req, res) => {
  const tok = adminTokenOf(req);
  if (tok) db.prepare('DELETE FROM admin_sessions WHERE token_hash = ?').run(sha256(tok));
  send(res, 200, { ok: true });
});

// تغییر رمز مدیر از داخل پنل: رمز فعلی لازم است، رمز تازه حداقل ۱۲ کاراکتر و غیرآزمایشی.
// هش رمز تازه (scrypt) در پایگاه داده ذخیره می‌شود و از آن پس بر رمز محیطی مقدم است.
// نشست‌های دیگر مدیر باطل می‌شوند؛ نشست فعلی می‌ماند. خودِ رمز هیچ‌جا ثبت نمی‌شود.
route('POST', '/api/admin/change-password', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  const b = await readJson(req);
  if (!verifyAdminPassword(b.current_password)) return send(res, 401, { error: 'bad_current_password' });
  const next = String(b.new_password || '');
  if (isWeakAdminPassword(next)) return send(res, 400, { error: 'weak_password' });
  db.prepare('INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value')
    .run('admin_password_hash', hashAdminPassword(next));
  // همگام‌سازی با حساب owner در نسل دوم پنل تا هر دو مسیر یک رمز را ببینند
  db.prepare("UPDATE admin_users SET password_hash = ? WHERE username = 'owner'").run(hashAdminPassword(next));
  db.prepare('DELETE FROM admin_sessions WHERE token_hash != ?').run(sha256(adminTokenOf(req) || ''));
  audit('admin.change_password', {});
  send(res, 200, { ok: true });
});

route('GET', '/api/admin/settings', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  const out = {};
  for (const k of Object.keys(SETTING_DEFS)) {
    const d = SETTING_DEFS[k];
    out[k] = { value: getSetting(k), type: d.type, label: d.label, values: d.values || null, min: d.min ?? null, max: d.max ?? null };
  }
  send(res, 200, { settings: out });
});

route('PUT', '/api/admin/settings', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  if (!requirePerm(req, res, 'settings.manage')) return;
  const b = await readJson(req);
  const keys = Object.keys(b || {});
  if (!keys.length) return send(res, 400, { error: 'nothing_to_change' });
  const rows = [];
  for (const k of keys) {
    if (!SETTING_DEFS[k]) return send(res, 400, { error: 'unknown_key', key: k });
    const v = normalizeSetting(k, b[k]);
    if (v === null) return send(res, 400, { error: 'invalid_value', key: k });
    if (k === 'default_city_id') {
      const c = db.prepare('SELECT traveler_enabled FROM cities WHERE id = ?').get(Number(v));
      if (!c || !c.traveler_enabled) return send(res, 400, { error: 'invalid_city', key: k });
    }
    rows.push([k, v]);
  }
  db.transaction(() => {
    for (const [k, v] of rows) db.prepare('INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value').run(k, v);
  })();
  audit('settings.update', { keys });
  send(res, 200, { ok: true, changed: keys });
});

route('GET', '/api/admin/summary', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  const reservations = {};
  for (const r of db.prepare('SELECT status, COUNT(*) AS n FROM reservations GROUP BY status').all()) reservations[r.status] = r.n;
  const translators = {};
  for (const r of db.prepare('SELECT status, COUNT(*) AS n FROM translators GROUP BY status').all()) translators[r.status] = r.n;
  const payments_waiting = db.prepare("SELECT COUNT(*) AS n FROM reservations WHERE status = 'finished' AND (pay_state IS NULL OR pay_state NOT IN ('settled','refunded'))").get().n;
  const disputes = db.prepare("SELECT COUNT(*) AS n FROM reservations WHERE pay_state = 'disputed'").get().n;
  // شاخص‌های سلامت عملیات (نسل دوم پنل): داده‌ها از همین پایگاه داده، بدون هیچ منبع بیرونی
  const since7 = now() - 7 * DAY_MS;
  const created7 = db.prepare('SELECT COUNT(*) AS n FROM reservations WHERE created_at >= ?').get(since7).n;
  const done7 = db.prepare("SELECT COUNT(*) AS n FROM reservations WHERE status = 'done' AND created_at >= ?").get(since7).n;
  const cancelled7 = db.prepare("SELECT COUNT(*) AS n FROM reservations WHERE status = 'cancelled' AND created_at >= ?").get(since7).n;
  const avgMatchRow = db.prepare('SELECT AVG(matched_at - created_at) AS a FROM reservations WHERE matched_at IS NOT NULL AND created_at >= ?').get(since7);
  const oldest = db.prepare("SELECT MIN(created_at) AS m FROM reservations WHERE status IN ('searching','matching')").get().m;
  const pendingChanges = db.prepare("SELECT (SELECT COUNT(*) FROM change_requests WHERE status = 'pending') + (SELECT COUNT(*) FROM extension_requests WHERE status = 'pending') AS n").get().n;
  const uploadedDocs = db.prepare("SELECT COUNT(*) AS n FROM translator_documents WHERE status = 'uploaded'").get().n;
  const onlineTranslators = db.prepare('SELECT COUNT(*) AS n FROM translators WHERE online = 1').get().n;
  const blockedTravelers = db.prepare('SELECT COUNT(*) AS n FROM users WHERE role = \'traveler\' AND blocked = 1').get().n;
  const health = {
    created_7d: created7, done_7d: done7, cancelled_7d: cancelled7,
    completion_rate_7d: created7 ? Math.round((done7 / created7) * 100) : null,
    avg_match_minutes_7d: avgMatchRow && avgMatchRow.a != null ? Math.round(avgMatchRow.a / 60000) : null,
    oldest_searching_minutes: oldest ? Math.round((now() - oldest) / 60000) : null,
    pending_changes: pendingChanges,
    uploaded_docs: uploadedDocs,
    online_translators: onlineTranslators,
    blocked_travelers: blockedTravelers,
  };
  // قیف جذب مترجم: شمار هر مرحله از ثبت‌نام تا فعال‌سازی (نمونه‌برداری از مقالهٔ قیف جذب اوبر)
  const funnel = {
    registered: translators.registered || 0,
    pending_review: translators.pending_review || 0,
    active: (translators.active_general || 0) + (translators.active_group || 0),
    rejected: translators.rejected || 0,
    suspended: translators.suspended || 0,
  };
  send(res, 200, { reservations, translators, payments_waiting, disputes, health, funnel });
});

// فهرست رزروها برای پنل مدیر (فقط‌خواندنی). تب‌ها بر اساس نگاشت وضعیت‌های سرور در بریف پنل (بخش ۵.۷):
// pending = در انتظار تطبیق، upcoming = پیش‌رو، ongoing = در جریان (پایان‌یافته منتظر پرداخت)، done، cancelled
route('GET', '/api/admin/bookings', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  const q = new URL(req.url, 'http://x').searchParams;
  const TABS = {
    pending: ['searching', 'waiting_schedule', 'matching', 'unmatched_ask', 'no_match'],
    upcoming: ['matched'],
    ongoing: ['finished'],
    done: ['done'],
    cancelled: ['cancelled'],
  };
  const tab = TABS[q.get('tab')] ? q.get('tab') : 'pending';
  const kind = q.get('kind') === 'instant' || q.get('kind') === 'scheduled' ? q.get('kind') : '';
  const term = String(q.get('q') || '').trim().slice(0, 64);
  const limit = Math.min(Math.max(parseInt(q.get('limit'), 10) || 20, 1), 100);
  const offset = Math.max(parseInt(q.get('offset'), 10) || 0, 0);
  const where = 'r.status IN ' + '(' + TABS[tab].map(() => '?').join(',') + ')' +
    (kind ? ' AND r.kind = ?' : '') +
    (term ? " AND (r.traveler_name LIKE ? ESCAPE '\\' OR CAST(r.id AS TEXT) LIKE ? ESCAPE '\\' OR tu.phone LIKE ? ESCAPE '\\')" : '');
  const args = TABS[tab].slice();
  if (kind) args.push(kind);
  if (term) {
    const esc = term.replace(/[\\%_]/g, (c) => '\\' + c);
    args.push('%' + esc + '%', '%' + esc + '%', '%' + esc + '%');
  }
  const total = db.prepare('SELECT COUNT(*) AS n FROM reservations r LEFT JOIN users tu ON tu.id = r.translator_id WHERE ' + where).get(...args).n;
  const rows = db.prepare(`SELECT r.id, r.kind, r.traveler_name, r.place, r.origin_lang, r.dest_lang, r.field,
      r.status, r.total, r.net, r.pay_method, r.pay_state, r.scheduled_at, r.created_at, r.updated_at, r.finished_at,
      tu.phone AS translator_phone,
      COALESCE(json_extract(tp.profile, '$.first_name') || ' ' || json_extract(tp.profile, '$.last_name'), '') AS translator_name
    FROM reservations r
    LEFT JOIN users tu ON tu.id = r.translator_id
    LEFT JOIN translators tp ON tp.user_id = r.translator_id
    WHERE ` + where + ' ORDER BY r.created_at DESC LIMIT ? OFFSET ?').all(...args, limit, offset);
  send(res, 200, { tab, total, offset, limit, bookings: rows.map((r) => ({
    id: r.id, kind: r.kind, traveler_name: r.traveler_name || '', place: r.place || '',
    langs: r.origin_lang + '-' + r.dest_lang, field: r.field, status: r.status,
    total: r.total, net: r.net, pay_method: r.pay_method || '', pay_state: r.pay_state || '',
    translator: r.translator_name || '', translator_phone: r.translator_phone || '',
    scheduled_at: r.scheduled_at, created_at: r.created_at, finished_at: r.finished_at, updated_at: r.updated_at,
  })) });
});

// فهرست مسافران (فقط‌خواندنی): شماره، شمار رزروها و آخرین فعالیت. هیچ دادهٔ حساسی (کد/توکن) اینجا نیست.
route('GET', '/api/admin/travelers', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  const q = new URL(req.url, 'http://x').searchParams;
  const term = String(q.get('q') || '').trim().slice(0, 64);
  const limit = Math.min(Math.max(parseInt(q.get('limit'), 10) || 20, 1), 100);
  const offset = Math.max(parseInt(q.get('offset'), 10) || 0, 0);
  const where = "u.role = 'traveler'" + (term ? " AND u.phone LIKE ? ESCAPE '\\'" : '');
  const args = term ? ['%' + term.replace(/[\\%_]/g, (c) => '\\' + c) + '%'] : [];
  const total = db.prepare('SELECT COUNT(*) AS n FROM users u WHERE ' + where).get(...args).n;
  const rows = db.prepare(`SELECT u.id, u.phone, u.created_at,
      COUNT(r.id) AS reservations_total,
      SUM(CASE WHEN r.status = 'done' THEN 1 ELSE 0 END) AS reservations_done,
      MAX(r.created_at) AS last_activity
    FROM users u LEFT JOIN reservations r ON r.traveler_id = u.id
    WHERE ` + where + ' GROUP BY u.id ORDER BY u.created_at DESC LIMIT ? OFFSET ?').all(...args, limit, offset);
  send(res, 200, { total, offset, limit, travelers: rows });
});

// نمای مالی (فقط‌خواندنی): پرداخت‌های منتظر تأیید، اختلاف‌ها، جمع تسویه‌شده و تسویهٔ دوره‌ای به شبا (فقط ۴ رقم آخر)
route('GET', '/api/admin/finance', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  const waiting = db.prepare("SELECT COUNT(*) AS n, COALESCE(SUM(total), 0) AS sum FROM reservations WHERE status = 'finished' AND (pay_state IS NULL OR pay_state NOT IN ('settled','refunded'))").get();
  const disputes = db.prepare("SELECT COUNT(*) AS n, COALESCE(SUM(total), 0) AS sum FROM reservations WHERE pay_state = 'disputed'").get();
  const refunded = db.prepare("SELECT COUNT(*) AS n, COALESCE(SUM(total), 0) AS sum FROM reservations WHERE pay_state = 'refunded'").get();
  // پرداخت‌های نقدی معلق: مسافر «پرداخت کردم» زده اما مترجم دریافت را تأیید نکرده؛ تسویهٔ دستی مدیر همین‌جا ممکن است.
  const waitingList = db.prepare(`SELECT r.id, r.traveler_name, r.place, r.total, r.net, r.finished_at, r.updated_at,
      tu.phone AS traveler_phone, tr.phone AS translator_phone,
      COALESCE(json_extract(tp.profile, '$.first_name') || ' ' || json_extract(tp.profile, '$.last_name'), '') AS translator_name
    FROM reservations r
    LEFT JOIN users tu ON tu.id = r.traveler_id
    LEFT JOIN users tr ON tr.id = r.translator_id
    LEFT JOIN translators tp ON tp.user_id = r.translator_id
    WHERE r.status = 'finished' AND ((r.pay_method = 'cash' AND r.pay_state = 'awaiting_cash') OR (r.pay_method IS NULL AND r.pay_state IS NULL))
    ORDER BY r.finished_at LIMIT 100`).all();
  const settled = db.prepare("SELECT COUNT(*) AS n, COALESCE(SUM(total), 0) AS sum_total, COALESCE(SUM(net), 0) AS sum_net FROM reservations WHERE status = 'done' AND pay_state = 'settled'").get();
  // ---------- درآمد پلتفرم ----------
  // سهم پلتفرم از هر رزرو = total − net (کارمزد + مالیات). تحقق‌یافته = تسویه‌شده؛ در انتظار = پایان‌یافتهٔ بی‌پرداخت.
  const dayStart = new Date(); dayStart.setHours(0, 0, 0, 0); const dayMs = dayStart.getTime();
  const weekMs = dayMs - 6 * 86400000;
  const incomeRealized = db.prepare("SELECT COALESCE(SUM(total - net), 0) s FROM reservations WHERE status = 'done' AND pay_state = 'settled'").get().s;
  const incomeToday = db.prepare("SELECT COALESCE(SUM(total - net), 0) s FROM reservations WHERE status = 'done' AND pay_state = 'settled' AND updated_at >= ?").get(dayMs).s;
  const incomeWeek = db.prepare("SELECT COALESCE(SUM(total - net), 0) s FROM reservations WHERE status = 'done' AND pay_state = 'settled' AND updated_at >= ?").get(weekMs).s;
  const incomePending = db.prepare("SELECT COALESCE(SUM(total - net), 0) s FROM reservations WHERE status = 'finished' AND (pay_state IS NULL OR pay_state NOT IN ('settled','refunded'))").get().s;
  const cashEarned = db.prepare("SELECT COALESCE(SUM(total - net), 0) s FROM reservations WHERE status = 'done' AND pay_state = 'settled' AND pay_method = 'cash'").get().s;
  const cashPaid = db.prepare('SELECT COALESCE(SUM(amount), 0) s FROM debt_payments').get().s;
  const income = { realized: incomeRealized, today: incomeToday, week: incomeWeek, pending: incomePending,
    cash_debt: Math.max(0, cashEarned - cashPaid) };
  const perTranslator = db.prepare(`SELECT r.translator_id AS id, tu.phone,
      COALESCE(json_extract(tp.profile, '$.first_name') || ' ' || json_extract(tp.profile, '$.last_name'), '') AS name,
      COALESCE(json_extract(tp.profile, '$.iban'), '') AS iban,
      COUNT(*) AS n, COALESCE(SUM(r.net), 0) AS sum_net, MAX(r.updated_at) AS last_settled_at
    FROM reservations r
    JOIN users tu ON tu.id = r.translator_id
    LEFT JOIN translators tp ON tp.user_id = r.translator_id
    WHERE r.status = 'done' AND r.pay_state = 'settled' AND r.translator_id IS NOT NULL
    GROUP BY r.translator_id ORDER BY last_settled_at DESC LIMIT 100`).all();
  send(res, 200, {
    waiting: { count: waiting.n, sum: waiting.sum },
    disputes: { count: disputes.n, sum: disputes.sum },
    refunded: { count: refunded.n, sum: refunded.sum },
    waiting_list: waitingList.map((r) => ({
      id: r.id, traveler_name: r.traveler_name || '', traveler_phone: r.traveler_phone || '',
      place: r.place || '', total: r.total, net: r.net,
      translator: r.translator_name || '', translator_phone: r.translator_phone || '',
      finished_at: r.finished_at, updated_at: r.updated_at,
    })),
    settled: { count: settled.n, sum_total: settled.sum_total, sum_net: settled.sum_net },
    income,
    settlements: perTranslator.map((r) => ({
      id: r.id, phone: r.phone, name: r.name || '',
      iban_last4: r.iban ? String(r.iban).replace(/\D/g, '').slice(-4) : '',
      count: r.n, sum_net: r.sum_net, last_settled_at: r.last_settled_at,
    })),
  });
});

// ---------- بدهی نقدی مترجمان (سهم پلتفرم دست مترجم است) ----------
route('GET', '/api/admin/debts', async (req, res) => {
  if (!requirePerm(req, res, 'finance.manage')) return;
  const rows = db.prepare(`SELECT r.translator_id AS id, tu.phone,
      COALESCE(json_extract(tp.profile, '$.first_name') || ' ' || json_extract(tp.profile, '$.last_name'), '') AS name,
      COALESCE(SUM(r.total - r.net), 0) AS earned
    FROM reservations r
    JOIN users tu ON tu.id = r.translator_id
    LEFT JOIN translators tp ON tp.user_id = r.translator_id
    WHERE r.status = 'done' AND r.pay_state = 'settled' AND r.pay_method = 'cash' AND r.translator_id IS NOT NULL
    GROUP BY r.translator_id`).all();
  const debts = rows.map((r) => {
    const paid = db.prepare('SELECT COALESCE(SUM(amount), 0) s FROM debt_payments WHERE translator_id = ?').get(r.id).s;
    return { id: r.id, phone: r.phone, name: r.name || '', earned: r.earned, paid,
      debt: Math.max(0, r.earned - paid) };
  }).filter((d) => d.earned > 0 || d.paid > 0).sort((a, b) => b.debt - a.debt);
  const history = db.prepare(`SELECT p.id, p.translator_id, p.amount, p.note, p.admin, p.created_at, tu.phone
    FROM debt_payments p LEFT JOIN users tu ON tu.id = p.translator_id ORDER BY p.id DESC LIMIT 50`).all();
  send(res, 200, { debts, history: history.map((h) => ({ id: h.id, translator_id: h.translator_id, phone: h.phone,
    amount: h.amount, note: h.note || '', admin: h.admin || '', created_at: h.created_at })) });
});
route('POST', '/api/admin/debts/:uid/pay', async (req, res, url, params) => {
  if (!requirePerm(req, res, 'finance.manage')) return;
  const uid = parseId(params.uid);
  const b = await readJson(req, 4 * 1024).catch(() => ({}));
  const amount = Math.trunc(Number(b.amount));
  if (!uid || !Number.isFinite(amount) || amount <= 0) return send(res, 400, { error: 'invalid_amount' });
  const t = db.prepare('SELECT user_id FROM translators WHERE user_id = ?').get(uid);
  if (!t) return send(res, 404, { error: 'not_found' });
  const debt = translatorDebt(uid);
  if (debt <= 0) return send(res, 409, { error: 'no_debt' });
  const pay = Math.min(amount, debt);
  const adminName = (() => { const a = adminUserOf(req); return (a && (a.name || a.username)) || 'admin'; })();
  db.prepare('INSERT INTO debt_payments (translator_id, amount, note, admin, created_at) VALUES (?, ?, ?, ?, ?)')
    .run(uid, pay, clip(String(b.note || ''), 200), adminName, now());
  audit('debt.payment', { user_id: uid, amount: pay });
  const rest = translatorDebt(uid);
  db.prepare("INSERT INTO translator_notifications (user_id, kind, ref, created_at) VALUES (?, 'debt_paid', ?, ?)").run(uid, String(pay), now());
  const fmt = (n) => String(n).replace(/\B(?=(\d{3})+(?!\d))/g, '،');
  pushTranslator(uid, rest <= 0
    ? { title: 'بدهی شما تسویه شد', body: 'پرداخت ' + fmt(pay) + ' تومانی ثبت شد؛ بدهی صفر شد و درخواست‌های جدید برایتان باز گشت.', tag: 'debt-clear-' + Date.now() }
    : { title: 'پرداخت بدهی ثبت شد', body: fmt(pay) + ' تومان ثبت شد؛ باقیماندهٔ بدهی: ' + fmt(rest) + ' تومان.', tag: 'debt-pay-' + Date.now() });
  send(res, 200, { ok: true, paid: pay, remaining: rest, blocked: rest > 0 });
});

// ---------- نقشهٔ زندهٔ پنل: شهرها + مترجمان آنلاینِ دارای موقعیت + رزروهای جاری ----------
route('GET', '/api/admin/map', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  const cities = db.prepare('SELECT id, name_fa, lat, lng, radius_km, traveler_enabled, translator_enabled FROM cities ORDER BY id').all();
  const translators = db.prepare(`SELECT t.user_id, t.lat, t.lng, t.loc_at, t.online, u.phone,
      COALESCE(json_extract(t.profile, '$.first_name') || ' ' || json_extract(t.profile, '$.last_name'), '') AS name
    FROM translators t JOIN users u ON u.id = t.user_id
    WHERE t.share_loc = 1 AND t.lat IS NOT NULL AND t.lng IS NOT NULL AND t.online = 1
      AND t.loc_at >= ? ORDER BY t.loc_at DESC LIMIT 200`).all(now() - 24 * 3600 * 1000);
  const reservations = db.prepare(`SELECT id, lat, lng, status, field, place FROM reservations
    WHERE lat IS NOT NULL AND lng IS NOT NULL AND status IN ('searching','matching','unmatched_ask','matched','finished')
    ORDER BY updated_at DESC LIMIT 200`).all();
  send(res, 200, {
    cities: cities.map((c) => ({ id: c.id, name_fa: c.name_fa, lat: c.lat, lng: c.lng, radius_km: c.radius_km,
      traveler_enabled: !!c.traveler_enabled, translator_enabled: !!c.translator_enabled })),
    translators: translators.map((t) => ({ id: t.user_id, lat: t.lat, lng: t.lng, name: t.name || '', phone: t.phone,
      at: new Date(t.loc_at).toISOString() })),
    reservations: reservations.map((r) => ({ id: r.id, lat: r.lat, lng: r.lng, status: r.status, field: r.field, place: r.place || '' })),
  });
});

// صف تجدیدنظرها (بریف ۴.۴، فقط‌خواندنی): مترجمان رد نهایی با مهلت ۷ روزه.
// جریان ثبت درخواست تجدیدنظر هنوز در اپ مترجم پیاده‌سازی نشده است؛ طبق قاعدهٔ بریف («قابلیتی که در کد نیست
// در پنل ساختگی نمایش داده نمی‌شود») این صف فقط دادهٔ واقعی «ردشده‌ها» را نشان می‌دهد و flow_active=false است.
route('GET', '/api/admin/recons', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  const RECON_WINDOW_DAYS = 7;
  const rows = db.prepare(`SELECT t.user_id AS id, u.phone, t.score, t.updated_at,
      COALESCE(json_extract(t.profile, '$.first_name') || ' ' || json_extract(t.profile, '$.last_name'), '') AS name
    FROM translators t JOIN users u ON u.id = t.user_id
    WHERE t.status = 'rejected'
    ORDER BY t.updated_at DESC LIMIT 100`).all();
  const tNow = now();
  send(res, 200, {
    flow_active: false,
    window_days: RECON_WINDOW_DAYS,
    recons: rows.map((r) => {
      const elapsed = tNow - r.updated_at;
      return {
        id: r.id, name: r.name || '', phone: r.phone, score: r.score,
        rejected_at: r.updated_at,
        window_left_days: Math.max(0, Math.ceil((RECON_WINDOW_DAYS * 86400000 - elapsed) / 86400000)),
        window_expired: elapsed > RECON_WINDOW_DAYS * 86400000,
      };
    }),
  });
});

// صف اختلاف‌های نقدی (بریف ۴.۱۰، فقط‌خواندنی): رزروهای با pay_state = 'disputed'.
// حل‌وفصل با یادداشت داخلی هنوز پیاده‌سازی نشده؛ تیکت پشتیبانی هم در کد نیست —
// فقط وضعیت پیکربندی پشتیبانی (شمارهٔ تلفن) گزارش می‌شود تا چیزی ساختگی نمایش داده نشود.
route('GET', '/api/admin/disputes', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  const rows = db.prepare(`SELECT r.id, r.kind, r.traveler_name, r.place, r.total, r.net, r.pay_method,
      r.finished_at, r.updated_at, tu.phone AS traveler_phone, tr.phone AS translator_phone,
      COALESCE(json_extract(tp.profile, '$.first_name') || ' ' || json_extract(tp.profile, '$.last_name'), '') AS translator_name
    FROM reservations r
    LEFT JOIN users tu ON tu.id = r.traveler_id
    LEFT JOIN users tr ON tr.id = r.translator_id
    LEFT JOIN translators tp ON tp.user_id = r.translator_id
    WHERE r.pay_state = 'disputed'
    ORDER BY r.updated_at DESC LIMIT 100`).all();
  const supportPhone = getSetting('support_phone');
  send(res, 200, {
    disputes: rows.map((r) => ({
      id: r.id, kind: r.kind, traveler_name: r.traveler_name || '', traveler_phone: r.traveler_phone || '',
      place: r.place || '', total: r.total, net: r.net, pay_method: r.pay_method || '',
      translator: r.translator_name || '', translator_phone: r.translator_phone || '',
      finished_at: r.finished_at, updated_at: r.updated_at,
    })),
    support: { phone_configured: !!(supportPhone && String(supportPhone).trim()), tickets_in_code: false },
  });
});

// ماتریس اعزام (بریف ۴.۱۱، فقط‌خواندنی): نمای زندهٔ ماموریت‌های فعال/پیش‌رو و مترجمان آنلاینِ بدون ماموریت.
// هیچ اقدامی از این صفحه انجام نمی‌شود؛ ردیف‌ها مترجم و بازهٔ اشغال هرکدام از رزروهای واقعی ساخته می‌شود.
route('GET', '/api/admin/dispatch', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  const missions = db.prepare(`SELECT r.id, r.kind, r.place, r.traveler_name, r.origin_lang, r.dest_lang, r.field,
      r.scheduled_at, r.hours, r.service_started_at, r.created_at, r.status,
      tu.phone AS translator_phone, tp.online,
      COALESCE(json_extract(tp.profile, '$.first_name') || ' ' || json_extract(tp.profile, '$.last_name'), '') AS translator_name
    FROM reservations r
    JOIN users tu ON tu.id = r.translator_id
    JOIN translators tp ON tp.user_id = r.translator_id
    WHERE r.status IN ('matched', 'finished')
    ORDER BY r.scheduled_at, r.created_at LIMIT 200`).all();
  const idle = db.prepare(`SELECT t.user_id AS id, u.phone,
      COALESCE(json_extract(t.profile, '$.first_name') || ' ' || json_extract(t.profile, '$.last_name'), '') AS name
    FROM translators t JOIN users u ON u.id = t.user_id
    WHERE t.online = 1 AND t.status IN ('active_general', 'active_specialized')
      AND NOT EXISTS (SELECT 1 FROM reservations r WHERE r.translator_id = t.user_id AND r.status IN ('matched', 'finished'))
    ORDER BY u.phone LIMIT 200`).all();
  send(res, 200, {
    generated_at: now(),
    missions: missions.map((r) => ({
      id: r.id, kind: r.kind, place: r.place || '', traveler_name: r.traveler_name || '',
      langs: r.origin_lang + '-' + r.dest_lang, field: r.field, status: r.status,
      translator: r.translator_name || '', translator_phone: r.translator_phone || '', online: !!r.online,
      start: r.scheduled_at || r.service_started_at || r.created_at,
      hours: Math.max(1, r.hours || 1),
    })),
    idle_online: idle,
  });
});

// کدهای امنیتی قفل‌شده (۵ تلاش ناموفق): مدیر می‌تواند قفل را باز کند یا کد تازه بسازد. خود کد هرگز به پنل داده نمی‌شود.
route('GET', '/api/admin/locked-service-codes', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  const rows = db.prepare(`SELECT id, traveler_name, place, status, service_code_attempts, created_at
    FROM reservations WHERE service_code_attempts >= 5 AND status = 'matched' ORDER BY created_at DESC LIMIT 100`).all();
  send(res, 200, { locked: rows.map((r) => ({ id: r.id, traveler_name: r.traveler_name || '', place: r.place || '',
    status: r.status, attempts: r.service_code_attempts, created_at: r.created_at })) });
});

route('POST', '/api/admin/reservations/:id/unlock-service-code', async (req, res, url, params) => {
  if (!requireAdmin(req, res)) return;
  if (!requirePerm(req, res, 'bookings.manage')) return;
  const id = parseId(params.id);
  const r = id && db.prepare('SELECT id FROM reservations WHERE id = ?').get(id);
  if (!r) return send(res, 404, { error: 'not_found' });
  const b = await readJson(req).catch(() => ({}));
  if (b && b.regenerate === true) {
    const fresh = String(crypto.randomInt(10000, 100000));
    db.prepare('UPDATE reservations SET service_code = ?, service_code_attempts = 0, updated_at = ? WHERE id = ?')
      .run(encryptServiceCode(fresh), now(), r.id);
    revEvent(r.id, 'service_code_unlocked', 'admin', { regenerated: true });
    return send(res, 200, { ok: true, regenerated: true });
  }
  db.prepare('UPDATE reservations SET service_code_attempts = 0, updated_at = ? WHERE id = ?').run(now(), r.id);
  revEvent(r.id, 'service_code_unlocked', 'admin', { regenerated: false });
  send(res, 200, { ok: true, regenerated: false });
});

// خط زمانی رزرو برای پشتیبانی: همهٔ گذارهای مهم به ترتیب وقوع.
route('GET', '/api/admin/reservations/:id/events', async (req, res, url, params) => {
  if (!requireAdmin(req, res)) return;
  const id = parseId(params.id);
  const r = id && db.prepare('SELECT id FROM reservations WHERE id = ?').get(id);
  if (!r) return send(res, 404, { error: 'not_found' });
  const rows = db.prepare('SELECT id, event, actor, detail, created_at FROM reservation_events WHERE reservation_id = ? ORDER BY id').all(id);
  send(res, 200, { events: rows.map((e) => {
    let d = {}; try { d = JSON.parse(e.detail || '{}'); } catch (err) { /* detail خراب — خالی نشان داده می‌شود */ }
    return { id: e.id, event: e.event, actor: e.actor, detail: d, created_at: e.created_at };
  }) });
});

// تسویهٔ دستی پرداخت نقدی معلق: مسافر پرداخت را ثبت کرده (awaiting_cash) اما مترجم دریافت را تأیید نکرده است.
// مدیر با این اقدام جای تأیید مترجم را می‌گیرد؛ پرونده بسته می‌شود و در گزارش تغییرات ثبت می‌شود.
// گسترده: رزرو تمام‌شده‌ای که هنوز روش پرداخت انتخاب نکرده (pay_method/pay_state هر دو NULL) هم قابل تسویهٔ دستی است —
// این حالت بن‌بست رخ می‌دهد اگر مدیر هر دو روش پرداخت را خاموش کرده باشد و مسافر در «انتخاب پرداخت» گیر کند.
route('POST', '/api/admin/reservations/:id/settle', async (req, res, url, params) => {
  if (!requireAdmin(req, res)) return;
  if (!requirePerm(req, res, 'finance.manage')) return;
  const id = parseId(params.id);
  const r = id && db.prepare('SELECT id, status, pay_method, pay_state FROM reservations WHERE id = ?').get(id);
  if (!r) return send(res, 404, { error: 'not_found' });
  const settleable = r.status === 'finished' &&
    (r.pay_state === 'awaiting_cash' || (r.pay_state == null && r.pay_method == null));
  if (!settleable) return send(res, 409, { error: 'not_settleable' });
  const b = await readJson(req, 4 * 1024).catch(() => ({}));
  const note = String((b && b.note) || '').slice(0, 300);
  db.prepare("UPDATE reservations SET translator_confirmed = 1, pay_state = 'settled', status = 'done', updated_at = ? WHERE id = ?").run(now(), id);
  if (r.pay_method === 'cash') onCashSettled(r);
  revEvent(id, 'manual_settled', 'admin', { note: clip(note, 300) });
  audit('reservation.manual_settle', { id, note: clip(note, 300) });
  send(res, 200, { ok: true, status: 'done', pay_state: 'settled' });
});

// حل‌وفصل اختلاف نقدی از سوی مدیر: دو تصمیم ممکن است —
// «settle»: تأیید دریافت نقدی و تسویهٔ عادی (رزرو done می‌شود)؛
// «refund»: پول به مسافر برمی‌گردد (pay_state = refunded؛ رزرو finished می‌ماند و پروندهٔ مالی بسته است).
route('POST', '/api/admin/disputes/:id/resolve', async (req, res, url, params) => {
  if (!requireAdmin(req, res)) return;
  if (!requirePerm(req, res, 'finance.manage')) return;
  const id = parseId(params.id);
  const r = id && db.prepare('SELECT id, pay_state FROM reservations WHERE id = ?').get(id);
  if (!r) return send(res, 404, { error: 'not_found' });
  if (r.pay_state !== 'disputed') return send(res, 409, { error: 'not_disputed' });
  const b = await readJson(req, 4 * 1024).catch(() => ({}));
  const note = String((b && b.note) || '').slice(0, 300);
  const t = now();
  if (b.decision === 'settle') {
    db.prepare("UPDATE reservations SET pay_state = 'settled', status = 'done', traveler_paid = 1, translator_confirmed = 1, updated_at = ? WHERE id = ?").run(t, id);
    if (r.pay_method === 'cash') onCashSettled(r);
    revEvent(id, 'dispute_resolved', 'admin', { decision: 'settle', note: clip(note, 300) });
    audit('dispute.resolve', { id, decision: 'settle', note: clip(note, 300) });
    return send(res, 200, { ok: true, status: 'done', pay_state: 'settled' });
  }
  if (b.decision === 'refund') {
    db.prepare("UPDATE reservations SET pay_state = 'refunded', updated_at = ? WHERE id = ?").run(t, id);
    db.prepare("UPDATE gateway_payments SET status = 'refunded' WHERE reservation_id = ? AND status = 'paid'").run(id);
    revEvent(id, 'dispute_resolved', 'admin', { decision: 'refund', note: clip(note, 300) });
    audit('dispute.resolve', { id, decision: 'refund', note: clip(note, 300) });
    return send(res, 200, { ok: true, pay_state: 'refunded' });
  }
  send(res, 400, { error: 'invalid_decision' });
});

route('GET', '/api/admin/translators', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  const q = new URL(req.url, 'http://x').searchParams;
  const status = q.get('status') || 'pending_review';
  const limit = Math.min(Math.max(parseInt(q.get('limit'), 10) || 50, 1), 200);
  const offset = Math.max(parseInt(q.get('offset'), 10) || 0, 0);
  // جستجو روی شماره و نام (نام در پروفایل ذخیره شده است)؛ نویسه‌های LIKE escape می‌شوند
  const term = String(q.get('q') || '').trim().slice(0, 60).replace(/[\\%_]/g, (c) => '\\' + c);
  // تب «فعال» پنل هر دو وضعیت مؤثر را می‌گیرد: فعال عمومی و فعال تخصصی (نردبان CAP)
  const statusList = status === 'active_general' ? ['active_general', 'active_specialized'] : [status];
  const where = 't.status IN (' + statusList.map(() => '?').join(',') + ')' + (term ? " AND (u.phone LIKE ? ESCAPE '\\' OR (COALESCE(json_extract(t.profile, '$.first_name'), '') || ' ' || COALESCE(json_extract(t.profile, '$.last_name'), '')) LIKE ? ESCAPE '\\')" : '');
  const params = term ? [...statusList, `%${term}%`, `%${term}%`] : statusList;
  const total = db.prepare(`SELECT COUNT(*) AS n FROM translators t JOIN users u ON u.id = t.user_id WHERE ${where}`).get(...params).n;
  const rows = db.prepare(`SELECT t.user_id AS id, u.phone, t.status, t.gender, t.score, t.updated_at, t.profile FROM translators t
      JOIN users u ON u.id = t.user_id WHERE ${where} ORDER BY t.updated_at, t.user_id LIMIT ? OFFSET ?`).all(...params, limit, offset)
    .map((r) => {
      let pr = {}; try { pr = JSON.parse(r.profile || '{}'); } catch (e) {}
      return { id: r.id, phone: r.phone, status: r.status, gender: r.gender, score: r.score, updated_at: r.updated_at,
        name: [pr.first_name, pr.last_name].filter(Boolean).join(' ') };
    });
  send(res, 200, { translators: rows, total, limit, offset });
});

// تصمیم کارشناس انسانی: فقط از وضعیت «در انتظار بررسی نهایی» (سند ۷.۳)
route('POST', '/api/admin/translators/:id/decision', async (req, res, url, params) => {
  if (!requireAdmin(req, res)) return;
  if (!requirePerm(req, res, 'translators.manage')) return;
  const id = parseId(params.id);
  const b = await readJson(req);
  const t = id && db.prepare('SELECT status FROM translators WHERE user_id = ?').get(id);
  if (!t) return send(res, 404, { error: 'not_found' });
  if (t.status !== 'pending_review') return send(res, 409, { error: 'not_pending_review', status: t.status });
  const next = b.decision === 'approve' ? 'active_general' : b.decision === 'reject' ? 'rejected' : null;
  if (!next) return send(res, 400, { error: 'invalid_decision' });
  db.prepare('UPDATE translators SET status = ?, updated_at = ? WHERE user_id = ?').run(next, now(), id);
  send(res, 200, { ok: true, status: next });
});

// فهرست مدارک در انتظار بررسی؛ محتوا فقط با درخواست صریح باز می‌شود
// هر مترجم یک ردیف: همه‌ی مدارک فعالش با وضعیت هرکدام (مدارک جایگزین‌شده نمایش داده نمی‌شوند)
route('GET', '/api/admin/translator-docs', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  const q = new URL(req.url, 'http://x').searchParams;
  const onlyReview = q.get('filter') !== 'all';
  const limit = Math.min(Math.max(parseInt(q.get('limit'), 10) || 50, 1), 200);
  const offset = Math.max(parseInt(q.get('offset'), 10) || 0, 0);
  const cond = onlyReview ? "AND EXISTS (SELECT 1 FROM translator_documents d WHERE d.user_id = t.user_id AND d.status = 'uploaded')" : '';
  const total = db.prepare(`SELECT COUNT(*) AS n FROM translators t WHERE 1=1 ${cond}`).get().n;
  const people = db.prepare(`SELECT t.user_id AS id, u.phone, t.status, t.profile, t.fields, t.interview FROM translators t
    JOIN users u ON u.id = t.user_id WHERE 1=1 ${cond} ORDER BY t.user_id DESC LIMIT ? OFFSET ?`).all(limit, offset);
  if (!people.length) return send(res, 200, { translators: [], total, limit, offset });
  const ids = people.map((p) => p.id);
  const docs = db.prepare(`SELECT id, user_id, kind, status, mime, size, reject_reason, expires_at, updated_at FROM translator_documents
    WHERE user_id IN (${ids.map(() => '?').join(',')}) AND status != 'superseded' ORDER BY kind, id`).all(...ids);
  const byUser = new Map();
  const tNow = now();
  for (const d of docs) {
    if (!byUser.has(d.user_id)) byUser.set(d.user_id, []);
    byUser.get(d.user_id).push({ id: d.id, kind: d.kind, status: d.status, mime: d.mime, size: d.size,
      reject_reason: d.reject_reason || '', expires_at: d.expires_at ? new Date(d.expires_at).toISOString() : null,
      expired: !!d.expires_at && d.expires_at < tNow, updated_at: new Date(d.updated_at).toISOString() });
  }
  send(res, 200, { translators: people.map((p) => {
    let pr = {}; try { pr = JSON.parse(p.profile || '{}'); } catch (e) {}
    const selFields = JSON.parse(p.fields || '[]').map((f) => FIELD_ALIAS[f] || f);
    const cert = langCertOk({ user_id: p.id }); // p.user_id به id تغییر نام یافته؛ صریح می‌سازیم
    return { id: p.id, phone: p.phone, status: p.status, name: [pr.first_name, pr.last_name].filter(Boolean).join(' '),
      national_code: pr.national_code || null, birth_date: pr.birth_date || null, iban: pr.iban || null,
      fields: selFields.map((f) => ({ code: f, base: BASE_FIELDS.has(f), selected: true, active: BASE_FIELDS.has(f) || cert })),
      documents: byUser.get(p.id) || [] };
  }), total, limit, offset });
});

route('GET', '/api/admin/documents', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  const status = new URL(req.url, 'http://x').searchParams.get('status') || 'uploaded';
  if (!['uploaded', 'approved', 'rejected'].includes(status)) return send(res, 400, { error: 'invalid_status' });
  const rows = db.prepare(`SELECT d.id, d.user_id, u.phone, d.kind, d.status, d.mime, d.size, d.reject_reason, d.expires_at, d.updated_at
    FROM translator_documents d JOIN users u ON u.id = d.user_id WHERE d.status = ? ORDER BY d.updated_at LIMIT 200`).all(status);
  const expiresIso = (r) => (r.expires_at ? new Date(r.expires_at).toISOString() : null);
  send(res, 200, { documents: rows.map((r) => ({ ...r, expires_at: expiresIso(r), expired: !!r.expires_at && r.expires_at < now(), updated_at: new Date(r.updated_at).toISOString() })) });
});

route('GET', '/api/admin/documents/:id/file', async (req, res, url, params) => {
  if (!requireAdmin(req, res)) return;
  const id = parseId(params.id);
  const row = id && db.prepare('SELECT mime, blob FROM translator_documents WHERE id = ?').get(id);
  if (!row) return send(res, 404, { error: 'not_found' });
  const buf = decryptDoc(row.blob);
  audit('document.view', { id });
  send(res, 200, { mime: row.mime, data: `data:${row.mime};base64,${buf.toString('base64')}` });
});

route('POST', '/api/admin/documents/:id/decision', async (req, res, url, params) => {
  if (!requireAdmin(req, res)) return;
  if (!requirePerm(req, res, 'docs.manage')) return;
  const id = parseId(params.id);
  const b = await readJson(req);
  const d = id && db.prepare('SELECT id, user_id, kind, expires_at FROM translator_documents WHERE id = ?').get(id);
  if (!d) return send(res, 404, { error: 'not_found' });
  if (b.decision === 'approve') {
    if (d.expires_at && d.expires_at < now()) return send(res, 409, { error: 'doc_expired' });
    db.prepare(`UPDATE translator_documents SET status = 'superseded', updated_at = ? WHERE user_id = ? AND kind = ? AND status = 'approved' AND id != ?`).run(now(), d.user_id, d.kind, id);
    db.prepare(`UPDATE translator_documents SET status = 'approved', reject_reason = NULL, updated_at = ? WHERE id = ?`).run(now(), id);
    // تأیید مدرک زبان گیت حوزه‌های تخصصی را باز می‌کند: وضعیت مؤثر فعال‌ها به active_specialized می‌رود
    if (d.kind === 'lang_cert') {
      const tt = db.prepare('SELECT interview FROM translators WHERE user_id = ?').get(d.user_id);
      if (tt && tt.interview === 'pass') db.prepare("UPDATE translators SET status = 'active_specialized', updated_at = ? WHERE user_id = ? AND status LIKE 'active_%'").run(now(), d.user_id);
    }
  } else if (b.decision === 'reject') {
    const reason = clip(b.reason, 200);
    if (!reason) return send(res, 400, { error: 'reason_required' });
    db.prepare(`UPDATE translator_documents SET status = 'rejected', reject_reason = ?, updated_at = ? WHERE id = ?`).run(reason, now(), id);
    const rej = db.prepare(`INSERT OR IGNORE INTO translator_notifications (user_id, doc_id, kind, created_at, ref) VALUES (?, ?, 'doc_rejected', ?, ?)`).run(d.user_id, id, now(), reason);
    if (rej.changes) pushTranslator(d.user_id, { title: 'مدرک رد شد', body: 'مدرک «' + (DOC_NAME_FA[d.kind] || d.kind || '') + '» رد شد: ' + reason + '. مدرک اصلاح‌شده ارسال کنید.', tag: 'doc-' + id + '-rejected' });
    // رد مدرک زبان گیت تخصص را می‌بندد: بازگشت به وضعیت فعال عمومی
    if (d.kind === 'lang_cert') db.prepare("UPDATE translators SET status = 'active_general', updated_at = ? WHERE user_id = ? AND status = 'active_specialized'").run(now(), d.user_id);
  } else return send(res, 400, { error: 'invalid_decision' });
  audit('document.' + b.decision, { id, reason: b.decision === 'reject' ? clip(b.reason, 200) : undefined });
  send(res, 200, { ok: true });
});

// نتیجه‌ی مصاحبه‌ی زبان (کارشناس انسانی): «pass» یا «retry». هر تلاش در تاریخچه ثبت می‌شود (سند ۵).
route('POST', '/api/admin/translators/:id/interview', async (req, res, url, params) => {
  if (!requireAdmin(req, res)) return;
  if (!requirePerm(req, res, 'interviews.manage')) return;
  const id = parseId(params.id);
  const b = await readJson(req);
  const t = id && db.prepare('SELECT status FROM translators WHERE user_id = ?').get(id);
  if (!t) return send(res, 404, { error: 'not_found' });
  if (REG_CLOSED.has(t.status)) return send(res, 409, { error: 'registration_closed', status: t.status });
  if (b.result !== 'pass' && b.result !== 'retry') return send(res, 400, { error: 'invalid_result' });
  db.prepare('UPDATE translators SET interview = ?, updated_at = ? WHERE user_id = ?').run(b.result, now(), id);
  db.prepare('INSERT INTO translator_interviews (user_id, result, created_at) VALUES (?, ?, ?)').run(id, b.result, now());
  send(res, 200, { ok: true, result: b.result });
});

const LANGS = new Set(LANG_CODES);
// ---------- تکسونومی حوزه‌ها و گیت‌های احراز صلاحیت (CAP) ----------
// دو حوزهٔ پایه: بلافاصله پس از قبولی آزمون زبان فعال‌اند (بدون مدرک تخصصی).
// سه حوزهٔ تخصصی: گیت‌شان «مدرک زبان» تأییدشده و اعتباردار است؛ تا آن لحظه مترجم در میز کار است
// ولی درخواست تخصصی نمی‌گیرد. خودرو قابلیت جداگانه است (نه حوزه): گیت‌ش مدارک خودرو/گواهینامه.
const FIELDS = new Set(['tourism', 'pilgrimage', 'medical', 'business', 'legal']);
const FIELDS_ORDER = ['tourism', 'pilgrimage', 'medical', 'business', 'legal'];
const BASE_FIELDS = new Set(['tourism', 'pilgrimage']);
const SPEC_FIELDS = new Set(['medical', 'business', 'legal']);
const FIELD_ALIAS = { general: 'tourism' }; // سازگاری کلاینت‌ها و داده‌های قدیمی
const normField = (f) => (f == null ? null : (FIELD_ALIAS[f] || f));
const FIELD_FA = { tourism: 'گردشگری، تفریحی و خرید', pilgrimage: 'زیارتی و مذهبی', medical: 'درمانی، کلینیکال و پزشکی', business: 'بازرگانی، تجاری و قراردادها', legal: 'حقوقی، اداری و سفارت‌خانه‌ها' };
const GENDER_PREF = new Set(['any', 'female', 'male']); // ترجیح مسافر دربارهٔ جنسیت مترجم
const TRAVELER_GENDER_PREF = new Set(['any', 'female', 'male']); // جنسیت مسافرانی که مترجم می‌پذیرد
const SEARCHABLE = ['searching', 'matching'];
const CANCELLABLE = ['searching', 'waiting_schedule', 'matching', 'unmatched_ask', 'no_match'];

const setStatus = (id, status) => {
  const cur = db.prepare('SELECT status FROM reservations WHERE id = ?').get(id);
  db.prepare('UPDATE reservations SET status = ?, updated_at = ? WHERE id = ?').run(status, now(), id);
  if (!cur || cur.status !== status) revEvent(id, 'status_' + status, 'system', { from: cur ? cur.status : null });
};
const closeOffers = (rid, status = 'withdrawn') =>
  db.prepare("UPDATE offers SET status = ?, decided_at = ? WHERE reservation_id = ? AND status = 'pending'").run(status, now(), rid);

// مترجم‌های آنلاین، فعال، با هر دو زبان؛ کسی که قبلاً پیشنهاد گرفته یا پیشنهاد باز دارد، دوباره نمی‌گیرد.
// ابتدا محدودیت مترجم دربارهٔ جنسیت مسافر بررسی می‌شود؛ سپس ترجیح مسافر دربارهٔ جنسیت مترجم.
function genderOk(r, t) {
  const acceptedTravelerGender = TRAVELER_GENDER_PREF.has(t.traveler_gender_pref) ? t.traveler_gender_pref : 'any';
  if (acceptedTravelerGender !== 'any' && r.traveler_gender !== acceptedTravelerGender) return false;
  if (r.gender_pref === 'female' || r.gender_pref === 'male') return t.gender === r.gender_pref;
  // Preserve the passenger's legacy same-gender fallback only while the translator has no restrictive setting.
  if (acceptedTravelerGender !== 'any' || !r.traveler_gender) return true;
  const sameGender = t.gender && t.gender === r.traveler_gender;
  return !!sameGender || !!t.accept_any;
}
// مدرک زبان تأییدشده و اعتباردار = کلید حوزه‌های تخصصی (CAP). یک مدرک، هر سه حوزهٔ تخصصی انتخابی را باز می‌کند.
function langCertOk(t) {
  return !!db.prepare(`SELECT 1 FROM translator_documents WHERE user_id = ? AND kind = 'lang_cert' AND status = 'approved'
    AND (expires_at IS NULL OR expires_at >= ?)`).get(t.user_id, now());
}
// مترجم در بازه‌ی ±۲ ساعت ماموریت دیگری ندارد
function busyAt(translatorId, startMs, exceptId) {
  return !!db.prepare(`SELECT 1 FROM reservations WHERE translator_id = ? AND status = 'matched' AND id != ?
      AND ABS(COALESCE(scheduled_at, matched_at) - ?) < ?`).get(translatorId, exceptId || 0, startMs, 2 * 3600 * 1000);
}
const startOf = (r) => r.scheduled_at || now();

// همراهی با خودرو فقط وقتی: مترجم خودرو ثبت کرده، و مدارک خودرو و گواهینامه‌اش تأیید شده‌اند (سند ۶.۲).
// مترجم دیگر فقط مأموریت پیاده می‌بیند؛ مأموریت سواره برای او پنهان است.
function carReady(t, party) {
  const p = JSON.parse(t.profile || '{}');
  if (p.car !== true) return false;
  // ظرفیت خودرو باید حداقل به تعداد مسافران باشد (سند ۶.۲)
  if (!p.car_capacity || p.car_capacity < (Number(party) || 1)) return false;
  // انقضا همین لحظه بررسی می‌شود: مدرک منقضی‌شده، حالت خودرو را خاموش می‌کند
  const ok = db.prepare(`SELECT COUNT(*) AS n FROM translator_documents WHERE user_id = ? AND status = 'approved'
    AND kind IN ('car_docs', 'licence') AND (expires_at IS NULL OR expires_at >= ?)`).get(t.user_id, now());
  return ok.n === 2;
}

function eligibleTranslators(r) {
  if (!featureOn('translator_online')) return [];
  // توازن بار (یافتهٔ ۱۲): به‌جای ترتیب ثابت شناسه، مترجمی که دیرترین پیشنهاد را داشته
  // (یا اصلاً پیشنهاد نگرفته — NULL در ASC اول می‌آید) زودتر پیشنهاد می‌گیرد.
  const rows = db.prepare(`SELECT t.user_id, t.langs, t.fields, t.profile, t.gender, t.accept_any, t.traveler_gender_pref,
      t.city_id, t.lat, t.lng, t.share_loc FROM translators t
    JOIN cities c ON c.id = t.city_id AND c.translator_enabled = 1
    WHERE t.city_id = ? AND t.online = 1 AND t.status LIKE 'active_%' AND t.interview = 'pass'
      AND NOT EXISTS (SELECT 1 FROM offers o WHERE o.translator_id = t.user_id AND o.status = 'pending')
      AND NOT EXISTS (SELECT 1 FROM offers o WHERE o.reservation_id = ? AND o.translator_id = t.user_id)
    ORDER BY (SELECT MAX(o2.created_at) FROM offers o2 WHERE o2.translator_id = t.user_id) ASC, t.user_id ASC`).all(r.city_id, r.id);
  return rows.filter((t) => {
    const L = JSON.parse(t.langs);
    const F = JSON.parse(t.fields || '["tourism"]');
    // گیت واقعی حوزه: مترجم فقط درخواست حوزه‌ای می‌گیرد که هم انتخابش کرده باشد، هم گیتش باز باشد
    // (پایه = انتخاب؛ تخصص = + مدرک زبان تأییدشده). «general همیشه باز» دیگر وجود ندارد.
    const rf = FIELD_ALIAS[r.field] || r.field;
    const fieldOk = F.includes(rf) && (BASE_FIELDS.has(rf) || langCertOk(t));
    const carOk = !r.car || carReady(t, r.party);
    // گیت بدهی: تسویه‌نشدهٔ نقدی (سهم پلتفرم دست مترجم است) پیشنهاد جدید نمی‌گیرد
    const debtOk = translatorDebt(t.user_id) <= 0;
    // گیت موقعیت: اگر مختصات رزرو و مترجم هر دو موجود و اشتراک روشن باشد، خارج از شعاع شهر حذف می‌شود؛
    // مترجمِ بی‌موقعیت حذف نمی‌شود (اشتراک موقعیت اختیاری است و نباید او را از چرخه بیندازد).
    let locOk = true;
    if (r.lat != null && r.lng != null && t.share_loc === 1 && t.lat != null && t.lng != null) {
      const city = db.prepare('SELECT radius_km FROM cities WHERE id = ?').get(t.city_id);
      const R = (city ? city.radius_km : 30) * 1000;
      const dLat = (t.lat - r.lat) * Math.PI / 180, dLng = (t.lng - r.lng) * Math.PI / 180;
      const a = Math.sin(dLat / 2) ** 2 + Math.cos(r.lat * Math.PI / 180) * Math.cos(t.lat * Math.PI / 180) * Math.sin(dLng / 2) ** 2;
      locOk = 6371000 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a)) <= R;
    }
    return L.includes(r.origin_lang) && L.includes(r.dest_lang) && fieldOk && carOk && debtOk && locOk && genderOk(r, t) && !busyAt(t.user_id, startOf(r), r.id);
  });
}

// اگر پیشنهاد بازی نیست، به نفر بعدی پیشنهاد بده
function offerNext(r) {
  if (!SEARCHABLE.includes(r.status)) return;
  if (db.prepare("SELECT 1 FROM offers WHERE reservation_id = ? AND status = 'pending'").get(r.id)) return;
  const c = eligibleTranslators(r)[0];
  if (!c) return;
  db.prepare('INSERT INTO offers (reservation_id, translator_id, status, expires_at, created_at) VALUES (?, ?, ?, ?, ?)')
    .run(r.id, c.user_id, 'pending', now() + TIMING.OFFER_MS, now());
  // اعلان فوری «درخواست جدید»: کاربرد اصلی پوش — مترجم حتی با اپ بسته می‌فهمد
  pushTranslator(c.user_id, { title: 'درخواست جدید همراه',
    body: 'حوزه‌ی ' + (FIELD_FA[normField(r.field)] || 'همراهی') + ' — ' + (r.place || 'محل توافقی') + '؛ برای پذیرش به میز کار بروید.',
    tag: 'offer-' + r.id });
}

// موتور تطبیق: پیشنهادهای منقضی، سقف جستجو، و مرحله‌های زمان‌دار
const INTERVIEW_MIN = 10;          // مدت مصاحبه‌ی زنده (سند ۵)
// اتاق ویدئویی درون‌برنامه‌ای وجود ندارد؛ هماهنگی مصاحبه با یادداشت مدیر انجام می‌شود
const INTERVIEW_REMINDER_MS = 60 * 60 * 1000; // یادآوری یک ساعت قبل از نوبت
// ---------- اعلان فوری (Web Push + VAPID) ----------
// کلیدهای VAPID: اولویت با متغیر محیطی (HZ_VAPID_PUBLIC_KEY / HZ_VAPID_PRIVATE_KEY)؛
// در نبودِ آن‌ها، جفت‌کلید یک‌بار تولید و در جدول settings ذخیره می‌شود.
function vapidDetails() {
  const pub = process.env.HZ_VAPID_PUBLIC_KEY || settingRaw('vapid_public');
  const priv = process.env.HZ_VAPID_PRIVATE_KEY || settingRaw('vapid_private');
  if (!pub || !priv) return null;
  return { publicKey: pub, privateKey: priv };
}
function ensureVapid() {
  if (!webpush) return;
  if (process.env.HZ_VAPID_PUBLIC_KEY && process.env.HZ_VAPID_PRIVATE_KEY) return;
  if (settingRaw('vapid_public') && settingRaw('vapid_private')) return;
  const k = webpush.generateVAPIDKeys();
  const up = db.prepare('INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value');
  up.run('vapid_public', k.publicKey);
  up.run('vapid_private', k.privateKey);
  console.log('[push] کلیدهای VAPID تولید و ذخیره شد.');
}
ensureVapid();

// ارسال پوش آتش‌وفراموش: خطای هر اشتراک هرگز جریان درخواست را نمی‌شکند؛
// اشتراک ۴۰۴/۴۱۰ (منقضی/حذف‌شده) از پایگاه داده پاک می‌شود.
function pushUser(userId, payload) {
  if (!webpush) return;
  const d = vapidDetails();
  if (!d) return;
  const rows = db.prepare('SELECT * FROM push_subscriptions WHERE user_id = ? ORDER BY id LIMIT 15').all(userId);
  if (!rows.length) return;
  const msg = JSON.stringify({
    title: String(payload.title || 'همراه').slice(0, 120),
    body: String(payload.body || '').slice(0, 300),
    url: payload.url || '/traveler/app.html', tag: payload.tag || undefined
  });
  for (const s of rows) {
    webpush.sendNotification({ endpoint: s.endpoint, keys: { p256dh: s.p256dh, auth: s.auth } }, msg, { vapidDetails: d, TTL: 3600 })
      .then(() => db.prepare('UPDATE push_subscriptions SET last_sent_at = ?, last_error = NULL WHERE id = ?').run(now(), s.id))
      .catch((e) => {
        const code = e && e.statusCode;
        if (code === 404 || code === 410) db.prepare('DELETE FROM push_subscriptions WHERE id = ?').run(s.id);
        else db.prepare('UPDATE push_subscriptions SET last_error = ? WHERE id = ?').run(clip(String((e && e.message) || code || 'send_failed'), 200), s.id);
      });
  }
}
const pushTraveler = (userId, p) => pushUser(userId, Object.assign({ url: '/traveler/app.html' }, p));
const pushTranslator = (userId, p) => pushUser(userId, Object.assign({ url: '/translator/app.html' }, p));

// اعلان ثبت‌شدهٔ مسافر (بدون پوش) — برای تاریخچه و واکشی اپ
function notifyTraveler(userId, reservationId, kind, text) {
  if (!userId) return;
  db.prepare('INSERT INTO traveler_notifications (user_id, reservation_id, kind, text, created_at) VALUES (?, ?, ?, ?, ?)')
    .run(userId, reservationId || null, kind, text, now());
}

const DOC_NAME_FA = { car_docs: 'مدارک خودرو (بیمه‌نامه)', licence: 'گواهینامه‌ی رانندگی', ipd_permit: 'مجوز ورود IPD',
  criminal_record: 'گواهی عدم سوءپیشینه', lang_cert: 'مدرک زبان' };
function notifyExpiry(t) {
  const soon = db.prepare(`SELECT id, user_id, kind, expires_at FROM translator_documents
    WHERE status = 'approved' AND expires_at IS NOT NULL AND expires_at <= ?`).all(t + 30 * DAY_MS);
  const ins = db.prepare('INSERT OR IGNORE INTO translator_notifications (user_id, doc_id, kind, created_at) VALUES (?, ?, ?, ?)');
  for (const d of soon) {
    const k = d.expires_at < t ? 'expired' : 'expiring';
    const done = ins.run(d.user_id, d.id, k, t);
    if (!done.changes) continue; // قبلاً ثبت شده؛ پوش تکراری نفرستیم (sweep مداوم اجرا می‌شود)
    const name = DOC_NAME_FA[d.kind] || d.kind;
    pushTranslator(d.user_id, k === 'expired'
      ? { title: 'مدرک منقضی شد', body: 'اعتبار مدرک «' + name + '» تمام شده است؛ مدرک جدید ارسال کنید.', tag: 'doc-' + d.id + '-expired' }
      : { title: 'مدرک به‌زودی منقضی می‌شود', body: 'اعتبار مدرک «' + name + '» ۳۰ روز دیگر تمام می‌شود؛ مدرک جدید ارسال کنید.', tag: 'doc-' + d.id + '-expiring' });
  }
}

function notifyInterviews(t) {
  const due = db.prepare(`SELECT id, booked_user_id FROM interview_slots WHERE status = 'booked' AND booked_user_id IS NOT NULL
    AND starts_at - ? <= ? AND starts_at + ? > ?`).all(INTERVIEW_REMINDER_MS, t, INTERVIEW_MIN * 60000, t);
  for (const sl of due) {
    const ref = 'slot:' + sl.id;
    const done = db.prepare(`INSERT INTO translator_notifications (user_id, kind, created_at, ref)
      SELECT ?, 'interview_reminder', ?, ? WHERE NOT EXISTS (SELECT 1 FROM translator_notifications WHERE user_id = ? AND kind = 'interview_reminder' AND ref = ?)`)
      .run(sl.booked_user_id, t, ref, sl.booked_user_id, ref);
    if (done.changes) pushTranslator(sl.booked_user_id, { title: 'یادآوری مصاحبه', body: 'زمان و هماهنگی نوبت مصاحبه‌ی زبان را در بخش مصاحبه ببینید.', tag: 'interview-' + sl.id });
  }
}

function sweep() {
  const t = now();
  // پاک‌سازی ردیف‌های منقضی (یافتهٔ ۱۱): تا پیش از این نشست‌های منقضی فقط هنگام دسترسی حذف می‌شدند
  // و ردیف‌های بلااستفاده برای همیشه می‌ماندند. کد OTP منقضی هم حذف می‌شود؛ قفل فعال باقی می‌ماند.
  db.prepare('DELETE FROM sessions WHERE expires_at < ?').run(t);
  db.prepare('DELETE FROM admin_sessions WHERE expires_at < ?').run(t);
  db.prepare('DELETE FROM otp_codes WHERE expires_at < ? AND (locked_until IS NULL OR locked_until <= ?)').run(t, t);
  notifyExpiry(t);
  notifyInterviews(t);
  db.prepare("UPDATE offers SET status = 'expired', decided_at = ? WHERE status = 'pending' AND expires_at <= ?").run(t, t);
  db.prepare("UPDATE change_requests SET status = 'expired', decided_at = ? WHERE status = 'pending' AND expires_at <= ?").run(t, t);
  db.prepare("UPDATE extension_requests SET status = 'expired', decided_at = ? WHERE status = 'pending' AND expires_at <= ?").run(t, t);
  const list = db.prepare("SELECT * FROM reservations WHERE status IN ('searching','waiting_schedule','matching','unmatched_ask')").all();
  for (const r of list) {
    if (r.kind === 'instant' && r.status === 'searching' && t - r.search_started_at >= TIMING.INSTANT_SEARCH_MS) {
      setStatus(r.id, 'no_match'); closeOffers(r.id); continue;
    }
    if (r.kind === 'scheduled') {
      if (t >= r.scheduled_at) {
        // اگر تا لحظه‌ی قرار تطبیق نشده، چه در انتظار و چه در جستجوی دوباره، لغو خودکار و رایگان
        setStatus(r.id, 'cancelled'); closeOffers(r.id); continue;
      }
      if (r.status === 'waiting_schedule' && t >= r.scheduled_at - TIMING.SCHEDULE_MATCH_BEFORE_MS) {
        setStatus(r.id, 'matching');
      // search_started_at پس از آستانه یعنی مسافر «تلاش دوباره» را زده؛ جست‌وجو تا موعد ادامه می‌یابد.
      } else if (r.status === 'matching' && t >= r.scheduled_at - TIMING.SCHEDULE_ASK_BEFORE_MS
        && r.search_started_at < r.scheduled_at - TIMING.SCHEDULE_ASK_BEFORE_MS) {
        setStatus(r.id, 'unmatched_ask'); closeOffers(r.id);
      }
    }
  }
  for (const r of db.prepare("SELECT * FROM reservations WHERE status IN ('searching','matching')").all()) offerNext(r);
}

// نام و خودروی مترجمِ تطبیق‌یافته برای نمایش به مسافر (از پروفایل ثبت‌نامی؛ بدون داده‌ی خصوصی)
function matchedTranslatorInfo(r) {
  if (!r.translator_id) return { translator_name: null, translator_car: null };
  const t = db.prepare('SELECT profile FROM translators WHERE user_id = ?').get(r.translator_id);
  let p = {}; try { p = JSON.parse((t && t.profile) || '{}'); } catch (e) {}
  return {
    translator_name: [p.first_name, p.last_name].filter(Boolean).join(' ') || null,
    translator_car: p.car_model || null,
  };
}

// کد امنیتی شروع خدمت در پایگاه داده رمزنگاری‌شده نگه داشته می‌شود (AES-256-GCM با همان کلید مدارک)؛
// فقط مسافرِ صاحب رزرو آن را از سرور می‌گیرد. ردیف‌های قدیمیِ متن ساده هم خوانده می‌شوند تا رزرو باز خراب نشود.
const SERVICE_CODE_PREFIX = 'enc1:';
function encryptServiceCode(code) {
  return SERVICE_CODE_PREFIX + encryptDoc(Buffer.from(String(code), 'utf8')).toString('base64');
}
function plainServiceCode(r) {
  const raw = r && r.service_code;
  if (!raw) return null;
  if (!String(raw).startsWith(SERVICE_CODE_PREFIX)) return String(raw); // رزرو قدیمی پیش از رمزنگاری
  try { return decryptDoc(Buffer.from(String(raw).slice(SERVICE_CODE_PREFIX.length), 'base64')).toString('utf8'); }
  catch (e) { return null; }
}

// نمای مسافر از یک رزرو (بدون اطلاعات داخلی)
function reservationView(r) {
  return {
    id: r.id, kind: r.kind, status: r.status,
    origin_lang: r.origin_lang, dest_lang: r.dest_lang, field: r.field,
    place: r.place, notes: r.notes, gender_pref: r.gender_pref, hours: r.hours,
    scheduled_at: r.scheduled_at ? new Date(r.scheduled_at).toISOString() : null,
    total: r.total, base: r.base == null ? undefined : r.base, tax: r.tax == null ? undefined : r.tax,
    billed_hours: r.billed_hours == null ? undefined : r.billed_hours,
    list_total: r.list_total == null ? undefined : r.list_total,
    matched: !!r.translator_id, cancel_after_match: !!r.cancel_after_match,
    ...matchedTranslatorInfo(r),
    pay_method: r.pay_method || null, pay_state: r.pay_state || null,
    service_code: plainServiceCode(r),
    service_started: !!r.service_started_at,
    service_started_at: r.service_started_at ? new Date(r.service_started_at).toISOString() : null,
    finished_at: r.finished_at ? new Date(r.finished_at).toISOString() : null,
    finish_requested: !!r.finish_requested_at,
    finished_by: r.finished_by || null,
    lat: r.lat == null ? null : r.lat, lng: r.lng == null ? null : r.lng,
    created_at: r.created_at,
    pending_change: pendingChangeOf(r.id),
    pending_extension: pendingExtensionOf(r.id),
    last_extension_status: lastExtensionStatusOf(r.id),
  };
}
function pendingChangeOf(rid) {
  const pc = db.prepare("SELECT id, changes, expires_at FROM change_requests WHERE reservation_id = ? AND status = 'pending'").get(rid);
  return pc ? { id: pc.id, changes: JSON.parse(pc.changes), expires_at: new Date(pc.expires_at).toISOString() } : null;
}
function pendingExtensionOf(rid) {
  const pe = db.prepare("SELECT id, extra_hours, extra_base, extra_tax, expires_at FROM extension_requests WHERE reservation_id = ? AND status = 'pending'").get(rid);
  return pe ? { id: pe.id, extra_hours: pe.extra_hours, extra_total: pe.extra_base + pe.extra_tax, expires_at: new Date(pe.expires_at).toISOString() } : null;
}
function lastExtensionStatusOf(rid) {
  const le = db.prepare('SELECT status FROM extension_requests WHERE reservation_id = ? ORDER BY id DESC LIMIT 1').get(rid);
  return le ? le.status : null;
}

function activeTranslator(res, u) {
  const t = db.prepare('SELECT status FROM translators WHERE user_id = ?').get(u.id);
  if (!t || !t.status.startsWith('active_')) { send(res, 403, { error: 'not_active' }); return false; }
  return true;
}
const parseId = (v) => { const n = Number(v); return Number.isInteger(n) && n > 0 ? n : null; };

// ---------- مسافر: رزرو ----------
// سقف یکسان مدت خدمت برای ایجاد و ویرایش؛ با سقف تمدید (EXTENSION_MAX_HOURS = 12) هم‌راستاست
// تا «مدت کل خدمت» در همهٔ مسیرها یکسان اعتبارسنجی شود (یافتهٔ ۶). ساعت همیشه صحیح است.
const DURATION_MIN_H = 1;
const DURATION_MAX_H = 12;

route('GET', '/api/traveler/bookings', async (req, res) => {
  const u = requireUser(req, res, 'traveler'); if (!u) return;
  const rows = db.prepare('SELECT * FROM reservations WHERE traveler_id = ? ORDER BY created_at DESC').all(u.id);
  send(res, 200, { bookings: rows.map(reservationView) });
});

route('POST', '/api/traveler/bookings', async (req, res) => {
  const u = requireUser(req, res, 'traveler'); if (!u) return;
  // گارد مسدودسازی (نسل دوم پنل): کارشناس عملیات حساب سوءاستفاده‌گر را مسدود می‌کند؛
  // مسافر مسدود هیچ رزرو جدیدی نمی‌تواند ثبت کند (مأموریت جاری از طرف سرور لغو نمی‌شود).
  const meRow = db.prepare('SELECT blocked FROM users WHERE id = ?').get(u.id);
  if (meRow && meRow.blocked) return send(res, 403, { error: 'account_blocked' });
  const b = await readJson(req, 64 * 1024);
  const kind = b.kind === 'scheduled' ? 'scheduled' : b.kind === 'instant' ? 'instant' : null;
  if (!kind) return send(res, 400, { error: 'invalid_kind' });
  if (!requireFeature(res, 'traveler_booking')) return;
  if (!requireFeature(res, kind === 'instant' ? 'instant_booking' : 'scheduled_booking')) return;
  // گارد رزرو فوری همپوشان (کلید ادمین single_active_instant): اگر مسافر مأموریت فعالی در جریان دارد،
  // رزرو فوری دوم ثبت نمی‌شود تا دو مترجم هم‌زمان برای یک مسافر اعزام نشوند. وضعیت‌های «در جریان»:
  // searching (در جست‌وجوی مترجم)، matching (زمان‌دار نزدیک موعد) و matched (مترجم متصل است).
  // توجه: «در انتظار پاسخ تغییر» وضعیت رزرو نیست (در جدول change_requests زندگی می‌کند)؛
  // waiting_schedule و unmatched_ask آینده‌اند و مسیر را نمی‌بندند؛ no_match/finished/cancelled مأموریت جاری نیستند.
  if (kind === 'instant' && featureOn('single_active_instant')) {
    const busy = db.prepare(`SELECT id, status FROM reservations
      WHERE traveler_id = ? AND status IN ('searching','matching','matched')
      ORDER BY id DESC LIMIT 1`).get(u.id);
    if (busy) return send(res, 409, { error: 'overlapping_instant', reservation_id: busy.id, active_status: busy.status });
  }
  if (b.car && !requireFeature(res, 'car_mode')) return;
  const cityRes = resolveCity(b.city_id, 'traveler');
  if (cityRes.error) return send(res, cityRes.status, { error: cityRes.error });
  if (!LANGS.has(b.origin_lang) || !LANGS.has(b.dest_lang)) return send(res, 400, { error: 'invalid_language' });
  // حوزهٔ خدمت: صریح از مسافر، وگرنه از دستهٔ تعرفه‌ای؛ مقدار قدیمی general به tourism نگاشت می‌شود
  const field = normField(b.field) || (FIELDS.has(b.category) ? b.category : 'tourism');
  if (!FIELDS.has(field)) return send(res, 400, { error: 'invalid_field' });
  const place = String(b.place || '').trim();
  if (!place || place.length > 200) return send(res, 400, { error: 'invalid_place' });
  // مختصات محل ملاقات (از نقشه‌ی اپ مسافر)؛ اگر فرستاده شده باشد باید معتبر باشد تا مترجم بتواند مسیریابی کند.
  let lat = null, lng = null;
  if (b.lat !== undefined && b.lat !== null && b.lng !== undefined && b.lng !== null) {
    lat = Number(b.lat); lng = Number(b.lng);
    if (!Number.isFinite(lat) || !Number.isFinite(lng) || lat < -90 || lat > 90 || lng < -180 || lng > 180) {
      return send(res, 400, { error: 'invalid_coords' });
    }
  }
  // جیوفنس پوشش سرویس (منطق تحقیق‌شدهٔ شهر/شعاع): اگر مختصات آمده، شهرِ مسئول از هندسهٔ دایره‌های پوشش
  // تعیین می‌شود تا رزرو به شهرِ واقعی نقطه برود و تطبیق هم‌شهری معنا پیدا کند. اگر نقطه داخل هیچ
  // دایره‌ای نیست، شهر درخواستی می‌ماند و رویداد «بیرون از پوشش» برای پیگیری پنل ثبت می‌شود.
  const city = cityRes.city;
  let geoEvent = null;
  if (lat !== null && lng !== null) {
    const fence = cityCoveringPoint(lat, lng);
    if (fence && fence.id !== city.id && fence.traveler_enabled === 1) {
      const fc = db.prepare('SELECT id, name_fa FROM cities WHERE id = ? AND traveler_enabled = 1').get(fence.id);
      if (fc) geoEvent = { event: 'city_geofenced', detail: { from: city.id, from_name: city.name_fa, to: fc.id, to_name: fc.name_fa, lat, lng } };
    } else if (!fence) {
      geoEvent = { event: 'outside_coverage', detail: { city_id: city.id, lat, lng } };
    }
  }
  const finalCity = geoEvent && geoEvent.event === 'city_geofenced'
    ? db.prepare('SELECT id FROM cities WHERE id = ?').get(geoEvent.detail.to) : city;
  const notes = String(b.notes || '').slice(0, 500);
  const gender = GENDER_PREF.has(b.gender_pref) ? b.gender_pref : 'any';
  const travelerGender = b.traveler_gender === 'male' || b.traveler_gender === 'female' ? b.traveler_gender : null;
  const hours = Math.min(Math.max(Math.trunc(Number(b.hours)) || 1, DURATION_MIN_H), DURATION_MAX_H);
  const car = b.car ? 1 : 0;
  const category = Object.keys(getJsonSetting('hourly_tariffs')).includes(b.category) ? b.category : 'tourism';
  const party = Math.min(Math.max(Number(b.party) || 1, 1), 20);
  let scheduledAt = null;
  if (kind === 'scheduled') {
    scheduledAt = Date.parse(b.scheduled_at);
    if (!Number.isFinite(scheduledAt)) return send(res, 400, { error: 'invalid_time' });
    if (scheduledAt - now() < TIMING.SCHEDULE_MIN_LEAD_MS) return send(res, 400, { error: 'too_soon' });
  }
  const t = now();
  // خدمت قبل از مالیات است؛ مالیات روی خدمت محاسبه و همراه با آن ذخیره می‌شود (سند ۷.۳)
  const tariffs = getJsonSetting('hourly_tariffs');
  const hourlyRate = tariffs[category];
  const base = (hourlyRate + car * getSetting('car_fee_per_hour')) * hours;
  const tax = Math.round(base * PRICING.TAX_PERCENT / 100);
  const status = kind === 'instant' ? 'searching' : 'waiting_schedule';
  // کد امنیتی شروع خدمت را سرور صادر می‌کند (۵ رقم)؛ مسافر هنگام شروع آن را به مترجم اعلام می‌کند.
  const serviceCode = String(crypto.randomInt(10000, 100000));
  const info = db.prepare(`INSERT INTO reservations (traveler_id, kind, origin_lang, dest_lang, field, place, notes, traveler_name, gender_pref,
      scheduled_at, status, search_started_at, total, net, created_at, updated_at, traveler_gender, hours, car, party, base, tax, city_id, service_code, lat, lng)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
    .run(u.id, kind, b.origin_lang, b.dest_lang, field, place, notes, String(b.traveler_name || '').slice(0, 80), gender,
      scheduledAt, status, t, base + tax, Math.round(base * PRICING.TRANSLATOR_SHARE), t, t,
      travelerGender, hours, car, party, base, tax, finalCity.id, encryptServiceCode(serviceCode), lat, lng);
  revEvent(info.lastInsertRowid, 'created', 'traveler', { kind, status, total: base + tax });
  if (geoEvent) revEvent(info.lastInsertRowid, geoEvent.event, 'system', geoEvent.detail);
  sweep();
  const row = db.prepare('SELECT * FROM reservations WHERE id = ?').get(info.lastInsertRowid);
  send(res, 201, reservationView(row));
});

function ownReservation(res, u, params) {
  const id = parseId(params.id);
  const r = id && db.prepare('SELECT * FROM reservations WHERE id = ? AND traveler_id = ?').get(id, u.id);
  if (!r) { send(res, 404, { error: 'not_found' }); return null; }
  return r;
}

route('POST', '/api/traveler/bookings/:id/cancel', async (req, res, url, params) => {
  const u = requireUser(req, res, 'traveler'); if (!u) return;
  const r = ownReservation(res, u, params); if (!r) return;
  if (!CANCELLABLE.includes(r.status) && r.status !== 'matched') return send(res, 409, { error: 'not_cancellable' });
  if (r.service_started_at) return send(res, 409, { error: 'service_already_started' });
  const afterMatch = r.status === 'matched';
  db.prepare('UPDATE reservations SET status = ?, cancel_after_match = ?, updated_at = ? WHERE id = ?')
    .run('cancelled', afterMatch ? 1 : 0, now(), r.id);
  revEvent(r.id, 'cancelled', 'traveler', { fee_percent: afterMatch ? PRICING.CANCEL_FEE_PERCENT : 0, from: r.status });
  closeOffers(r.id);
  if (r.translator_id) {
    // اعلان لغو مسافر برای مترجم: ماموریتی که حذف شده را باید بداند
    db.prepare("INSERT INTO translator_notifications (user_id, kind, created_at, ref) VALUES (?, 'booking_cancelled', ?, ?)").run(r.translator_id, now(), String(r.id));
    pushTranslator(r.translator_id, { title: 'رزرو لغو شد', body: 'مسافر، رزرو «' + (r.place || '') + '» را لغو کرد؛ این ماموریت از فهرست شما حذف شد.', tag: 'cancel-' + r.id });
  }
  send(res, 200, { ok: true, fee_percent: afterMatch ? PRICING.CANCEL_FEE_PERCENT : 0 });
});

route('POST', '/api/traveler/bookings/:id/retry', async (req, res, url, params) => {
  const u = requireUser(req, res, 'traveler'); if (!u) return;
  const r = ownReservation(res, u, params); if (!r) return;
  if (r.status === 'no_match' && r.kind === 'instant') {
    db.prepare("UPDATE reservations SET status = 'searching', search_started_at = ?, updated_at = ? WHERE id = ?").run(now(), now(), r.id);
    revEvent(r.id, 'retried', 'traveler', { from: 'no_match' });
  } else if (r.status === 'unmatched_ask' && r.kind === 'scheduled' && now() < r.scheduled_at) {
    const t = now();
    db.prepare("UPDATE reservations SET status = 'matching', search_started_at = ?, updated_at = ? WHERE id = ?").run(t, t, r.id);
    revEvent(r.id, 'retried', 'traveler', { from: 'unmatched_ask' });
  } else return send(res, 409, { error: 'retry_not_allowed' });
  sweep();
  send(res, 200, { ok: true });
});

route('POST', '/api/traveler/bookings/:id/convert', async (req, res, url, params) => {
  const u = requireUser(req, res, 'traveler'); if (!u) return;
  if (!requireFeature(res, 'booking_convert')) return;
  const r = ownReservation(res, u, params); if (!r) return;
  if (!(r.status === 'no_match' && r.kind === 'instant')) return send(res, 409, { error: 'convert_not_allowed' });
  const b = await readJson(req);
  const at = Date.parse(b.scheduled_at);
  if (!Number.isFinite(at)) return send(res, 400, { error: 'invalid_time' });
  if (at - now() < TIMING.SCHEDULE_MIN_LEAD_MS) return send(res, 400, { error: 'too_soon' });
  db.prepare("UPDATE reservations SET kind = 'scheduled', scheduled_at = ?, status = 'waiting_schedule', updated_at = ? WHERE id = ?").run(at, now(), r.id);
  revEvent(r.id, 'converted', 'traveler', { scheduled_at: at });
  sweep();
  send(res, 200, { ok: true });
});

// ---------- پایان خدمت و پرداخت (سند ۷.۳ و تصمیم‌های ۴۷ و ۴۸) ----------
// روش‌های پرداخت را مدیر فعال می‌کند؛ پرداخت آنلاین هنوز درگاه واقعی ندارد (شبیه‌سازی).

function settleIfBoth(r) {
  const t = now();
  if (r.traveler_paid && r.translator_confirmed) {
    db.prepare("UPDATE reservations SET pay_state = 'settled', status = 'done', updated_at = ? WHERE id = ?").run(t, r.id);
    revEvent(r.id, 'settled', 'system', { method: r.pay_method || null });
    if (r.pay_method === 'cash') onCashSettled(r);
    return true;
  }
  return false;
}

// ---------- بدهی نقدی مترجم به پلتفرم ----------
// در پرداخت نقدی، کل مبلغ دست مترجم می‌ماند؛ سهم پلتفرم (total − net) بدهی او می‌شود.
// تا وقتی بدهی تسویه نشده، پیشنهاد جدیدی به او نمی‌رود (گیت در eligibleTranslators).
function translatorDebt(uid) {
  const earned = db.prepare("SELECT COALESCE(SUM(total - net), 0) s FROM reservations WHERE translator_id = ? AND status = 'done' AND pay_state = 'settled' AND pay_method = 'cash'").get(uid).s;
  const paid = db.prepare('SELECT COALESCE(SUM(amount), 0) s FROM debt_payments WHERE translator_id = ?').get(uid).s;
  return Math.max(0, earned - paid);
}
// اعلان بدهی تازه — هر رزرو فقط یک‌بار (ref یکتا در متن اعلان)
function onCashSettled(r) {
  const owed = r.total - r.net;
  if (owed <= 0) return;
  const dup = db.prepare("SELECT 1 FROM translator_notifications WHERE kind = 'debt_new' AND ref = ?").get(String(r.id));
  if (dup) return;
  db.prepare("INSERT INTO translator_notifications (user_id, kind, ref, created_at) VALUES (?, 'debt_new', ?, ?)").run(r.translator_id, String(r.id), now());
  const fmt = (n) => String(n).replace(/\B(?=(\d{3})+(?!\d))/g, '،');
  pushTranslator(r.translator_id, { title: 'بدهی سهم پلتفرم ثبت شد',
    body: 'بابت رزرو نقدی #' + r.id + ' مبلغ ' + fmt(owed) + ' تومان به پلتفرم بدهکارید؛ تا تسویه، درخواست جدیدی نمی‌بینید.', tag: 'debt-' + r.id });
}

// مترجم کد امنیتی شروع خدمت را از مسافر می‌گیرد و ثبت می‌کند؛ شروع خدمت فقط با کد درست ممکن است.
// پس از ۵ کد اشتباه، بررسی کد برای این رزرو قفل می‌شود و پرونده باید از پشتیبانی پیگیری شود.
// Private canonical state for service-control reconciliation. Never expose the passenger's code.
route('GET', '/api/translator/missions/:id', async (req, res, url, params) => {
  const u = requireUser(req, res, 'translator'); if (!u) return;
  if (!activeTranslator(res, u)) return;
  const id = parseId(params.id);
  const r = id && db.prepare('SELECT * FROM reservations WHERE id = ? AND translator_id = ?').get(id, u.id);
  if (!r) return send(res, 404, { error: 'not_found' });
  send(res, 200, { reservation_id: r.id, status: r.status, started: !!r.service_started_at,
    arrived_at: r.translator_arrived_at ? new Date(r.translator_arrived_at).toISOString() : null,
    service_started_at: r.service_started_at ? new Date(r.service_started_at).toISOString() : null,
    finish_requested: !!r.finish_requested_at, hours: r.hours, total: r.total, net: r.net,
    pay_method: r.pay_method || null, pay_state: r.pay_state || null,
    confirmed: !!r.translator_confirmed, traveler_paid: !!r.traveler_paid,
    details: { scheduled_at: r.scheduled_at || null, place: r.place, origin_lang: r.origin_lang, dest_lang: r.dest_lang,
      field: r.field, hours: r.hours, car: r.car, party: r.party, gender_pref: r.gender_pref, notes: r.notes } });
});

// Manual arrival receipt: this records the translator's report only; it never reads GPS or fabricates coordinates.
route('POST', '/api/translator/missions/:id/arrive', async (req, res, url, params) => {
  const u = requireUser(req, res, 'translator'); if (!u) return;
  if (!activeTranslator(res, u)) return;
  const id = parseId(params.id);
  const r = id && db.prepare("SELECT id, status, scheduled_at, translator_arrived_at, service_started_at FROM reservations WHERE id = ? AND translator_id = ?").get(id, u.id);
  if (!r) return send(res, 404, { error: 'not_found' });
  if (r.status !== 'matched' || r.service_started_at || (r.scheduled_at && now() < r.scheduled_at)) return send(res, 409, { error: 'arrival_not_allowed' });
  if (r.translator_arrived_at) return send(res, 200, { ok: true, already_arrived: true, arrived_at: new Date(r.translator_arrived_at).toISOString() });
  const t = now();
  const result = db.prepare("UPDATE reservations SET translator_arrived_at = ?, updated_at = ? WHERE id = ? AND translator_id = ? AND status = 'matched' AND translator_arrived_at IS NULL AND service_started_at IS NULL")
    .run(t, t, id, u.id);
  if (result.changes !== 1) return send(res, 409, { error: 'arrival_not_allowed' });
  send(res, 200, { ok: true, already_arrived: false, arrived_at: new Date(t).toISOString() });
});

route('POST', '/api/translator/missions/:id/verify-code', async (req, res, url, params) => {
  const u = requireUser(req, res, 'translator'); if (!u) return;
  if (!activeTranslator(res, u)) return;
  const id = parseId(params.id);
  const r = id && db.prepare("SELECT * FROM reservations WHERE id = ? AND translator_id = ? AND status = 'matched'").get(id, u.id);
  if (!r) return send(res, 404, { error: 'not_found' });
  if (r.service_started_at) return send(res, 200, { ok: true, already_started: true });
  if (!r.translator_arrived_at) return send(res, 409, { error: 'arrival_required' });
  if (r.scheduled_at && now() < r.scheduled_at) return send(res, 409, { error: 'too_early' });
  const storedCode = plainServiceCode(r);
  if (!storedCode) return send(res, 409, { error: 'no_service_code' });
  if ((r.service_code_attempts || 0) >= 5) return send(res, 423, { error: 'code_locked' });
  const b = await readJson(req);
  const code = String(b.code || '').replace(/[۰-۹]/g, (d) => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d)).replace(/[٠-٩]/g, (d) => '٠١٢٣٤٥٦٧٨٩'.indexOf(d)).replace(/\D/g, '');
  const given = Buffer.from(code);
  const want = Buffer.from(storedCode);
  if (given.length !== want.length || !crypto.timingSafeEqual(given, want)) {
    const attempts = (r.service_code_attempts || 0) + 1;
    db.prepare('UPDATE reservations SET service_code_attempts = ?, updated_at = ? WHERE id = ?').run(attempts, now(), r.id);
    return send(res, 401, { error: 'wrong_code', attempts_left: Math.max(0, 5 - attempts) });
  }
  db.prepare('UPDATE reservations SET service_started_at = ?, service_code_attempts = 0, updated_at = ? WHERE id = ?').run(now(), now(), r.id);
  revEvent(r.id, 'service_started', 'translator', {});
  send(res, 200, { ok: true, started: true });
});

// مترجم به‌تنهایی خدمت را تمام نمی‌کند؛ فقط «درخواست پایان» می‌فرستد و مسافر باید قبول کند.
// (پایان زودهنگام از سمت مترجم هم فقط در حد درخواست است؛ قبول یا رد با مسافر است.)
route('POST', '/api/translator/missions/:id/finish', async (req, res, url, params) => {
  const u = requireUser(req, res, 'translator'); if (!u) return;
  if (!activeTranslator(res, u)) return;
  const id = parseId(params.id);
  const r = id && db.prepare("SELECT * FROM reservations WHERE id = ? AND translator_id = ? AND status = 'matched'").get(id, u.id);
  if (!r) return send(res, 404, { error: 'not_found' });
  // درخواست پایان پیش از زمان قرار (رزرو زمان‌دار) ممکن نیست
  if (r.scheduled_at && now() < r.scheduled_at) return send(res, 409, { error: 'too_early' });
  // درخواست پایان فقط پس از شروع خدمت با کد امنیتی مسافر
  if (r.service_code && !r.service_started_at) return send(res, 409, { error: 'not_started' });
  if (r.finish_requested_at) return send(res, 202, { ok: true, pending_finish: true, already_requested: true });
  db.prepare('UPDATE reservations SET finish_requested_at = ?, updated_at = ? WHERE id = ?').run(now(), now(), r.id);
  revEvent(r.id, 'finish_requested', 'translator', {});
  send(res, 202, { ok: true, pending_finish: true });
});

// صورت‌حساب بر اساس مدت واقعی خدمت (قاعدهٔ کاربر):
// هر ساعتِ شروع‌شده محاسبه می‌شود؛ کف یک ساعت؛ مبنای شروع، ثبت کد امنیتی خدمت است (بی‌کد: لحظهٔ تطبیق).
// مبلغِ بیش از مدت رزرو هم با همین قاعده ادامه می‌یابد (اضافه‌خدمت هر ساعت شروع‌شده حساب می‌شود).
function quoteFor(hours, field, car) {
  const f = FIELD_ALIAS[field] || field;
  const tariffs = getJsonSetting('hourly_tariffs');
  const hourlyRate = tariffs[f] != null ? tariffs[f] : tariffs.tourism;
  const base = (hourlyRate + (car ? getSetting('car_fee_per_hour') : 0)) * hours;
  const tax = Math.round(base * PRICING.TAX_PERCENT / 100);
  return { base, tax, total: base + tax, net: Math.round(base * PRICING.TRANSLATOR_SHARE) };
}

// اعمال پایان خدمت با محاسبهٔ مدت واقعی:
// پایان زودهنگام از هر طرف که باشد، مسافر فقط مدت خدمت واقعی را می‌پردازد (سقف‌بندی به ساعات رزرو نیست؛
// اگر خدمت از موعد گذشت، هر ساعت شروع‌شده اضافه محاسبه می‌شود) و مبلغ اولیه در list_total می‌ماند.
function applyFinish(r, by) {
  const t = now();
  const start = r.service_started_at || r.matched_at || t;
  const servedH = Math.max(0, (t - start) / 3600000);
  const billed = Math.min(DURATION_MAX_H, Math.max(PRICING.MIN_BILL_H, Math.ceil(servedH - 1e-9)));
  // صورت‌حساب با نرخِ توافق‌شدهٔ همان رزرو مقیاس می‌شود (تغییر تعرفه بعد از رزرو، مبلغ گذشته را نمی‌شکند):
  // بهای هر ساعت = base/hours ثبت‌شده؛ مالیات و سهم مترجم هم به همان نسبت.
  let q;
  if (r.base > 0 && r.hours > 0) {
    const base = Math.round((r.base / r.hours) * billed);
    const tax = Math.round((r.tax || 0) * base / r.base);
    const net = Math.round((r.net || 0) * base / r.base);
    q = { base, tax, total: base + tax, net };
  } else {
    q = quoteFor(billed, r.field, r.car);
  }
  db.prepare(`UPDATE reservations SET status = 'finished', finished_at = ?, finished_by = ?, finish_requested_at = NULL,
      billed_hours = ?, list_total = COALESCE(list_total, ?), total = ?, base = ?, tax = ?, net = ?, updated_at = ? WHERE id = ?`)
    .run(t, by, billed, r.total, q.total, q.base, q.tax, q.net, t, r.id);
  revEvent(r.id, 'finished', by, {});
  if (billed !== r.hours) {
    revEvent(r.id, 'price_adjusted', 'system', { by, served_hours: Math.round(servedH * 100) / 100,
      billed_hours: billed, old_total: r.total, new_total: q.total });
  }
  return { billed, old_total: r.total, new_total: q.total, served_hours: Math.round(servedH * 100) / 100 };
}

// مسافر هر وقت (حتی زودتر از موعد) می‌تواند خودش خدمت را تمام کند؛ تأیید مترجم لازم نیست،
// و صورت‌حساب بر اساس مدت واقعی خدمت محاسبه می‌شود (کف یک ساعت، هر ساعتِ شروع‌شده کامل).
route('POST', '/api/traveler/bookings/:id/finish', async (req, res, url, params) => {
  const u = requireUser(req, res, 'traveler'); if (!u) return;
  const r = ownReservation(res, u, params); if (!r) return;
  if (r.status !== 'matched') return send(res, 409, { error: 'not_in_service' });
  if (r.service_code && !r.service_started_at) return send(res, 409, { error: 'not_started' });
  const adj = applyFinish(r, 'traveler');
  const fresh = db.prepare('SELECT * FROM reservations WHERE id = ?').get(r.id);
  send(res, 200, { ok: true, status: 'finished', finished_by: 'traveler', total: fresh.total,
    billed_hours: adj.billed, served_hours: adj.served_hours, list_total: adj.old_total,
    price_adjusted: adj.new_total !== adj.old_total });
});

// قبول درخواست پایان مترجم از سوی مسافر
route('POST', '/api/traveler/bookings/:id/finish-approve', async (req, res, url, params) => {
  const u = requireUser(req, res, 'traveler'); if (!u) return;
  const r = ownReservation(res, u, params); if (!r) return;
  if (r.status !== 'matched' || !r.finish_requested_at) return send(res, 409, { error: 'no_finish_request' });
  const adj = applyFinish(r, 'translator');
  const fresh = db.prepare('SELECT * FROM reservations WHERE id = ?').get(r.id);
  // مبلغ تعدیل‌شده را به هر دو طرف اعلام کن؛ مترجم نباید غافلگیر شود
  if (adj.new_total !== adj.old_total) {
    const fmt = (n) => String(n).replace(/\B(?=(\d{3})+(?!\d))/g, '،');
    pushTranslator(r.translator_id, { title: 'مبلغ رزرو تعدیل شد',
      body: 'مدت واقعی خدمت ' + adj.served_hours + ' ساعت بود؛ مبلغ از ' + fmt(adj.old_total) + ' به ' + fmt(adj.new_total) + ' تومان تعدیل شد.', tag: 'price-' + r.id });
  }
  send(res, 200, { ok: true, status: 'finished', finished_by: 'translator', total: fresh.total,
    billed_hours: adj.billed, served_hours: adj.served_hours, list_total: adj.old_total,
    price_adjusted: adj.new_total !== adj.old_total });
});

// رد درخواست پایان مترجم؛ خدمت ادامه پیدا می‌کند
route('POST', '/api/traveler/bookings/:id/finish-reject', async (req, res, url, params) => {
  const u = requireUser(req, res, 'traveler'); if (!u) return;
  const r = ownReservation(res, u, params); if (!r) return;
  if (r.status !== 'matched' || !r.finish_requested_at) return send(res, 409, { error: 'no_finish_request' });
  db.prepare('UPDATE reservations SET finish_requested_at = NULL, updated_at = ? WHERE id = ?').run(now(), r.id);
  send(res, 200, { ok: true, status: 'matched' });
});

// ---------- درگاه پرداخت آنلاین (زرین‌پال v4 + درگاه شبیه‌سازی‌شدهٔ داخلی) ----------
// سه حالت در تنظیمات: «instant» تسویهٔ فوری (پیش‌فرض تا راه‌اندازی درگاه)، «simulated» جریان کامل
// درگاه با صفحهٔ شبیه‌ساز داخلی (آموزش و آزمون)، «zarinpal» درگاه واقعی (سندباکس/لایو).
// مبلغ در جدول به تومان است؛ زرین‌پال v4 ریال می‌گیرد (×۱۰ در تماس‌های درگاه).
const gatewayProvider = () => (['instant', 'simulated', 'zarinpal'].includes(getSetting('payment_provider')) ? getSetting('payment_provider') : 'instant');
const zarinpalBase = () => (getSetting('zarinpal_sandbox') ? 'https://sandbox.zarinpal.com' : 'https://payment.zarinpal.com');
function callbackBase(req) {
  const custom = clip(String(getSetting('payment_callback_base') || '').trim(), 200).replace(/\/+$/, '');
  if (custom) return custom;
  const host = (req && (req.headers['x-forwarded-host'] || req.headers.host)) || ('127.0.0.1:' + PORT);
  const proto = (req && (req.headers['x-forwarded-proto'] || (req.socket && req.socket.encrypted ? 'https' : 'http'))) || 'http';
  return proto + '://' + host;
}
function redirect302(res, loc) { res.writeHead(302, { Location: loc }); res.end(); }
// تماس JSON سمت سرور با درگاه (timeout ۱۰ ثانیه؛ هر خطی null برمی‌گرداند نه کرش)
function httpsJson(host, pathname, bodyObj) {
  return new Promise((resolve) => {
    const data = bodyObj ? JSON.stringify(bodyObj) : null;
    const rq = https.request({ host, path: pathname, method: data ? 'POST' : 'GET', timeout: 10000,
      headers: Object.assign({ Accept: 'application/json' }, data ? { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(data) } : {}) }, (r) => {
      let buf = '';
      r.on('data', (c) => { buf += c; if (buf.length > 1e6) rq.destroy(); });
      r.on('end', () => { try { resolve(JSON.parse(buf)); } catch (e) { resolve(null); } });
    });
    rq.on('timeout', () => rq.destroy());
    rq.on('error', () => resolve(null));
    if (data) rq.write(data);
    rq.end();
  });
}
// اثر تسویهٔ پرداخت آنلاین — یکسان برای هر دو مسیر instant و کال‌بک درگاه
function completeOnlinePayment(r) {
  db.prepare("UPDATE reservations SET pay_method = 'online', traveler_paid = 1, pay_state = 'settled', status = 'done', updated_at = ? WHERE id = ?").run(now(), r.id);
  revEvent(r.id, 'payment_selected', 'traveler', { method: 'online', pay_state: 'settled', gateway: true });
}

// اعلان‌های ثبت‌شدهٔ مسافر (تطبیق، لغو مترجم، پرداخت) — واکشی با since برای نظرسنجی اپ
route('GET', '/api/traveler/notifications', async (req, res, url) => {
  const u = requireUser(req, res, 'traveler'); if (!u) return;
  const since = Number(url.searchParams.get('since') || 0) || 0;
  const rows = db.prepare('SELECT id, reservation_id, kind, text, created_at FROM traveler_notifications WHERE user_id = ? AND id > ? ORDER BY id DESC LIMIT 20').all(u.id, since);
  send(res, 200, { notifications: rows.map((r) => ({ id: r.id, reservation_id: r.reservation_id, kind: r.kind, text: r.text, created_at: new Date(r.created_at).toISOString() })) });
});

route('POST', '/api/traveler/bookings/:id/payment', async (req, res, url, params) => {
  const u = requireUser(req, res, 'traveler'); if (!u) return;
  const r = ownReservation(res, u, params); if (!r) return;
  if (r.status !== 'finished' && r.status !== 'done') return send(res, 409, { error: 'not_payable' });
  if (r.status === 'done') return send(res, 409, { error: 'already_paid' });
  const b = await readJson(req);
  const t = now();
  if (b.method === 'cash') {
    if (!PAYMENTS.CASH) return send(res, 409, { error: 'method_disabled' });
    db.prepare("UPDATE reservations SET pay_method = 'cash', traveler_paid = 1, pay_state = 'awaiting_cash', updated_at = ? WHERE id = ?").run(t, r.id);
    revEvent(r.id, 'payment_selected', 'traveler', { method: 'cash', pay_state: 'awaiting_cash' });
    settleIfBoth(db.prepare('SELECT * FROM reservations WHERE id = ?').get(r.id));
  } else if (b.method === 'online') {
    if (!PAYMENTS.ONLINE) return send(res, 409, { error: 'method_disabled' });
    const provider = gatewayProvider();
    if (provider === 'instant') {
      // تسویهٔ فوری (پیش‌فرض تا راه‌اندازی درگاه): همان جریان سازگار با اپ‌ها و تست‌های موجود
      db.prepare("UPDATE reservations SET pay_method = 'online', traveler_paid = 1, pay_state = 'settled', status = 'done', updated_at = ? WHERE id = ?").run(t, r.id);
      revEvent(r.id, 'payment_selected', 'traveler', { method: 'online', pay_state: 'settled' });
    } else {
      // جریان واقعی درگاه: آغاز پرداخت → هدایت به درگاه → بازگشت کال‌بک → تأیید سمت سرور
      let authority = crypto.randomBytes(16).toString('hex');
      const amount = Math.max(0, Number(r.total) || 0);
      let redirect_url = null;
      if (provider === 'simulated') {
        db.prepare('INSERT INTO gateway_payments (reservation_id, provider, authority, amount, status, created_at) VALUES (?, ?, ?, ?, ?, ?)')
          .run(r.id, provider, authority, amount, 'pending', t);
        redirect_url = '/pay/simulate?authority=' + authority;
      } else {
        const merch = clip(String(getSetting('zarinpal_merchant_id') || '').trim(), 64);
        if (!merch) return send(res, 502, { error: 'gateway_unavailable', detail: 'merchant_missing' });
        const zp = await httpsJson(new URL(zarinpalBase()).host, '/pg/v4/payment/request.json',
          { merchant_id: merch, amount: amount * 10, callback_url: callbackBase(req) + '/pay/callback', description: 'پرداخت همراهی — رزرو #' + r.id });
        const code = zp && zp.data && zp.data.code, zauth = zp && zp.data && zp.data.authority;
        if (code !== 100 || !zauth) return send(res, 502, { error: 'gateway_unavailable', detail: 'zarinpal_' + (code || 'no_response') });
        authority = zauth;
        db.prepare('INSERT INTO gateway_payments (reservation_id, provider, authority, amount, status, created_at, raw) VALUES (?, ?, ?, ?, ?, ?, ?)')
          .run(r.id, provider, authority, amount, 'pending', t, clip(JSON.stringify(zp).slice(0, 480), 500));
        redirect_url = zarinpalBase() + '/pg/StartPay/' + zauth;
      }
      revEvent(r.id, 'gateway_started', 'traveler', { provider, amount, authority });
      return send(res, 200, { ok: true, gateway: true, provider, authority, amount, redirect_url });
    }
  } else return send(res, 400, { error: 'invalid_method' });
  const fresh = db.prepare('SELECT status, pay_state FROM reservations WHERE id = ?').get(r.id);
  send(res, 200, { ok: true, status: fresh.status, pay_state: fresh.pay_state });
});

// کال‌بک درگاه: تأیید سمت سرور (زرین‌پال: verify v4؛ شبیه‌ساز: ثبت مستقیم) و سپس تسویهٔ رزرو.
// محافظت با authority یکتا و غیرقابل حدس (۳۲ نویسهٔ hex)؛ کال‌بک تکراری بی‌اثر است (idempotent).
route('GET', '/pay/callback', async (req, res, url) => {
  const q = url.searchParams;
  const authority = clip(String(q.get('authority') || q.get('Authority') || ''), 80);
  const status = String(q.get('status') || q.get('Status') || '').toUpperCase();
  const base = callbackBase(req);
  const row = authority && db.prepare('SELECT * FROM gateway_payments WHERE authority = ?').get(authority);
  if (!row) return redirect302(res, base + '/traveler/app.html#pay-result=fail');
  if (row.status === 'paid') return redirect302(res, base + '/traveler/app.html#pay-result=ok');
  const r = db.prepare('SELECT * FROM reservations WHERE id = ?').get(row.reservation_id);
  if (!r || r.status === 'done') {
    db.prepare("UPDATE gateway_payments SET status = 'paid', paid_at = ? WHERE id = ? AND status = 'pending'").run(now(), row.id);
    return redirect302(res, base + '/traveler/app.html#pay-result=ok');
  }
  if (status !== 'OK') {
    db.prepare("UPDATE gateway_payments SET status = 'failed', raw = ? WHERE id = ? AND status = 'pending'").run(clip('callback status=' + status, 500), row.id);
    revEvent(r.id, 'gateway_failed', 'system', { authority, stage: 'callback' });
    return redirect302(res, base + '/traveler/app.html#pay-result=fail');
  }
  if (row.provider === 'zarinpal') {
    const merch = clip(String(getSetting('zarinpal_merchant_id') || '').trim(), 64);
    const vr = await httpsJson(new URL(zarinpalBase()).host, '/pg/v4/payment/verify.json', { merchant_id: merch, amount: row.amount * 10, authority });
    const code = vr && vr.data && vr.data.code;
    if (code !== 100 && code !== 101) {
      db.prepare("UPDATE gateway_payments SET status = 'failed', raw = ? WHERE id = ? AND status = 'pending'").run(clip(JSON.stringify(vr || { err: 'verify_no_response' }), 500), row.id);
      revEvent(r.id, 'gateway_failed', 'system', { authority, stage: 'verify', code: code || null });
      return redirect302(res, base + '/traveler/app.html#pay-result=fail');
    }
    db.prepare("UPDATE gateway_payments SET status = 'paid', paid_at = ?, ref_id = ?, raw = ? WHERE id = ?")
      .run(now(), clip(String(vr.data.ref_id != null ? vr.data.ref_id : ''), 64), clip(JSON.stringify(vr).slice(0, 480), 500), row.id);
  } else {
    db.prepare("UPDATE gateway_payments SET status = 'paid', paid_at = ?, ref_id = ? WHERE id = ?").run(now(), 'SIM-' + row.id, row.id);
  }
  db.transaction(() => {
    completeOnlinePayment(r);
    revEvent(r.id, 'gateway_paid', 'system', { provider: row.provider, authority, amount: row.amount });
  })();
  notifyTraveler(r.traveler_id, r.id, 'paid', 'پرداخت رزرو «' + (r.place || '') + '» با موفقیت انجام شد؛ فاکتور در بخش حساب من ثبت شد.');
  pushTraveler(r.traveler_id, { title: 'پرداخت انجام شد', body: 'پرداخت شما با موفقیت ثبت شد؛ از همراهی شما سپاسگزاریم.', tag: 'pay-' + r.id });
  if (r.translator_id) pushTranslator(r.translator_id, { title: 'پرداخت مسافر ثبت شد', body: 'پرداخت آنلاین رزرو «' + (r.place || '') + '» ثبت و تسویه شد.', tag: 'pay-' + r.id });
  return redirect302(res, base + '/traveler/app.html#pay-result=ok');
});

// صفحهٔ شبیه‌ساز درگاه (فقط حالت simulated): جریان واقعی را تمرین می‌کند — آغاز، تصمیم کاربر، کال‌بک.
// بدون اسکریپت (سازگار CSP)؛ دو دکمه با لینک به کال‌بک.
route('GET', '/pay/simulate', async (req, res, url) => {
  const authority = clip(url.searchParams.get('authority') || '', 80);
  const row = authority && db.prepare('SELECT g.*, r.place, r.traveler_name, r.id AS rid FROM gateway_payments g JOIN reservations r ON r.id = g.reservation_id WHERE g.authority = ?').get(authority);
  if (!row) { res.writeHead(404, { 'Content-Type': 'text/html; charset=utf-8' }); return res.end('<!doctype html><html lang="fa" dir="rtl"><meta charset="utf-8"><title>همراه</title><p style="font-family:sans-serif">تراکنش یافت نشد.</p>'); }
  const done = row.status !== 'pending';
  const box = (inner) => '<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>درگاه پرداخت — همراه</title><style>' +
    'body{font-family:system-ui,sans-serif;background:#eef2f6;margin:0;padding:24px;color:#161c23}.c{max-width:420px;margin:24px auto;background:#fff;border-radius:16px;padding:24px;box-shadow:0 2px 12px rgba(0,0,0,.08)}h1{font-size:17px;margin:0 0 4px}p{font-size:13px;color:#555;margin:6px 0}.amt{font-size:26px;font-weight:800;margin:14px 0}.row{display:flex;gap:10px;margin-top:18px}a.btn{flex:1;text-align:center;padding:12px;border-radius:12px;text-decoration:none;font-weight:700;font-size:14px}.ok{background:#0c7a43;color:#fff}.no{background:#f3e6e4;color:#8c1d18}.tag{display:inline-block;font-size:11px;background:#fff7e0;color:#8a6100;border-radius:99px;padding:3px 10px}' +
    '</style></head><body><div class="c">' + inner + '</div></body></html>';
  if (done) {
    return res.end(box('<h1>وضعیت تراکنش</h1><span class="tag">درگاه شبیه‌سازی‌شدهٔ داخلی — محیط آزمایشی</span>' +
      '<p>این پرداخت قبلاً ثبت شده است. می‌توانید به برنامه برگردید.</p><div class="row"><a class="btn ok" href="/traveler/app.html">بازگشت به برنامه</a></div>'));
  }
  res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(box('<h1>پرداخت همراهی تشریاتی</h1><span class="tag">درگاه شبیه‌سازی‌شدهٔ داخلی — محیط آزمایشی</span>' +
    '<div class="amt">' + Number(row.amount).toLocaleString('fa-IR') + ' تومان</div>' +
    '<p>رزرو #' + row.rid + ' — ' + String(row.place || 'محل توافقی') + '</p>' +
    '<p>کد پیگیری: <span dir="ltr">' + authority + '</span></p>' +
    '<div class="row"><a class="btn ok" href="/pay/callback?authority=' + authority + '&status=OK">پرداخت موفق (آزمایشی)</a>' +
    '<a class="btn no" href="/pay/callback?authority=' + authority + '&status=NOK">انصراف / ناموفق</a></div>'));
});

route('POST', '/api/traveler/bookings/:id/dispute', async (req, res, url, params) => {
  const u = requireUser(req, res, 'traveler'); if (!u) return;
  const r = ownReservation(res, u, params); if (!r) return;
  if (r.status !== 'finished' || r.pay_method !== 'cash') return send(res, 409, { error: 'not_disputable' });
  db.prepare("UPDATE reservations SET pay_state = 'disputed', updated_at = ? WHERE id = ?").run(now(), r.id);
  revEvent(r.id, 'disputed', 'traveler', {});
  send(res, 200, { ok: true, pay_state: 'disputed' });
});

// مترجم: تأیید دریافت نقدی. با تأیید مسافر، رزرو تسویه و انجام‌شده می‌شود.
route('POST', '/api/translator/missions/:id/cash-confirm', async (req, res, url, params) => {
  const u = requireUser(req, res, 'translator'); if (!u) return;
  if (!activeTranslator(res, u)) return;
  const id = parseId(params.id);
  const r = id && db.prepare("SELECT * FROM reservations WHERE id = ? AND translator_id = ? AND status = 'finished' AND pay_method = 'cash'").get(id, u.id);
  if (!r) return send(res, 404, { error: 'not_found' });
  if (r.pay_state === 'disputed') return send(res, 409, { error: 'disputed' });
  db.prepare('UPDATE reservations SET translator_confirmed = 1, updated_at = ? WHERE id = ?').run(now(), r.id);
  revEvent(r.id, 'cash_confirmed', 'translator', {});
  const settled = settleIfBoth(db.prepare('SELECT * FROM reservations WHERE id = ?').get(r.id));
  send(res, 200, { ok: true, settled, waiting_traveler: !settled });
});

route('POST', '/api/translator/missions/:id/cash-dispute', async (req, res, url, params) => {
  const u = requireUser(req, res, 'translator'); if (!u) return;
  if (!activeTranslator(res, u)) return;
  const id = parseId(params.id);
  const r = id && db.prepare("SELECT * FROM reservations WHERE id = ? AND translator_id = ? AND status = 'finished' AND pay_method = 'cash'").get(id, u.id);
  if (!r) return send(res, 404, { error: 'not_found' });
  db.prepare("UPDATE reservations SET pay_state = 'disputed', updated_at = ? WHERE id = ?").run(now(), r.id);
  revEvent(r.id, 'disputed', 'translator', {});
  send(res, 200, { ok: true, pay_state: 'disputed' });
});

// مترجم: پرداخت‌های منتظر تأیید (پایان‌یافته و تسویه‌نشده)
route('GET', '/api/translator/payments', async (req, res) => {
  const u = requireUser(req, res, 'translator'); if (!u) return;
  if (!activeTranslator(res, u)) return;
  const rows = db.prepare("SELECT id, place, traveler_name, total, net, pay_method, pay_state, translator_confirmed FROM reservations WHERE translator_id = ? AND status = 'finished' AND (pay_state IS NULL OR pay_state NOT IN ('settled','refunded')) ORDER BY finished_at").all(u.id);
  const settlements = db.prepare("SELECT id, place, traveler_name, total, net, hours, pay_method, pay_state, translator_confirmed, traveler_paid, finished_at FROM reservations WHERE translator_id = ? AND status = 'done' AND pay_state = 'settled' ORDER BY finished_at DESC LIMIT 10").all(u.id);
  send(res, 200, {
    payments: rows.map((r) => ({ reservation_id: r.id, place: r.place, travelerName: r.traveler_name, total: r.total, net: r.net,
      pay_method: r.pay_method, pay_state: r.pay_state, confirmed: !!r.translator_confirmed })),
    settlements: settlements.map((r) => ({ reservation_id: r.id, place: r.place, travelerName: r.traveler_name, total: r.total, net: r.net,
      hours: r.hours, pay_method: r.pay_method, pay_state: r.pay_state, confirmed: !!r.translator_confirmed,
      traveler_paid: !!r.traveler_paid, finished_at: r.finished_at ? new Date(r.finished_at).toISOString() : null })),
    // بدهی نقدی فعال: تا تسویه، پیشنهاد جدید بسته است (گیت بدهی)
    debt: { amount: translatorDebt(u.id), blocked: translatorDebt(u.id) > 0 },
  });
});

// ---------- ثبت‌نام مترجم روی سرور (مراحل ۱ تا ۵) ----------
// پس از ثبت، پرونده فقط «در انتظار بررسی نهایی» می‌شود؛ هیچ فعال‌سازی خودکاری نیست (سند ۷.۳).
// زبان‌ها و زمینه‌ها همان مقادیری هستند که تطبیق استفاده می‌کند.
const REG_DONE = new Set(['active_general', 'active_specialized']);
const REG_CLOSED = new Set(['rejected', 'suspended', 'deleted']);
// زبان‌های ثبت‌نام همان فهرست زبان‌های جفت‌زبان‌های مدیر است (LANG_CODES) تا زبان‌های
// فعال در تطبیق (ترکی، فرانسه، روسی، چینی) دقیقاً همان‌ها در ثبت‌نام هم موجود باشند (یافتهٔ ۵).
const REG_LANGS = LANG_CODES;
const REG_FIELDS = ['tourism', 'pilgrimage', 'medical', 'business', 'legal'];
const clip = (v, max) => String(v || '').trim().slice(0, max);
const pick = (arr, allowed) => [...new Set((Array.isArray(arr) ? arr : []).filter((x) => allowed.includes(x)))];

route('POST', '/api/translator/registration', async (req, res) => {
  const u = requireUser(req, res, 'translator'); if (!u) return;
  const b = await readJson(req);
  if (!requireFeature(res, 'translator_registration')) return;
  const cityRes = resolveCity(b.city_id, 'translator');
  if (cityRes.error) return send(res, cityRes.status, { error: cityRes.error });
  if (b.nda !== true || b.charter !== true) return send(res, 400, { error: 'consent_required' });
  if (b.gender !== 'male' && b.gender !== 'female') return send(res, 400, { error: 'gender_required' });
  const first = clip(b.first_name, 60), last = clip(b.last_name, 60);
  if (!first || !last) return send(res, 400, { error: 'name_required' });
  const langs = pick(b.languages, REG_LANGS);
  if (langs.length < 1) return send(res, 400, { error: 'languages_required' });
  // حوزه‌ها: مقادیر قدیمی (general) به تکسونومی تازه نگاشت می‌شوند؛ حداقل یک حوزه الزامی است
  const fields = pick((Array.isArray(b.fields) ? b.fields : []).map((x) => FIELD_ALIAS[x] || x), REG_FIELDS);
  if (fields.length < 1) return send(res, 400, { error: 'fields_required' });
  const postal = String(b.postal_code == null ? '' : b.postal_code).replace(/[^0-9]/g, '');
  if (postal && postal.length !== 10) return send(res, 400, { error: 'postal_code_invalid' });
  // فیلدهای هویتی فرم ثبت‌نام (کد ملی، تاریخ تولد، شبا) اکنون دریافت و ذخیره می‌شوند؛
  // فرم سمت کلاینت این‌ها را الزامی می‌داند ولی تا پیش از این هرگز به سرور نمی‌رسیدند (یافتهٔ ۴).
  // اختیاری نگه داشته می‌شوند تا نشست‌های قدیمی/آزمون‌ها نشکنند؛ کلاینت ارسالشان را الزامی می‌کند.
  const faDigits = (s) => String(s == null ? '' : s).replace(/[۰-۹]/g, (d) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)));
  const nationalCode = faDigits(b.national_code).replace(/\D/g, '');
  if (nationalCode && nationalCode.length !== 10) return send(res, 400, { error: 'national_code_invalid' });
  const birthDate = clip(b.birth_date, 20);
  const iban = faDigits(b.iban).replace(/\D/g, '');
  if (iban && iban.length !== 24) return send(res, 400, { error: 'iban_invalid' });
  const profile = JSON.stringify({
    first_name: first, last_name: last, city: cityRes.city.name_fa, postal_code: postal || null,
    national_code: nationalCode || null, birth_date: birthDate || null, iban: iban || null,
    car: b.car === true, car_model: clip(b.car_model, 60),
    car_capacity: Math.min(Math.max(Math.trunc(Number(b.car_capacity)) || 0, 0), 8) || null,
    interview_at: clip(b.interview_at, 40),
    charter_at: now(), nda_at: now(),
  });
  const cur = db.prepare('SELECT status FROM translators WHERE user_id = ?').get(u.id);
  if (cur && REG_CLOSED.has(cur.status)) return send(res, 409, { error: 'registration_closed', status: cur.status });
  const next = !cur || cur.status === 'registered' || cur.status === 'in_progress' ? 'pending_review' : cur.status;
  db.prepare(`INSERT INTO translators (user_id, status, gender, profile, langs, fields, updated_at, city_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
              ON CONFLICT(user_id) DO UPDATE SET status = excluded.status, gender = excluded.gender, profile = excluded.profile,
                langs = excluded.langs, fields = excluded.fields, updated_at = excluded.updated_at,
                city_id = CASE WHEN translators.status LIKE 'active_%' THEN translators.city_id ELSE excluded.city_id END`)
    .run(u.id, next, b.gender, profile, JSON.stringify(langs), JSON.stringify(fields), now(), cityRes.city.id);
  send(res, 200, { status: next, languages: langs, fields });
});

// تکمیل اختیاری حوزه‌ها پس از ورود به میز کار (از نمای «وضعیت مدارک و صلاحیت»):
// مترجم فعال هر زمان می‌تواند فهرست حوزه‌هایش را کامل کند؛ پایه‌ها بلافاصله باز می‌شوند،
// تخصصی‌ها با همان گیت (مدرک زبان تأییدشده). هیچ مانعی برای میز کار ایجاد نمی‌کند.
route('PATCH', '/api/translator/fields', async (req, res) => {
  const u = requireUser(req, res, 'translator'); if (!u) return;
  const b = await readJson(req);
  const t = db.prepare('SELECT status, interview FROM translators WHERE user_id = ?').get(u.id);
  if (!t) return send(res, 409, { error: 'registration_required' });
  if (!REG_DONE.has(t.status)) return send(res, 409, { error: 'not_active', status: t.status });
  const fields = pick((Array.isArray(b.fields) ? b.fields : []).map((x) => FIELD_ALIAS[x] || x), REG_FIELDS);
  if (fields.length < 1) return send(res, 400, { error: 'fields_required' });
  db.prepare('UPDATE translators SET fields = ?, updated_at = ? WHERE user_id = ?').run(JSON.stringify(fields), now(), u.id);
  const cert = langCertOk({ user_id: u.id });
  // وضعیت مؤثر به‌روز می‌ماند: با مدرک زبانِ تأییدشده، فعالِ تخصصی
  if (t.interview === 'pass' && cert && t.status === 'active_general') {
    db.prepare("UPDATE translators SET status = 'active_specialized', updated_at = ? WHERE user_id = ?").run(now(), u.id);
  }
  send(res, 200, { ok: true, fields, unlocked: fields.filter((f) => BASE_FIELDS.has(f) || cert),
    locked: fields.filter((f) => SPEC_FIELDS.has(f) && !cert) });
});

// ---------- مدارک مترجم (رمزنگاری‌شده، سند ۴.۲ و ۶.۱) ----------
// فایل‌ها با AES-256-GCM رمز می‌شوند؛ کلید از HZ_DOC_KEY خوانده می‌شود.
// مترجم فقط وضعیت را می‌بیند؛ محتوا فقط برای تیم احراز (ادمین) باز می‌شود.
const DOC_KINDS = new Set(['nid_card', 'selfie', 'portrait', 'address_proof', 'criminal_record', 'drug_free',
  'ipd_permit', 'cip_permit', 'specialty_cert', 'lang_cert', 'car_docs', 'licence']);
// مدرک زبان (lang_cert) گیت حوزه‌های تخصصی است؛ گواهی تخصصی هر حوزه (specialty_cert:<field>) صرفاً مکمل پرونده است
const DOC_MIMES = { 'image/jpeg': 'jpg', 'image/png': 'png', 'application/pdf': 'pdf' };
const DOC_MAX_BYTES = 5 * 1024 * 1024;
const DOC_EXPIRING = new Set(['car_docs', 'licence', 'ipd_permit', 'criminal_record']);
const DAY_MS = 24 * 60 * 60 * 1000;
// پایان روز تاریخ انقضا به وقت تهران (+03:30)
const expiryEnd = (d) => { const t = Date.parse(`${d}T23:59:59+03:30`); return Number.isNaN(t) ? null : t; };
const DOC_KEY = crypto.createHash('sha256').update(process.env.HZ_DOC_KEY || 'hz-dev-only-doc-key').digest();
if (!process.env.HZ_DOC_KEY) {
  if (!DEV) { console.error('خطا: HZ_DOC_KEY برای اجرای غیرتوسعه لازم است.'); process.exit(1); }
  console.log('هشدار: HZ_DOC_KEY تنظیم نشده؛ کلید توسعه استفاده می‌شود.');
}
// امضای فایل: محتوای واقعی باید با نوع اعلام‌شده یکی باشد
const DOC_SIGNATURES = { jpg: [[0xff, 0xd8, 0xff]], png: [[0x89, 0x50, 0x4e, 0x47]], pdf: [[0x25, 0x50, 0x44, 0x46]] };
const sigOk = (buf, ext) => (DOC_SIGNATURES[ext] || []).some((sig) => sig.every((b, i) => buf[i] === b));
const encryptDoc = (buf) => {
  const iv = crypto.randomBytes(12);
  const c = crypto.createCipheriv('aes-256-gcm', DOC_KEY, iv);
  const enc = Buffer.concat([c.update(buf), c.final()]);
  return Buffer.concat([iv, c.getAuthTag(), enc]);
};
const decryptDoc = (blob) => {
  const d = crypto.createDecipheriv('aes-256-gcm', DOC_KEY, blob.subarray(0, 12));
  d.setAuthTag(blob.subarray(12, 28));
  return Buffer.concat([d.update(blob.subarray(28)), d.final()]);
};

route('POST', '/api/translator/documents', async (req, res) => {
  const u = requireUser(req, res, 'translator'); if (!u) return;
  if (Number(req.headers['content-length'] || 0) > DOC_MAX_BYTES * 1.4) return send(res, 413, { error: 'file_too_large' });
  const b = await readJson(req, DOC_MAX_BYTES * 1.4);
  if (!DOC_KINDS.has(b.kind) && !/^specialty_cert:(general|medical|legal|business)$/.test(String(b.kind))) return send(res, 400, { error: 'invalid_kind' });
  const m = /^data:([a-z\/+]+);base64,(.+)$/i.exec(String(b.data || ''));
  if (!m || !DOC_MIMES[m[1].toLowerCase()]) return send(res, 400, { error: 'invalid_file_type' });
  const raw = Buffer.from(m[2], 'base64');
  if (!raw.length) return send(res, 400, { error: 'empty_file' });
  if (raw.length > DOC_MAX_BYTES) return send(res, 413, { error: 'file_too_large' });
  if (!sigOk(raw, DOC_MIMES[m[1].toLowerCase()])) return send(res, 400, { error: 'file_content_mismatch' });
  let expires = null;
  if (DOC_EXPIRING.has(b.kind)) {
    expires = expiryEnd(String(b.expires_at || '').trim());
    if (expires === null) return send(res, 400, { error: 'expiry_required' });
    if (expires < now()) return send(res, 400, { error: 'expiry_in_past' });
  }
  const t = db.prepare('SELECT status FROM translators WHERE user_id = ?').get(u.id);
  if (!t) return send(res, 409, { error: 'registration_required' });
  if (REG_CLOSED.has(t.status)) return send(res, 409, { error: 'registration_closed', status: t.status });
  const ts = now();
  db.prepare("DELETE FROM translator_documents WHERE user_id = ? AND kind = ? AND status IN ('uploaded', 'rejected')").run(u.id, b.kind);
  db.prepare(`INSERT INTO translator_documents (user_id, kind, status, mime, size, blob, expires_at, created_at, updated_at)
              VALUES (?, ?, 'uploaded', ?, ?, ?, ?, ?, ?)`).run(u.id, b.kind, m[1].toLowerCase(), raw.length, encryptDoc(raw), expires, ts, ts);
  send(res, 200, { ok: true, kind: b.kind, status: 'uploaded' });
});

route('GET', '/api/translator/documents', async (req, res) => {
  const u = requireUser(req, res, 'translator'); if (!u) return;
  const rows = db.prepare(`SELECT id, kind, status, size, reject_reason, expires_at, updated_at FROM translator_documents
    WHERE user_id = ? AND status != 'superseded' ORDER BY kind`).all(u.id);
  const t = now();
  send(res, 200, { documents: rows.map((r) => ({ kind: r.kind, status: r.status, size: r.size,
    reject_reason: r.reject_reason || '', updated_at: new Date(r.updated_at).toISOString(),
    expires_at: r.expires_at ? new Date(r.expires_at).toISOString() : null,
    expired: !!r.expires_at && r.expires_at < t,
    expiring_soon: !!r.expires_at && r.expires_at >= t && r.expires_at - t <= 30 * DAY_MS })) });
});

// ---------- تنظیم پذیرش جنسیت مسافر ----------
route('GET', '/api/translator/preferences', async (req, res) => {
  const u = requireUser(req, res, 'translator'); if (!u) return;
  if (!activeTranslator(res, u)) return;
  const t = db.prepare('SELECT traveler_gender_pref FROM translators WHERE user_id = ?').get(u.id);
  const preference = t && TRAVELER_GENDER_PREF.has(t.traveler_gender_pref) ? t.traveler_gender_pref : 'any';
  send(res, 200, { traveler_gender_pref: preference });
});

route('PATCH', '/api/translator/preferences', async (req, res) => {
  const u = requireUser(req, res, 'translator'); if (!u) return;
  if (!activeTranslator(res, u)) return;
  const b = await readJson(req);
  if (!b || !TRAVELER_GENDER_PREF.has(b.traveler_gender_pref)) return send(res, 400, { error: 'invalid_traveler_gender_pref' });
  const acceptsAny = b.traveler_gender_pref === 'any' ? 1 : 0;
  db.prepare('UPDATE translators SET traveler_gender_pref = ?, accept_any = ?, updated_at = ? WHERE user_id = ?')
    .run(b.traveler_gender_pref, acceptsAny, now(), u.id);
  // Re-run matching for waiting requests; already-issued offers remain unchanged.
  sweep();
  send(res, 200, { ok: true, traveler_gender_pref: b.traveler_gender_pref });
});

// ---------- پروفایل مترجم (نمایش + ویرایش مجاز) ----------
// هویت (نام/کد ملی) از پروندهٔ احراز می‌آید و اینجا فقط‌خواندنی است؛
// ویرایش پذیر: جنسیت و شهر. بقیهٔ ترجیحات مسیر خودش را دارد (preferences).
route('GET', '/api/translator/profile', async (req, res) => {
  const u = requireUser(req, res, 'translator'); if (!u) return;
  const t = db.prepare(`SELECT t.gender, t.city_id, t.langs, t.status, t.profile, t.share_loc, t.loc_at, c.name_fa AS city_name
    FROM translators t LEFT JOIN cities c ON c.id = t.city_id WHERE t.user_id = ?`).get(u.id);
  if (!t) return send(res, 404, { error: 'not_found' });
  const pr = (() => { try { return JSON.parse(t.profile || '{}'); } catch (e) { return {}; } })();
  send(res, 200, {
    phone: u.phone,
    first_name: pr.first_name || '', last_name: pr.last_name || '',
    national_code: pr.national_code || '', birth_date: pr.birth_date || '',
    gender: ['male', 'female'].includes(t.gender) ? t.gender : null,
    city_id: t.city_id || null, city_name: t.city_name || null,
    langs: JSON.parse(t.langs || '[]'),
    location: { sharing: t.share_loc === 1, at: t.loc_at ? new Date(t.loc_at).toISOString() : null },
    status: t.status,
  });
});
route('PATCH', '/api/translator/profile', async (req, res) => {
  const u = requireUser(req, res, 'translator'); if (!u) return;
  const b = await readJson(req);
  const t = db.prepare('SELECT status FROM translators WHERE user_id = ?').get(u.id);
  if (!t) return send(res, 409, { error: 'registration_required' });
  const sets = [], args = [];
  if ('gender' in b) {
    if (!['male', 'female'].includes(b.gender)) return send(res, 400, { error: 'invalid_gender' });
    sets.push('gender = ?'); args.push(b.gender);
  }
  if ('city_id' in b) {
    const city = db.prepare('SELECT id FROM cities WHERE id = ? AND translator_enabled = 1').get(Number(b.city_id) || 0);
    if (!city) return send(res, 400, { error: 'invalid_city' });
    sets.push('city_id = ?'); args.push(city.id);
  }
  if (!sets.length) return send(res, 400, { error: 'nothing_to_update' });
  sets.push('updated_at = ?'); args.push(now(), u.id);
  db.prepare('UPDATE translators SET ' + sets.join(', ') + ' WHERE user_id = ?').run(...args);
  audit('translator.profile_update', { user_id: u.id, keys: Object.keys(b) });
  send(res, 200, { ok: true });
});

// ---------- موقعیت مکانی اختیاری مترجم ----------
// فقط با اجازهٔ مترجم (share_loc) ذخیره می‌شود؛ برای تطبیق شعاعی و نقشهٔ زندهٔ پنل. آخرین نقطه نگه داشته می‌شود.
route('POST', '/api/translator/location', async (req, res) => {
  const u = requireUser(req, res, 'translator'); if (!u) return;
  const b = await readJson(req);
  const lat = Number(b.lat), lng = Number(b.lng);
  if (!Number.isFinite(lat) || !Number.isFinite(lng) || Math.abs(lat) > 90 || Math.abs(lng) > 180) {
    return send(res, 400, { error: 'invalid_coordinates' });
  }
  if ('sharing' in b && typeof b.sharing !== 'boolean') return send(res, 400, { error: 'invalid_sharing' });
  const sharing = 'sharing' in b ? (b.sharing ? 1 : 0) : 1;
  db.prepare('UPDATE translators SET lat = ?, lng = ?, loc_at = ?, share_loc = ?, updated_at = ? WHERE user_id = ?')
    .run(lat, lng, now(), sharing, now(), u.id);
  send(res, 200, { ok: true, sharing: !!sharing });
});

// قابلیت خودرو (CAP — قاعدهٔ ۲ و ۴): ثبت/به‌روزرسانی بعدی خودرو از کارت صلاحیت، هر زمان مترجم خواست.
// انتخاب خودرو هیچ مانعی برای میز کار نیست؛ فقط تا تأیید بیمه (car_docs) و گواهینامه (licence)
// رزرو سواره برای او پیشنهاد نمی‌شود و همان حالت «فقط پیاده» می‌ماند.
route('PATCH', '/api/translator/vehicle', async (req, res) => {
  const u = requireUser(req, res, 'translator'); if (!u) return;
  const b = await readJson(req);
  const t = db.prepare('SELECT status, profile FROM translators WHERE user_id = ?').get(u.id);
  if (!t) return send(res, 409, { error: 'registration_required' });
  if (!REG_DONE.has(t.status)) return send(res, 409, { error: 'not_active', status: t.status });
  const on = b.car === true;
  const model = clip(b.car_model, 60);
  const capacity = Math.min(Math.max(Math.trunc(Number(b.car_capacity)) || 0, 0), 8) || null;
  if (on && (!model || !capacity || capacity < 1)) return send(res, 400, { error: 'car_details_required' });
  const p = JSON.parse(t.profile || '{}');
  p.car = on;
  p.car_model = on ? model : '';
  p.car_capacity = on ? capacity : null;
  db.prepare('UPDATE translators SET profile = ?, updated_at = ? WHERE user_id = ?').run(JSON.stringify(p), now(), u.id);
  audit('translator.vehicle', { id: u.id, car: on });
  send(res, 200, { ok: true, car: on, car_ready: carReady({ user_id: u.id, profile: JSON.stringify(p) }, 1) });
});

// ---------- مترجم: پیشنهادها و آنلاین ----------
// Read effective presence without changing matching, score or profile data.
route('GET', '/api/translator/online', async (req, res) => {
  const u = requireUser(req, res, 'translator'); if (!u) return;
  if (!activeTranslator(res, u)) return;
  const t = db.prepare('SELECT online FROM translators WHERE user_id = ?').get(u.id);
  const enabled = featureOn('translator_online');
  send(res, 200, { online: enabled && !!(t && t.online), enabled });
});

route('PATCH', '/api/translator/online', async (req, res) => {
  const u = requireUser(req, res, 'translator'); if (!u) return;
  if (!activeTranslator(res, u)) return;
  const b = await readJson(req);
  if (!b || typeof b.online !== 'boolean') return send(res, 400, { error: 'invalid_online' });
  if (b.online === true && !requireFeature(res, 'translator_online')) return;
  const g = b.gender === 'male' || b.gender === 'female' ? b.gender : null;
  db.prepare(`UPDATE translators SET online = ?, updated_at = ?,
      gender = COALESCE(?, gender), accept_any = COALESCE(?, accept_any) WHERE user_id = ?`)
    .run(b.online ? 1 : 0, now(), g, typeof b.accept_any === 'boolean' ? (b.accept_any ? 1 : 0) : null, u.id);
  if (b.online) sweep();
  send(res, 200, { online: !!b.online });
});

route('GET', '/api/translator/offers', async (req, res) => {
  const u = requireUser(req, res, 'translator'); if (!u) return;
  if (!activeTranslator(res, u)) return;
  sweep();
  const t = db.prepare('SELECT online FROM translators WHERE user_id = ?').get(u.id);
  const serverTime = now();
  const rows = db.prepare(`SELECT o.id AS offer_id, o.expires_at, o.created_at AS offer_created_at, r.* FROM offers o JOIN reservations r ON r.id = o.reservation_id
    WHERE o.translator_id = ? AND o.status = 'pending' ORDER BY o.created_at`).all(u.id);
  // قبل از پذیرش: فقط ساعت/تاریخ، مبدا-مقصد، نشانی ملاقات، نام مسافر، یادداشت و سهم خالص (بدون جنسیت)
  const changeRows = db.prepare(`SELECT c.id, c.reservation_id, c.changes, c.expires_at, r.place, r.traveler_name, r.net, r.kind, r.scheduled_at
    FROM change_requests c JOIN reservations r ON r.id = c.reservation_id
    WHERE r.translator_id = ? AND c.status = 'pending' AND c.expires_at > ?`).all(u.id, now());
  const extRows = db.prepare(`SELECT e.id, e.reservation_id, e.extra_hours, e.extra_base, e.extra_tax, e.extra_net, e.expires_at, r.place, r.traveler_name, r.net
    FROM extension_requests e JOIN reservations r ON r.id = e.reservation_id
    WHERE r.translator_id = ? AND e.status = 'pending' AND e.expires_at > ?`).all(u.id, now());
  send(res, 200, { online: !!(t && t.online), server_time: new Date(serverTime).toISOString(),
    extensions: extRows.map((e) => ({ id: e.id, reservation_id: e.reservation_id, place: e.place, traveler_name: e.traveler_name,
      extra_hours: e.extra_hours, extra_total: e.extra_base + e.extra_tax, extra_net: e.extra_net,
      new_net: (e.net || 0) + e.extra_net, expires_at: new Date(e.expires_at).toISOString() })),
    changes: changeRows.map((c) => ({ id: c.id, reservation_id: c.reservation_id, place: c.place, traveler_name: c.traveler_name,
    kind: c.kind, scheduled_at: c.scheduled_at ? new Date(c.scheduled_at).toISOString() : null, changes: JSON.parse(c.changes), expires_at: new Date(c.expires_at).toISOString() })),
    offers: rows.map((r) => ({
    id: r.offer_id, reservation_id: r.id, kind: r.kind, origin_lang: r.origin_lang, dest_lang: r.dest_lang, field: r.field,
    place: r.place, traveler_name: r.traveler_name, notes: r.notes, hours: r.hours, car: r.car, party: r.party,
    scheduled_at: r.scheduled_at ? new Date(r.scheduled_at).toISOString() : null,
    net: r.net, created_at: new Date(r.offer_created_at).toISOString(), expires_at: new Date(r.expires_at).toISOString(),
  })) });
});

// Decision history is private to the offered translator; no passenger code or gender.
route('GET', '/api/translator/offers/:id', async (req, res, url, params) => {
  const u = requireUser(req, res, 'translator'); if (!u) return;
  if (!activeTranslator(res, u)) return;
  const id = parseId(params.id);
  const o = id && db.prepare('SELECT * FROM offers WHERE id = ? AND translator_id = ?').get(id, u.id);
  if (!o) return send(res, 404, { error: 'not_found' });
  const r = db.prepare('SELECT net, translator_id FROM reservations WHERE id = ?').get(o.reservation_id);
  if (!r) return send(res, 404, { error: 'not_found' });
  send(res, 200, { id: o.id, reservation_id: o.reservation_id,
    status: o.status === 'pending' && o.expires_at <= now() ? 'expired' : o.status,
    expires_at: new Date(o.expires_at).toISOString(), net: r.net, assigned: r.translator_id === u.id });
});

route('POST', '/api/translator/offers/:id/accept', async (req, res, url, params) => {
  const u = requireUser(req, res, 'translator'); if (!u) return;
  if (!activeTranslator(res, u)) return;
  const id = parseId(params.id);
  const o = id && db.prepare('SELECT * FROM offers WHERE id = ? AND translator_id = ?').get(id, u.id);
  if (!o) return send(res, 404, { error: 'not_found' });
  const r = db.prepare('SELECT * FROM reservations WHERE id = ?').get(o.reservation_id);
  if (o.status !== 'pending' || o.expires_at <= now()) return send(res, 410, { error: 'offer_expired' });
  if (!SEARCHABLE.includes(r.status)) return send(res, 409, { error: 'no_longer_available' });
  db.transaction(() => {
    db.prepare("UPDATE reservations SET status = 'matched', translator_id = ?, matched_at = ?, translator_arrived_at = NULL, updated_at = ? WHERE id = ?").run(u.id, now(), now(), r.id);
    db.prepare("UPDATE offers SET status = 'accepted', decided_at = ? WHERE id = ?").run(now(), o.id);
    db.prepare("UPDATE offers SET status = 'withdrawn', decided_at = ? WHERE reservation_id = ? AND status = 'pending'").run(now(), r.id);
  })();
  revEvent(r.id, 'matched', 'translator', { offer_id: o.id });
  // اعلان مسافر: مترجم مشخص شد (پوش + ثبت اعلان)
  const tp = db.prepare('SELECT profile FROM translators WHERE user_id = ?').get(u.id);
  const pj = tp ? (JSON.parse(tp.profile || '{}')) : {};
  const tname = [pj.first_name, pj.last_name].filter(Boolean).join(' ');
  notifyTraveler(r.traveler_id, r.id, 'matched', 'مترجم شما' + (tname ? ' (' + tname + ')' : '') + ' برای رزرو «' + (r.place || '') + '» مشخص شد؛ جزئیات در اپ.');
  pushTraveler(r.traveler_id, { title: 'مترجم شما مشخص شد', body: (tname || 'مترجم') + ' درخواست شما را پذیرفت؛ جزئیات در اپ.', tag: 'matched-' + r.id });
  send(res, 200, { ok: true, reservation_id: r.id });
});

route('POST', '/api/translator/offers/:id/decline', async (req, res, url, params) => {
  const u = requireUser(req, res, 'translator'); if (!u) return;
  if (!activeTranslator(res, u)) return;
  const id = parseId(params.id);
  const o = id && db.prepare('SELECT * FROM offers WHERE id = ? AND translator_id = ?').get(id, u.id);
  if (!o) return send(res, 404, { error: 'not_found' });
  if (o.status !== 'pending' || o.expires_at <= now()) return send(res, 410, { error: 'offer_expired' });
  db.prepare("UPDATE offers SET status = 'declined', decided_at = ? WHERE id = ?").run(now(), o.id);
  sweep();
  send(res, 200, { ok: true });
});

// The former assignee can verify their own cancellation without seeing the next assignee.
route('GET', '/api/translator/missions/:id/cancellation', async (req, res, url, params) => {
  const u = requireUser(req, res, 'translator'); if (!u) return;
  if (!activeTranslator(res, u)) return;
  const id = parseId(params.id);
  const r = id && db.prepare('SELECT translator_id, status FROM reservations WHERE id = ?').get(id);
  const c = id && db.prepare('SELECT created_at FROM mission_cancellations WHERE reservation_id = ? AND translator_id = ?').get(id, u.id);
  if (!r || (!c && r.translator_id !== u.id)) return send(res, 404, { error: 'not_found' });
  send(res, 200, { reservation_id: id, cancelled: !!c,
    cancelled_at: c ? new Date(c.created_at).toISOString() : null,
    assigned: r.translator_id === u.id && r.status === 'matched' });
});

// لغو توسط مترجم پس از پذیرش: بدون جریمه‌ی پولی، امتیاز کم می‌شود و ماموریت دوباره تطبیق می‌شود
route('POST', '/api/translator/missions/:id/cancel', async (req, res, url, params) => {
  const u = requireUser(req, res, 'translator'); if (!u) return;
  if (!activeTranslator(res, u)) return;
  const id = parseId(params.id);
  const r = id && db.prepare("SELECT * FROM reservations WHERE id = ? AND translator_id = ? AND status = 'matched'").get(id, u.id);
  if (!r) return send(res, 404, { error: 'not_found' });
  if (r.service_started_at) return send(res, 409, { error: 'service_already_started' });
  const t = now();
  let next = 'searching';
  if (r.kind === 'scheduled') next = t >= r.scheduled_at - TIMING.SCHEDULE_MATCH_BEFORE_MS ? 'matching' : 'waiting_schedule';
  db.transaction(() => {
    db.prepare('INSERT INTO mission_cancellations (reservation_id, translator_id, created_at) VALUES (?, ?, ?)').run(r.id, u.id, t);
    db.prepare(`UPDATE reservations SET status = ?, translator_id = NULL, matched_at = NULL, translator_arrived_at = NULL, search_started_at = ?, updated_at = ? WHERE id = ?`)
      .run(next, t, t, r.id);
    db.prepare('UPDATE translators SET score = MAX(0, score - 5), updated_at = ? WHERE user_id = ?').run(t, u.id);
  })();
  revEvent(r.id, 'translator_cancelled', 'translator', { reassigned_to: next });
  // شکاف ۵: مسافر باید بداند مترجم کنار رفته و جستجوی جایگزین ادامه دارد
  notifyTraveler(r.traveler_id, r.id, 'translator_cancelled', 'مترجم شما از رزرو «' + (r.place || '') + '» کنار رفت؛ ' + (next === 'waiting_schedule' ? 'زمان‌بندی حفظ شد و جستجوی مترجم جایگزین ادامه دارد.' : 'جستجوی مترجم جایگزین آغاز شد.'));
  pushTraveler(r.traveler_id, { title: 'تغییر مترجم', body: 'مترجم قبلی از رزرو کنار رفت؛ جستجوی مترجم جایگزین آغاز شد.', tag: 'tcancel-' + r.id });
  sweep();
  send(res, 200, { ok: true, reservation_id: r.id, cancelled_at: new Date(t).toISOString(), reassigned: next !== 'waiting_schedule' });
});

route('GET', '/api/translator/missions', async (req, res) => {
  const u = requireUser(req, res, 'translator'); if (!u) return;
  if (!activeTranslator(res, u)) return;
  const serverTime = now();
  const from = serverTime - 3600 * 1000;
  // Keep an in-progress service visible even when its scheduled/matched time is over an hour old.
  const fromReservations = db.prepare(`SELECT * FROM reservations WHERE translator_id = ? AND status = 'matched'
      AND (COALESCE(scheduled_at, matched_at) > ? OR service_started_at IS NOT NULL)
      ORDER BY COALESCE(scheduled_at, matched_at)`).all(u.id, from)
    .map((r) => ({ id: 'R' + r.id, reservation_id: r.id, code: 'R-' + r.id, purpose: r.field, travelerName: r.traveler_name, place: r.place,
      kind: r.kind, origin_lang: r.origin_lang, dest_lang: r.dest_lang, car: r.car, party: r.party, notes: r.notes,
      scheduled_at: r.scheduled_at ? new Date(r.scheduled_at).toISOString() : null,
      lat: r.lat == null ? null : r.lat, lng: r.lng == null ? null : r.lng,
      startAt: new Date(r.scheduled_at || r.matched_at).toISOString(), total: r.total, net: r.net, status: 'accepted',
      arrived_at: r.translator_arrived_at ? new Date(r.translator_arrived_at).toISOString() : null,
      started: !!r.service_started_at, service_started_at: r.service_started_at ? new Date(r.service_started_at).toISOString() : null, hours: r.hours,
      finish_requested: !!r.finish_requested_at }));
  // ماموریت‌های آزمایشی تزریقی (فقط حالت توسعه)
  const fromDev = db.prepare(`SELECT id, code, purpose, traveler_name, place, start_at, total, net, status FROM missions
      WHERE translator_id = ? AND status = 'accepted' AND start_at > ?`).all(u.id, from)
    .map((m) => ({ id: m.id, code: m.code, purpose: m.purpose, travelerName: m.traveler_name, place: m.place,
      startAt: new Date(m.start_at).toISOString(), total: m.total, net: m.net, status: m.status }));
  const all = fromReservations.concat(fromDev).sort((a, b) => Date.parse(a.startAt) - Date.parse(b.startAt));
  send(res, 200, { server_time: new Date(serverTime).toISOString(), missions: all });
});

// ---------- تغییر رزرو پس از پذیرش ----------
const CHANGE_COLUMNS = { scheduled_at: 'time', place: 'place', origin_lang: 'lang', dest_lang: 'lang', field: 'field',
  hours: 'duration', car: 'car', party: 'party', gender_pref: 'gender' };
const CHANGE_WINDOW_MS = 5 * 60 * 1000 * SCALE;   // مهلت پاسخ مترجم
const CHANGE_LIMIT = 3;                            // حداکثر تغییر مهم
const CHANGE_CUTOFF_MS = 30 * 60 * 1000 * SCALE;   // زیر ۳۰ دقیقه مانده، تغییر مهم پیشنهاد نمی‌شود

// اعتبارسنجی فیلدهای درخواست؛ یادداشت همیشه آزاد است
function parseChanges(b, r) {
  const out = {};
  if ('scheduled_at' in b) {
    if (r.kind !== 'scheduled') return { error: 'time_not_applicable' };
    const at = Date.parse(b.scheduled_at);
    if (!Number.isFinite(at)) return { error: 'invalid_time' };
    if (at - now() < TIMING.SCHEDULE_MIN_LEAD_MS) return { error: 'too_soon' };
    out.scheduled_at = at;
  }
  if ('place' in b) { const v = String(b.place || '').trim(); if (!v || v.length > 200) return { error: 'invalid_place' }; out.place = v; }
  if ('origin_lang' in b) { if (!LANGS.has(b.origin_lang)) return { error: 'invalid_language' }; out.origin_lang = b.origin_lang; }
  if ('dest_lang' in b) { if (!LANGS.has(b.dest_lang)) return { error: 'invalid_language' }; out.dest_lang = b.dest_lang; }
  if ('field' in b) { if (!FIELDS.has(b.field)) return { error: 'invalid_field' }; out.field = b.field; }
  if ('hours' in b) out.hours = Math.min(Math.max(Math.trunc(Number(b.hours)) || 1, DURATION_MIN_H), DURATION_MAX_H);
  if ('car' in b) out.car = b.car ? 1 : 0;
  if ('party' in b) out.party = Math.min(Math.max(Number(b.party) || 1, 1), 20);
  if ('gender_pref' in b) { if (!GENDER_PREF.has(b.gender_pref)) return { error: 'invalid_gender' }; out.gender_pref = b.gender_pref; }
  if ('notes' in b) out.notes = String(b.notes || '').slice(0, 500);
  return { changes: out, important: Object.keys(out).some((k) => k in CHANGE_COLUMNS) };
}

// اعمال تغییرها روی رزرو؛ اگر زمان یا مشخصات عوض شود، تطبیق از نو حساب می‌شود
function applyChanges(r, changes) {
  const keys = Object.keys(changes);
  if (!keys.length) return;
  const sets = keys.map((k) => `${k} = ?`).join(', ');
  const clearArrival = keys.some((k) => k === 'place' || k === 'scheduled_at');
  db.prepare(`UPDATE reservations SET ${sets}${clearArrival ? ', translator_arrived_at = NULL' : ''}, updated_at = ? WHERE id = ?`)
    .run(...keys.map((k) => changes[k]), now(), r.id);
  const important = keys.some((k) => k in CHANGE_COLUMNS);
  if (!r.translator_id && important) {
    closeOffers(r.id);
    if ('scheduled_at' in changes) {
      setStatus(r.id, now() >= changes.scheduled_at - TIMING.SCHEDULE_MATCH_BEFORE_MS ? 'matching' : 'waiting_schedule');
    } else if (r.status === 'no_match') {
      setStatus(r.id, 'searching');
    }
  }
  sweep();
}

route('POST', '/api/traveler/bookings/:id/change', async (req, res, url, params) => {
  const u = requireUser(req, res, 'traveler'); if (!u) return;
  if (!requireFeature(res, 'booking_change')) return;
  const r = ownReservation(res, u, params); if (!r) return;
  if (r.status === 'cancelled') return send(res, 409, { error: 'not_changeable' });
  const b = await readJson(req);
  const parsed = parseChanges(b, r);
  if (parsed.error) return send(res, 400, { error: parsed.error });
  if (!Object.keys(parsed.changes).length) return send(res, 400, { error: 'nothing_to_change' });
  if (!parsed.important) { applyChanges(r, parsed.changes); return send(res, 200, { applied: true }); }
  if (r.scheduled_at && now() >= r.scheduled_at - CHANGE_CUTOFF_MS) return send(res, 409, { error: 'too_late_for_change' });
  if (!r.translator_id) { applyChanges(r, parsed.changes); return send(res, 200, { applied: true }); }
  // مترجم پذیرفته: رضایت او لازم است
  if (db.prepare("SELECT 1 FROM change_requests WHERE reservation_id = ? AND status = 'pending'").get(r.id)) return send(res, 409, { error: 'change_pending' });
  const count = db.prepare('SELECT COUNT(*) AS n FROM change_requests WHERE reservation_id = ?').get(r.id).n;
  if (count >= CHANGE_LIMIT) return send(res, 409, { error: 'change_limit' });
  const info = db.prepare('INSERT INTO change_requests (reservation_id, changes, status, expires_at, created_at) VALUES (?, ?, ?, ?, ?)')
    .run(r.id, JSON.stringify(parsed.changes), 'pending', now() + CHANGE_WINDOW_MS, now());
  send(res, 202, { pending: true, id: info.lastInsertRowid, expires_at: new Date(now() + CHANGE_WINDOW_MS).toISOString() });
});

// ---------- تمدید زمان خدمت در جریان (سند: تمدید فقط با تأیید مترجم) ----------
// قیمت تمدید از روی همان نرخ لحظه‌ی ثبت رزرو حساب می‌شود (base/hours) تا تغییر تعرفه‌ی مدیر روی رزرو باز اثر نگذارد.
function extensionQuote(r, extraHours) {
  const perHourBase = r.hours > 0 ? Math.round(r.base / r.hours) : 0;
  const extraBase = perHourBase * extraHours;
  const extraTax = r.base > 0 ? Math.round(extraBase * r.tax / r.base) : 0;
  const extraNet = r.base > 0 ? Math.round(extraBase * r.net / r.base) : 0;
  return { extraBase, extraTax, extraNet };
}
const EXTENSION_MAX_HOURS = 12; // سقف کل مدت خدمت، هماهنگ با سقف ثبت رزرو

route('POST', '/api/traveler/bookings/:id/extend', async (req, res, url, params) => {
  const u = requireUser(req, res, 'traveler'); if (!u) return;
  const r = ownReservation(res, u, params); if (!r) return;
  const b = await readJson(req);
  const extra = Math.trunc(Number(b.extra_hours)) || 1;
  if (extra < 1 || extra > 4) return send(res, 400, { error: 'invalid_extension' });
  // تمدید فقط وقتی خدمت واقعاً شروع شده و هنوز تمام نشده است
  if (r.status !== 'matched' || !r.service_started_at || !r.translator_id) return send(res, 409, { error: 'extension_not_allowed' });
  if ((r.hours || 1) + extra > EXTENSION_MAX_HOURS) return send(res, 409, { error: 'extension_limit' });
  if (db.prepare("SELECT 1 FROM extension_requests WHERE reservation_id = ? AND status = 'pending'").get(r.id)) {
    return send(res, 409, { error: 'extension_pending' });
  }
  const q = extensionQuote(r, extra);
  const info = db.prepare(`INSERT INTO extension_requests (reservation_id, extra_hours, extra_base, extra_tax, extra_net, status, expires_at, created_at)
    VALUES (?, ?, ?, ?, ?, 'pending', ?, ?)`)
    .run(r.id, extra, q.extraBase, q.extraTax, q.extraNet, now() + CHANGE_WINDOW_MS, now());
  send(res, 202, { pending: true, id: info.lastInsertRowid, extra_hours: extra,
    extra_total: q.extraBase + q.extraTax, new_total: r.total + q.extraBase + q.extraTax,
    expires_at: new Date(now() + CHANGE_WINDOW_MS).toISOString() });
});

function ownExtension(res, u, params) {
  const id = parseId(params.id);
  const e = id && db.prepare('SELECT e.*, r.translator_id AS tid FROM extension_requests e JOIN reservations r ON r.id = e.reservation_id WHERE e.id = ?').get(id);
  if (!e || e.tid !== u.id) { send(res, 404, { error: 'not_found' }); return null; }
  return e;
}
route('GET', '/api/translator/extensions/:id', async (req, res, url, params) => {
  const u = requireUser(req, res, 'translator'); if (!u) return;
  if (!activeTranslator(res, u)) return;
  const e = ownExtension(res, u, params); if (!e) return;
  send(res, 200, { id: e.id, reservation_id: e.reservation_id,
    status: e.status === 'pending' && e.expires_at <= now() ? 'expired' : e.status,
    extra_hours: e.extra_hours, extra_total: e.extra_base + e.extra_tax, extra_net: e.extra_net,
    expires_at: new Date(e.expires_at).toISOString() });
});
route('POST', '/api/translator/extensions/:id/accept', async (req, res, url, params) => {
  const u = requireUser(req, res, 'translator'); if (!u) return;
  if (!activeTranslator(res, u)) return;
  const e = ownExtension(res, u, params); if (!e) return;
  if (e.status !== 'pending' || e.expires_at <= now()) return send(res, 410, { error: 'extension_expired' });
  const r = db.prepare('SELECT * FROM reservations WHERE id = ?').get(e.reservation_id);
  if (!r || r.status !== 'matched') return send(res, 409, { error: 'extension_not_allowed' });
  db.prepare("UPDATE extension_requests SET status = 'accepted', decided_at = ? WHERE id = ?").run(now(), e.id);
  db.prepare(`UPDATE reservations SET hours = hours + ?, base = base + ?, tax = tax + ?, total = total + ?, net = net + ?, updated_at = ? WHERE id = ?`)
    .run(e.extra_hours, e.extra_base, e.extra_tax, e.extra_base + e.extra_tax, e.extra_net, now(), r.id);
  send(res, 200, { ok: true });
});
route('POST', '/api/translator/extensions/:id/reject', async (req, res, url, params) => {
  const u = requireUser(req, res, 'translator'); if (!u) return;
  if (!activeTranslator(res, u)) return;
  const e = ownExtension(res, u, params); if (!e) return;
  if (e.status !== 'pending' || e.expires_at <= now()) return send(res, 410, { error: 'extension_expired' });
  db.prepare("UPDATE extension_requests SET status = 'rejected', decided_at = ? WHERE id = ?").run(now(), e.id);
  send(res, 200, { ok: true });
});

function ownChange(res, u, params) {
  const id = parseId(params.id);
  const c = id && db.prepare('SELECT c.*, r.translator_id AS tid FROM change_requests c JOIN reservations r ON r.id = c.reservation_id WHERE c.id = ?').get(id);
  if (!c || c.tid !== u.id) { send(res, 404, { error: 'not_found' }); return null; }
  return c;
}
route('GET', '/api/translator/changes/:id', async (req, res, url, params) => {
  const u = requireUser(req, res, 'translator'); if (!u) return;
  if (!activeTranslator(res, u)) return;
  const c = ownChange(res, u, params); if (!c) return;
  send(res, 200, { id: c.id, reservation_id: c.reservation_id,
    status: c.status === 'pending' && c.expires_at <= now() ? 'expired' : c.status,
    changes: JSON.parse(c.changes), expires_at: new Date(c.expires_at).toISOString() });
});
route('POST', '/api/translator/changes/:id/accept', async (req, res, url, params) => {
  const u = requireUser(req, res, 'translator'); if (!u) return;
  if (!activeTranslator(res, u)) return;
  const c = ownChange(res, u, params); if (!c) return;
  if (c.status !== 'pending' || c.expires_at <= now()) return send(res, 410, { error: 'change_expired' });
  const r = db.prepare('SELECT * FROM reservations WHERE id = ?').get(c.reservation_id);
  if (!r || r.status !== 'matched') return send(res, 409, { error: 'change_not_allowed' });
  db.transaction(() => {
    db.prepare("UPDATE change_requests SET status = 'accepted', decided_at = ? WHERE id = ?").run(now(), c.id);
    applyChanges(r, JSON.parse(c.changes));
  })();
  send(res, 200, { ok: true });
});
route('POST', '/api/translator/changes/:id/reject', async (req, res, url, params) => {
  const u = requireUser(req, res, 'translator'); if (!u) return;
  if (!activeTranslator(res, u)) return;
  const c = ownChange(res, u, params); if (!c) return;
  if (c.status !== 'pending' || c.expires_at <= now()) return send(res, 410, { error: 'change_expired' });
  db.prepare("UPDATE change_requests SET status = 'rejected', decided_at = ? WHERE id = ?").run(now(), c.id);
  send(res, 200, { ok: true });
});


// ---------- قابلیت‌ها، شهرها و ممیزی (پنل مدیر) ----------
function featuresNow() {
  let stored = {};
  try { stored = JSON.parse(settingRaw('features') || '{}'); } catch (e) { stored = {}; }
  return resolveFeatures(stored);
}
function featureOn(key) { return featuresNow()[key] === true; }
function requireFeature(res, key) {
  if (featureOn(key)) return true;
  send(res, 409, { error: 'feature_disabled', feature: key });
  return false;
}
function audit(action, detail) {
  // هویت عامل از زمینهٔ درخواست ادمین خوانده می‌شود؛ اقدامات سیستم بدون actor ثبت می‌شوند
  const ctx = ADMIN_CTX.getStore();
  const actor = ctx && ctx.admin ? ctx.admin.username : null;
  db.prepare('INSERT INTO audit_log (created_at, action, detail, actor) VALUES (?, ?, ?, ?)').run(now(), action, JSON.stringify(detail || {}), actor);
}
// خط زمانی رزرو: هر گذار مهم یک ردیف در reservation_events ثبت می‌کند.
// رویدادهای وضعیتی از setStatus می‌آیند (status_* ) و گذارهای صریح از نقاط فراخوانی.
function revEvent(reservationId, event, actor, detail) {
  if (!reservationId) return;
  try {
    db.prepare('INSERT INTO reservation_events (reservation_id, event, actor, detail, created_at) VALUES (?, ?, ?, ?, ?)')
      .run(reservationId, String(event), String(actor || 'system'), JSON.stringify(detail || {}), now());
  } catch (e) { /* ثبت خط زمانی هرگز جریان اصلی را نباید بشکند */ }
}
function defaultCityId() {
  const v = Number(getSetting('default_city_id'));
  return Number.isInteger(v) && v > 0 ? v : null;
}
// ---------- هندسهٔ پوشش سرویس (منطق تحقیق‌شدهٔ شهر/شعاع) ----------
// شعاع هر شهر یعنی «مرز جغرافیایی مسئولیت آن شهر» (الگوی service area در پلتفرم‌های اعزام):
// هر نقطهٔ ملاقات فقط به شهری تعلق دارد که دایرهٔ پوششش (مرکز + radius_km) آن نقطه را در بر بگیرد.
// اگر چند شهر یک نقطه را پوشش دهند، شهری برنده است که نقطه نسبت به شعاعش مرکزتر باشد (نسبت فاصله/شعاع کمینه).
function haversineKm(la1, lo1, la2, lo2) {
  const R = 6371, p = Math.PI / 180;
  const a = Math.sin((la2 - la1) * p / 2) * Math.sin((la2 - la1) * p / 2) +
    Math.cos(la1 * p) * Math.cos(la2 * p) * Math.sin((lo2 - lo1) * p / 2) * Math.sin((lo2 - lo1) * p / 2);
  return 2 * R * Math.asin(Math.sqrt(a));
}
function cityCoveringPoint(lat, lng) {
  let best = null;
  for (const c of db.prepare('SELECT id, lat, lng, radius_km, traveler_enabled FROM cities').all()) {
    const d = haversineKm(lat, lng, c.lat, c.lng);
    if (d <= c.radius_km && (!best || d / c.radius_km < best.d / best.radius_km)) {
      best = { id: c.id, d, radius_km: c.radius_km, traveler_enabled: c.traveler_enabled };
    }
  }
  return best;
}
// شهر درخواست: city_id صریح یا شهر پیش‌فرض؛ باید وجود داشته و برای آن نقش فعال باشد
function resolveCity(raw, role) {
  const id = raw === undefined || raw === null || raw === '' ? defaultCityId() : parseId(raw);
  if (!id) return { error: 'city_required', status: 400 };
  const c = db.prepare('SELECT id, name_fa, traveler_enabled, translator_enabled FROM cities WHERE id = ?').get(id);
  if (!c) return { error: 'invalid_city', status: 400 };
  const on = role === 'traveler' ? c.traveler_enabled : c.translator_enabled;
  if (!on) return { error: 'city_not_active', status: 409 };
  return { city: c };
}

route('GET', '/api/admin/features', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  const on = featuresNow();
  send(res, 200, { features: FEATURE_KEYS.map((k) => ({ key: k, group: FEATURES[k].group, label: FEATURES[k].label,
    implemented: FEATURES[k].implemented, requires: FEATURES[k].requires, effect: FEATURES[k].effect, enabled: on[k] })) });
});

route('PUT', '/api/admin/features', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  if (!requirePerm(req, res, 'features.manage')) return;
  const b = await readJson(req);
  const before = featuresNow();
  const v = validateFeaturePatch(b, before);
  if (!v.ok) return send(res, v.status, { error: v.error, key: v.key, requires: v.requires });
  const changed = FEATURE_KEYS.filter((k) => v.next[k] !== before[k]);
  const stored = {};
  for (const k of FEATURE_KEYS) stored[k] = v.next[k];
  db.transaction(() => {
    db.prepare('INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value')
      .run('features', JSON.stringify(stored));
    // خاموش‌کردن ثبت‌نام آنلاین: مترجمان آنلاین به حالت آفلاین برگردند
    if (changed.includes('translator_online') && !v.next.translator_online) {
      db.prepare('UPDATE translators SET online = 0').run();
    }
  })();
  audit('features.update', { changed: changed.map((k) => ({ key: k, enabled: v.next[k] })) });
  send(res, 200, { ok: true, changed });
});

// ورودی شهر: اعتبارسنجی سخت‌گیرانه؛ partial یعنی فقط فیلدهای ارسالی بررسی شوند
function cityInput(b, partial) {
  const out = {};
  if (!partial || b.name_fa !== undefined) {
    const nf = typeof b.name_fa === 'string' ? b.name_fa.trim() : '';
    if (nf.length < 2 || nf.length > 40) return { error: 'invalid_name' };
    out.name_fa = nf;
  }
  if (b.name_en !== undefined) {
    const ne = typeof b.name_en === 'string' ? b.name_en.trim() : '';
    if (ne.length > 40 || !/^[A-Za-z][A-Za-z .'-]*$/.test(ne) && ne !== '') return { error: 'invalid_name_en' };
    out.name_en = ne;
  }
  if (b.province !== undefined) {
    if (typeof b.province !== 'string' || b.province.length > 60) return { error: 'invalid_province' };
    out.province = b.province.trim();
  }
  if (!partial || b.lat !== undefined) {
    const la = typeof b.lat === 'number' ? b.lat : NaN;
    if (!Number.isFinite(la) || la < -90 || la > 90) return { error: 'invalid_lat' };
    out.lat = la;
  }
  if (!partial || b.lng !== undefined) {
    const lo = typeof b.lng === 'number' ? b.lng : NaN;
    if (!Number.isFinite(lo) || lo < -180 || lo > 180) return { error: 'invalid_lng' };
    out.lng = lo;
  }
  if (!partial || b.radius_km !== undefined) {
    const r = b.radius_km === undefined ? 30 : b.radius_km;
    if (!Number.isInteger(r) || r < 1 || r > 200) return { error: 'invalid_radius' };
    out.radius_km = r;
  }
  for (const k of ['traveler_enabled', 'translator_enabled']) {
    if (!partial || b[k] !== undefined) {
      const val = b[k] === undefined ? true : b[k];
      if (typeof val !== 'boolean') return { error: 'invalid_value', key: k };
      out[k] = val ? 1 : 0;
    }
  }
  return { value: out };
}

const cityView = (c) => ({ id: c.id, name_fa: c.name_fa, name_en: c.name_en, province: c.province, lat: c.lat, lng: c.lng,
  radius_km: c.radius_km, traveler_enabled: c.traveler_enabled === 1, translator_enabled: c.translator_enabled === 1,
  translators: c.translators || 0, open_bookings: c.open_bookings || 0, matched_bookings: c.matched_bookings || 0,
  translators_online: c.translators_online || 0, bookings_7d: c.bookings_7d || 0, done_7d: c.done_7d || 0 });

route('GET', '/api/admin/cities', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  const since7 = now() - 7 * DAY_MS;
  const rows = db.prepare(`SELECT c.*,
      (SELECT COUNT(*) FROM translators t WHERE t.city_id = c.id AND t.status LIKE 'active_%') AS translators,
      (SELECT COUNT(*) FROM reservations r WHERE r.city_id = c.id AND r.status IN (${UNMATCHED_SQL})) AS open_bookings,
      (SELECT COUNT(*) FROM reservations r WHERE r.city_id = c.id AND r.status = 'matched') AS matched_bookings,
      (SELECT COUNT(*) FROM translators t WHERE t.city_id = c.id AND t.online = 1) AS translators_online,
      (SELECT COUNT(*) FROM reservations r WHERE r.city_id = c.id AND r.created_at >= ?) AS bookings_7d,
      (SELECT COUNT(*) FROM reservations r WHERE r.city_id = c.id AND r.status = 'done' AND r.created_at >= ?) AS done_7d
    FROM cities c ORDER BY c.id`).all(since7, since7);
  send(res, 200, { cities: rows.map(cityView), default_city_id: defaultCityId() });
});

route('POST', '/api/admin/cities', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  if (!requirePerm(req, res, 'cities.manage')) return;
  const b = await readJson(req);
  const v = cityInput(b && typeof b === 'object' ? b : {}, false);
  if (v.error) return send(res, 400, { error: v.error, key: v.key });
  const t = now();
  let id;
  try {
    const r = db.prepare(`INSERT INTO cities (name_fa, name_en, province, lat, lng, radius_km, traveler_enabled, translator_enabled, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).run(v.value.name_fa, v.value.name_en || '', v.value.province || '', v.value.lat,
      v.value.lng, v.value.radius_km, v.value.traveler_enabled, v.value.translator_enabled, t, t);
    id = Number(r.lastInsertRowid);
  } catch (e) {
    if (/UNIQUE/.test(e.message)) return send(res, 409, { error: 'city_exists' });
    throw e;
  }
  audit('city.create', { id, name_fa: v.value.name_fa });
  send(res, 201, { ok: true, id });
});

route('PATCH', '/api/admin/cities/:id', async (req, res, url, params) => {
  if (!requireAdmin(req, res)) return;
  if (!requirePerm(req, res, 'cities.manage')) return;
  const id = parseId(params.id);
  const cur = id && db.prepare('SELECT * FROM cities WHERE id = ?').get(id);
  if (!cur) return send(res, 404, { error: 'not_found' });
  const b = await readJson(req);
  if (!b || typeof b !== 'object' || Array.isArray(b)) return send(res, 400, { error: 'invalid_body' });
  const v = cityInput(b, true);
  if (v.error) return send(res, 400, { error: v.error, key: v.key });
  const keys = Object.keys(v.value);
  if (!keys.length) return send(res, 400, { error: 'nothing_to_change' });
  const next = { ...cur, ...v.value };
  const closing = cur.traveler_enabled === 1 && next.traveler_enabled === 0;
  const openIds = closing
    ? db.prepare(`SELECT id FROM reservations WHERE city_id = ? AND status IN (${UNMATCHED_SQL})`).all(id).map((x) => x.id)
    : [];
  if (openIds.length && b.confirm_cancel !== true) {
    return send(res, 409, { error: 'open_bookings', count: openIds.length });
  }
  db.transaction(() => {
    db.prepare(`UPDATE cities SET name_fa = ?, name_en = ?, province = ?, lat = ?, lng = ?, radius_km = ?,
      traveler_enabled = ?, translator_enabled = ?, updated_at = ? WHERE id = ?`)
      .run(next.name_fa, next.name_en, next.province, next.lat, next.lng, next.radius_km,
        next.traveler_enabled, next.translator_enabled, now(), id);
    // رزروهای باز این شهر (هنوز مترجم ندارند) لغو می‌شوند؛ بدون کارمزد، چون تطبیق نشده است
    for (const rid of openIds) { closeOffers(rid); setStatus(rid, 'cancelled'); }
  })();
  audit('city.update', { id, changed: keys, cancelled: openIds.length });
  send(res, 200, { ok: true, cancelled: openIds.length });
});

// پوشش سرویس: رزروهای «بیرون از پوشش» (نقاط کور) — رزروهای بازِ دارای مختصات که داخل هیچ دایرهٔ شهری نیستند.
// این‌ها رزروهایی‌اند که تطبیق هم‌شهری برایشان احتمال شکست دارد؛ کارشناس باید شهر را اصلاح یا پوشش را گسترش دهد.
route('GET', '/api/admin/coverage', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  const rows = db.prepare(`SELECT r.id, r.place, r.lat, r.lng, r.status, r.kind, r.traveler_name, r.created_at,
      c.name_fa AS city_name
    FROM reservations r LEFT JOIN cities c ON c.id = r.city_id
    WHERE r.lat IS NOT NULL AND r.lng IS NOT NULL AND r.status IN (${UNMATCHED_SQL}) ORDER BY r.created_at DESC LIMIT 100`).all();
  const outside = rows.filter((r) => !cityCoveringPoint(r.lat, r.lng));
  send(res, 200, { checked: rows.length,
    outside: outside.map((r) => ({ id: r.id, place: r.place || '', lat: r.lat, lng: r.lng, status: r.status, kind: r.kind,
      traveler_name: r.traveler_name || '', city_name: r.city_name || '', created_at: r.created_at })) });
});

// صف «گیر کرده‌ها» (نردبان CAP): چه مترجمی منتظر کدام گیت است تا کارشناس سریع بازش کند
route('GET', '/api/admin/gates', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  const rows = db.prepare(`SELECT t.user_id, t.status, t.fields, t.profile, u.phone
    FROM translators t JOIN users u ON u.id = t.user_id
    WHERE t.status IN ('pending_review', 'active_general', 'active_specialized') ORDER BY t.updated_at ASC LIMIT 300`).all();
  const stuck = [];
  for (const t0 of rows) {
    let pr = {}; try { pr = JSON.parse(t0.profile || '{}'); } catch (e) {}
    const F = JSON.parse(t0.fields || '[]').map((f) => FIELD_ALIAS[f] || f);
    const items = [];
    if (t0.status === 'pending_review') items.push({ gate: 'decision', label: 'انتظار تصمیم کارشناس (بررسی نهایی)' });
    if (t0.status !== 'pending_review' && F.some((f) => SPEC_FIELDS.has(f)) && !langCertOk(t0))
      items.push({ gate: 'lang_cert', label: 'مدرک زبان برای حوزه‌های تخصصی ارسال/تأیید نشده است' });
    if (pr.car === true && !carReady(t0, 1))
      items.push({ gate: 'car', label: 'مدارک خودرو (بیمه/گواهینامه) کامل یا تأیید نیست' });
    if (items.length) stuck.push({ id: t0.user_id, phone: t0.phone, status: t0.status, name: [pr.first_name, pr.last_name].filter(Boolean).join(' '), blocked: items });
  }
  send(res, 200, { stuck });
});

// ---------- نسل دوم پنل: هویت کارمند جاری ----------
route('GET', '/api/admin/me', async (req, res) => {
  if (!ADMIN_PASSWORD) return send(res, 404, { error: 'not_found' });
  const u = adminUserOf(req);
  if (!u) return send(res, 401, { error: 'unauthorized' });
  const perms = Object.keys(ADMIN_PERMS).filter((p) => (ADMIN_PERMS[p] || []).includes(u.role));
  send(res, 200, { user: { id: u.id, username: u.username, name: u.name, role: u.role, role_fa: ADMIN_ROLES[u.role] || u.role }, perms });
});

// ---------- کارمندان و نقش‌ها (فقط صاحب پلتفرم) ----------
route('GET', '/api/admin/staff', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  if (!requirePerm(req, res, 'staff.manage')) return;
  const rows = db.prepare(`SELECT u.id, u.username, u.name, u.role, u.is_active, u.created_at, u.last_login_at,
      (SELECT COUNT(*) FROM admin_sessions s WHERE s.admin_user_id = u.id AND s.expires_at > ?) AS sessions
    FROM admin_users u ORDER BY u.id`).all(now());
  send(res, 200, { staff: rows.map((r) => ({ id: r.id, username: r.username, name: r.name, role: r.role,
    is_active: r.is_active === 1, created_at: r.created_at, last_login_at: r.last_login_at || null, sessions: r.sessions })) });
});

route('POST', '/api/admin/staff', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  if (!requirePerm(req, res, 'staff.manage')) return;
  const b = await readJson(req);
  const username = clip(b.username, 40).toLowerCase();
  if (!/^[a-z0-9_.-]{3,40}$/.test(username)) return send(res, 400, { error: 'invalid_username' });
  if (!ADMIN_ROLES[b.role]) return send(res, 400, { error: 'invalid_role' });
  if (isWeakAdminPassword(String(b.password || ''))) return send(res, 400, { error: 'weak_password' });
  if (db.prepare('SELECT 1 FROM admin_users WHERE username = ?').get(username)) return send(res, 409, { error: 'username_taken' });
  const t = now();
  const r = db.prepare('INSERT INTO admin_users (username, name, password_hash, role, is_active, created_at) VALUES (?, ?, ?, ?, 1, ?)')
    .run(username, clip(b.name, 80), hashAdminPassword(String(b.password)), b.role, t);
  const id = Number(r.lastInsertRowid);
  audit('staff.create', { id, username, role: b.role });
  send(res, 201, { ok: true, id });
});

route('PATCH', '/api/admin/staff/:id', async (req, res, url, params) => {
  if (!requireAdmin(req, res)) return;
  if (!requirePerm(req, res, 'staff.manage')) return;
  const id = parseId(params.id);
  const target = id && db.prepare('SELECT * FROM admin_users WHERE id = ?').get(id);
  if (!target) return send(res, 404, { error: 'not_found' });
  const me = adminUserOf(req);
  const b = await readJson(req);
  const next = { name: target.name, role: target.role, is_active: target.is_active };
  if (b.name !== undefined) next.name = clip(b.name, 80);
  if (b.role !== undefined) {
    if (!ADMIN_ROLES[b.role]) return send(res, 400, { error: 'invalid_role' });
    next.role = b.role;
  }
  if (b.is_active !== undefined) next.is_active = b.is_active ? 1 : 0;
  if (next.role !== 'owner' || !next.is_active) {
    // آخرین owner فعال نمی‌تواند حذف نقش یا غیرفعال شود (ضد قفل‌شدن پنل)
    const otherOwners = db.prepare("SELECT COUNT(*) AS n FROM admin_users WHERE role = 'owner' AND is_active = 1 AND id != ?").get(target.id).n;
    if (target.role === 'owner' && otherOwners === 0) return send(res, 409, { error: 'last_owner' });
  }
  if (me && me.id === target.id && !next.is_active) return send(res, 409, { error: 'self_disable' });
  db.prepare('UPDATE admin_users SET name = ?, role = ?, is_active = ? WHERE id = ?').run(next.name, next.role, next.is_active, target.id);
  if (!next.is_active) db.prepare('DELETE FROM admin_sessions WHERE admin_user_id = ?').run(target.id);
  audit('staff.update', { id: target.id, name: next.name, role: next.role, is_active: !!next.is_active });
  send(res, 200, { ok: true });
});

route('POST', '/api/admin/staff/:id/password', async (req, res, url, params) => {
  if (!requireAdmin(req, res)) return;
  if (!requirePerm(req, res, 'staff.manage')) return;
  const id = parseId(params.id);
  const target = id && db.prepare('SELECT id, username FROM admin_users WHERE id = ?').get(id);
  if (!target) return send(res, 404, { error: 'not_found' });
  const b = await readJson(req);
  if (isWeakAdminPassword(String(b.password || ''))) return send(res, 400, { error: 'weak_password' });
  db.prepare('UPDATE admin_users SET password_hash = ? WHERE id = ?').run(hashAdminPassword(String(b.password)), target.id);
  db.prepare('DELETE FROM admin_sessions WHERE admin_user_id = ?').run(target.id); // نشست‌های قدیمی باطل
  audit('staff.password_reset', { id: target.id, username: target.username });
  send(res, 200, { ok: true });
});

route('POST', '/api/admin/staff/:id/revoke', async (req, res, url, params) => {
  if (!requireAdmin(req, res)) return;
  if (!requirePerm(req, res, 'staff.manage')) return;
  const id = parseId(params.id);
  const target = id && db.prepare('SELECT id, username FROM admin_users WHERE id = ?').get(id);
  if (!target) return send(res, 404, { error: 'not_found' });
  db.prepare('DELETE FROM admin_sessions WHERE admin_user_id = ?').run(target.id);
  audit('staff.revoke_sessions', { id: target.id, username: target.username });
  send(res, 200, { ok: true });
});

// ---------- صف چرخهٔ تغییرات (تغییر + تمدید در انتظار تصمیم مترجم) ----------
route('GET', '/api/admin/changes', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  const t = now();
  const base = `SELECT cr.id, cr.reservation_id, cr.status, cr.created_at, cr.decided_at,
      r.traveler_name, r.place, r.status AS reservation_status, r.translator_id,
      COALESCE(json_extract(tp.profile, '$.first_name') || ' ' || json_extract(tp.profile, '$.last_name'), '') AS translator_name
    FROM change_requests cr
    JOIN reservations r ON r.id = cr.reservation_id
    LEFT JOIN users tru ON tru.id = r.translator_id
    LEFT JOIN translators tp ON tp.user_id = r.translator_id`;
  const extBase = `SELECT er.id, er.reservation_id, er.status, er.created_at, er.decided_at, er.extra_hours, er.extra_net,
      r.traveler_name, r.place, r.status AS reservation_status, r.translator_id,
      COALESCE(json_extract(tp.profile, '$.first_name') || ' ' || json_extract(tp.profile, '$.last_name'), '') AS translator_name
    FROM extension_requests er
    JOIN reservations r ON r.id = er.reservation_id
    LEFT JOIN users tru ON tru.id = r.translator_id
    LEFT JOIN translators tp ON tp.user_id = r.translator_id`;
  const changes = db.prepare(base + " ORDER BY (cr.status = 'pending') DESC, cr.id DESC LIMIT 100").all()
    .map((r) => ({ id: r.id, kind: 'change', reservation_id: r.reservation_id, status: r.status,
      created_at: r.created_at, decided_at: r.decided_at, traveler_name: r.traveler_name || '', place: r.place || '',
      reservation_status: r.reservation_status, translator_name: r.translator_name || '',
      waiting_minutes: r.status === 'pending' ? Math.round((t - r.created_at) / 60000) : null }));
  const extensions = db.prepare(extBase + " ORDER BY (er.status = 'pending') DESC, er.id DESC LIMIT 100").all()
    .map((r) => ({ id: r.id, kind: 'extension', reservation_id: r.reservation_id, status: r.status,
      created_at: r.created_at, decided_at: r.decided_at, extra_hours: r.extra_hours, extra_net: r.extra_net,
      traveler_name: r.traveler_name || '', place: r.place || '',
      reservation_status: r.reservation_status, translator_name: r.translator_name || '',
      waiting_minutes: r.status === 'pending' ? Math.round((t - r.created_at) / 60000) : null }));
  const all = changes.concat(extensions).sort((a, b) => (a.status === 'pending' ? 0 : 1) - (b.status === 'pending' ? 0 : 1) || b.created_at - a.created_at);
  send(res, 200, { changes: all.slice(0, 150), pending_count: all.filter((x) => x.status === 'pending').length });
});

// ---------- گزارش‌های عملیات (نمونه‌برداری از داشبوردهای استاندارد اعزام: نرخ تکمیل، زمان تطبیق، لغو، درآمد) ----------
route('GET', '/api/admin/reports', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  if (!requirePerm(req, res, 'reports.view')) return;
  const q = new URL(req.url, 'http://x').searchParams;
  const days = [7, 30, 90].includes(Number(q.get('days'))) ? Number(q.get('days')) : 7;
  const since = now() - days * DAY_MS;
  const created = db.prepare('SELECT COUNT(*) AS n FROM reservations WHERE created_at >= ?').get(since).n;
  const done = db.prepare("SELECT COUNT(*) AS n FROM reservations WHERE status = 'done' AND created_at >= ?").get(since).n;
  const cancelled = db.prepare("SELECT COUNT(*) AS n FROM reservations WHERE status = 'cancelled' AND created_at >= ?").get(since).n;
  const avgMatchRow = db.prepare('SELECT AVG(matched_at - created_at) AS a FROM reservations WHERE matched_at IS NOT NULL AND created_at >= ?').get(since);
  const byMethod = db.prepare(`SELECT COALESCE(pay_method, 'none') AS m, COUNT(*) AS n, COALESCE(SUM(total), 0) AS sum
    FROM reservations WHERE created_at >= ? AND status IN ('finished','done') GROUP BY COALESCE(pay_method, 'none')`).all(since);
  const payout = db.prepare("SELECT COALESCE(SUM(net), 0) AS n FROM reservations WHERE created_at >= ? AND status = 'done'").get(since).n;
  const perDay = db.prepare(`SELECT date(created_at / 1000, 'unixepoch') AS d,
      SUM(CASE WHEN 1=1 THEN 1 ELSE 0 END) AS created,
      SUM(CASE WHEN status = 'done' THEN 1 ELSE 0 END) AS done,
      SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) AS cancelled
    FROM reservations WHERE created_at >= ? GROUP BY d ORDER BY d`).all(since);
  const topTranslators = db.prepare(`SELECT r.translator_id AS id,
      COALESCE(json_extract(tp.profile, '$.first_name') || ' ' || json_extract(tp.profile, '$.last_name'), '') AS name,
      COUNT(*) AS missions, COALESCE(SUM(r.net), 0) AS net
    FROM reservations r LEFT JOIN translators tp ON tp.user_id = r.translator_id
    WHERE r.created_at >= ? AND r.status = 'done' AND r.translator_id IS NOT NULL
    GROUP BY r.translator_id ORDER BY missions DESC LIMIT 8`).all(since);
  const newTranslators = db.prepare("SELECT COUNT(*) AS n FROM users WHERE role = 'translator' AND created_at >= ?").get(since).n;
  const activeTranslators = db.prepare("SELECT COUNT(*) AS n FROM translators WHERE status LIKE 'active_%'").get().n;
  send(res, 200, {
    days, generated_at: new Date().toISOString(),
    bookings: { created, done, cancelled,
      completion_rate: created ? Math.round((done / created) * 100) : null,
      cancel_rate: created ? Math.round((cancelled / created) * 100) : null,
      avg_match_minutes: avgMatchRow && avgMatchRow.a != null ? Math.round(avgMatchRow.a / 60000) : null },
    finance: { revenue_by_method: byMethod.map((x) => ({ method: x.m, count: x.n, total: x.sum })), translator_payout: payout },
    translators: { new_signups: newTranslators, active: activeTranslators },
    per_day: perDay,
    top_translators: topTranslators,
  });
});

// خروجی CSV رزروها (برای اکسل؛ با BOM تا فارسی درست باز شود)
route('GET', '/api/admin/reports.csv', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  if (!requirePerm(req, res, 'reports.view')) return;
  const q = new URL(req.url, 'http://x').searchParams;
  const days = [7, 30, 90].includes(Number(q.get('days'))) ? Number(q.get('days')) : 30;
  const since = now() - days * DAY_MS;
  const rows = db.prepare(`SELECT r.id, r.created_at, r.kind, r.status, r.traveler_name, r.place, r.origin_lang, r.dest_lang,
      r.field, r.hours, r.car, r.total, r.net, r.pay_method, r.pay_state, r.scheduled_at,
      tu.phone AS translator_phone,
      COALESCE(json_extract(tp.profile, '$.first_name') || ' ' || json_extract(tp.profile, '$.last_name'), '') AS translator_name
    FROM reservations r
    LEFT JOIN users tu ON tu.id = r.translator_id
    LEFT JOIN translators tp ON tp.user_id = r.translator_id
    WHERE r.created_at >= ? ORDER BY r.id DESC LIMIT 5000`).all(since);
  const esc = (v) => '"' + String(v == null ? '' : v).replace(/"/g, '""') + '"';
  const head = ['id', 'created_at', 'kind', 'status', 'traveler_name', 'place', 'langs', 'field', 'hours', 'car', 'total', 'net', 'pay_method', 'pay_state', 'translator_name', 'translator_phone'];
  const lines = [head.join(',')];
  for (const r of rows) {
    lines.push([r.id, new Date(r.created_at).toISOString(), r.kind, r.status, esc(r.traveler_name), esc(r.place),
      r.origin_lang + '-' + r.dest_lang, r.field, r.hours, r.car ? 'yes' : 'no', r.total, r.net,
      r.pay_method || '', r.pay_state || '', esc(r.translator_name), r.translator_phone || ''].join(','));
  }
  audit('reports.export_csv', { days, rows: rows.length });
  res.writeHead(200, { 'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': 'attachment; filename="hamrah-bookings.csv"', 'Cache-Control': 'no-store' });
  res.end('\ufeff' + lines.join('\r\n'));
});

// ---------- پروندهٔ مسافر + مسدودسازی ----------
route('GET', '/api/admin/travelers/:id', async (req, res, url, params) => {
  if (!requireAdmin(req, res)) return;
  const id = parseId(params.id);
  const u = id && db.prepare("SELECT id, phone, created_at, blocked FROM users WHERE id = ? AND role = 'traveler'").get(id);
  if (!u) return send(res, 404, { error: 'not_found' });
  const stats = db.prepare(`SELECT COUNT(*) AS total,
      SUM(CASE WHEN status = 'done' THEN 1 ELSE 0 END) AS done,
      SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) AS cancelled
    FROM reservations WHERE traveler_id = ?`).get(id);
  const reservations = db.prepare(`SELECT id, kind, status, place, origin_lang, dest_lang, total, net, pay_method, pay_state, created_at, scheduled_at
    FROM reservations WHERE traveler_id = ? ORDER BY id DESC LIMIT 30`).all(id);
  send(res, 200, { traveler: { id: u.id, phone: u.phone, created_at: u.created_at, blocked: u.blocked === 1,
    reservations_total: stats.total || 0, done: stats.done || 0, cancelled: stats.cancelled || 0 },
    reservations });
});

route('POST', '/api/admin/travelers/:id/block', async (req, res, url, params) => {
  if (!requireAdmin(req, res)) return;
  if (!requirePerm(req, res, 'travelers.manage')) return;
  const id = parseId(params.id);
  const u = id && db.prepare("SELECT id FROM users WHERE id = ? AND role = 'traveler'").get(id);
  if (!u) return send(res, 404, { error: 'not_found' });
  const b = await readJson(req).catch(() => ({}));
  const reason = clip(b.reason, 200);
  if (!reason) return send(res, 400, { error: 'reason_required' });
  db.prepare('UPDATE users SET blocked = 1 WHERE id = ?').run(id);
  audit('traveler.block', { id, reason });
  send(res, 200, { ok: true, blocked: true });
});

route('POST', '/api/admin/travelers/:id/unblock', async (req, res, url, params) => {
  if (!requireAdmin(req, res)) return;
  if (!requirePerm(req, res, 'travelers.manage')) return;
  const id = parseId(params.id);
  const u = id && db.prepare("SELECT id FROM users WHERE id = ? AND role = 'traveler'").get(id);
  if (!u) return send(res, 404, { error: 'not_found' });
  db.prepare('UPDATE users SET blocked = 0 WHERE id = ?').run(id);
  audit('traveler.unblock', { id });
  send(res, 200, { ok: true, blocked: false });
});

// ---------- تعلیق/بازفعال‌سازی مترجم (نردبان پاسخ؛ بین «فعال» و «رد‌شده») ----------
route('POST', '/api/admin/translators/:id/suspend', async (req, res, url, params) => {
  if (!requireAdmin(req, res)) return;
  if (!requirePerm(req, res, 'translators.manage')) return;
  const id = parseId(params.id);
  const t = id && db.prepare('SELECT user_id, status FROM translators WHERE user_id = ?').get(id);
  if (!t) return send(res, 404, { error: 'not_found' });
  if (!String(t.status).startsWith('active_')) return send(res, 409, { error: 'not_active', status: t.status });
  const b = await readJson(req).catch(() => ({}));
  const reason = clip(b.reason, 200);
  if (!reason) return send(res, 400, { error: 'reason_required' });
  db.prepare('UPDATE translators SET status = ?, online = 0, updated_at = ? WHERE user_id = ?').run('suspended', now(), id);
  audit('translator.suspend', { id, reason });
  send(res, 200, { ok: true, status: 'suspended' });
});

route('POST', '/api/admin/translators/:id/reactivate', async (req, res, url, params) => {
  if (!requireAdmin(req, res)) return;
  if (!requirePerm(req, res, 'translators.manage')) return;
  const id = parseId(params.id);
  const t = id && db.prepare('SELECT user_id, status, interview FROM translators WHERE user_id = ?').get(id);
  if (!t) return send(res, 404, { error: 'not_found' });
  if (t.status !== 'suspended') return send(res, 409, { error: 'not_suspended', status: t.status });
  // بازگشت به وضعیت مؤثر: اگر گیت تخصص (مدرک زبان) باز باشد، active_specialized وگرنه active_general
  const st = t.interview === 'pass' && langCertOk({ user_id: id }) ? 'active_specialized' : 'active_general';
  db.prepare('UPDATE translators SET status = ?, updated_at = ? WHERE user_id = ?').run(st, now(), id);
  audit('translator.reactivate', { id });
  send(res, 200, { ok: true, status: st });
});

// اعلان دستی کارشناس به مترجم: پیام متنی کوتاه داخل اپ مترجم (بدون پیامک بیرونی؛ ابزار ارتباط پروانه‌ای)
route('POST', '/api/admin/translators/:id/notify', async (req, res, url, params) => {
  if (!requireAdmin(req, res)) return;
  if (!requirePerm(req, res, 'translators.manage')) return;
  const id = parseId(params.id);
  const t = id && db.prepare('SELECT user_id FROM translators WHERE user_id = ?').get(id);
  if (!t) return send(res, 404, { error: 'not_found' });
  const b = await readJson(req).catch(() => ({}));
  const text = clip(b && b.text, 300);
  if (!text) return send(res, 400, { error: 'text_required' });
  db.prepare("INSERT INTO translator_notifications (user_id, kind, created_at, ref) VALUES (?, 'custom', ?, ?)").run(id, now(), text);
  pushTranslator(id, { title: 'پیام از پشتیبانی همراه', body: text, tag: 'custom-' + now() });
  audit('translator.notify', { id });
  send(res, 200, { ok: true });
});

// وضعیت اعلان فوری برای پنل: کلید عمومی VAPID + تعداد اشتراک‌ها + خطاهای اخیر
route('GET', '/api/admin/push', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  if (!requirePerm(req, res, 'settings.manage')) return;
  const d = vapidDetails();
  const n = db.prepare('SELECT COUNT(*) AS n FROM push_subscriptions').get().n;
  const byRole = db.prepare('SELECT role, COUNT(*) AS n FROM push_subscriptions GROUP BY role').all();
  const errs = db.prepare('SELECT COUNT(*) AS n FROM push_subscriptions WHERE last_error IS NOT NULL').get().n;
  send(res, 200, { enabled: !!webpush && !!d, public_key: d ? d.publicKey : null, subscriptions: n, by_role: byRole, with_errors: errs });
});

// اعلان آزمایشی از پنل: بررسی زنده‌ی زنجیره‌ی پوش برای یک کاربر
route('POST', '/api/admin/push/test', async (req, res) => {
  if (!requireAdmin(req, res)) return;
  if (!requirePerm(req, res, 'settings.manage')) return;
  const b = await readJson(req).catch(() => ({}));
  const uid = Number(b && b.user_id);
  if (!Number.isInteger(uid) || uid <= 0) return send(res, 400, { error: 'invalid_user' });
  const u = db.prepare('SELECT id, role FROM users WHERE id = ?').get(uid);
  if (!u) return send(res, 404, { error: 'not_found' });
  const queued = db.prepare('SELECT COUNT(*) AS n FROM push_subscriptions WHERE user_id = ?').get(uid).n;
  pushUser(uid, { title: 'اعلان آزمایشی پنل', body: String((b && b.text) || 'اگر این اعلان را می‌بینید، زنجیره‌ی اعلان فوری کار می‌کند.'), url: u.role === 'translator' ? '/translator/app.html' : '/traveler/app.html', tag: 'admin-test' });
  audit('push.test', { uid });
  send(res, 200, { ok: true, queued });
});

// پرداخت‌های درگاهی برای نمای مالی پنل
route('GET', '/api/admin/gateway-payments', async (req, res, url) => {
  if (!requireAdmin(req, res)) return;
  if (!requirePerm(req, res, 'finance.manage')) return;
  const rows = db.prepare(`SELECT g.id, g.reservation_id, g.provider, g.authority, g.amount, g.status, g.created_at, g.paid_at, g.ref_id,
    r.place, r.traveler_name FROM gateway_payments g LEFT JOIN reservations r ON r.id = g.reservation_id ORDER BY g.id DESC LIMIT 100`).all();
  send(res, 200, { payments: rows.map((r) => ({ id: r.id, reservation_id: r.reservation_id, provider: r.provider,
    authority: r.authority, amount: r.amount, status: r.status, ref_id: r.ref_id, place: r.place, traveler_name: r.traveler_name,
    created_at: new Date(r.created_at).toISOString(), paid_at: r.paid_at ? new Date(r.paid_at).toISOString() : null })) });
});

route('GET', '/api/admin/audit', async (req, res, url) => {
  if (!requireAdmin(req, res)) return;
  if (!requirePerm(req, res, 'audit.view')) return;
  const lim = Math.min(Math.max(Number(url.searchParams.get('limit')) || 100, 1), 500);
  const rows = db.prepare('SELECT id, created_at, action, detail, actor FROM audit_log ORDER BY id DESC LIMIT ?').all(lim);
  send(res, 200, { entries: rows.map((r) => ({ id: r.id, at: new Date(r.created_at).toISOString(), action: r.action, detail: JSON.parse(r.detail), actor: r.actor || null })) });
});

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  const pathname = url.pathname;
  for (const [k, v] of Object.entries(securityHeaders(pathname, FRAME_ANCESTORS, SCRIPT_HASHES))) res.setHeader(k, v);
  if (!pathname.startsWith('/api/') && !pathname.startsWith('/pay/')) {
    if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405); return res.end(); }
    return serveStatic(req, res, pathname);
  }
  let r = null, badParams = false; const params = {};
  for (const x of routes) {
    if (x.method !== req.method) continue;
    const m = pathname.match(x.re);
    if (m) {
      r = x;
      // رمزگشایی امن پارامترها: ورودی بدفرم ۴۰۰ می‌دهد، نه کرش پروسه (یافتهٔ بحرانی ۱)
      for (let i = 0; i < x.keys.length; i++) {
        const d = safeDecode(m[i + 1]);
        if (d === null) { badParams = true; break; }
        params[x.keys[i]] = d;
      }
      break;
    }
  }
  if (badParams) return send(res, 400, { error: 'invalid_encoding' });
  if (!r) return send(res, 404, { error: 'not_found' });
  try {
    if (pathname.startsWith('/api/admin/')) {
      const au = adminUserOf(req);
      await ADMIN_CTX.run({ admin: au }, async () => r.handler(req, res, url, params));
    } else {
      await r.handler(req, res, url, params);
    }
  } catch (e) {
    const status = e.status || 500;
    if (status === 500) console.error('[server]', e);
    if (!res.headersSent) send(res, status, { error: status === 500 ? 'server_error' : e.message });
  }
});

if (require.main === module) {
  // بررسی ایمنی پیکربندی انتشار بالاتر (ابتدای فایل) انجام شده است.
  setInterval(sweep, Math.max(100, 3000 * SCALE)).unref(); // موتور تطبیق هر ۳ ثانیه (در حالت فشرده کوتاه‌تر)
  server.listen(PORT, '0.0.0.0', () => {
    console.log(`همراه: http://0.0.0.0:${PORT}  (حالت توسعه: ${DEV ? 'روشن' : 'خاموش'}، پایگاه داده: ${DB_PATH})`);
    if (!DEV && !SMS.configured) console.log('هشدار: پیامک‌دهنده تنظیم نشده است (HZ_SMS_PROVIDER/HZ_SMS_API_KEY)؛ ارسال کد ورود پاسخ 503 می‌دهد.');
  });
}

module.exports = { server, db, CONFIG, normalizePhone };
