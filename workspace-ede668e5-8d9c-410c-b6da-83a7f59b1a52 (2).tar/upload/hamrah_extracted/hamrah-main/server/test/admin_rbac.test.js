'use strict';
/* نسل دوم پنل مدیریت — قرارداد RBAC سرور:
 *  ۱) ورود: تک‌رمزی قدیمی (بدون نام کاربری) به حساب owner مهاجرت می‌کند؛ ورود با نام کاربری هم کار می‌کند
 *  ۲) GET /api/admin/me هویت و مجوزهای نقش را می‌دهد
 *  ۳) گارد مجوز روی اقدام‌های حساس: نقش ناهماهنگ ۴۰۳ forbidden با need می‌گیرد
 *  ۴) کارمندان: ساخت/غیرفعال‌سازی/ریست رمز/خروج اجباری فقط برای owner؛ آخرین owner محافظت می‌شود
 *  ۵) مسدودسازی مسافر: رزرو جدید ۴۰۳ account_blocked؛ رفع مسدودی مسیر را باز می‌کند
 *  ۶) تعلیق مترجم: فعال → suspended (آنلاین خاموش) → بازفعال‌سازی active_general
 *  ۷) صف چرخهٔ تغییرات، گزارش‌ها و CSV، شهرهای سنجیده‌شده، audit صاحب‌دار
 * اجرا:
 *   HZ_DEV=1 HZ_ADMIN_PASSWORD=test-admin-pass HZ_DB=/tmp/hz_rbac.sqlite PORT=8082 node server.js
 *   BASE=http://127.0.0.1:8082 node test/admin_rbac.test.js
 */
const BASE = process.env.BASE || 'http://127.0.0.1:8082';
let passed = 0, failed = 0;
function check(name, ok, extra = '') {
  if (ok) { passed++; console.log('  ok   ' + name); }
  else { failed++; console.log('  FAIL ' + name + (extra ? '  [' + extra + ']' : '')); }
}
async function call(method, p, body, token) {
  const headers = { 'Content-Type': 'application/json' };
  if (token) headers.Authorization = 'Bearer ' + token;
  const r = await fetch(BASE + p, { method, headers, body: body ? JSON.stringify(body) : undefined });
  let data = null; try { data = await r.json(); } catch (e) { /* csv/empty */ }
  return { status: r.status, data };
}
const STAFF_PASS = 'Str0ng-Pass-2026!';

async function main() {
  // ---------- ۱) ورود ----------
  let r = await call('POST', '/api/admin/login', { password: 'wrong' });
  check('رمز نادرست ۴۰۱', r.status === 401 && r.data.error === 'bad_password');
  r = await call('POST', '/api/admin/login', { password: 'test-admin-pass' });
  check('ورود تک‌رمزی قدیمی (owner) کار می‌کند', r.status === 200 && r.data.role === 'owner');
  const owner = r.data.token;
  r = await call('POST', '/api/admin/login', { username: 'owner', password: 'test-admin-pass' });
  check('ورود با نام کاربری owner هم کار می‌کند', r.status === 200);

  // ---------- ۲) me ----------
  r = await call('GET', '/api/admin/me', null, owner);
  check('me: هویت owner', r.status === 200 && r.data.user.username === 'owner' && r.data.user.role === 'owner');
  check('me: مجوز staff.manage برای owner', (r.data.perms || []).includes('staff.manage'));
  r = await call('GET', '/api/admin/me');
  check('me بدون توکن ۴۰۱', r.status === 401);

  // ---------- ۳) ساخت نقش‌ها و گاردها ----------
  r = await call('POST', '/api/admin/staff', { username: 'ops1', name: 'عملیات یک', role: 'ops', password: STAFF_PASS }, owner);
  check('ساخت کارمند ops', r.status === 201 && r.data.ok);
  r = await call('POST', '/api/admin/staff', { username: 'fin1', name: 'مالی یک', role: 'finance', password: STAFF_PASS }, owner);
  check('ساخت کارمند finance', r.status === 201);
  r = await call('POST', '/api/admin/staff', { username: 'ops1', name: 'تکراری', role: 'ops', password: STAFF_PASS }, owner);
  check('نام کاربری تکراری ۴۰۹', r.status === 409 && r.data.error === 'username_taken');
  r = await call('POST', '/api/admin/staff', { username: 'weak2', name: 'x', role: 'ops', password: '123' }, owner);
  check('رمز ضعیف ۴۰۰', r.status === 400 && r.data.error === 'weak_password');

  const opsTok = (await call('POST', '/api/admin/login', { username: 'ops1', password: STAFF_PASS })).data.token;
  const finTok = (await call('POST', '/api/admin/login', { username: 'fin1', password: STAFF_PASS })).data.token;
  check('ورود کارمند ops با نام کاربری', !!opsTok);
  r = await call('GET', '/api/admin/me', null, opsTok);
  check('me کارمند ops نقش درست دارد', r.data.user.role === 'ops' && (r.data.perms || []).includes('bookings.manage'));
  check('me کارمند ops فاقد staff.manage', !(r.data.perms || []).includes('staff.manage'));

  // گاردهای عملیات
  r = await call('PUT', '/api/admin/features', { car_mode: false }, opsTok);
  check('ops: PUT features ۴۰۳ forbidden', r.status === 403 && r.data.error === 'forbidden' && r.data.need === 'features.manage');
  r = await call('PUT', '/api/admin/settings', { cancel_fee_percent: 30 }, opsTok);
  check('ops: PUT settings ۴۰۳', r.status === 403 && r.data.need === 'settings.manage');
  r = await call('POST', '/api/admin/staff', { username: 'hack1', role: 'owner', password: STAFF_PASS }, opsTok);
  check('ops: ساخت کارمند ۴۰۳', r.status === 403 && r.data.need === 'staff.manage');
  r = await call('GET', '/api/admin/staff', null, opsTok);
  check('ops: فهرست کارمندان ۴۰۳', r.status === 403);
  r = await call('GET', '/api/admin/reports', null, opsTok);
  check('ops: گزارش‌ها مجاز است', r.status === 200);
  r = await call('GET', '/api/admin/bookings?tab=pending', null, opsTok);
  check('ops: رزروها مجاز است', r.status === 200);
  // گاردهای مالی
  r = await call('PUT', '/api/admin/features', { car_mode: false }, finTok);
  check('finance: PUT features ۴۰۳', r.status === 403);
  r = await call('GET', '/api/admin/finance', null, finTok);
  check('finance: نمای مالی مجاز است', r.status === 200);
  r = await call('POST', '/api/admin/translators/99999/decision', { decision: 'approve' }, finTok);
  check('finance: تصمیم مترجم ۴۰۳ (پیش از ۴۰۴)', r.status === 403);

  // ---------- ۴) محافظت owner و غیرفعال‌سازی ----------
  const lst = await call('GET', '/api/admin/staff', null, owner);
  const opsId = lst.data.staff.find((s) => s.username === 'ops1').id;
  const ownerId = lst.data.staff.find((s) => s.username === 'owner').id;
  r = await call('PATCH', '/api/admin/staff/' + ownerId, { is_active: false }, owner);
  check('غیرفعال‌سازی آخرین owner ۴۰۹ last_owner', r.status === 409 && r.data.error === 'last_owner');
  r = await call('PATCH', '/api/admin/staff/' + ownerId, { role: 'ops' }, owner);
  check('تنزل آخرین owner ۴۰۹', r.status === 409);
  r = await call('PATCH', '/api/admin/staff/' + ownerId, { is_active: false }, opsTok);
  check('غیرفعال‌سازی توسط غیر owner ۴۰۳', r.status === 403);
  r = await call('PATCH', '/api/admin/staff/' + opsId, { is_active: false }, owner);
  check('غیرفعال‌سازی ops موفق', r.status === 200);
  r = await call('GET', '/api/admin/me', null, opsTok);
  check('ops غیرفعال با توکن زنده ۴۰۱', r.status === 401);
  r = await call('POST', '/api/admin/login', { username: 'ops1', password: STAFF_PASS });
  check('ورود ops غیرفعال ۴۰۳', r.status === 403 && r.data.error === 'account_disabled');
  r = await call('PATCH', '/api/admin/staff/' + opsId, { is_active: true }, owner);
  check('فعال‌سازی دوباره ops', r.status === 200);
  const opsTok2 = (await call('POST', '/api/admin/login', { username: 'ops1', password: STAFF_PASS })).data.token;
  r = await call('POST', '/api/admin/staff/' + opsId + '/password', { password: 'An0ther-Pass-2026!' }, owner);
  check('ریست رمز کارمند', r.status === 200);
  r = await call('GET', '/api/admin/me', null, opsTok2);
  check('نشست قدیمی پس از ریست رمز باطل است', r.status === 401);
  r = await call('POST', '/api/admin/login', { username: 'ops1', password: 'An0ther-Pass-2026!' });
  check('ورود با رمز ریست‌شده', r.status === 200);

  // ---------- ۵) مسدودسازی مسافر ----------
  const ph = '915' + String(4560000).slice(-7);
  await call('POST', '/api/auth/request-code', { phone: ph, role: 'traveler' });
  const vt = (await call('POST', '/api/auth/verify', { phone: ph, role: 'traveler', code: '123456' })).data.token;
  const tl = await call('GET', '/api/admin/travelers?q=' + ph, null, owner);
  const tid = tl.data.travelers[0].id;
  r = await call('POST', '/api/admin/travelers/' + tid + '/block', {}, owner);
  check('مسدودسازی بدون دلیل ۴۰۰', r.status === 400 && r.data.error === 'reason_required');
  r = await call('POST', '/api/admin/travelers/' + tid + '/block', { reason: 'تست سوءاستفاده' }, owner);
  check('مسدودسازی با دلیل موفق', r.status === 200 && r.data.blocked === true);
  r = await call('POST', '/api/traveler/bookings', { kind: 'instant', origin_lang: 'fa', dest_lang: 'en', place: 'تست' }, vt);
  check('مسافر مسدود رزرو ۴۰۳ account_blocked می‌گیرد', r.status === 403 && r.data.error === 'account_blocked');
  r = await call('GET', '/api/admin/travelers/' + tid, null, owner);
  check('پروندهٔ مسافر مسدود را نشان می‌دهد', r.status === 200 && r.data.traveler.blocked === true);
  r = await call('POST', '/api/admin/travelers/' + tid + '/unblock', {}, finTok);
  check('رفع مسدودی توسط مالی ۴۰۳', r.status === 403 && r.data.need === 'travelers.manage');
  r = await call('POST', '/api/admin/travelers/' + tid + '/unblock', {}, owner);
  check('رفع مسدودی توسط عملیاتِ مجاز موفق', r.status === 200);

  // ---------- ۶) تعلیق مترجم ----------
  const tph = '915' + String(4561000).slice(-7);
  await call('POST', '/api/auth/request-code', { phone: tph, role: 'translator' });
  const ttok = (await call('POST', '/api/auth/verify', { phone: tph, role: 'translator', code: '123456' })).data.token;
  await call('POST', '/api/dev/approve-translator', null, ttok);
  await call('PATCH', '/api/translator/online', { online: true }, ttok);
  const tlist = await call('GET', '/api/admin/translators?status=active_general', null, owner);
  const tr = tlist.data.translators.find((x) => x.phone === tph);
  check('مترجم فعال در فهرست هست', !!tr);
  r = await call('POST', '/api/admin/translators/' + tr.id + '/suspend', {}, owner);
  check('تعلیق بدون دلیل ۴۰۰', r.status === 400);
  r = await call('POST', '/api/admin/translators/' + tr.id + '/suspend', { reason: 'تست تخلف' }, owner);
  check('تعلیق با دلیل موفق', r.status === 200 && r.data.status === 'suspended');
  r = await call('GET', '/api/admin/translators?status=suspended', null, owner);
  check('مترجم تعلیق‌شده در فهرست تعلیق‌ها هست', r.data.translators.some((x) => x.id === tr.id));
  r = await call('POST', '/api/admin/translators/' + tr.id + '/suspend', { reason: 'دوباره' }, owner);
  check('تعلیق مجدد مترجم تعلیق‌شده ۴۰۹', r.status === 409 && r.data.error === 'not_active');
  r = await call('POST', '/api/admin/translators/' + tr.id + '/reactivate', {}, finTok);
  check('بازفعال‌سازی توسط مالی ۴۰۳', r.status === 403 && r.data.need === 'translators.manage');
  r = await call('POST', '/api/admin/translators/' + tr.id + '/reactivate', {}, owner);
  // وضعیت مؤثر پس از بازفعال‌سازی: با گیت تخصص باز (مدرک زبان تأییدشده) active_specialized وگرنه active_general
  check('بازفعال‌سازی موفق', r.status === 200 && (r.data.status === 'active_general' || r.data.status === 'active_specialized'), JSON.stringify(r.data));

  // ---------- ۷) صف تغییرات، گزارش، شهرها، audit ----------
  r = await call('GET', '/api/admin/changes', null, opsTok === undefined ? owner : owner);
  check('صف چرخهٔ تغییرات مجاز و ساختار درست', r.status === 200 && Array.isArray(r.data.changes) && typeof r.data.pending_count === 'number');
  r = await call('GET', '/api/admin/reports?days=7', null, owner);
  check('گزارش: نرخ تکمیل و میانگین تطبیق هست', r.status === 200 && 'completion_rate' in r.data.bookings && Array.isArray(r.data.per_day));
  const csv = await fetch(BASE + '/api/admin/reports.csv?days=7', { headers: { Authorization: 'Bearer ' + owner } });
  const csvText = await csv.text();
  check('CSV با content-type درست و سرخط', csv.status === 200 && csv.headers.get('content-type').includes('text/csv') && csvText.includes('traveler_name'));
  r = await call('GET', '/api/admin/cities', null, owner);
  const c0 = r.data.cities[0];
  check('شهرها: سنجش عرضه/تقاضا اضافه شد', r.status === 200 && 'translators_online' in c0 && 'bookings_7d' in c0 && 'done_7d' in c0);
  r = await call('GET', '/api/admin/audit?limit=50', null, owner);
  check('audit: actor برای اقدامات owner ثبت شده', r.status === 200 && r.data.entries.some((e) => e.action === 'staff.create' && e.actor === 'owner'));
  r = await call('GET', '/api/admin/audit', null, finTok);
  check('audit برای مالی ۴۰۳', r.status === 403 && r.data.need === 'audit.view');
  r = await call('GET', '/api/admin/summary', null, owner);
  check('summary: health و funnel اضافه شد', r.status === 200 && 'health' in r.data && 'funnel' in r.data && 'oldest_searching_minutes' in r.data.health);

  console.log('RESULT: ' + (failed === 0 ? 'PASS' : 'FAIL') + ' (' + passed + '/' + (passed + failed) + ')');
  process.exit(failed === 0 ? 0 : 1);
}
main().catch((e) => { console.error('CRASH', e); process.exit(1); });
