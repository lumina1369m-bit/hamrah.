'use strict';
/* شکاف ۴ بازبینی اپ مسافر — قرارداد «در انتظار پاسخ تغییر»:
 *  «در انتظار پاسخ» وضعیتِ رزرو نیست؛ در جدول change_requests زندگی می‌کند و از فیلدهای
 *  pending_change (نمای مسافر) و changes (نمای مترجم) دیده می‌شود. وضعیت رزرو در تمام چرخهٔ
 *  تغییر، matched می‌ماند. این تست قرارداد را pin می‌کند تا ارجاع‌های پاک‌شدهٔ change_pending
 *  از فیلترهای وضعیتی سرور و پنل ادمین دیگر بازنگردند.
 *  ۱) چرخهٔ پذیرش: 202 → 409 درخواست هم‌زمان → پذیرش مترجم → اعمال + وضعیت همچنان matched
 *  ۲) چرخهٔ رد: رد درخواست وضعیت را نمی‌شکند و مسیر درخواست جدید باز است
 *  ۳) تغییر غیرمهم (یادداشت) فوری اعمال می‌شود و درخواست معلق نمی‌سازد
 *  ۴) نماهای ادمین (تب پیش‌رو، ماتریس اعزام) رزرو matched را بدون وضعیت مرده می‌بینند
 *  ۵) گارد رزرو فوری همپوشان پس از پاکسازی پابرجاست
 * اجرا مثل api.test.js:
 *   HZ_DEV=1 HZ_ADMIN_PASSWORD=test-admin-pass HZ_DB=/tmp/hz_cf.sqlite PORT=8082 node server.js
 *   BASE=http://127.0.0.1:8082 node test/change_flow.test.js
 */
const BASE = process.env.BASE || 'http://127.0.0.1:8082';
let passed = 0, failed = 0;
function check(name, ok, extra = '') {
  if (ok) { passed++; console.log('  ok   ' + name); }
  else { failed++; console.log('  FAIL ' + name + (extra ? '  [' + extra + ']' : '')); }
}
async function call(method, p, body, token) {
  const headers = { 'Content-Type': 'application/json' };
  if (token) headers.Authorization = 'Bearer ' + token;
  const r = await fetch(BASE + p, { method, headers, body: body ? JSON.stringify(body) : undefined });
  let data = null; try { data = await r.json(); } catch (e) { /* non-json */ }
  return { status: r.status, data };
}
const phoneFor = (n) => '915' + String(7000000 + n).slice(-7);
async function makeTraveler(n) {
  const phone = phoneFor(n);
  await call('POST', '/api/auth/request-code', { phone, role: 'traveler' });
  const v = await call('POST', '/api/auth/verify', { phone, role: 'traveler', code: '123456' });
  return v.data.token;
}
async function makeTranslator(n) {
  const phone = phoneFor(n);
  await call('POST', '/api/auth/request-code', { phone, role: 'translator' });
  const v = await call('POST', '/api/auth/verify', { phone, role: 'translator', code: '123456' });
  await call('POST', '/api/dev/approve-translator', null, v.data.token);
  return v.data.token;
}
async function matchInstant(ptok, ttok, place) {
  await call('PATCH', '/api/translator/online', { online: true }, ttok);
  const b = await call('POST', '/api/traveler/bookings', { kind: 'instant', origin_lang: 'fa', dest_lang: 'en', place, hours: 2 }, ptok);
  const bid = b.data.id;
  let off = null;
  for (let i = 0; i < 5 && !off; i++) {
    const o = await call('GET', '/api/translator/offers', null, ttok);
    off = (o.data.offers || []).find((x) => x.reservation_id === bid);
    if (!off) {
      const all = (o.data.offers || []).filter((x) => x.reservation_id === bid);
      for (const x of all) await call('POST', `/api/translator/offers/${x.id}/decline`, null, ttok);
      await new Promise((r) => setTimeout(r, 1200));
    }
  }
  if (!off) return { bid, ok: false };
  const acc = await call('POST', `/api/translator/offers/${off.id}/accept`, null, ttok);
  return { bid, ok: acc.status === 200 };
}
const travelerBooking = async (ptok, bid) =>
  (await call('GET', '/api/traveler/bookings', null, ptok)).data.bookings.find((x) => x.id === bid);

async function main() {
  console.log('== قرارداد «در انتظار پاسخ تغییر» (شکاف ۴)');
  const ptok = await makeTraveler(1);
  const ttok = await makeTranslator(1);
  const adm = (await call('POST', '/api/admin/login', { password: process.env.ADMIN_PASSWORD || 'test-admin-pass' })).data.token;
  check('ورود مدیر', !!adm);
  const m = await matchInstant(ptok, ttok, 'میدان آزادی - تغییر');
  check('تطبیق فوری', m.ok, JSON.stringify(m));

  // --- ۱: چرخهٔ پذیرش ---
  const c1 = await call('POST', `/api/traveler/bookings/${m.bid}/change`, { place: 'پارکوی ولیعصر - تغییر' }, ptok);
  check('تغییر مهم با مترجم متصل → 202 در انتظار', c1.status === 202 && c1.data.pending === true && !!c1.data.id, JSON.stringify(c1));
  let bk = await travelerBooking(ptok, m.bid);
  check('وضعیت رزرو در انتظار پاسخ همچنان matched است (وضعیت مرده بازنگشت)', bk && bk.status === 'matched', JSON.stringify({ s: bk && bk.status }));
  check('pending_change در نمای مسافر دیده می‌شود', bk && bk.pending_change && bk.pending_change.changes && bk.pending_change.changes.place === 'پارکوی ولیعصر - تغییر', JSON.stringify(bk && bk.pending_change));
  const dup = await call('POST', `/api/traveler/bookings/${m.bid}/change`, { place: 'تلاش دوم' }, ptok);
  check('درخواست دوم هم‌زمان → 409 change_pending (کد خطای زنده)', dup.status === 409 && dup.data.error === 'change_pending', JSON.stringify(dup));
  const offers = await call('GET', '/api/translator/offers', null, ttok);
  check('درخواست معلق در نمای مترجم (changes) هست', (offers.data.changes || []).some((c) => c.reservation_id === m.bid && c.changes.place === 'پارکوی ولیعصر - تغییر'), JSON.stringify(offers.data.changes));
  const acc = await call('POST', `/api/translator/changes/${c1.data.id}/accept`, null, ttok);
  check('پذیرش مترجم → 200', acc.status === 200, JSON.stringify(acc));
  bk = await travelerBooking(ptok, m.bid);
  check('پس از پذیرش: مکان عوض شد، وضعیت matched، معلق پاک شد',
    bk && bk.place === 'پارکوی ولیعصر - تغییر' && bk.status === 'matched' && bk.pending_change == null,
    JSON.stringify({ p: bk && bk.place, s: bk && bk.status, pc: bk && bk.pending_change }));
  const ev1 = await call('GET', `/api/admin/reservations/${m.bid}/events`, null, adm);
  const evNames = (ev1.data.events || []).map((x) => x.event);
  check('هیچ رویداد status_change_pending در تاریخچه نیست', ev1.status === 200 && !evNames.includes('status_change_pending'), JSON.stringify(evNames));
  check('رویدادهای ثبت رزرو و تطبیق در تاریخچه‌اند (created/matched)', evNames.includes('created') && evNames.includes('matched'), JSON.stringify(evNames));

  // --- ۲: چرخهٔ رد ---
  const c2 = await call('POST', `/api/traveler/bookings/${m.bid}/change`, { place: 'تجریش - رد' }, ptok);
  check('درخواست جدید پس از پذیرش قبلی مجاز است', c2.status === 202, JSON.stringify(c2));
  const rej = await call('POST', `/api/translator/changes/${c2.data.id}/reject`, null, ttok);
  check('رد مترجم → 200', rej.status === 200, JSON.stringify(rej));
  bk = await travelerBooking(ptok, m.bid);
  check('پس از رد: مکان قبلی، وضعیت matched، معلق پاک شد',
    bk && bk.place === 'پارکوی ولیعصر - تغییر' && bk.status === 'matched' && bk.pending_change == null,
    JSON.stringify({ p: bk && bk.place, s: bk && bk.status, pc: bk && bk.pending_change }));

  // --- ۳: تغییر غیرمهم (یادداشت) فوری اعمال می‌شود ---
  const c3 = await call('POST', `/api/traveler/bookings/${m.bid}/change`, { notes: 'بدون تغییر مهم' }, ptok);
  check('تغییر غیرمهم فوری اعمال می‌شود', c3.status === 200 && c3.data.applied === true, JSON.stringify(c3));
  bk = await travelerBooking(ptok, m.bid);
  check('یادداشت جدید روی رزرو و بدون pending_change', bk && bk.notes === 'بدون تغییر مهم' && bk.pending_change == null, JSON.stringify({ n: bk && bk.notes, pc: bk && bk.pending_change }));

  // --- ۴: نماهای ادمین بدون وضعیت مرده ---
  const up = await call('GET', '/api/admin/bookings?tab=upcoming', null, adm);
  check('تب پیش‌روی ادمین رزرو matched را می‌بیند', up.status === 200 && (up.data.bookings || []).some((x) => x.id === m.bid && x.status === 'matched'), JSON.stringify((up.data.bookings || []).map((x) => x.id)));
  const dsp = await call('GET', '/api/admin/dispatch', null, adm);
  check('ماتریس اعزام: ماموریت با وضعیت matched', (dsp.data.missions || []).some((x) => x.id === m.bid && x.status === 'matched'), JSON.stringify((dsp.data.missions || []).map((x) => ({ id: x.id, s: x.status }))));
  // در این پایگاه ایزوله تنها یک مترجم آنلاین وجود دارد و ماموریت فعال دارد → بیکارها باید خالی باشد
  check('مترجم متصل در فهرست بیکارها نیست', (dsp.data.idle || []).length === 0, JSON.stringify(dsp.data.idle));

  // --- ۵: گارد رزرو فوری همپوشان پس از پاکسازی پابرجاست ---
  const f1 = await call('PUT', '/api/admin/features', { single_active_instant: true }, adm);
  check('فیچر single_active_instant روشن شد', f1.status === 200 && (f1.data.changed || []).includes('single_active_instant'), JSON.stringify(f1.data));
  const second = await call('POST', '/api/traveler/bookings', { kind: 'instant', origin_lang: 'fa', dest_lang: 'en', place: 'رزرو دوم', hours: 1 }, ptok);
  check('رزرو فوری دوم هنگام ماموریت فعال → 409 overlapping_instant', second.status === 409 && second.data.error === 'overlapping_instant' && second.data.reservation_id === m.bid && second.data.active_status === 'matched', JSON.stringify(second.data));
  const cx = await call('POST', `/api/traveler/bookings/${m.bid}/cancel`, {}, ptok);
  check('لغو ماموریت فعال', cx.status === 200, JSON.stringify(cx));
  const third = await call('POST', '/api/traveler/bookings', { kind: 'instant', origin_lang: 'fa', dest_lang: 'en', place: 'رزرو پس از لغو', hours: 1 }, ptok);
  check('پس از لغو مسیر رزرو فوری باز است', [200, 201, 202].includes(third.status) && !!(third.data && third.data.id), JSON.stringify({ s: third.status, d: third.data && third.data.id }));
  const f0 = await call('PUT', '/api/admin/features', { single_active_instant: false }, adm);
  check('فیچر به پیش‌فرض خاموش برگشت', f0.status === 200 && (f0.data.changed || []).includes('single_active_instant'), JSON.stringify(f0.data));

  console.log(`\nنتیجه: ${passed} پاس، ${failed} خطا`);
  process.exit(failed ? 1 : 0);
}
main().catch((e) => { console.error(e); process.exit(1); });
