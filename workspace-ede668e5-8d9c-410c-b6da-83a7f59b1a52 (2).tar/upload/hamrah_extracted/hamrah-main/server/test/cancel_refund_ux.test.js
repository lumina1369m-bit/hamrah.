'use strict';
/* تست تجربهٔ مسافر در لغو با کارمزد، نمایش استرداد و گسترش تسویهٔ دستی:
 *  ۱) config عمومی درصد کارمزد لغو را می‌دهد (برای پیش‌نمایش مودال لغو در اپ مسافر)
 *  ۲) رزرو تمام‌شده بدون انتخاب روش پرداخت در «پرونده‌های باز» مالی دیده می‌شود و تسویهٔ دستی می‌پذیرد
 *  ۳) لغو پس از تطبیق fee_percent برمی‌گرداند و رویداد cancelled با کارمزد در تاریخچه ثبت می‌شود
 * اجرا مثل api.test.js:
 *   HZ_DEV=1 HZ_ADMIN_PASSWORD=test-admin-pass HZ_DB=/tmp/hz_c.sqlite PORT=8082 node server.js
 *   BASE=http://127.0.0.1:8082 node test/cancel_refund_ux.test.js
 */
const BASE = process.env.BASE || 'http://127.0.0.1:8082';
let passed = 0, failed = 0;
function check(name, ok, extra = '') {
  if (ok) { passed++; console.log('  ok   ' + name); }
  else { failed++; console.log('  FAIL ' + name + (extra ? '  [' + extra + ']' : '')); }
}
async function call(method, p, body, token) {
  const headers = { 'Content-Type': 'application/json' };
  if (token) headers.Authorization = 'Bearer ' + token;
  const r = await fetch(BASE + p, { method, headers, body: body ? JSON.stringify(body) : undefined });
  let data = null; try { data = await r.json(); } catch (e) { /* non-json */ }
  return { status: r.status, data };
}
const phoneFor = (n) => '914' + String(7000000 + n).slice(-7);

async function makeTraveler(n) {
  const phone = phoneFor(n);
  await call('POST', '/api/auth/request-code', { phone, role: 'traveler' });
  const v = await call('POST', '/api/auth/verify', { phone, role: 'traveler', code: '123456' });
  return v.data.token;
}
async function makeTranslator(n) {
  const phone = phoneFor(n);
  await call('POST', '/api/auth/request-code', { phone, role: 'translator' });
  const v = await call('POST', '/api/auth/verify', { phone, role: 'translator', code: '123456' });
  await call('POST', '/api/dev/approve-translator', null, v.data.token);
  return v.data.token;
}
// تطبیق فوری با یک مترجم آنلاین؛ خروجی: bid تطبیق‌یافته یا خطا
async function matchInstant(ptok, ttok, place) {
  await call('PATCH', '/api/translator/online', { online: true }, ttok);
  const b = await call('POST', '/api/traveler/bookings', { kind: 'instant', origin_lang: 'fa', dest_lang: 'en', place, hours: 2 }, ptok);
  const bid = b.data.id;
  let off = null;
  for (let i = 0; i < 5 && !off; i++) {
    const o = await call('GET', '/api/translator/offers', null, ttok);
    off = (o.data.offers || []).find((x) => x.reservation_id === bid);
    if (!off) {
      const all = (o.data.offers || []).filter((x) => x.reservation_id === bid);
      for (const x of all) await call('POST', `/api/translator/offers/${x.id}/decline`, null, ttok);
      await new Promise((r) => setTimeout(r, 1200));
    }
  }
  if (!off) return { bid, ok: false };
  const acc = await call('POST', `/api/translator/offers/${off.id}/accept`, null, ttok);
  return { bid, ok: acc.status === 200 };
}
// چرخهٔ کامل تا «پایان خدمت» بدون انتخاب روش پرداخت (پیش از پرداخت متوقف می‌شود)
async function finishWithoutPayment(ptok, ttok, place) {
  const m = await matchInstant(ptok, ttok, place);
  if (!m.ok) return { ...m, ok: false };
  await call('POST', `/api/translator/missions/${m.bid}/arrive`, null, ttok);
  const bk = (await call('GET', '/api/traveler/bookings', null, ptok)).data.bookings.find((x) => x.id === m.bid);
  const st = await call('POST', `/api/translator/missions/${m.bid}/verify-code`, { code: bk.service_code }, ttok);
  if (st.status !== 200) return { ...m, ok: false };
  const fin = await call('POST', `/api/traveler/bookings/${m.bid}/finish`, null, ptok);
  return { ...m, ok: fin.status === 200 && fin.data.status === 'finished' };
}

async function main() {
  console.log('== لغو با کارمزد، استرداد و پرونده‌های باز');
  const ptok = await makeTraveler(1);
  const ttok = await makeTranslator(1);
  const adm = (await call('POST', '/api/admin/login', { password: process.env.ADMIN_PASSWORD || 'test-admin-pass' })).data.token;
  check('ورود مدیر', !!adm);

  // --- ۱: config عمومی شامل درصد کارمزد لغو ---
  const cfg = await call('GET', '/api/config');
  const fee = cfg.data && cfg.data.tariffs && cfg.data.tariffs.cancel_fee_percent;
  check('cancel_fee_percent در config عمومی (پیش‌فرض ۲۰)', cfg.status === 200 && Number.isInteger(fee) && fee === 20, JSON.stringify(cfg.data && cfg.data.tariffs));

  // --- ۲: رزرو تمام‌شده بدون روش پرداخت → پروندهٔ باز + تسویهٔ دستی ---
  const f1 = await finishWithoutPayment(ptok, ttok, 'میدان آزادی - پروندهٔ باز');
  check('چرخه تا پایان خدمت بدون پرداخت', f1.ok, JSON.stringify(f1));
  let bk1 = (await call('GET', '/api/traveler/bookings', null, ptok)).data.bookings.find((x) => x.id === f1.bid);
  check('وضعیت finished با pay_state خالی', bk1 && bk1.status === 'finished' && bk1.pay_state == null, JSON.stringify({ s: bk1 && bk1.status, p: bk1 && bk1.pay_state }));
  const fin1 = await call('GET', '/api/admin/finance', null, adm);
  check('پروندهٔ باز در waiting_list مالی دیده می‌شود',
    (fin1.data.waiting_list || []).some((w) => w.id === f1.bid && w.pay_method == null), JSON.stringify((fin1.data.waiting_list || []).map((w) => w.id)));
  let res = await call('POST', `/api/admin/reservations/${f1.bid}/settle`, {});
  check('تسویهٔ دستی بدون توکن ۴۰۱', res.status === 401);
  res = await call('POST', `/api/admin/reservations/${f1.bid}/settle`, { note: 'بستن پروندهٔ بن‌بست پرداخت' }, adm);
  check('تسویهٔ دستی رزرو بدون روش پرداخت → settled + done', res.status === 200 && res.data.pay_state === 'settled' && res.data.status === 'done', JSON.stringify(res));
  res = await call('POST', `/api/admin/reservations/${f1.bid}/settle`, {}, adm);
  check('تسویهٔ دوبارهٔ همان رزرو ۴۰۹', res.status === 409 && res.data.error === 'not_settleable');
  bk1 = (await call('GET', '/api/traveler/bookings', null, ptok)).data.bookings.find((x) => x.id === f1.bid);
  check('نمای مسافر پس از بستن پرونده', bk1 && bk1.status === 'done' && bk1.pay_state === 'settled');

  // --- ۳: لغو پس از تطبیق → کارمزد اعلامی + رویداد در تاریخچه ---
  const f2 = await matchInstant(ptok, ttok, 'میدان ونک - لغو با کارمزد');
  check('تطبیق فوری دوم', f2.ok, JSON.stringify(f2));
  res = await call('POST', `/api/traveler/bookings/${f2.bid}/cancel`, {}, ptok);
  check('لغو پس از تطبیق با fee_percent', res.status === 200 && res.data.fee_percent === 20, JSON.stringify(res));
  const bk2 = (await call('GET', '/api/traveler/bookings', null, ptok)).data.bookings.find((x) => x.id === f2.bid);
  check('رزرو لغوشده با پرچم cancel_after_match', bk2 && bk2.status === 'cancelled' && bk2.cancel_after_match === true, JSON.stringify({ s: bk2 && bk2.status, c: bk2 && bk2.cancel_after_match }));
  const ev = await call('GET', `/api/admin/reservations/${f2.bid}/events`, null, adm);
  const cancelled = (ev.data.events || []).find((x) => x.event === 'cancelled');
  check('رویداد cancelled با کارمزد در تاریخچه', ev.status === 200 && !!cancelled && cancelled.actor === 'traveler' && cancelled.detail && cancelled.detail.fee_percent === 20, JSON.stringify(ev.data && ev.data.events));

  // --- ۴: گاردهای قبلی پابرجا ---
  const f3 = await finishWithoutPayment(ptok, ttok, 'تجریش - گارد اختلاف');
  check('چرخهٔ سوم تا پایان خدمت', f3.ok, JSON.stringify(f3));
  const dis = await call('POST', `/api/traveler/bookings/${f3.bid}/dispute`, {}, ptok);
  check('اختلاف فقط با روش نقدی ممکن نیست (روشی انتخاب نشده)', dis.status === 409 && dis.data.error === 'not_disputable', JSON.stringify(dis));
  res = await call('POST', `/api/admin/disputes/${f3.bid}/resolve`, { decision: 'settle' }, adm);
  check('حل اختلاف برای پروندهٔ بدون اختلاف ۴۰۹', res.status === 409 && res.data.error === 'not_disputed');

  console.log(`\nنتیجه: ${passed} پاس، ${failed} خطا`);
  process.exit(failed ? 1 : 0);
}
main().catch((e) => { console.error(e); process.exit(1); });
