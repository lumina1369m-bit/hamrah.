'use strict';
/* تست درگاه پرداخت آنلاین + اعلان فوری (Web Push) + اعلان لغو (شکاف ۵).
 * پیش‌نیاز: سرور با پایگاه داده‌ی تازه و HZ_ADMIN_PASSWORD=test-admin-pass:
 *   HZ_DEV=1 HZ_DB=/tmp/hz_gateway_test.sqlite PORT=8081 HZ_ADMIN_PASSWORD=test-admin-pass node server.js
 *   BASE=http://127.0.0.1:8081 node test/gateway_push.test.js
 *
 * ایزوله‌سازی: مترجمان این تست با جفت‌زبان «zh-fa» ثبت‌نام می‌شوند؛ باقی‌ماندهٔ مترجمان
 * تست‌های قبلی (fa/ar/en) واجد شرط پیشنهاد برای رزروهای zh این تست نیستند و توازن بار
 * پیشنهاد را نمی‌رباید. یک مترجم یدکی (T2) هم نگه داشته می‌شود تا اگر توازن بار پیشنهاد
 * را به او داد، همان ماموریت با توکن خودش پیش برود.
 */
const BASE = process.env.BASE || 'http://127.0.0.1:8081';
const ADM = 'test-admin-pass';
let passed = 0, failed = 0;
function check(name, ok, extra = '') {
  if (ok) { passed++; console.log('  ok   ' + name); }
  else { failed++; console.log('  FAIL ' + name + (extra ? '  [' + extra + ']' : '')); }
}
async function call(method, p, body, token) {
  const headers = { 'Content-Type': 'application/json' };
  if (token) headers.Authorization = 'Bearer ' + token;
  const r = await fetch(BASE + p, { method, headers, body: body ? JSON.stringify(body) : undefined, redirect: 'manual' });
  let data = null; try { data = await r.json(); } catch (e) { /* html/redirect */ }
  return { status: r.status, data, location: r.headers.get('location') };
}
const phoneFor = (n) => '912' + String(1000000 + n).slice(-7);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ثبت‌نام کامل با زبان‌های خواسته‌شده و سپس پذیرش توسعه‌ای (وضعیت فعال)
async function makeTranslator(n, langs) {
  const phone = phoneFor(n);
  await call('POST', '/api/auth/request-code', { phone, role: 'translator' });
  const v = await call('POST', '/api/auth/verify', { phone, role: 'translator', code: '123456' });
  const token = v.data.token;
  if (langs) {
    const reg = await call('POST', '/api/translator/registration', {
      nda: true, charter: true, gender: 'male', first_name: 'تست' + n, last_name: 'مترجم',
      languages: langs, fields: ['tourism', 'pilgrimage', 'medical', 'business', 'legal'], city_id: 1,
    }, token);
    if (reg.status !== 200) return { token, ok: false, reg };
  }
  await call('POST', '/api/dev/approve-translator', null, token);
  return { token, ok: true };
}
async function makeTraveler(n) {
  const phone = '9' + String(300000000 + n).slice(-9);
  await call('POST', '/api/auth/request-code', { phone, role: 'traveler' });
  return (await call('POST', '/api/auth/verify', { phone, role: 'traveler', code: '123456' })).data.token;
}

async function main() {
  const base = Math.floor(Math.random() * 400) * 10 + 300;
  const T1 = await makeTranslator(base + 1, ['zh', 'fa']);
  check('مترجم اصلی با جفت‌زبان zh-fa ثبت‌نام و فعال شد', T1.ok === true, JSON.stringify(T1.reg && { s: T1.reg.status, e: T1.reg.data }));
  await call('PATCH', '/api/translator/online', { online: true }, T1.token);
  const T2 = await makeTranslator(base + 2, ['zh', 'fa']);
  await call('PATCH', '/api/translator/online', { online: true }, T2.token);
  const T = T1.token;
  const P = await makeTraveler(base + 3);
  const adm = (await call('POST', '/api/admin/login', { password: ADM })).data.token;
  check('ورود مدیر برای تنظیم درگاه', !!adm);

  try {
    console.log('== اعلان فوری: VAPID و اشتراک');
    let r = await call('GET', '/api/push/vapid', null, P);
    check('کلید عمومی VAPID برای کاربر واردشده صادر می‌شود', r.status === 200 && typeof r.data.publicKey === 'string' && r.data.publicKey.length >= 40, JSON.stringify(r.data));
    const vapidKey = r.data.publicKey;
    check('کلید VAPID بدون نشست ممنوع است', (await call('GET', '/api/push/vapid')).status === 401);
    r = await call('POST', '/api/push/subscribe', { endpoint: 'https://push.example/sub/' + base + '-a', keys: { p256dh: 'k-p256dh-' + base, auth: 'k-auth-' + base } }, P);
    check('اشتراک معتبر ثبت می‌شود', r.status === 200 && r.data.ok === true, JSON.stringify(r));
    check('ثبت دوبارهٔ همان endpoint به‌روزرسانی است (۲۰۰)', (await call('POST', '/api/push/subscribe', { endpoint: 'https://push.example/sub/' + base + '-a', keys: { p256dh: 'k2', auth: 'k2' } }, P)).status === 200);
    check('اشتراک با endpoint غیر https رد می‌شود', (await call('POST', '/api/push/subscribe', { endpoint: 'http://push.example/x', keys: { p256dh: 'a', auth: 'b' } }, P)).status === 400);
    check('اشتراک بدون کلیدها رد می‌شود', (await call('POST', '/api/push/subscribe', { endpoint: 'https://push.example/x' }, P)).status === 400);
    r = await call('GET', '/api/admin/push', null, adm);
    check('پنل وضعیت پوش را دارد (فعال + کلید + شمارش)', r.status === 200 && r.data.enabled === true && r.data.public_key === vapidKey && r.data.subscriptions >= 1, JSON.stringify(r.data));
    check('حذف اشتراک انجام می‌شود', (await call('POST', '/api/push/unsubscribe', { endpoint: 'https://push.example/sub/' + base + '-a' }, P)).status === 200);
    r = await call('GET', '/api/admin/push', null, adm);
    check('پس از حذف، شمارش اشتراک کم می‌شود', r.status === 200 && r.data.subscriptions === 0, JSON.stringify(r.data));
    check('وضعیت پوش بدون نشست ممنوع است', (await call('GET', '/api/admin/push')).status === 401);

    // جریان کامل «رزرو تا پایان خدمت»؛ توکن مترجمِ پذیرنده برگردانده می‌شود
    const toFinished = async (place) => {
      const b = await call('POST', '/api/traveler/bookings', { kind: 'instant', origin_lang: 'zh', dest_lang: 'fa', place, traveler_name: 'گ', lat: 35.72, lng: 51.41 }, P);
      if (!b.data || !b.data.id) return null;
      let off = null, tok = null;
      for (let i = 0; i < 8 && !off; i++) {
        for (const t of [T1.token, T2.token]) {
          const oo = (await call('GET', '/api/translator/offers', null, t)).data.offers.find((x) => x.place === place);
          if (oo) { off = oo; tok = t; break; }
        }
        if (!off) await sleep(400);
      }
      if (!off) return null;
      await call('POST', `/api/translator/offers/${off.id}/accept`, null, tok);
      const id = b.data.id;
      await call('POST', `/api/translator/missions/${id}/arrive`, null, tok);
      const code = (await call('GET', '/api/traveler/bookings', null, P)).data.bookings.find((x) => x.id === id).service_code;
      await call('POST', `/api/translator/missions/${id}/verify-code`, { code }, tok);
      await call('POST', `/api/translator/missions/${id}/finish`, null, tok);
      const ap = await call('POST', `/api/traveler/bookings/${id}/finish-approve`, null, P);
      return ap.status === 200 ? { id, tok } : null;
    };
    const viewOf = async (id) => (await call('GET', '/api/traveler/bookings', null, P)).data.bookings.find((x) => x.id === id);

    console.log('== درگاه شبیه‌سازی‌شده: جریان کامل آغاز → کال‌بک → تسویه');
    await call('PUT', '/api/admin/settings', { payment_provider: 'simulated', online_enabled: 1 }, adm);
    const f1 = await toFinished('درگاه موفق');
    check('رزرو اول به «پایان خدمت» رسید', !!f1);
    if (f1) {
      let r2 = await call('POST', `/api/traveler/bookings/${f1.id}/payment`, { method: 'online' }, P);
      check('پرداخت آنلاین در حالت درگاه، هدایت برمی‌گرداند نه تسویهٔ فوری', r2.status === 200 && r2.data.gateway === true && r2.data.provider === 'simulated' && typeof r2.data.redirect_url === 'string' && r2.data.redirect_url.includes('/pay/simulate?authority='), JSON.stringify(r2.data));
      const auth1 = r2.data && r2.data.authority;
      check('رزرو هنوز done نشده و در انتظار درگاه است', (await viewOf(f1.id)).status === 'finished' && !(await viewOf(f1.id)).pay_state);
      const pg = await fetch(BASE + '/pay/simulate?authority=' + auth1);
      const pageHtml = await pg.text();
      check('صفحهٔ شبیه‌ساز درگاه برای کد رهگیری باز می‌شود', pg.status === 200 && pageHtml.includes(auth1) && pageHtml.includes('پرداخت موفق'));
      const cb = await fetch(BASE + '/pay/callback?authority=' + auth1 + '&status=OK', { redirect: 'manual' });
      check('کال‌بک موفق به اپ مسافر با pay-result=ok برمی‌گرداند', cb.status === 302 && (cb.headers.get('location') || '').includes('#pay-result=ok'), String(cb.headers.get('location')));
      const v1 = await viewOf(f1.id);
      check('پس از کال‌بک موفق، رزرو انجام‌شده و تسویه‌شده است', v1.status === 'done' && v1.pay_state === 'settled' && v1.pay_method === 'online', JSON.stringify(v1));
      const cb2 = await fetch(BASE + '/pay/callback?authority=' + auth1 + '&status=OK', { redirect: 'manual' });
      check('کال‌بک تکراری (idempotent) بدون خطا همان نتیجه است', cb2.status === 302 && (cb2.headers.get('location') || '').includes('#pay-result=ok'));
      check('پرداخت دوباره روی رزرو تسویه‌شده ممنوع است', (await call('POST', `/api/traveler/bookings/${f1.id}/payment`, { method: 'online' }, P)).status === 409);
    }

    console.log('== درگاه: مسیر ناموفق و تلاش مجدد');
    const f2 = await toFinished('درگاه ناموفق');
    check('رزرو دوم به پایان خدمت رسید', !!f2);
    if (f2) {
      let r2 = await call('POST', `/api/traveler/bookings/${f2.id}/payment`, { method: 'online' }, P);
      const auth2 = r2.data && r2.data.authority;
      check('تلاش دوم کد رهگیری تازه دارد', r2.status === 200 && r2.data.gateway === true && !!auth2, JSON.stringify(r2.data));
      const cbN = await fetch(BASE + '/pay/callback?authority=' + auth2 + '&status=NOK', { redirect: 'manual' });
      check('کال‌بک ناموفق به pay-result=fail برمی‌گرداند', cbN.status === 302 && (cbN.headers.get('location') || '').includes('#pay-result=fail'));
      const v2 = await viewOf(f2.id);
      check('پس از انصراف در درگاه، رزرو همچنان قابل پرداخت است', v2.status === 'finished' && !v2.pay_state, JSON.stringify(v2));
      const r3 = await call('POST', `/api/traveler/bookings/${f2.id}/payment`, { method: 'online' }, P);
      const auth3 = r3.data && r3.data.authority;
      check('تلاش مجدد پس از شکست مجاز است و کد تازه می‌گیرد', r3.status === 200 && r3.data.gateway === true && auth3 && auth3 !== auth2);
      const cb3 = await fetch(BASE + '/pay/callback?authority=' + auth3 + '&status=OK', { redirect: 'manual' });
      check('کال‌بک تلاش موفق دوم تسویه می‌کند', cb3.status === 302 && (await viewOf(f2.id)).status === 'done');
      check('کال‌بک با کد ناشناس به fail هدایت می‌کند', (await fetch(BASE + '/pay/callback?authority=deadbeef&status=OK', { redirect: 'manual' })).headers.get('location').includes('#pay-result=fail'));
    }

    console.log('== حالت فوری (instant) سازگار با جریان قبلی + زرین‌پال بی‌پذیرنده');
    await call('PUT', '/api/admin/settings', { payment_provider: 'instant' }, adm);
    const f3 = await toFinished('فوری آنلاین');
    check('رزرو سوم به پایان خدمت رسید', !!f3);
    if (f3) {
      const r4 = await call('POST', `/api/traveler/bookings/${f3.id}/payment`, { method: 'online' }, P);
      check('حالت instant همان تسویهٔ فوری قبلی را می‌دهد', r4.status === 200 && !r4.data.gateway && r4.data.pay_state === 'settled', JSON.stringify(r4.data));
    }
    await call('PUT', '/api/admin/settings', { payment_provider: 'zarinpal', online_enabled: 1 }, adm);
    const f4 = await toFinished('زرین بی‌پذیرنده');
    check('رزرو چهارم به پایان خدمت رسید', !!f4);
    if (f4) {
      const r5 = await call('POST', `/api/traveler/bookings/${f4.id}/payment`, { method: 'online' }, P);
      check('زرین‌پال بدون merchant_id خطای واضح می‌دهد', r5.status === 502 && r5.data.error === 'gateway_unavailable' && r5.data.detail === 'merchant_missing', JSON.stringify(r5.data));
    }
    let gw = await call('GET', '/api/admin/gateway-payments', null, adm);
    check('جدول پرداخت‌های درگاهی در پنل داده دارد', gw.status === 200 && gw.data.payments.length >= 3 && gw.data.payments.some((x) => x.status === 'paid') && gw.data.payments.some((x) => x.status === 'failed'), JSON.stringify(gw.data.payments && gw.data.payments.map((x) => x.status)));
    check('جدول درگاه بدون نشست ممنوع است', (await call('GET', '/api/admin/gateway-payments')).status === 401);

    console.log('== شکاف ۵: اعلان تطبیق و لغو (هر دو طرف)');
    let n0 = await call('GET', '/api/traveler/notifications', null, P);
    check('endpoint اعلان مسافر کار می‌کند', n0.status === 200 && Array.isArray(n0.data.notifications));
    const maxId0 = n0.data.notifications.reduce((m, n) => Math.max(m, n.id), 0);
    const b5 = await call('POST', '/api/traveler/bookings', { kind: 'instant', origin_lang: 'zh', dest_lang: 'fa', place: 'اعلان تطبیق', traveler_name: 'گ', lat: 35.72, lng: 51.41 }, P);
    let m5 = null, tok5 = null;
    for (let i = 0; i < 8 && !m5; i++) {
      for (const t of [T1.token, T2.token]) {
        const oo = (await call('GET', '/api/translator/offers', null, t)).data.offers.find((x) => x.place === 'اعلان تطبیق');
        if (oo) { m5 = oo; tok5 = t; break; }
      }
      if (!m5) await sleep(400);
    }
    check('پیشنهاد رزرو اعلان به یکی از مترجمان zh رسید', !!m5);
    await call('POST', `/api/translator/offers/${m5.id}/accept`, null, tok5);
    let nn = await call('GET', '/api/traveler/notifications', null, P);
    const matchedNotif = nn.data.notifications.find((n) => n.kind === 'matched' && n.reservation_id === b5.data.id);
    check('اعلان «مترجم شما مشخص شد» برای مسافر ثبت شد', !!matchedNotif && matchedNotif.text.includes('مترجم شما'), JSON.stringify(nn.data.notifications));
    nn = await call('GET', '/api/traveler/notifications?since=' + maxId0, null, P);
    check('واکشی با since فقط اعلان‌های تازه را می‌دهد', nn.status === 200 && nn.data.notifications.every((n) => n.id > maxId0) && nn.data.notifications.some((n) => n.kind === 'matched'));

    // لغو مترجم → اعلان مسافر (شکاف ۵)
    await call('POST', `/api/translator/missions/${b5.data.id}/cancel`, null, tok5);
    nn = await call('GET', '/api/traveler/notifications', null, P);
    const tCancel = nn.data.notifications.find((n) => n.kind === 'translator_cancelled' && n.reservation_id === b5.data.id);
    check('اعلان «کنار رفتن مترجم» برای مسافر ثبت شد', !!tCancel && tCancel.text.includes('کنار رفت'), JSON.stringify(tCancel));
    const afterTCancel = (await call('GET', '/api/traveler/bookings', null, P)).data.bookings.find((x) => x.id === b5.data.id);
    check('پس از لغو مترجم، رزرو به جستجو برگشته است', ['searching', 'matching', 'waiting_schedule'].includes(afterTCancel.status), afterTCancel.status);

    // لغو مسافر → اعلان مترجم
    const b6 = await call('POST', '/api/traveler/bookings', { kind: 'instant', origin_lang: 'zh', dest_lang: 'fa', place: 'اعلان لغو مسافر', traveler_name: 'گ', lat: 35.72, lng: 51.41 }, P);
    let m6 = null, tok6 = null;
    for (let i = 0; i < 8 && !m6; i++) {
      for (const t of [T1.token, T2.token]) {
        const oo = (await call('GET', '/api/translator/offers', null, t)).data.offers.find((x) => x.place === 'اعلان لغو مسافر');
        if (oo) { m6 = oo; tok6 = t; break; }
      }
      if (!m6) await sleep(400);
    }
    check('پیشنهاد رزرو لغو به مترجم رسید', !!m6);
    await call('POST', `/api/translator/offers/${m6.id}/accept`, null, tok6);
    await call('POST', `/api/traveler/bookings/${b6.data.id}/cancel`, null, P);
    const tn = await call('GET', '/api/translator/notifications', null, tok6);
    const trCancel = tn.data.notifications.find((n) => n.kind === 'booking_cancelled');
    check('اعلان «لغو مسافر» برای مترجم ثبت شد', !!trCancel && trCancel.text.includes('لغو'), JSON.stringify(tn.data.notifications.slice(0, 3)));
    check('نوع اعلان لغو در لیست سفید اپ مترجم پذیرفته است', !!trCancel && ['custom', 'booking_cancelled', 'doc_rejected', 'expired', 'expiring', 'interview_reminder'].includes(trCancel.kind));
  } finally {
    // پاکسازی تضمینی: حتی با کرش وسط تست، جریان پرداخت برای تست‌های بعدی به حالت پیش‌فرض برمی‌گردد
    await call('PUT', '/api/admin/settings', { payment_provider: 'instant', online_enabled: 0 }, adm);
  }

  console.log(`\nنتیجه: ${passed} موفق، ${failed} ناموفق`);
  process.exit(failed ? 1 : 0);
}
main().catch((e) => { console.error('CRASH', e); process.exit(1); });
