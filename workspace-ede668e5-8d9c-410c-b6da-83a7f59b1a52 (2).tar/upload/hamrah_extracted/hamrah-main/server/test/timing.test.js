'use strict';
// تست زمان‌بندی تطبیق روی سروری که با HZ_TIME_SCALE=0.01 بالا آمده (۶۰ ثانیه ≈ ۰٫۶ ثانیه، ۱۰ دقیقه ≈ ۶ ثانیه).
const BASE = process.env.BASE || 'http://127.0.0.1:8082';
let passed = 0, failed = 0;
const check = (name, ok, extra = '') => { if (ok) { passed++; console.log('  ok   ' + name); } else { failed++; console.log('  FAIL ' + name + (extra ? '  [' + extra + ']' : '')); } };
async function call(method, p, body, token) {
  const headers = { 'Content-Type': 'application/json' };
  if (token) headers.Authorization = 'Bearer ' + token;
  const r = await fetch(BASE + p, { method, headers, body: body ? JSON.stringify(body) : undefined });
  let data = null; try { data = await r.json(); } catch (e) {}
  return { status: r.status, data };
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function makeTranslator(phone, online = true) {
  await call('POST', '/api/auth/request-code', { phone, role: 'translator' });
  const v = await call('POST', '/api/auth/verify', { phone, role: 'translator', code: '123456' });
  await call('POST', '/api/dev/approve-translator', null, v.data.token);
  if (online) await call('PATCH', '/api/translator/online', { online: true }, v.data.token);
  return v.data.token;
}
async function main() {
  const k = String(Math.floor(Math.random() * 9e7) + 1e7); // ۸ رقم؛ شماره = '9' + k + n (۱۰ رقم)
  const A = await makeTranslator('9' + k + '1');
  await sleep(50);
  const B = await makeTranslator('9' + k + '2');
  const C = await makeTranslator('9' + k + '5', false); // آفلاین تا آزمون تلاش دوباره
  await call('POST', '/api/auth/request-code', { phone: '9' + k + '3', role: 'traveler' });
  const pv = await call('POST', '/api/auth/verify', { phone: '9' + k + '3', role: 'traveler', code: '123456' });
  const P = pv.data.token;
  console.log('== پیشنهاد ۶۰ ثانیه‌ای');
  const r = await call('POST', '/api/traveler/bookings', { kind: 'instant', origin_lang: 'ar', dest_lang: 'fa', place: 'زمان‌بندی', traveler_name: 'T' }, P);
  const bid = r.data.id;
  let oa = await call('GET', '/api/translator/offers', null, A);
  let ob = await call('GET', '/api/translator/offers', null, B);
  const firstIsA = oa.data.offers.some((o) => o.place === 'زمان‌بندی');
  const firstIsB = ob.data.offers.some((o) => o.place === 'زمان‌بندی');
  check('پیشنهاد به یک مترجم رسید', firstIsA !== firstIsB);
  const firstOffer = (firstIsA ? oa : ob).data.offers.find(o => o.place === 'زمان‌بندی');
  const firstOwner = firstIsA ? A : B;
  // مهلت پذیرش ۰٫۶ ثانیه است؛ بعد از آن پیشنهاد به نفر بعد می‌رود که مهلتش ۰٫۶ ثانیه‌ی دیگر است.
  // باید بین این دو باشیم: ۰٫۹ ثانیه (اگر بیشتر صبر کنیم، پیشنهاد دوم هم منقضی شده است)
  await sleep(900);
  check('نمای خصوصی پیشنهاد گذشته را منقضی نشان می‌دهد', (await call('GET', `/api/translator/offers/${firstOffer.id}`, null, firstOwner)).data.status === 'expired');
  check('رد دیرهنگام پیشنهاد موفق اعلام نمی‌شود', (await call('POST', `/api/translator/offers/${firstOffer.id}/decline`, null, firstOwner)).status === 410);
  check('پذیرش دیرهنگام پیشنهاد ممنوع است', (await call('POST', `/api/translator/offers/${firstOffer.id}/accept`, null, firstOwner)).status === 410);

  oa = await call('GET', '/api/translator/offers', null, A);
  ob = await call('GET', '/api/translator/offers', null, B);
  const nowA = oa.data.offers.some((o) => o.place === 'زمان‌بندی');
  const nowB = ob.data.offers.some((o) => o.place === 'زمان‌بندی');
  check('پس از انقضا، پیشنهاد به مترجم دوم رفت', (firstIsA && nowB) || (firstIsB && nowA), JSON.stringify([nowA, nowB]));
  check('پس از انقضا، مترجم اول دیگر پیشنهاد ندارد', firstIsA ? !nowA : !nowB);
  console.log('== سقف جستجوی فوری ۱۰ دقیقه‌ای');
  await sleep(6500); // ≈ ۶ ثانیه سقف
  let bk = (await call('GET', '/api/traveler/bookings', null, P)).data.bookings.find((b) => b.id === bid);
  check('بعد از سقف، وضعیت «بدون تطبیق» است', bk.status === 'no_match', bk.status);
  const retry = await call('POST', `/api/traveler/bookings/${bid}/retry`, null, P);
  check('تلاش دوباره جستجو را از نو شروع می‌کند', retry.status === 200);
  bk = (await call('GET', '/api/traveler/bookings', null, P)).data.bookings.find((b) => b.id === bid);
  check('پس از تلاش دوباره وضعیت «در جستجو»', bk.status === 'searching');
  console.log('== زمان‌دار: قبل از پنجره‌ی تطبیق منتظر می‌ماند');
  const sched = new Date(Date.now() + 90 * 1000).toISOString(); // با مقیاس ۰٫۰۱ حداقل فاصله ۷۲ ثانیه است
  const rs = await call('POST', '/api/traveler/bookings', { kind: 'scheduled', origin_lang: 'ar', dest_lang: 'fa', place: 'قرار', scheduled_at: sched, traveler_name: 'T' }, P);
  check('رزرو زمان‌دار با مقیاس زمانی پذیرفته شد', rs.status === 201, JSON.stringify(rs));
  check('قبل از پنجره، هنوز پیشنهادی نیست (در انتظار)', rs.data.status === 'waiting_schedule');
  const cancelled = await call('POST', `/api/traveler/bookings/${rs.data.id}/cancel`, null, P);
  check('لغو زمان‌دار منتظر رایگان است', cancelled.status === 200 && cancelled.data.fee_percent === 0);
  console.log('== زمان‌دار: تلاش دوباره پس از مهلت ۱۵ دقیقه‌ای');
  const retryAt = new Date(Date.now() + 73 * 1000).toISOString(); // حداقل فاصله‌ی زمان‌دار با مقیاس ۰٫۰۱ کمی بیش از ۷۲ ثانیه است
  const retryBooking = await call('POST', '/api/traveler/bookings', {
    kind: 'scheduled', origin_lang: 'ar', dest_lang: 'fa', place: 'تلاش دوباره زمان‌دار',
    scheduled_at: retryAt, traveler_name: 'T'
  }, P);
  check('رزرو زمان‌دار آزمون تلاش دوباره ساخته شد', retryBooking.status === 201, JSON.stringify(retryBooking));
  if (retryBooking.status === 201) {
    await sleep(Math.max(0, Date.parse(retryAt) - 8000 - Date.now())); // یک ثانیه پس از مهلتِ ۱۵ دقیقه‌ای
    let retryView = (await call('GET', '/api/traveler/bookings', null, P)).data.bookings.find(b => b.id === retryBooking.data.id);
    for (let i = 0; i < 20 && retryView.status !== 'unmatched_ask'; i++) {
      await sleep(250);
      retryView = (await call('GET', '/api/traveler/bookings', null, P)).data.bookings.find(b => b.id === retryBooking.data.id);
    }
    check('پس از نبود پذیرش تا ۱۵ دقیقه مانده، انتخاب دوباره یا لغو نمایش داده می‌شود', retryView.status === 'unmatched_ask', retryView.status);
    await call('PATCH', '/api/translator/online', { online: true }, C);
    const resumed = await call('POST', `/api/traveler/bookings/${retryBooking.data.id}/retry`, null, P);
    check('درخواست تلاش دوباره از سوی سرور پذیرفته می‌شود', resumed.status === 200, JSON.stringify(resumed));
    const resumedOffers = (await call('GET', '/api/translator/offers', null, C)).data.offers || [];
    check('تلاش دوباره جستجو را از سر می‌گیرد و به مترجم تازه‌در‌دسترس پیشنهاد می‌دهد', resumedOffers.some(o => o.reservation_id === retryBooking.data.id));
    retryView = (await call('GET', '/api/traveler/bookings', null, P)).data.bookings.find(b => b.id === retryBooking.data.id);
    check('وضعیت پس از تلاش دوباره واقعاً «در حال تطبیق» است', retryView.status === 'matching', retryView.status);
    await sleep(Math.max(0, Date.parse(retryAt) - Date.now() + 150));
    retryView = (await call('GET', '/api/traveler/bookings', null, P)).data.bookings.find(b => b.id === retryBooking.data.id);
    check('رزروِ بی‌تطبیق در موعد مقرر خودکار و رایگان لغو می‌شود', retryView.status === 'cancelled', retryView.status);
    await call('PATCH', '/api/translator/online', { online: false }, C);
  }
  console.log('== پنجره‌ی ۵ دقیقه‌ای درخواست تغییر (مقیاس ۰٫۰۱ ≈ ۳ ثانیه)');
  {
    const P2phone = '9' + k + '4';
    await call('POST', '/api/auth/request-code', { phone: P2phone, role: 'traveler' });
    const P2 = (await call('POST', '/api/auth/verify', { phone: P2phone, role: 'traveler', code: '123456' })).data.token;
    await call('POST', `/api/traveler/bookings/${bid}/cancel`, null, P);
    const place0 = 'مکان پنجره ' + k;
    const bk2 = (await call('POST', '/api/traveler/bookings', { kind: 'instant', origin_lang: 'ar', dest_lang: 'fa', place: place0, traveler_name: 'T' }, P2)).data;
    await sleep(100);
    const offA = (await call('GET', '/api/translator/offers', null, A)).data.offers || [];
    const offB = (await call('GET', '/api/translator/offers', null, B)).data.offers || [];
    const [tokOwner, offer] = offA.some((o) => o.place === place0) ? [A, offA.find((o) => o.place === place0)] : [B, offB.find((o) => o.place === place0)];
    const acc = await call('POST', `/api/translator/offers/${offer.id}/accept`, null, tokOwner);
    check('مترجم پیشنهاد را پذیرفت', acc.status === 200, JSON.stringify(acc));
    const ch = await call('POST', `/api/traveler/bookings/${bk2.id}/change`, { place: 'مکان جدید پنجره' }, P2);
    check('تغییر مکان پس از پذیرش، ۲۰۲ و در انتظار است', ch.status === 202 && ch.data.pending === true, JSON.stringify(ch));
    const dup = await call('POST', `/api/traveler/bookings/${bk2.id}/change`, { place: 'باز هم' }, P2);
    check('درخواست دوم هم‌زمان ممنوع است', dup.status === 409 && dup.data.error === 'change_pending');
    let view = (await call('GET', '/api/traveler/bookings', null, P2)).data.bookings.find((b) => b.id === bk2.id);
    check('در نمای مسافر، درخواست باز دیده می‌شود', !!view.pending_change);
    await sleep(3600); // ۵ دقیقه ≈ ۳ ثانیه با مقیاس؛ کمی بیشتر
    view = (await call('GET', '/api/traveler/bookings', null, P2)).data.bookings.find((b) => b.id === bk2.id);
    check('پس از پنجره، درخواست بی‌پاسخ منقضی و پاک می‌شود', view.pending_change === null, JSON.stringify(view.pending_change));
    check('نمای خصوصی تغییر منقضی را منتظر نشان نمی‌دهد', (await call('GET', `/api/translator/changes/${ch.data.id}`, null, tokOwner)).data.status === 'expired');
    check('رد دیرهنگام تغییر موفق اعلام نمی‌شود', (await call('POST', `/api/translator/changes/${ch.data.id}/reject`, null, tokOwner)).status === 410);
    check('مکان بدون پاسخ مترجم عوض نشده', view.place === place0, view.place);
    const late = await call('POST', `/api/translator/changes/${ch.data.id}/accept`, null, tokOwner);
    check('پذیرش دیرهنگام مترجم رد می‌شود', late.status === 410, String(late.status));
    const again = await call('POST', `/api/traveler/bookings/${bk2.id}/change`, { place: 'مکان جدید پنجره' }, P2);
    check('پس از انقضا، درخواست تازه مجاز است (شمارش ۲ از ۳)', again.status === 202, JSON.stringify(again));
    await call('POST', `/api/traveler/bookings/${bk2.id}/cancel`, null, P2);
  }
  console.log('== پایان خدمت پیش از زمان قرار ممنوع است');
  {
    // رزرو زمان‌دار: با مقیاس ۰٫۰۱، قرار ۷۵ ثانیه‌ی دیگر است و پنجره‌ی تطبیق ۳۶ ثانیه مانده به قرار باز می‌شود.
    const sched = new Date(Date.now() + 75 * 1000).toISOString();
    const rs = await call('POST', '/api/traveler/bookings', { kind: 'scheduled', origin_lang: 'ar', dest_lang: 'fa', place: 'پایان زودهنگام', scheduled_at: sched, traveler_name: 'T' }, P);
    check('رزرو زمان‌دار برای آزمون پایان ساخته شد', rs.status === 201, JSON.stringify(rs));
    // صبر تا بازشدن پنجره‌ی تطبیق و رسیدن پیشنهاد (حداکثر ~۵۰ ثانیه)
    let offer = null, owner = null;
    for (let i = 0; i < 250 && !offer; i++) {
      const oa = (await call('GET', '/api/translator/offers', null, A)).data.offers || [];
      const ob = (await call('GET', '/api/translator/offers', null, B)).data.offers || [];
      if (oa.some((o) => o.place === 'پایان زودهنگام')) { offer = oa.find((o) => o.place === 'پایان زودهنگام'); owner = A; }
      else if (ob.some((o) => o.place === 'پایان زودهنگام')) { offer = ob.find((o) => o.place === 'پایان زودهنگام'); owner = B; }
      if (!offer) await sleep(200);
    }
    check('پیشنهاد در پنجره‌ی تطبیق رسید', !!offer);
    if (offer) {
      const acc = await call('POST', `/api/translator/offers/${offer.id}/accept`, null, owner);
      check('پذیرش در پنجره ممکن است', acc.status === 200, JSON.stringify(acc));
      const fin = await call('POST', `/api/translator/missions/${rs.data.id}/finish`, null, owner);
      check('پایان خدمت پیش از زمان قرار: ۴۰۹', fin.status === 409 && fin.data.error === 'too_early', JSON.stringify(fin));
      const earlyArrival = await call('POST', `/api/translator/missions/${rs.data.id}/arrive`, null, owner);
      check('گزارش حضور مترجم پیش از زمان قرار رد می‌شود', earlyArrival.status === 409 && earlyArrival.data.error === 'arrival_not_allowed', JSON.stringify(earlyArrival));
      const newTime = new Date(Date.now() + 90 * 1000).toISOString();
      const timeChange = await call('POST', `/api/traveler/bookings/${rs.data.id}/change`, { scheduled_at: newTime }, P);
      check('تغییر زمان قرار هم رضایت می‌خواهد', timeChange.status === 202);
      check('مترجم تغییر زمان را می‌پذیرد', (await call('POST', `/api/translator/changes/${timeChange.data.id}/accept`, null, owner)).status === 200);
      check('زمان جدید در نمای خصوصی مأموریت اعمال می‌شود', (await call('GET', `/api/translator/missions/${rs.data.id}`, null, owner)).data.details.scheduled_at === Date.parse(newTime));
      const cancelled = await call('POST', `/api/translator/missions/${rs.data.id}/cancel`, null, owner);
      check('لغو زمان‌دار دور ادعای تطبیق فوری نمی‌کند', cancelled.status === 200 && cancelled.data.reassigned === false);
      const cancellation = (await call('GET', `/api/translator/missions/${rs.data.id}/cancellation`, null, owner)).data;
      check('تاریخچهٔ لغو زمان‌دار پس از واگذاری قابل بررسی است', cancellation.cancelled === true && cancellation.assigned === false && cancellation.cancelled_at === cancelled.data.cancelled_at);
      const waiting = (await call('GET', '/api/traveler/bookings', null, P)).data.bookings.find(b => b.id === rs.data.id);
      check('رزرو زمان‌دار با همان قیمت برای زمان تطبیق بعدی می‌ماند', waiting.status === 'waiting_schedule' && !waiting.matched && waiting.total === rs.data.total);


    }
    await call('POST', `/api/traveler/bookings/${rs.data.id}/cancel`, null, P);
  }
  console.log('== پاسخ دیرهنگام به تمدید');
  {
    const created = await call('POST', '/api/traveler/bookings', { kind: 'instant', origin_lang: 'ar', dest_lang: 'fa', place: 'تمدید منقضی', traveler_name: 'T' }, P);
    const oa = (await call('GET', '/api/translator/offers', null, A)).data.offers;
    const ob = (await call('GET', '/api/translator/offers', null, B)).data.offers;
    const [owner, offer] = oa.some(o => o.place === 'تمدید منقضی') ? [A, oa.find(o => o.place === 'تمدید منقضی')] : [B, ob.find(o => o.place === 'تمدید منقضی')];
    await call('POST', `/api/translator/offers/${offer.id}/accept`, null, owner);
    await call('POST', `/api/translator/missions/${created.data.id}/arrive`, null, owner);
    await call('POST', `/api/translator/missions/${created.data.id}/verify-code`, { code: created.data.service_code }, owner);
    const before = (await call('GET', `/api/translator/missions/${created.data.id}`, null, owner)).data;
    const e = await call('POST', `/api/traveler/bookings/${created.data.id}/extend`, { extra_hours: 1 }, P);
    check('تمدید دارای مهلت ساخته می‌شود', e.status === 202, JSON.stringify(e));
    await sleep(3600);
    check('نمای خصوصی، تمدید منقضی را منتظر نشان نمی‌دهد', (await call('GET', `/api/translator/extensions/${e.data.id}`, null, owner)).data.status === 'expired');
    check('رد دیرهنگام تمدید تأیید کاذب ندارد', (await call('POST', `/api/translator/extensions/${e.data.id}/reject`, null, owner)).status === 410);
    check('پذیرش دیرهنگام تمدید ممنوع است', (await call('POST', `/api/translator/extensions/${e.data.id}/accept`, null, owner)).status === 410);
    const after = (await call('GET', `/api/translator/missions/${created.data.id}`, null, owner)).data;
    check('انقضا ساعت، مبلغ و زمان شروع را تغییر نمی‌دهد', after.hours === before.hours && after.total === before.total && after.service_started_at === before.service_started_at);
    await call('POST', `/api/traveler/bookings/${created.data.id}/finish`, null, P);
  }
  console.log(`\nنتیجه: ${passed} موفق، ${failed} ناموفق`);
  process.exit(failed ? 1 : 0);
}
main().catch((e) => { console.error(e); process.exit(1); });
