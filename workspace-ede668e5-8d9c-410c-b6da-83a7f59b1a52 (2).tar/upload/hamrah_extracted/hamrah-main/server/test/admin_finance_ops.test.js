'use strict';
/* تست عملیات مالی مدیر: تسویهٔ دستی پرداخت نقدی معلق و حل‌وفصل اختلاف.
 * اجرا مثل api.test.js:
 *   HZ_DEV=1 HZ_ADMIN_PASSWORD=test-admin-pass HZ_DB=/tmp/hz_f.sqlite PORT=8082 node server.js
 *   BASE=http://127.0.0.1:8082 node test/admin_finance_ops.test.js
 */
const BASE = process.env.BASE || 'http://127.0.0.1:8082';
let passed = 0, failed = 0;
function check(name, ok, extra = '') {
  if (ok) { passed++; console.log('  ok   ' + name); }
  else { failed++; console.log('  FAIL ' + name + (extra ? '  [' + extra + ']' : '')); }
}
async function call(method, p, body, token) {
  const headers = { 'Content-Type': 'application/json' };
  if (token) headers.Authorization = 'Bearer ' + token;
  const r = await fetch(BASE + p, { method, headers, body: body ? JSON.stringify(body) : undefined });
  let data = null; try { data = await r.json(); } catch (e) { /* non-json */ }
  return { status: r.status, data };
}
const phoneFor = (n) => '913' + String(7000000 + n).slice(-7);

async function makeTraveler(n) {
  const phone = phoneFor(n);
  await call('POST', '/api/auth/request-code', { phone, role: 'traveler' });
  const v = await call('POST', '/api/auth/verify', { phone, role: 'traveler', code: '123456' });
  return v.data.token;
}
async function makeTranslator(n) {
  const phone = phoneFor(n);
  await call('POST', '/api/auth/request-code', { phone, role: 'translator' });
  const v = await call('POST', '/api/auth/verify', { phone, role: 'translator', code: '123456' });
  await call('POST', '/api/dev/approve-translator', null, v.data.token);
  return v.data.token;
}
// چرخهٔ کامل تا پرداخت نقدی: رزرو فوری → تطبیق → شروع با کد → پایان توسط مسافر → پرداخت نقدی
async function cashFlow(ptok, ttok, place) {
  await call('PATCH', '/api/translator/online', { online: true }, ttok);
  const b = await call('POST', '/api/traveler/bookings', { kind: 'instant', origin_lang: 'fa', dest_lang: 'en', place, hours: 2 }, ptok);
  const bid = b.data.id;
  let off = null;
  for (let i = 0; i < 5 && !off; i++) {
    const o = await call('GET', '/api/translator/offers', null, ttok);
    off = (o.data.offers || []).find((x) => x.reservation_id === bid);
    if (!off) {
      // با توازن بار ممکن است پیشنهاد به مترجم دیگری برسد؛ رد می‌کنیم تا نوبت هدف شود
      const all = (o.data.offers || []).filter((x) => x.reservation_id === bid);
      for (const x of all) await call('POST', `/api/translator/offers/${x.id}/decline`, null, ttok);
      await new Promise((r) => setTimeout(r, 1200));
    }
  }
  if (!off) return { bid, ok: false };
  const acc = await call('POST', `/api/translator/offers/${off.id}/accept`, null, ttok);
  if (acc.status !== 200) return { bid, ok: false };
  const bk = (await call('GET', '/api/traveler/bookings', null, ptok)).data.bookings.find((x) => x.id === bid);
  await call('POST', `/api/translator/missions/${bid}/arrive`, null, ttok);
  const st = await call('POST', `/api/translator/missions/${bid}/verify-code`, { code: bk.service_code }, ttok);
  if (st.status !== 200) return { bid, ok: false };
  const fin = await call('POST', `/api/traveler/bookings/${bid}/finish`, null, ptok);
  if (fin.status !== 200) return { bid, ok: false };
  const pay = await call('POST', `/api/traveler/bookings/${bid}/payment`, { method: 'cash' }, ptok);
  return { bid, ok: pay.status === 200 && pay.data.pay_state === 'awaiting_cash' };
}

async function main() {
  console.log('== عملیات مالی مدیر');
  const ptok = await makeTraveler(1);
  const ttok = await makeTranslator(1);
  const r = await call('POST', '/api/admin/login', { password: process.env.ADMIN_PASSWORD || 'test-admin-pass' });
  const adm = r.data && r.data.token;
  check('ورود مدیر', r.status === 200 && !!adm);

  // --- سناریو ۱: تسویهٔ دستی پرداخت معلق ---
  const f1 = await cashFlow(ptok, ttok, 'میدان آزادی - تست تسویه');
  check('چرخهٔ نقدی تا awaiting_cash', f1.ok, JSON.stringify(f1));
  let res = await call('POST', `/api/admin/reservations/${f1.bid}/settle`, {});
  check('تسویهٔ دستی بدون توکن مدیر ۴۰۱', res.status === 401, JSON.stringify(res));
  res = await call('POST', '/api/admin/reservations/999999/settle', {}, adm);
  check('تسویهٔ دستی رزرو ناموجود ۴۰۴', res.status === 404, JSON.stringify(res));
  res = await call('POST', `/api/admin/reservations/${f1.bid}/settle`, {}, adm);
  check('تسویهٔ دستی معلق → settled + done', res.status === 200 && res.data.pay_state === 'settled' && res.data.status === 'done', JSON.stringify(res));
  res = await call('POST', `/api/admin/reservations/${f1.bid}/settle`, {}, adm);
  check('تسویهٔ دوباره همان رزرو ۴۰۹', res.status === 409 && res.data.error === 'not_settleable', JSON.stringify(res));
  const tPay = await call('GET', '/api/translator/payments', null, ttok);
  check('پس از تسویه، رزرو از صف پرداخت مترجم خارج شد',
    !(tPay.data.payments || []).some((p) => p.reservation_id === f1.bid), JSON.stringify(tPay.data));

  // --- سناریو ۲: حل اختلاف با استرداد ---
  const f2 = await cashFlow(ptok, ttok, 'میدان ونک - تست استرداد');
  check('چرخهٔ نقدی دوم تا awaiting_cash', f2.ok, JSON.stringify(f2));
  const dis = await call('POST', `/api/traveler/bookings/${f2.bid}/dispute`, {}, ptok);
  check('اعلام اختلاف مسافر → disputed', dis.status === 200 && dis.data.pay_state === 'disputed', JSON.stringify(dis));
  res = await call('POST', `/api/admin/disputes/${f2.bid}/resolve`, { decision: 'settle' });
  check('حل اختلاف بدون توکن مدیر ۴۰۱', res.status === 401);
  res = await call('POST', `/api/admin/disputes/${f2.bid}/resolve`, { decision: 'nonsense' }, adm);
  check('تصمیم نامعتبر ۴۰۰', res.status === 400 && res.data.error === 'invalid_decision', JSON.stringify(res));
  res = await call('POST', `/api/admin/disputes/999999/resolve`, { decision: 'refund' }, adm);
  check('حل اختلاف رزرو ناموجود ۴۰۴', res.status === 404);
  res = await call('POST', `/api/admin/disputes/${f2.bid}/resolve`, { decision: 'refund', note: 'وجه به مسافر بازگشت' }, adm);
  check('استرداد → refunded', res.status === 200 && res.data.pay_state === 'refunded', JSON.stringify(res));
  res = await call('POST', `/api/admin/disputes/${f2.bid}/resolve`, { decision: 'settle' }, adm);
  check('حل دوبارهٔ اختلاف بسته‌شده ۴۰۹', res.status === 409 && res.data.error === 'not_disputed', JSON.stringify(res));
  const bk2 = (await call('GET', '/api/traveler/bookings', null, ptok)).data.bookings.find((x) => x.id === f2.bid);
  check('نمای مسافر از refunded', bk2 && bk2.pay_state === 'refunded' && bk2.status === 'finished', JSON.stringify(bk2));
  const fin = await call('GET', '/api/admin/finance', null, adm);
  check('شمارندهٔ refunded در نمای مالی', fin.status === 200 && fin.data.refunded && fin.data.refunded.count === 1, JSON.stringify(fin.data && fin.data.refunded));
  check('refunded از «منتظر تأیید» خارج شد',
    !(fin.data.waiting_list || []).some((w) => w.id === f2.bid) && (fin.data.settled.count >= 1), JSON.stringify(fin.data.waiting));
  const tPay2 = await call('GET', '/api/translator/payments', null, ttok);
  check('refunded در صف پرداخت مترجم نیست', !(tPay2.data.payments || []).some((p) => p.reservation_id === f2.bid), JSON.stringify(tPay2.data));

  // --- سناریو ۳: حل اختلاف با تسویهٔ عادی ---
  const f3 = await cashFlow(ptok, ttok, 'تجریش - تست تسویه عادی');
  check('چرخهٔ نقدی سوم تا awaiting_cash', f3.ok, JSON.stringify(f3));
  await call('POST', `/api/traveler/bookings/${f3.bid}/dispute`, {}, ptok);
  res = await call('POST', `/api/admin/disputes/${f3.bid}/resolve`, { decision: 'settle', note: 'دو طرف توافق کردند' }, adm);
  check('تسویهٔ عادی → settled + done', res.status === 200 && res.data.pay_state === 'settled' && res.data.status === 'done', JSON.stringify(res));
  const bk3 = (await call('GET', '/api/traveler/bookings', null, ptok)).data.bookings.find((x) => x.id === f3.bid);
  check('نمای مسافر از تسویهٔ اختلاف', bk3 && bk3.pay_state === 'settled' && bk3.status === 'done', JSON.stringify(bk3));
  const aud = await call('GET', '/api/admin/audit?limit=20', null, adm);
  const acts = (aud.data.entries || []);
  check('اقدام‌ها در گزارش تغییرات ثبت شد',
    acts.some((a) => a.action === 'dispute.resolve') && acts.some((a) => a.action === 'reservation.manual_settle'), JSON.stringify(acts.slice(0, 3)));

  console.log(`\nنتیجه: ${passed} پاس، ${failed} خطا`);
  process.exit(failed ? 1 : 0);
}
main().catch((e) => { console.error(e); process.exit(1); });
