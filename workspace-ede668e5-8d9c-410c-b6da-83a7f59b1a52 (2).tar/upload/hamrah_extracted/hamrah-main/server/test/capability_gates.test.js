'use strict';
/* تست ماتریس گیت‌های احراز صلاحیت (CAP) — پنج قاعدهٔ طرح:
 * ۱) مترجمِ فقط-پایه (tourism/pilgrimage) پس از قبولی آزمون زبان، درخواست همان حوزه‌های پایه را می‌گیرد و تخصصی را نمی‌گیرد.
 * ۲) خودرو قابلیت جداست: ثبتش مانع میز کار نیست؛ تا تأیید بیمه+گواهینامه رزرو سواره نمی‌گیرد.
 * ۳) گیت حوزه‌های تخصصی = مدرک زبان تأییدشده؛ بدون آن، درخواست تخصصی پیشنهاد نمی‌شود.
 * ۴) تکمیل بعدی اختیاری: PATCH fields (تخصص) و PATCH vehicle (خودرو) از کارت صلاحیت.
 * ۵) مترجم بدون خودرو (پایه یا تخصصی) فقط درخواست پیاده می‌بیند.
 * اجرا: BASE=http://127.0.0.1:8081 node test/capability_gates.test.js (سرور با HZ_DEV=1 و HZ_ADMIN_PASSWORD)
 */
const BASE = process.env.BASE || 'http://127.0.0.1:8081';
let passed = 0, failed = 0;
function check(name, ok, extra = '') {
  if (ok) { passed++; console.log('  ok   ' + name); }
  else { failed++; console.log('  FAIL ' + name + (extra ? '  [' + extra + ']' : '')); }
}
async function call(method, p, body, token) {
  const headers = { 'Content-Type': 'application/json' };
  if (token) headers.Authorization = 'Bearer ' + token;
  const r = await fetch(BASE + p, { method, headers, body: body ? JSON.stringify(body) : undefined });
  let data = null; try { data = await r.json(); } catch (e) { /* non-json */ }
  return { status: r.status, data };
}
const PNG = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==';
const FUTURE = new Date(Date.now() + 365 * 86400000).toISOString().slice(0, 10);

async function login(phone, role) {
  await call('POST', '/api/auth/request-code', { phone, role });
  const v = await call('POST', '/api/auth/verify', { phone, role, code: '123456' });
  return v.data.token;
}

// ثبت‌نام واقعی (بدون dev-approve) → پرونده در pending_review؛ سپس تصمیم کارشناس + نتیجهٔ مصاحبه
async function makeRealTranslator(n, fields, car) {
  const tok = await login('915' + String(3000000 + n).slice(-7), 'translator');
  const reg = { nda: true, charter: true, gender: 'male', first_name: 'مترجم' + n, last_name: 'گیت', city: 'تهران',
    languages: ['ar', 'fa'], fields, car: car === true };
  if (car) { reg.car_model = 'پژو ' + n; reg.car_capacity = 4; }
  const r = await call('POST', '/api/translator/registration', reg, tok);
  if (r.status !== 200) throw new Error('registration failed: ' + JSON.stringify(r.data));
  return { tok, id: (await call('GET', '/api/auth/me', null, tok)).data.id, status: r.data.status, fields: r.data.fields };
}

async function approveFile(adm, id) {
  let r = await call('POST', `/api/admin/translators/${id}/decision`, { decision: 'approve' }, adm);
  if (r.status !== 200) throw new Error('decision failed: ' + JSON.stringify(r.data));
  r = await call('POST', `/api/admin/translators/${id}/interview`, { result: 'pass' }, adm);
  if (r.status !== 200) throw new Error('interview failed: ' + JSON.stringify(r.data));
}

// آنلاین‌شدن فقط برای مترجم فعال معنا دارد؛ بعد از تأیید پرونده صدا زده می‌شود
async function goOnline(tok) {
  const r = await call('PATCH', '/api/translator/online', { online: true }, tok);
  if (r.status !== 200) throw new Error('online failed: ' + JSON.stringify(r.data));
}

// مدرک بارگذاری و توسط کارشناس تأیید می‌شود؛ شناسهٔ مدرک از صف ادمین خوانده می‌شود
async function approveDoc(adm, tok, kind, expiresAt) {
  const up = await call('POST', '/api/translator/documents', { kind, data: PNG, expires_at: expiresAt }, tok);
  if (up.status !== 200) throw new Error('doc upload failed: ' + JSON.stringify(up.data));
  const page = await call('GET', '/api/admin/translator-docs?filter=all&limit=200', null, adm);
  const me = (await call('GET', '/api/auth/me', null, tok)).data.id;
  const mine = page.data.translators.find((t) => t.id === me);
  const doc = mine && (mine.documents || []).filter((d) => d.kind === kind && d.status === 'uploaded').pop();
  if (!doc) throw new Error('doc not in admin queue: ' + kind);
  const dec = await call('POST', `/api/admin/documents/${doc.id}/decision`, { decision: 'approve' }, adm);
  if (dec.status !== 200) throw new Error('doc decision failed: ' + JSON.stringify(dec.data));
}

// درخواست مسافر و بررسی رسیدن/نرسیدن پیشنهاد به مترجم هدف
async function offerArrives(target, place, others) {
  let o = (await call('GET', '/api/translator/offers', null, target)).data.offers.find((x) => x.place === place);
  for (let i = 0; !o && i < 3 && others.length; i++) {
    for (const t of others) {
      const oo = (await call('GET', '/api/translator/offers', null, t)).data.offers.find((x) => x.place === place);
      if (oo) await call('POST', `/api/translator/offers/${oo.id}/decline`, null, t);
    }
    o = (await call('GET', '/api/translator/offers', null, target)).data.offers.find((x) => x.place === place);
  }
  return o;
}
async function book(ptok, field, place, extra) {
  const r = await call('POST', '/api/traveler/bookings', Object.assign(
    { kind: 'instant', origin_lang: 'ar', dest_lang: 'fa', field, place, traveler_name: 'مسافر گیت' }, extra || {}), ptok);
  if (r.status !== 200 && r.status !== 201) throw new Error('booking failed: ' + JSON.stringify(r.data));
  return r.data;
}

// پیشنهاد باز، مترجم را از چرخهٔ پیشنهاد بعدی خارج می‌کند (شرط NOT EXISTS)؛
// برای ایزوله‌سازی هر گام، پیشنهادهای باز مترجمان آزمون پیش از هر رزرو بسته می‌شوند.
async function clearOffers(...toks) {
  for (const tok of toks) {
    // فهرست پیشنهادها فقط pendingهای فعال را می‌دهد (بدون فیلد status)؛ همه رد می‌شوند
    const offs = (await call('GET', '/api/translator/offers', null, tok)).data.offers || [];
    for (const o of offs) await call('POST', `/api/translator/offers/${o.id}/decline`, null, tok);
  }
}

// رزروهای جستجوی کهنه (مثلاً منفی‌های گیت که بی‌پیشنهاد مانده‌اند) در اولین sweep بعد از باز شدن گیت
// پیشنهاد را «می‌دزدند» — این رفتار درست پلتفرم است؛ تست پیش از هر رزرو نو آن‌ها را لغو می‌کند.
async function cancelStale(ptok) {
  const bks = (await call('GET', '/api/traveler/bookings', null, ptok)).data.bookings || [];
  for (const b of bks.filter((x) => ['searching', 'waiting_schedule', 'matching', 'unmatched_ask', 'no_match'].includes(x.status))) {
    await call('POST', `/api/traveler/bookings/${b.id}/cancel`, null, ptok);
  }
}

async function main() {
  console.log('== ماتریس گیت‌های CAP');
  const adm = (await call('POST', '/api/admin/login', { password: process.env.HZ_ADMIN_PASSWORD || 'test-admin-pass' })).data.token;
  await call('POST', '/api/dev/offline-all', null, adm); // ایزوله‌سازی: فقط مترجمان همین تست آنلاین‌اند
  const ptok = await login('916' + String(2000000 + Math.floor(Math.random() * 999999)).slice(-7), 'traveler');

  // ---------- قاعدهٔ ۱: مترجم فقط-پایه ----------
  const A = await makeRealTranslator(1, ['tourism', 'pilgrimage'], false);
  check('ثبت‌نامِ فقط-پایه با مقادیر نو ذخیره می‌شود', JSON.stringify(A.fields) === '["tourism","pilgrimage"]', JSON.stringify(A.fields));
  await approveFile(adm, A.id);
  await goOnline(A.tok);
  let cap = (await call('GET', '/api/translator/capability', null, A.tok)).data;
  check('پروندهٔ تأییدشده: میز کار باز است (active_general)', cap.status === 'active_general', cap.status);
  check('نردبان: حوزه‌های پایه بدون مدرک تخصصی فعال‌اند', cap.ladder.fields.filter((f) => f.base).every((f) => f.selected && f.active));
  check('نردبان: گیت تخصص بسته است (بدون مدرک زبان)', cap.dimensions.specialized.ok === false);
  await book(ptok, 'tourism', 'گیت-الف-گردشگری');
  check('قاعدهٔ ۱: درخواست گردشگری به مترجم پایه می‌رسد', !!(await offerArrives(A.tok, 'گیت-الف-گردشگری', [])));
  await clearOffers(A.tok); await cancelStale(ptok);
  await book(ptok, 'pilgrimage', 'گیت-الف-زیارتی');
  check('قاعدهٔ ۱: درخواست زیارتی به مترجم پایه می‌رسد', !!(await offerArrives(A.tok, 'گیت-الف-زیارتی', [])));
  await book(ptok, 'medical', 'گیت-الف-درمانی');
  check('قاعدهٔ ۱: درخواست درمانی به مترجم فقط-پایه نمی‌رسد', !(await offerArrives(A.tok, 'گیت-الف-درمانی', [])));

  // ---------- قاعدهٔ ۳+۴: گیت تخصص با مدرک زبان + تکمیل بعدی از کارت صلاحیت ----------
  await approveDoc(adm, A.tok, 'lang_cert');
  cap = (await call('GET', '/api/translator/capability', null, A.tok)).data;
  check('تأیید مدرک زبان: وضعیت مؤثر به active_specialized می‌رود', cap.status === 'active_specialized', cap.status);
  check('نردبان: گیت تخصص باز شد', cap.dimensions.specialized.ok === true);
  const pf = await call('PATCH', '/api/translator/fields', { fields: ['tourism', 'pilgrimage', 'medical'] }, A.tok);
  check('قاعدهٔ ۴: افزودن حوزهٔ تخصصی از کارت صلاحیت — unlocked شامل درمانی', pf.status === 200 && pf.data.unlocked.includes('medical') && pf.data.locked.length === 0, JSON.stringify(pf.data));
  await clearOffers(A.tok); await cancelStale(ptok);
  await book(ptok, 'medical', 'گیت-ب-درمانی');
  check('قاعدهٔ ۳: با مدرک زبانِ تأییدشده، درخواست درمانی می‌رسد', !!(await offerArrives(A.tok, 'گیت-ب-درمانی', [])));
  await clearOffers(A.tok); await cancelStale(ptok);
  await book(ptok, 'business', 'گیت-ب-بازرگانی');
  check('قاعدهٔ ۳: حوزهٔ انتخاب‌نشده حتی با گیت باز پیشنهاد نمی‌گیرد', !(await offerArrives(A.tok, 'گیت-ب-بازرگانی', [])));
  const pfLocked = await call('PATCH', '/api/translator/fields', { fields: ['tourism', 'pilgrimage', 'medical', 'business', 'legal'] }, A.tok);
  check('قاعدهٔ ۴: همهٔ حوزه‌ها قابل انتخاب‌اند و با گیت باز قفل ندارند', pfLocked.status === 200 && pfLocked.data.locked.length === 0);

  // ---------- قاعدهٔ ۲+۵: خودرو قابلیت جداست؛ بدون خودرو فقط پیاده ----------
  const C = await makeRealTranslator(2, ['tourism'], false);
  await approveFile(adm, C.id);
  await goOnline(C.tok);
  cap = (await call('GET', '/api/translator/capability', null, C.tok)).data;
  check('مترجم پایهٔ بدون خودرو: میز کار باز، خودرو خاموش', cap.status === 'active_general' && cap.dimensions.car.active === false && cap.dimensions.car.registered === false);
  await clearOffers(A.tok, C.tok); await cancelStale(ptok);
  await book(ptok, 'tourism', 'گیت-ج-سواره', { car: true, party: 2 });
  check('قاعدهٔ ۲: رزرو سواره به مترجم بدون خودرو نمی‌رسد', !(await offerArrives(C.tok, 'گیت-ج-سواره', [A.tok])));
  await clearOffers(A.tok, C.tok); await cancelStale(ptok);
  await book(ptok, 'tourism', 'گیت-ج-پیاده');
  check('قاعدهٔ ۵: همان مترجم، درخواست پیاده را می‌بیند', !!(await offerArrives(C.tok, 'گیت-ج-پیاده', [A.tok])));
  // ثبت بعدی خودرو از کارت صلاحیت (قاعدهٔ ۴) — بدون مدل → ۴۰۰
  const badV = await call('PATCH', '/api/translator/vehicle', { car: true }, C.tok);
  check('قاعدهٔ ۲: ثبت خودرو بدون مدل/ظرفیت رد می‌شود', badV.status === 400 && badV.data.error === 'car_details_required', JSON.stringify(badV.data));
  const veh = await call('PATCH', '/api/translator/vehicle', { car: true, car_model: 'پژو ۲۰۷ گیت', car_capacity: 4 }, C.tok);
  check('قاعدهٔ ۲: ثبت خودرو مانع میز کار نیست و گیت خودرو هنوز بسته است', veh.status === 200 && veh.data.car === true && veh.data.car_ready === false, JSON.stringify(veh.data));
  cap = (await call('GET', '/api/translator/capability', null, C.tok)).data;
  check('کارت صلاحیت: خودرو «ثبت‌شده ولی غیرفعال» گزارش می‌شود', cap.dimensions.car.registered === true && cap.dimensions.car.active === false);
  // بیمه + گواهینامه با تاریخ انقضا، تأیید ادمین
  await approveDoc(adm, C.tok, 'car_docs', FUTURE);
  await approveDoc(adm, C.tok, 'licence', FUTURE);
  cap = (await call('GET', '/api/translator/capability', null, C.tok)).data;
  check('قاعدهٔ ۲: با تأیید بیمه+گواهینامه، گیت خودرو باز می‌شود', cap.dimensions.car.active === true);
  await clearOffers(A.tok, C.tok); await cancelStale(ptok);
  await book(ptok, 'tourism', 'گیت-د-سواره', { car: true, party: 2 });
  check('قاعدهٔ ۲: رزرو سواره پس از تأیید مدارک به مترجم می‌رسد', !!(await offerArrives(C.tok, 'گیت-د-سواره', [A.tok])));
  // انقضای مدارک: خودرو خاموش، پیاده روشن (قاعدهٔ ۵)
  await call('POST', '/api/dev/expire-docs', null, C.tok);
  cap = (await call('GET', '/api/translator/capability', null, C.tok)).data;
  check('قاعدهٔ ۲: انقضای مدارک، گیت خودرو را خاموش می‌کند', cap.dimensions.car.active === false);
  await clearOffers(A.tok, C.tok); await cancelStale(ptok);
  await book(ptok, 'tourism', 'گیت-د-بعد-انقضا', { car: true, party: 2 });
  check('قاعدهٔ ۵: با مدارک منقضی، رزرو سواره پنهان است', !(await offerArrives(C.tok, 'گیت-د-بعد-انقضا', [A.tok])));
  await clearOffers(A.tok, C.tok); await cancelStale(ptok);
  await book(ptok, 'tourism', 'گیت-د-پیاده-پایانی');
  check('قاعدهٔ ۵: با مدارک منقضی، درخواست پیاده همچنان می‌رسد', !!(await offerArrives(C.tok, 'گیت-د-پیاده-پایانی', [A.tok])));

  // ---------- مهاجرت دادهٔ قدیمی: general → tourism ----------
  const M = await makeRealTranslator(3, ['general'], false);
  check('مهاجرت: مقادیر قدیمی general به tourism نگاشت می‌شود', JSON.stringify(M.fields) === '["tourism"]', JSON.stringify(M.fields));

  console.log(failed ? `\nRESULT: FAILED (${failed}/${passed + failed})` : `\nRESULT: PASS (${passed}/${passed})`);
  process.exit(failed ? 1 : 0);
}

main().catch((e) => { console.error('HARNESS ERROR', e && e.message ? e.message : e); process.exit(2); });
