'use strict';
/* تست خط زمانی رزرو (reservation_events — آیتم ۴):
 * چرخهٔ کامل نقدی تا تسویه باید رشتهٔ رویداد ترتیبی درست بسازد؛ رویدادهای ادمین
 * (تسویهٔ دستی، حل اختلاف، رفع قفل کد) هم باید ثبت شوند؛ endpoint فقط برای ادمین است.
 * اجرا مثل api.test.js:
 *   HZ_DEV=1 HZ_ADMIN_PASSWORD=test-admin-pass HZ_DB=/tmp/hz_ev.sqlite PORT=8082 node server.js
 *   BASE=http://127.0.0.1:8082 node test/reservation_events.test.js
 */
const BASE = process.env.BASE || 'http://127.0.0.1:8082';
let passed = 0, failed = 0;
function check(name, ok, extra = '') {
  if (ok) { passed++; console.log('  ok   ' + name); }
  else { failed++; console.log('  FAIL ' + name + (extra ? '  [' + extra + ']' : '')); }
}
async function call(method, p, body, token) {
  const headers = { 'Content-Type': 'application/json' };
  if (token) headers.Authorization = 'Bearer ' + token;
  const r = await fetch(BASE + p, { method, headers, body: body ? JSON.stringify(body) : undefined });
  let data = null; try { data = await r.json(); } catch (e) { /* non-json */ }
  return { status: r.status, data };
}
const phoneFor = (n) => '915' + String(3000000 + n).slice(-7);

async function makeTraveler(n) {
  const phone = phoneFor(n);
  await call('POST', '/api/auth/request-code', { phone, role: 'traveler' });
  const v = await call('POST', '/api/auth/verify', { phone, role: 'traveler', code: '123456' });
  return v.data.token;
}
async function makeTranslator(n) {
  const phone = phoneFor(n);
  await call('POST', '/api/auth/request-code', { phone, role: 'translator' });
  const v = await call('POST', '/api/auth/verify', { phone, role: 'translator', code: '123456' });
  await call('POST', '/api/dev/approve-translator', null, v.data.token);
  return v.data.token;
}
async function getOffer(ttok, bid) {
  for (let i = 0; i < 6; i++) {
    const o = await call('GET', '/api/translator/offers', null, ttok);
    const off = (o.data.offers || []).find((x) => x.reservation_id === bid);
    if (off) return off;
    for (const x of (o.data.offers || []).filter((x) => x.reservation_id === bid)) await call('POST', `/api/translator/offers/${x.id}/decline`, null, ttok);
    await new Promise((r) => setTimeout(r, 1000));
  }
  return null;
}
async function cashFlow(ptok, ttok, place) {
  await call('PATCH', '/api/translator/online', { online: true }, ttok);
  const b = await call('POST', '/api/traveler/bookings', { kind: 'instant', origin_lang: 'fa', dest_lang: 'en', place, hours: 2 }, ptok);
  const bid = b.data.id;
  const off = await getOffer(ttok, bid);
  if (!off) return { bid, ok: false };
  await call('POST', `/api/translator/offers/${off.id}/accept`, null, ttok);
  const bk = (await call('GET', '/api/traveler/bookings', null, ptok)).data.bookings.find((x) => x.id === bid);
  await call('POST', `/api/translator/missions/${bid}/arrive`, null, ttok);
  await call('POST', `/api/translator/missions/${bid}/verify-code`, { code: bk.service_code }, ttok);
  await call('POST', `/api/traveler/bookings/${bid}/finish`, null, ptok);
  await call('POST', `/api/traveler/bookings/${bid}/payment`, { method: 'cash' }, ptok);
  return { bid, ok: true };
}
const names = (ev) => ev.map((e) => e.event);
const indexOfEvent = (ev, name) => ev.findIndex((e) => e.event === name);

(async () => {
  // --- گیت احراز
  const noAuth = await call('GET', '/api/admin/reservations/1/events');
  check('بدون توکن ادمین ۴۰۱', noAuth.status === 401, 'status=' + noAuth.status);
  const ptok = await makeTraveler(1);
  const ttok = await makeTranslator(1);
  const travTok = await call('GET', '/api/traveler/bookings', null, ptok);
  check('مسافر و مترجم آماده', travTok.status === 200);
  const notFound = await call('GET', '/api/admin/reservations/999999/events');
  check('بدون توکن هم ۴۰۱ مقدم بر ۴۰۴ است', notFound.status === 401);

  const adm = (await call('POST', '/api/admin/login', { password: process.env.ADMIN_PASSWORD || 'test-admin-pass' })).data.token;
  const nf = await call('GET', '/api/admin/reservations/999999/events', null, adm);
  check('رزرو ناموجود ۴۰۴', nf.status === 404, 'status=' + nf.status);

  // --- چرخهٔ کامل نقدی
  const f = await cashFlow(ptok, ttok, 'میدان آزادی - خط زمانی');
  check('چرخهٔ نقدی تا awaiting_cash کامل شد', f.ok && !!f.bid);
  const bid = f.bid;
  const bk = (await call('GET', '/api/traveler/bookings', null, ptok)).data.bookings.find((x) => x.id === bid);

  // --- تسویهٔ دستی ادمین → رویداد manual_settled
  const ms = await call('POST', `/api/admin/reservations/${bid}/settle`, { note: 'تأیید تلفنی' }, adm);
  check('تسویهٔ دستی انجام شد', ms.status === 200, JSON.stringify(ms.data));

  const ev = (await call('GET', `/api/admin/reservations/${bid}/events`, null, adm)).data.events;
  const ns = names(ev);
  check('created ثبت شده', ns.includes('created'));
  check('matched ثبت شده', ns.includes('matched'));
  check('service_started ثبت شده', ns.includes('service_started'));
  check('finished ثبت شده با عامل مسافر', ns.includes('finished') && ev[indexOfEvent(ev, 'finished')].actor === 'traveler');
  check('payment_selected با نقدی', ns.includes('payment_selected') && ev[indexOfEvent(ev, 'payment_selected')].detail.method === 'cash');
  check('manual_settled با یادداشت', ns.includes('manual_settled') && (ev[indexOfEvent(ev, 'manual_settled')].detail.note || '').includes('تأیید تلفنی'));
  const iCreated = indexOfEvent(ev, 'created'), iMatched = indexOfEvent(ev, 'matched'),
    iStarted = indexOfEvent(ev, 'service_started'), iFinished = indexOfEvent(ev, 'finished'),
    iPay = indexOfEvent(ev, 'payment_selected'), iMs = indexOfEvent(ev, 'manual_settled');
  check('ترتیب رویدادها درست است', iCreated < iMatched && iMatched < iStarted && iStarted < iFinished && iFinished < iPay && iPay < iMs,
    JSON.stringify(ns));
  check('created جزئیات نوع و مبلغ دارد', ev[iCreated].detail.kind === 'instant' && Number.isFinite(ev[iCreated].detail.total));
  check('actorهای معتبر', ev.every((e) => ['traveler', 'translator', 'admin', 'system'].includes(e.actor)), JSON.stringify([...new Set(ev.map((e) => e.actor))]));
  check('created_at صعودی', ev.every((e, i) => i === 0 || e.created_at >= ev[i - 1].created_at));

  // --- چرخهٔ دوم: تسویهٔ دوطرفهٔ واقعی — پرداخت نقدی مسافر (awaiting_cash) سپس تأیید مترجم
  const ptok2 = await makeTraveler(2);
  const f2 = await cashFlow(ptok2, ttok, 'تأیید نقدی دوطرفه');
  check('چرخهٔ دوم تا awaiting_cash کامل شد', f2.ok);
  const cc = await call('POST', `/api/translator/missions/${f2.bid}/cash-confirm`, null, ttok);
  check('تأیید نقدی مترجم → تسویهٔ دوطرفه', cc.status === 200 && cc.data.settled === true, JSON.stringify(cc.data));
  const ev2 = (await call('GET', `/api/admin/reservations/${f2.bid}/events`, null, adm)).data.events;
  const ns2 = names(ev2);
  check('cash_confirmed با عامل مترجم', ns2.includes('cash_confirmed') && ev2[indexOfEvent(ev2, 'cash_confirmed')].actor === 'translator');
  check('settled ثبت شده', ns2.includes('settled'));

  // --- چرخهٔ سوم: اختلاف و استرداد به مسافر (تصمیم refund)
  const ptok3 = await makeTraveler(3);
  const f3 = await cashFlow(ptok3, ttok, 'میدان آزادی - اختلاف');
  check('چرخهٔ اختلاف کامل شد', f3.ok);
  await call('POST', `/api/traveler/bookings/${f3.bid}/dispute`, null, ptok3);
  const resRefund = await call('POST', `/api/admin/disputes/${f3.bid}/resolve`, { decision: 'refund', note: 'استرداد وجه' }, adm);
  check('حل اختلاف (استرداد)', resRefund.status === 200 && resRefund.data.pay_state === 'refunded');
  const ev3d = (await call('GET', `/api/admin/reservations/${f3.bid}/events`, null, adm)).data.events;
  const ns3 = names(ev3d);
  check('disputed با عامل مسافر', ns3.includes('disputed') && ev3d[indexOfEvent(ev3d, 'disputed')].actor === 'traveler');
  check('dispute_resolved با تصمیم refund', ns3.includes('dispute_resolved') && ev3d[indexOfEvent(ev3d, 'dispute_resolved')].detail.decision === 'refund');

  // --- رفع قفل کد خدمت (چرخهٔ چهارم): رسیدن → ۵ کد غلط → قفل → رفع قفل → لغو مترجم (خدمت شروع نشده)
  const ptok4 = await makeTraveler(4);
  const b3 = await call('POST', '/api/traveler/bookings', { kind: 'instant', origin_lang: 'fa', dest_lang: 'en', place: 'قفل کد', hours: 1 }, ptok4);
  const bid3 = b3.data.id;
  const off3 = await getOffer(ttok, bid3);
  await call('POST', `/api/translator/offers/${off3.id}/accept`, null, ttok);
  await call('POST', `/api/translator/missions/${bid3}/arrive`, null, ttok);
  for (let i = 0; i < 5; i++) await call('POST', `/api/translator/missions/${bid3}/verify-code`, { code: '00000' }, ttok);
  const lockedResp = await call('POST', `/api/translator/missions/${bid3}/verify-code`, { code: '12345' }, ttok);
  check('کد بعد از ۵ تلاش قفل شد (۴۲۳)', lockedResp.status === 423 && lockedResp.data.error === 'code_locked',
    'status=' + lockedResp.status + ' body=' + JSON.stringify(lockedResp.data));
  const unl = await call('POST', `/api/admin/reservations/${bid3}/unlock-service-code`, {}, adm);
  check('رفع قفل انجام شد', unl.status === 200);
  const ev3 = (await call('GET', `/api/admin/reservations/${bid3}/events`, null, adm)).data.events;
  check('service_code_unlocked ثبت شده', names(ev3).includes('service_code_unlocked'));

  // --- لغو مترجم بدون شروع خدمت (بعد از رفع قفل)
  const tc = await call('POST', `/api/translator/missions/${bid3}/cancel`, null, ttok);
  check('لغو مترجم قبل از شروع خدمت ممکن است', tc.status === 200, JSON.stringify(tc.data));
  const ev3b = (await call('GET', `/api/admin/reservations/${bid3}/events`, null, adm)).data.events;
  check('translator_cancelled ثبت شده', names(ev3b).includes('translator_cancelled'));

  const ptok5 = await makeTraveler(5);
  const b4 = await call('POST', '/api/traveler/bookings', { kind: 'instant', origin_lang: 'fa', dest_lang: 'en', place: 'لغو مسافر', hours: 1 }, ptok5);
  await call('POST', `/api/traveler/bookings/${b4.data.id}/cancel`, null, ptok5);
  const ev4 = (await call('GET', `/api/admin/reservations/${b4.data.id}/events`, null, adm)).data.events;
  const ns4 = names(ev4);
  check('لغو رایگان قبل از تطبیق با جریمهٔ صفر', ns4.includes('cancelled') && ev4[indexOfEvent(ev4, 'cancelled')].detail.fee_percent === 0);

  console.log(`\nنتیجه: ${passed} پاس، ${failed} خطا`);
  process.exit(failed ? 1 : 0);
})().catch((e) => { console.error('اجرای تست شکست خورد:', e); process.exit(1); });
