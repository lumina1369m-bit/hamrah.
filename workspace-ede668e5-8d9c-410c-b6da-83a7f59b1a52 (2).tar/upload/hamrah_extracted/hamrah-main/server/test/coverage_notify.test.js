'use strict';
/* تست پوشش سرویس (جیوفنس شهرها) و اعلان دستی به مترجم.
 * اجرا: BASE=http://127.0.0.1:8081 node test/coverage_notify.test.js
 * قراردادها:
 *  - رزرو با مختصاتِ داخل دایرهٔ شهر دیگر → شهر مسئول با هندسه عوض می‌شود (رویداد city_geofenced).
 *  - رزرو با مختصات بیرون از همهٔ دایره‌ها → رویداد outside_coverage و دیده‌شدن در /admin/coverage.
 *  - اعلان دستی کارشناس (kind=custom) در اعلان‌های مترجم با همان متن ظاهر می‌شود.
 */
const path = require('path');
const BASE = process.env.BASE || 'http://127.0.0.1:8081';
const PASSWORD = process.env.HZ_ADMIN_PASSWORD || 'test-admin-pass';

let pass = 0, fail = 0;
function check(name, ok, extra) {
  if (ok) { pass++; console.log('  ok   ' + name); }
  else { fail++; console.log('  FAIL ' + name + (extra ? ' — ' + JSON.stringify(extra).slice(0, 300) : '')); }
}
async function call(method, p, body, token) {
  const h = { 'Content-Type': 'application/json' };
  if (token) h.Authorization = 'Bearer ' + token;
  const r = await fetch(BASE + p, { method, headers: h, body: body == null ? undefined : JSON.stringify(body) });
  let d = {}; try { d = await r.json(); } catch (e) {}
  return { status: r.status, data: d };
}
async function makeUser(role, fields) {
  const phone = '9' + String(Math.floor(Math.random() * 1e9)).padStart(9, '0');
  await call('POST', '/api/auth/request-code', { phone, role });
  const v = await call('POST', '/api/auth/verify', { phone, role, code: '123456' });
  if (fields && fields.translator) {
    await call('POST', '/api/translator/registration', Object.assign({
      nda: true, charter: true, gender: 'female', first_name: 'آزمون', last_name: 'پوشش',
      languages: ['fa', 'ar'], fields: ['general'],
    }, fields.translator), v.data.token);
  }
  return { phone, token: v.data.token, id: v.data.user.id };
}

(async () => {
  const adm = await call('POST', '/api/admin/login', { password: PASSWORD });
  check('ورود مدیر', adm.status === 200 && adm.data.token);
  const atok = adm.data.token;

  const cities = await call('GET', '/api/admin/cities', null, atok);
  const mashhad = (cities.data.cities || []).find((c) => c.name_fa === 'مشهد');
  const tehran = (cities.data.cities || []).find((c) => c.name_fa === 'تهران');
  check('شهرهای نمونه (تهران و مشهد) موجودند', !!(mashhad && tehran), cities.data.cities);

  // ۱) رزرو با مختصات داخل مشهد ولی شهرِ صریح تهران → هندسه برنده است
  const t1 = await makeUser('traveler');
  const b1 = await call('POST', '/api/traveler/bookings', {
    kind: 'instant', origin_lang: 'ar', dest_lang: 'fa', place: 'حرم مطهر', city_id: tehran.id,
    lat: 36.2880, lng: 59.6157,
  }, t1.token);
  check('رزرو با مختصات مشهد ساخته شد', b1.status === 201, b1.data);
  const ev1 = await call('GET', '/api/admin/reservations/' + b1.data.id + '/events', null, atok);
  const geo = (ev1.data.events || []).find((e) => e.event === 'city_geofenced');
  check('رویداد city_geofenced ثبت شد و شهر به مشهد رفت', !!geo && geo.detail.to === mashhad.id && geo.detail.from === tehran.id, ev1.data.events);
  check('city_id رزرو واقعاً مشهد شد', b1.data && ev1.status === 200);

  // ۲) رزرو بیرون از همهٔ پوشش‌ها (نقطهٔ کویری بین شهرها) → outside_coverage
  const t2 = await makeUser('traveler');
  const b2 = await call('POST', '/api/traveler/bookings', {
    kind: 'instant', origin_lang: 'ar', dest_lang: 'fa', place: 'میان‌راه کویری', lat: 30.7, lng: 55.9,
  }, t2.token);
  check('رزرو بیرون از پوشش ساخته شد (شهر پیش‌فرض)', b2.status === 201, b2.data);
  const ev2 = await call('GET', '/api/admin/reservations/' + b2.data.id + '/events', null, atok);
  check('رویداد outside_coverage ثبت شد', !!(ev2.data.events || []).find((e) => e.event === 'outside_coverage'), ev2.data.events);
  const cov = await call('GET', '/api/admin/coverage', null, atok);
  check('رزرو بیرون از پوشش در گزارش پوشش هست', (cov.data.outside || []).some((o) => o.id === b2.data.id), cov.data);

  // ۳) اعلان دستی به مترجم
  const tr = await makeUser('translator', { translator: {} });
  const reg = await call('GET', '/api/translator/status', null, tr.token);
  const n = await call('POST', '/api/admin/translators/' + tr.id + '/notify', { text: 'لطفاً مدارک را تا فردا کامل کنید.' }, atok);
  check('اعلان دستی ثبت شد', n.status === 200, n.data);
  const notif = await call('GET', '/api/translator/notifications', null, tr.token);
  const custom = (notif.data.notifications || []).find((x) => x.kind === 'custom');
  check('مترجم پیام سفارشی را با همان متن دید', !!custom && custom.text.indexOf('تا فردا') >= 0, notif.data.notifications);
  const nBad = await call('POST', '/api/admin/translators/' + tr.id + '/notify', {}, atok);
  check('اعلان بدون متن ۴۰۰ می‌دهد', nBad.status === 400 && nBad.data.error === 'text_required');

  console.log('RESULT:', fail ? 'FAIL' : 'PASS', `(${pass}/${pass + fail})`);
  process.exit(fail ? 1 : 0);
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
