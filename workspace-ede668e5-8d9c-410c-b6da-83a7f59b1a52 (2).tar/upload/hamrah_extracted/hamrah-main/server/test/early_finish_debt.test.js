'use strict';
/* تست صورت‌حساب پایان زودهنگام + بدهی نقدی + گیت‌های نو:
 * ۱) پایان زودهنگام از هر طرف: مبلغ = سقف(ساعات خدمت واقعی) با کف ۱ ساعت؛ مبلغ اولیه در list_total می‌ماند.
 * ۲) اضافه‌خدمت: هر ساعت شروع‌شده اضافه محاسبه می‌شود.
 * ۳) بدهی نقدی: تسویهٔ نقدی → سهم پلتفرم بدهی می‌شود → تا تسویه پیشنهاد جدید نمی‌رسد → ثبت پرداخت ادمین بازش می‌کند.
 * ۴) dev-approve انتخاب حوزه‌های مترجم را نمی‌کوبد و گیت تخصص را خودجوش باز نمی‌کند (باگ گزارش کاربر).
 * ۵) PATCH پروفایل (جنسیت/شهر) + موقعیت مکانی اختیاری + نقشهٔ ادمین + گیت شعاع موقعیت.
 * اجرا: BASE=http://127.0.0.1:8081 node test/early_finish_debt.test.js
 */
const BASE = process.env.BASE || 'http://127.0.0.1:8081';
let passed = 0, failed = 0;
function check(name, ok, extra = '') {
  if (ok) { passed++; console.log('  ok   ' + name); }
  else { failed++; console.log('  FAIL ' + name + (extra ? '  [' + extra + ']' : '')); }
}
async function call(method, p, body, token) {
  const headers = { 'Content-Type': 'application/json' };
  if (token) headers.Authorization = 'Bearer ' + token;
  const r = await fetch(BASE + p, { method, headers, body: body ? JSON.stringify(body) : undefined });
  let data = null; try { data = await r.json(); } catch (e) { /* non-json */ }
  return { status: r.status, data };
}
const PNG = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==';

async function login(phone, role) {
  await call('POST', '/api/auth/request-code', { phone, role });
  const v = await call('POST', '/api/auth/verify', { phone, role, code: '123456' });
  return v.data.token;
}
async function makeRealTranslator(n, fields, car) {
  const tok = await login('917' + String(4000000 + n * 7 + Math.floor(Math.random() * 900)).slice(-7), 'translator');
  const reg = { nda: true, charter: true, gender: 'male', first_name: 'بدهی' + n, last_name: 'تست', city: 'تهران',
    languages: ['ar', 'fa'], fields, car: car === true };
  if (car) { reg.car_model = 'سمند ' + n; reg.car_capacity = 4; }
  const r = await call('POST', '/api/translator/registration', reg, tok);
  if (r.status !== 200) throw new Error('registration failed: ' + JSON.stringify(r.data));
  const me = await call('GET', '/api/auth/me', null, tok);
  return { tok, id: me.data.id };
}
async function approveFile(adm, id) {
  await call('POST', `/api/admin/translators/${id}/decision`, { decision: 'approve' }, adm);
  await call('POST', `/api/admin/translators/${id}/interview`, { result: 'pass' }, adm);
}
async function goOnline(tok) { await call('PATCH', '/api/translator/online', { online: true }, tok); }
async function clearOffers(...toks) {
  for (const tok of toks) {
    const offs = (await call('GET', '/api/translator/offers', null, tok)).data.offers || [];
    for (const o of offs) await call('POST', `/api/translator/offers/${o.id}/decline`, null, tok);
  }
}
async function cancelStale(ptok) {
  const bks = (await call('GET', '/api/traveler/bookings', null, ptok)).data.bookings || [];
  for (const b of bks.filter((x) => ['searching', 'waiting_schedule', 'matching', 'unmatched_ask', 'no_match'].includes(x.status))) {
    await call('POST', `/api/traveler/bookings/${b.id}/cancel`, null, ptok);
  }
}
async function book(ptok, place, extra) {
  const r = await call('POST', '/api/traveler/bookings', Object.assign(
    { kind: 'instant', origin_lang: 'ar', dest_lang: 'fa', field: 'tourism', place, traveler_name: 'مسافر صورت‌حساب' }, extra || {}), ptok);
  if (r.status !== 200 && r.status !== 201) throw new Error('booking failed: ' + JSON.stringify(r.data));
  return r.data;
}
// گردش کامل: پیشنهاد → پذیرش → رسیدن مترجم → شروع خدمت با کد امنیتی مسافر
async function fullCycle(ptok, ttok, place, extra) {
  await clearOffers(ttok); await cancelStale(ptok);
  const bk = await book(ptok, place, extra);
  let offer = null;
  for (let i = 0; i < 5 && !offer; i++) {
    const offs = (await call('GET', '/api/translator/offers', null, ttok)).data.offers || [];
    offer = offs.find((x) => x.place === place) || null;
    if (!offer) await new Promise((res) => setTimeout(res, 700));
  }
  if (!offer) throw new Error('offer did not arrive for ' + place);
  const acc = await call('POST', `/api/translator/offers/${offer.id}/accept`, null, ttok);
  if (acc.status !== 200) throw new Error('accept failed: ' + JSON.stringify(acc.data));
  const fresh = (await call('GET', '/api/traveler/bookings', null, ptok)).data.bookings.find((x) => x.id === bk.id);
  if (!fresh || !fresh.service_code) throw new Error('service code not visible to traveler');
  const arr = await call('POST', `/api/translator/missions/${bk.id}/arrive`, null, ttok);
  if (arr.status !== 200) throw new Error('arrive failed: ' + JSON.stringify(arr.data));
  const start = await call('POST', `/api/translator/missions/${bk.id}/verify-code`, { code: fresh.service_code }, ttok);
  if (start.status !== 200) throw new Error('service start failed: ' + JSON.stringify(start.data));
  return bk;
}

async function main() {
  console.log('== صورت‌حساب پایان زودهنگام + بدهی نقدی');
  const adm = (await call('POST', '/api/admin/login', { password: process.env.HZ_ADMIN_PASSWORD || 'test-admin-pass' })).data.token;
  await call('POST', '/api/dev/offline-all', null, adm);
  const ptok = await login('918' + String(5000000 + Math.floor(Math.random() * 999999)).slice(-7), 'traveler');

  // ---------- ۱) پایان زودهنگام از سمت مترجم: کف یک ساعت ----------
  const T1 = await makeRealTranslator(1, ['tourism', 'pilgrimage'], false);
  await approveFile(adm, T1.id); await goOnline(T1.tok);
  let bk = await fullCycle(ptok, T1.tok, 'صورتحساب-کف-یک-ساعت', { hours: 2 });
  const origTotal = bk.total;
  const fin = await call('POST', `/api/translator/missions/${bk.id}/finish`, null, T1.tok);
  check('درخواست پایان مترجم ثبت می‌شود', fin.status === 202, JSON.stringify(fin.data));
  const ap = await call('POST', `/api/traveler/bookings/${bk.id}/finish-approve`, null, ptok);
  check('مسافر پایان را تأیید می‌کند', ap.status === 200, JSON.stringify(ap.data));
  check('خدمت چند‌ثانیه‌ای: کف یک ساعت صورتحساب می‌شود', ap.data.billed_hours === 1, JSON.stringify(ap.data));
  check('مبلغ تعدیل‌شده = مبلغ یک ساعت', ap.data.total < origTotal && ap.data.price_adjusted === true,
    `orig=${origTotal} new=${ap.data.total}`);
  const fresh1 = (await call('GET', '/api/traveler/bookings', null, ptok)).data.bookings.find((x) => x.id === bk.id);
  check('مبلغ اولیه در list_total حفظ شده', fresh1 && fresh1.list_total === origTotal, JSON.stringify(fresh1 && { lt: fresh1.list_total, t: fresh1.total }));
  // تسویهٔ نقدیِ همین رزرو → بدهی (بخش ۳ هم از همین رزرو استفاده می‌کند)
  const payCash = await call('POST', `/api/traveler/bookings/${bk.id}/payment`, { method: 'cash' }, ptok);
  check('پرداخت نقدی انتخاب می‌شود', payCash.status === 200, JSON.stringify(payCash.data));
  const cconf = await call('POST', `/api/translator/missions/${bk.id}/cash-confirm`, null, T1.tok);
  check('مترجم دریافت نقدی را تأیید می‌کند', cconf.status === 200 && cconf.data.settled === true, JSON.stringify(cconf.data));

  // ---------- ۲) بدهی نقدی: قفل پیشنهاد تا تسویه ----------
  const pay = (await call('GET', '/api/translator/payments', null, T1.tok)).data;
  check('بدهی سهم پلتفرم ثبت شده', pay.debt && pay.debt.amount > 0 && pay.debt.blocked === true, JSON.stringify(pay.debt));
  bk = await book(ptok, 'صورتحساب-بدهی-قفل');
  await new Promise((res) => setTimeout(res, 1200));
  const offsAfterDebt = (await call('GET', '/api/translator/offers', null, T1.tok)).data.offers || [];
  check('مترجم بدهکار پیشنهاد جدید نمی‌گیرد', !offsAfterDebt.some((x) => x.place === 'صورتحساب-بدهی-قفل'));
  await call('POST', `/api/traveler/bookings/${bk.id}/cancel`, null, ptok);
  const debts = (await call('GET', '/api/admin/debts', null, adm)).data;
  const row = (debts.debts || []).find((d) => d.id === T1.id);
  check('صف بدهی ادمین مترجم را نشان می‌دهد', !!row && row.debt === pay.debt.amount, JSON.stringify(row));
  const p1 = await call('POST', `/api/admin/debts/${T1.id}/pay`, { amount: row.debt, note: 'تسویهٔ کامل' }, adm);
  check('ثبت پرداخت بدهی از پنل', p1.status === 200 && p1.data.remaining === 0, JSON.stringify(p1.data));
  const pay2 = (await call('GET', '/api/translator/payments', null, T1.tok)).data;
  check('پس از تسویه، گیت بدهی باز می‌شود', pay2.debt.amount === 0 && pay2.debt.blocked === false, JSON.stringify(pay2.debt));
  bk = await book(ptok, 'صورتحساب-بدهی-باز');
  let offsBack = [];
  for (let i = 0; i < 5 && !offsBack.length; i++) {
    offsBack = (await call('GET', '/api/translator/offers', null, T1.tok)).data.offers || [];
    if (!offsBack.length) await new Promise((res) => setTimeout(res, 700));
  }
  check('مترجم تسویه‌شده دوباره پیشنهاد می‌گیرد', offsBack.some((x) => x.place === 'صورتحساب-بدهی-باز'));
  await call('POST', `/api/traveler/bookings/${bk.id}/cancel`, null, ptok);

  // ---------- ۳) اضافه‌خدمت: هر ساعت شروع‌شده کامل ----------
  bk = await fullCycle(ptok, T1.tok, 'صورتحساب-اضافه-خدمت', { hours: 2 });
  const orig2 = bk.total;
  await call('POST', '/api/dev/shift-service-start', { reservation_id: bk.id, minutes_ago: 132 }, ptok); // ۲:۱۲ خدمت
  await call('POST', `/api/traveler/bookings/${bk.id}/finish`, null, ptok);
  const done2 = (await call('GET', '/api/traveler/bookings', null, ptok)).data.bookings.find((x) => x.id === bk.id);
  check('اضافه‌خدمت ۲:۱۲ → سه ساعت صورتحساب', done2.total > orig2, `orig=${orig2} new=${done2.total}`);
  check('list_total اضافه‌خدمت = مبلغ اولیه', done2.list_total === orig2, JSON.stringify(done2.list_total));

  // ---------- ۴) پایان زودهنگام از سمت مسافر ----------
  bk = await fullCycle(ptok, T1.tok, 'صورتحساب-مسافر-پایان', { hours: 4 });
  const orig4 = bk.total;
  await call('POST', '/api/dev/shift-service-start', { reservation_id: bk.id, minutes_ago: 18 }, ptok);
  const tf = await call('POST', `/api/traveler/bookings/${bk.id}/finish`, null, ptok);
  check('پایان خودِ مسافر: کف یک ساعت، نه مبلغ کامل ۴ ساعته', tf.data.billed_hours === 1 && tf.data.total < orig4, JSON.stringify(tf.data));

  // ---------- ۵) dev-approve انتخاب مترجم را نمی‌کوبد (باگ گزارش کاربر) ----------
  const T2 = await makeRealTranslator(2, ['tourism', 'pilgrimage'], false);
  const da = await call('POST', '/api/dev/approve-translator', null, T2.tok);
  check('تأیید توسعه‌ای وارد میز کار می‌کند', da.status === 200 && String(da.data.status).indexOf('active_') === 0, JSON.stringify(da.data));
  let cap = (await call('GET', '/api/translator/capability', null, T2.tok)).data;
  check('انتخاب فقط-پایه حفظ شده (همه‌چیز فعال نمی‌شود)',
    cap.ladder.fields.filter((f) => f.selected).map((f) => f.code).join() === 'tourism,pilgrimage' &&
    cap.dimensions.specialized.ok === false, JSON.stringify(cap.ladder.fields));
  const T3 = await makeRealTranslator(3, ['tourism'], false);
  await call('POST', '/api/dev/approve-translator', { fields: ['medical', 'business'], lang_cert: true }, T3.tok);
  cap = (await call('GET', '/api/translator/capability', null, T3.tok)).data;
  check('با آرگومان صریح، فیلدها بازنویسی و گیت تخصص باز می‌شود',
    cap.ladder.fields.filter((f) => f.selected).map((f) => f.code).join() === 'medical,business' &&
    cap.dimensions.specialized.ok === true, JSON.stringify({ f: cap.ladder.fields, s: cap.dimensions.specialized }));

  // ---------- ۶) پروفایل + موقعیت مکانی + گیت شعاع ----------
  const badG = await call('PATCH', '/api/translator/profile', { gender: 'other' }, T2.tok);
  check('جنسیت نامعتبر رد می‌شود', badG.status === 400, JSON.stringify(badG.data));
  const badC = await call('PATCH', '/api/translator/profile', { city_id: 9999 }, T2.tok);
  check('شهر نامعتبر رد می‌شود', badC.status === 400, JSON.stringify(badC.data));
  const okP = await call('PATCH', '/api/translator/profile', { gender: 'male', city_id: 1 }, T2.tok);
  check('پروفایل معتبر ذخیره می‌شود', okP.status === 200, JSON.stringify(okP.data));
  const prof = (await call('GET', '/api/translator/profile', null, T2.tok)).data;
  check('پروفایل خوانده می‌شود (جنسیت/شهر/زبان)', prof.gender === 'male' && prof.city_id === 1 && (prof.langs || []).length >= 1, JSON.stringify(prof));

  // موقعیت دور (خارج شعاع تهران) → پیشنهاد نمی‌رسد؛ نزدیک → می‌رسد
  // (T1 آنلاین خاموش می‌شود تا تنها نامزدِ استخر T2 باشد و پیشنهاد دزدیده نشود)
  await call('PATCH', '/api/translator/online', { online: false }, T1.tok);
  const locFar = await call('POST', '/api/translator/location', { lat: 34.0, lng: 51.4, sharing: true }, T2.tok);
  check('ثبت موقعیت اختیاری ممکن است', locFar.status === 200, JSON.stringify(locFar.data));
  await goOnline(T2.tok);
  let bkFar = await book(ptok, 'موقعیت-دور-شعاع', { lat: 35.6892, lng: 51.389 });
  await new Promise((res) => setTimeout(res, 1200));
  let off = (await call('GET', '/api/translator/offers', null, T2.tok)).data.offers || [];
  check('مترجم خارج از شعاع پیشنهاد نمی‌گیرد', !off.some((x) => x.place === 'موقعیت-دور-شعاع'));
  await call('POST', `/api/traveler/bookings/${bkFar.id}/cancel`, null, ptok);
  await call('POST', '/api/translator/location', { lat: 35.72, lng: 51.39, sharing: true }, T2.tok);
  bkFar = await book(ptok, 'موقعیت-نزدیک-شعاع', { lat: 35.6892, lng: 51.389 });
  off = [];
  for (let i = 0; i < 5 && !off.length; i++) {
    off = (await call('GET', '/api/translator/offers', null, T2.tok)).data.offers || [];
    if (!off.length) await new Promise((res) => setTimeout(res, 700));
  }
  check('مترجم داخل شعاع پیشنهاد می‌گیرد', off.some((x) => x.place === 'موقعیت-نزدیک-شعاع'));
  await call('POST', `/api/traveler/bookings/${bkFar.id}/cancel`, null, ptok);
  const mapR = await call('GET', '/api/admin/map', null, adm);
  check('نقشهٔ ادمین شهرها + مترجمان دارای موقعیت را می‌دهد',
    mapR.status === 200 && (mapR.data.cities || []).length >= 1 && (mapR.data.translators || []).some((t) => t.id === T2.id), JSON.stringify(mapR.data && { t: (mapR.data.translators || []).length }));

  console.log(`\nنتیجه: ${passed} سبز / ${failed} سرخ`);
  process.exit(failed ? 1 : 0);
}

main().catch((e) => { console.error('CRASH:', e); process.exit(1); });
