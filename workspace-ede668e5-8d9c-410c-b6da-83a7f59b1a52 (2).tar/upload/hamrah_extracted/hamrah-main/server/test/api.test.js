'use strict';
/* تست API سرور همراه. قبل از اجرا سرور را با حالت توسعه و پایگاه داده‌ی تازه بالا بیاورید:
 *   HZ_DEV=1 HZ_DB=/tmp/hz_api_test.sqlite PORT=8081 node server.js
 *   BASE=http://127.0.0.1:8081 node test/api.test.js
 */
const BASE = process.env.BASE || 'http://127.0.0.1:8081';
let passed = 0, failed = 0;
function check(name, ok, extra = '') {
  if (ok) { passed++; console.log('  ok   ' + name); }
  else { failed++; console.log('  FAIL ' + name + (extra ? '  [' + extra + ']' : '')); }
}
async function call(method, p, body, token, authHeader = 'Authorization') {
  const headers = { 'Content-Type': 'application/json' };
  if (token) headers[authHeader] = authHeader === 'Authorization' ? 'Bearer ' + token : token;
  const r = await fetch(BASE + p, { method, headers, body: body ? JSON.stringify(body) : undefined });
  let data = null; try { data = await r.json(); } catch (e) { /* non-json */ }
  return { status: r.status, data };
}
const phoneFor = (n) => '912' + String(1000000 + n).slice(-7);


async function makeTranslator(n) {
  const phone = phoneFor(n);
  await call('POST', '/api/auth/request-code', { phone, role: 'translator' });
  const v = await call('POST', '/api/auth/verify', { phone, role: 'translator', code: '123456' });
  const token = v.data.token;
  // با گیت‌های واقعی CAP، دامنه و باز بودن گیت تخصص باید صریح درخواست شود (خودجوش دیگر وجود ندارد)
  await call('POST', '/api/dev/approve-translator', { fields: ['tourism', 'pilgrimage', 'medical', 'business', 'legal'], lang_cert: true }, token);
  return token;
}

// با توازن بار پیشنهادها (یافتهٔ ۱۲) ممکن است پیشنهاد ابتدا به مترجم واجد شرط دیگری برسد؛
// برای آزمون ترجیحِ مترجم هدف، پیشنهادهای دیگران برای همان رزرو رد می‌شود تا نوبت هدف برسد.
async function offerFor(target, place, others) {
  let o = (await call('GET', '/api/translator/offers', null, target)).data.offers.find((x) => x.place === place);
  for (let i = 0; !o && i < 3 && others.length; i++) {
    for (const t of others) {
      const oo = (await call('GET', '/api/translator/offers', null, t)).data.offers.find((x) => x.place === place);
      if (oo) await call('POST', `/api/translator/offers/${oo.id}/decline`, null, t);
    }
    o = (await call('GET', '/api/translator/offers', null, target)).data.offers.find((x) => x.place === place);
  }
  return o;
}

// شروع خدمت با کد امنیتی‌ای که سرور برای همان رزرو صادر کرده است
async function startService(bid, ttok, ptok) {
  const bk = (await call('GET', '/api/traveler/bookings', null, ptok)).data.bookings.find((b) => b.id === bid);
  const arrived = await call('POST', `/api/translator/missions/${bid}/arrive`, null, ttok);
  if (arrived.status !== 200 && arrived.status !== 409) return arrived;
  return call('POST', `/api/translator/missions/${bid}/verify-code`, { code: bk && bk.service_code }, ttok);
}

async function main() {
  const base = Math.floor(Math.random() * 500) * 10;
  console.log('== احراز هویت');
  const pT = phoneFor(base + 1);
  let r = await call('POST', '/api/auth/request-code', { phone: pT, role: 'translator' });
  check('درخواست کد برای شماره‌ی معتبر', r.status === 200 && r.data.ok, JSON.stringify(r));
  r = await call('POST', '/api/auth/request-code', { phone: pT, role: 'translator' });
  check('ارسال مجدد زودتر از ۱۲۰ ثانیه رد می‌شود', r.status === 429, String(r.status));
  r = await call('POST', '/api/auth/request-code', { phone: '0000', role: 'translator' });
  check('شماره‌ی نامعتبر رد می‌شود', r.status === 400);
  r = await call('POST', '/api/auth/verify', { phone: pT, role: 'translator', code: '000000' });
  check('کد اشتباه ۴۰۱ و تعداد تلاش باقی‌مانده', r.status === 401 && r.data.attempts_left === 4, JSON.stringify(r));
  for (let i = 0; i < 3; i++) await call('POST', '/api/auth/verify', { phone: pT, role: 'translator', code: '111111' });
  r = await call('POST', '/api/auth/verify', { phone: pT, role: 'translator', code: '111111' });
  check('پنجمین تلاش ناموفق قفل ۱۰ دقیقه‌ای می‌سازد', r.status === 423 && r.data.retry_after === 600, JSON.stringify(r));
  r = await call('POST', '/api/auth/verify', { phone: pT, role: 'translator', code: '123456' });
  check('در قفل، کد درست هم پذیرفته نمی‌شود', r.status === 423);

  // کاربر تازه برای جریان موفق
  const pT2 = phoneFor(base + 2);
  await call('POST', '/api/auth/request-code', { phone: pT2, role: 'translator' });
  r = await call('POST', '/api/auth/verify', { phone: pT2, role: 'translator', code: '123456' });
  check('کد درست نشست می‌دهد', r.status === 200 && !!r.data.token, JSON.stringify(r));
  const tokT = r.data && r.data.token;
  r = await call('POST', '/api/auth/verify', { phone: pT2, role: 'translator', code: '123456' });
  check('کد یک‌بارمصرف است', r.status === 400);

  r = await call('GET', '/api/auth/me', null, tokT);
  check('me با توکن معتبر', r.status === 200 && r.data.role === 'translator');
  r = await call('GET', '/api/auth/me', null, 'bogus');
  check('me با توکن نامعتبر ۴۰۱', r.status === 401);

  console.log('== مترجم');
  r = await call('GET', '/api/translator/status', null, tokT);
  check('وضعیت اولیه ثبت‌نام‌شده', r.status === 200 && r.data.status === 'registered', JSON.stringify(r));
  r = await call('GET', '/api/translator/missions', null, tokT);
  check('مترجم غیرفعال ماموریت نمی‌بیند', r.status === 403);
  r = await call('POST', '/api/dev/approve-translator', null, tokT);
  check('تأیید آزمایشی مترجم را فعال می‌کند', r.status === 200 && r.data.status === 'active_general');
  r = await call('GET', '/api/translator/missions', null, tokT, 'X-Auth-Token');
  check('هدر جایگزین X-Auth-Token نشست مترجم را برای فهرست مأموریت می‌پذیرد', r.status === 200 && Array.isArray(r.data.missions), JSON.stringify(r));
  const soon = new Date(Date.now() + 5 * 86400000).toISOString();
  const later = new Date(Date.now() + 6 * 86400000).toISOString();
  const past = new Date(Date.now() - 5 * 86400000).toISOString();
  await call('POST', '/api/dev/missions', { code: 'M-1', purpose: 'مذاکره', travelerName: 'A', place: 'x', startAt: soon, total: 100, net: 80, status: 'accepted' }, tokT);
  await call('POST', '/api/dev/missions', { code: 'M-2', purpose: 'در انتظار', travelerName: 'B', place: 'y', startAt: later, total: 50, net: 40, status: 'pending_invite' }, tokT);
  await call('POST', '/api/dev/missions', { code: 'M-3', purpose: 'گذشته', travelerName: 'C', place: 'z', startAt: past, total: 10, net: 8, status: 'accepted' }, tokT);
  r = await call('GET', '/api/translator/missions', null, tokT);
  const codes = (r.data && r.data.missions || []).map((m) => m.code);
  check('فقط ماموریت پذیرفته‌شده و آینده برمی‌گردد', r.status === 200 && codes.length === 1 && codes[0] === 'M-1', JSON.stringify(codes));
  check('پاسخ فهرست مأموریت زمان سرور را دارد', r.status === 200 && Number.isFinite(Date.parse(r.data.server_time)));
  check('مبلغ کل و سهم خالص دارد', r.data && r.data.missions[0].total === 100 && r.data.missions[0].net === 80);

  console.log('== مسافر و جداسازی نقش‌ها');
  const pP = phoneFor(base + 3);
  await call('POST', '/api/auth/request-code', { phone: pP, role: 'traveler' });
  r = await call('POST', '/api/auth/verify', { phone: pP, role: 'traveler', code: '123456' });
  const tokP = r.data && r.data.token;
  check('ورود مسافر', r.status === 200 && r.data.user.role === 'traveler');
  r = await call('GET', '/api/translator/missions', null, tokP);
  check('مسافر به API مترجم دسترسی ندارد', r.status === 403);
  r = await call('POST', '/api/traveler/bookings', { kind: 'instant', origin_lang: 'ar', dest_lang: 'fa', place: 'x', traveler_name: 'Ali', lat: 35.6997, lng: 51.338 }, tokP);
  check('مسافر رزرو فوری ثبت می‌کند', r.status === 201 && r.data.status === 'searching', JSON.stringify(r));
  check('کد امنیتی شروع خدمت را سرور صادر می‌کند (۵ رقم)', /^[0-9]{5}$/.test(r.data.service_code || ''), JSON.stringify(r.data.service_code));
  check('مختصات محل ملاقات ذخیره و برگردانده می‌شود', r.data.lat === 35.6997 && r.data.lng === 51.338, JSON.stringify([r.data.lat, r.data.lng]));
  r = await call('POST', '/api/traveler/bookings', { kind: 'instant', origin_lang: 'ar', dest_lang: 'fa', place: 'x', traveler_name: 'Ali', lat: 999, lng: 51.338 }, tokP);
  check('مختصات نامعتبر رد می‌شود', r.status === 400 && r.data.error === 'invalid_coords', JSON.stringify(r));
  const firstServiceCode = (await call('GET', '/api/traveler/bookings', null, tokP)).data.bookings[0].service_code;
  r = await call('GET', '/api/traveler/bookings', null, tokP);
  check('رزرو در لیست مسافر است', r.status === 200 && r.data.bookings.length === 1 && r.data.bookings[0].kind === 'instant');
  check('کد امنیتی در فهرست رزروهای مسافر همان کد صادرشده است', r.data.bookings[0].service_code === firstServiceCode);
  check('مختصات در فهرست رزروها هم هست', r.data.bookings[0].lat === 35.6997 && r.data.bookings[0].lng === 51.338);
  // این رزرو فقط برای بررسی فهرست بود؛ لغو می‌شود تا پیشنهادش به مترجمان بعدی نرسد
  await call('POST', `/api/traveler/bookings/${r.data.bookings[0].id}/cancel`, null, tokP);

  console.log('== تطبیق و پیشنهاد');
  const T1 = await makeTranslator(base + 10);
  const T2 = await makeTranslator(base + 11);
  // تا وقتی مترجم آنلاین نیست، پیشنهادی نیست
  r = await call('GET', '/api/translator/offers', null, T1);
  check('مترجم آفلاین پیشنهادی نمی‌گیرد', r.status === 200 && r.data.offers.length === 0 && r.data.online === false);
  const offlinePresence = await call('GET', '/api/translator/online', null, T1);
  check('آمادگی واقعی مترجم بدون تغییر وضعیت خوانده می‌شود', offlinePresence.status === 200 && offlinePresence.data.online === false && offlinePresence.data.enabled === true);
  check('آمادگی بدون نشست قابل خواندن نیست', (await call('GET', '/api/translator/online')).status === 401);
  check('مسافر به آمادگی مترجم دسترسی ندارد', (await call('GET', '/api/translator/online', null, tokP)).status === 403);
  for (const invalid of [{}, { online: 'true' }, { online: 1 }, { online: null }, []]) {
    const result = await call('PATCH', '/api/translator/online', invalid, T1);
    check('آمادگی غیربولی رد می‌شود: ' + JSON.stringify(invalid), result.status === 400 && result.data.error === 'invalid_online');
  }
  check('درخواست نامعتبر مترجم را آنلاین نمی‌کند', (await call('GET', '/api/translator/online', null, T1)).data.online === false);
  r = await call('PATCH', '/api/translator/online', { online: true }, T1);
  check('مترجم آنلاین می‌شود', r.status === 200 && r.data.online === true);
  check('بازخوانی مستقل، آنلاین‌شدن واقعی را تأیید می‌کند', (await call('GET', '/api/translator/online', null, T1)).data.online === true);
  // T1 قبلاً ممکن است کنار رزروهای قبلی تست باشد؛ پیشنهاد را با دو مترجم آنلاین بررسی می‌کنیم
  await call('PATCH', '/api/translator/online', { online: true }, T2);
  r = await call('POST', '/api/traveler/bookings', { kind: 'instant', origin_lang: 'ar', dest_lang: 'fa', field: 'medical', place: 'بیمارستان امام', notes: 'طبقه ۲', traveler_name: 'Ali R.' }, tokP);
  const bid = r.data.id;
  const off1 = await call('GET', '/api/translator/offers', null, T1);
  const off2 = await call('GET', '/api/translator/offers', null, T2);
  const mine = [...off1.data.offers, ...off2.data.offers].find((o) => o.place === 'بیمارستان امام');
  check('یک مترجم پیشنهاد می‌گیرد', !!mine, JSON.stringify([off1.data, off2.data]).slice(0, 200));
  check('پیشنهاد فیلد جنسیت ندارد', mine && !('gender' in mine) && !('total' in mine) && mine.net > 0);
  check('پیشنهاد جزئیات لازم کارت را دارد، بدون کد محرمانه', mine && mine.hours === 1 && mine.car === 0 && mine.party === 1 && mine.notes === 'طبقه ۲' && !('service_code' in mine));
  check('زمان‌سنج پیشنهاد به زمان‌های معتبر سرور متکی است', mine && Number.isFinite(Date.parse(mine.created_at)) && Number.isFinite(Date.parse(mine.expires_at)) && Date.parse(mine.expires_at) > Date.parse(mine.created_at));
  const tokOffer = mine && (off1.data.offers.find((o) => o.id === mine.id) ? T1 : T2);
  check('پیشنهاد به شناسه همان رزرو متصل است', mine.reservation_id === bid);
  const privateOffer = await call('GET', `/api/translator/offers/${mine.id}`, null, tokOffer);
  check('نمای خصوصی پیشنهاد، شناسه و سهم و انتظار همان رزرو را دارد', privateOffer.status === 200 && privateOffer.data.id === mine.id && privateOffer.data.reservation_id === bid && privateOffer.data.status === 'pending' && privateOffer.data.net === mine.net && privateOffer.data.assigned === false);
  check('نمای پیشنهاد بدون نشست ممنوع است', (await call('GET', `/api/translator/offers/${mine.id}`)).status === 401);
  check('مسافر نمای خصوصی پیشنهاد مترجم را نمی‌بیند', (await call('GET', `/api/translator/offers/${mine.id}`, null, tokP)).status === 403);
  check('مترجم دیگر نمای خصوصی پیشنهاد را نمی‌بیند', (await call('GET', `/api/translator/offers/${mine.id}`, null, tokOffer === T1 ? T2 : T1)).status === 404);
  check('نمای خصوصی پیشنهاد، جنسیت و مبلغ کل و کد مسافر را افشا نمی‌کند', !('gender' in privateOffer.data) && !('total' in privateOffer.data) && !('service_code' in privateOffer.data) && !('phone' in privateOffer.data));
  r = await call('POST', `/api/translator/offers/${mine.id}/accept`, null, tokOffer);
  check('پذیرش پیشنهاد', r.status === 200, JSON.stringify(r));
  const acceptedOffer = (await call('GET', `/api/translator/offers/${mine.id}`, null, tokOffer)).data;
  check('پذیرش در تاریخچه خصوصی همان پیشنهاد ثبت می‌شود', acceptedOffer.status === 'accepted' && acceptedOffer.assigned === true && acceptedOffer.reservation_id === bid);
  const acceptedMission = (await call('GET', `/api/translator/missions/${bid}`, null, tokOffer)).data;
  check('پذیرش واقعاً مأموریت همان رزرو با همان سهم می‌سازد', acceptedMission.status === 'matched' && acceptedMission.reservation_id === bid && acceptedMission.net === mine.net);

  r = await call('POST', `/api/translator/offers/${mine.id}/accept`, null, tokOffer);
  check('پذیرش دوباره پیشنهاد پذیرفته‌شده رد می‌شود', r.status === 410 || r.status === 409, String(r.status));
  r = await call('GET', '/api/traveler/bookings', null, tokP);
  const bk = r.data.bookings.find((b) => b.id === bid);
  check('رزرو مسافر پس از پذیرش تطبیق‌یافته است', bk && bk.status === 'matched' && bk.matched === true, JSON.stringify(bk));
  const other = mine && (tokOffer === T1 ? T2 : T1);
  r = await call('GET', '/api/translator/offers', null, other);
  check('پیشنهاد باز مترجم دیگر پس از پذیرش حذف می‌شود', !r.data.offers.some((o) => o.id === mine.id));
  r = await call('GET', '/api/translator/missions', null, tokOffer);
  check('ماموریت پذیرفته‌شده در میز کار مترجم است', r.status === 200 && r.data.missions.some((m) => m.code === 'R-' + bid && m.purpose === 'medical'));

  // رد پیشنهاد: پیشنهاد به نفر بعدی می‌رود؛ اگر کسی نماند، جستجو ادامه دارد
  r = await call('POST', '/api/traveler/bookings', { kind: 'instant', origin_lang: 'ar', dest_lang: 'fa', place: 'مترو', traveler_name: 'Ali R.' }, tokP);
  const bid2 = r.data.id;
  const first = await call('GET', '/api/translator/offers', null, T1);
  const first2 = await call('GET', '/api/translator/offers', null, T2);
  const cand = first.data.offers.find((o) => o.place === 'مترو') ? T1 : T2;
  const candOffers = cand === T1 ? first.data.offers : first2.data.offers;
  const o2 = candOffers.find((o) => o.place === 'مترو');
  r = await call('POST', `/api/translator/offers/${o2.id}/decline`, null, cand);
  check('رد پیشنهاد ثبت می‌شود', r.status === 200);
  const declinedOffer = (await call('GET', `/api/translator/offers/${o2.id}`, null, cand)).data;
  check('رد در تاریخچه خصوصی ثبت می‌شود و مأموریت نمی‌سازد', declinedOffer.status === 'declined' && declinedOffer.assigned === false && declinedOffer.reservation_id === bid2);
  check('رد دوباره پیشنهاد تصمیم‌گرفته‌شده موفق اعلام نمی‌شود', (await call('POST', `/api/translator/offers/${o2.id}/decline`, null, cand)).status === 410);

  const nextT = cand === T1 ? T2 : T1;
  r = await call('GET', '/api/translator/offers', null, nextT);
  // مترجمی که همین حالا رزرو پذیرفته، تا دو ساعت مشغول است و پیشنهاد نمی‌گیرد
  const nextBusy = nextT === tokOffer;
  check('پس از رد، پیشنهاد به مترجم بعدی می‌رود (یا اگر مشغول است، نمی‌رود)', r.data.offers.some((o) => o.place === 'مترو') === !nextBusy);
  r = await call('GET', '/api/traveler/bookings', null, tokP);
  check('رزرو هنوز در جستجوست', r.data.bookings.find((b) => b.id === bid2).status === 'searching');

  console.log('== جنسیت، تداخل زمانی و لغو مترجم');
  await call('PATCH', '/api/translator/online', { online: false }, T1);
  await call('PATCH', '/api/translator/online', { online: false }, T2);
  const T3 = await makeTranslator(base + 20);
  const T4 = await makeTranslator(base + 21);
  await call('PATCH', '/api/translator/online', { online: true, gender: 'female' }, T3);
  const searchCancelResult = await call('POST', `/api/traveler/bookings/${bid2}/cancel`, null, tokP); // درخواست آزمایشِ باز پاک می‌شود تا پیشنهاد کهنه تنظیم تازه را مسدود نکند
  await call('PATCH', '/api/translator/online', { online: true, gender: 'male' }, T4);
  r = await call('GET', '/api/translator/preferences', null, T3);
  check('تنظیم جنسیت مسافر برای مترجم تازه‌فعال‌شده «فرقی نمی‌کند» است', r.status === 200 && r.data.traveler_gender_pref === 'any');
  r = await call('PATCH', '/api/translator/preferences', { traveler_gender_pref: 'female' }, T3);
  check('مترجم می‌تواند فقط مسافران زن را انتخاب کند', r.status === 200 && r.data.traveler_gender_pref === 'female');
  r = await call('GET', '/api/translator/preferences', null, T3);
  check('ترجیح جنسیت مسافر از سرور بازخوانی می‌شود', r.status === 200 && r.data.traveler_gender_pref === 'female');
  r = await call('PATCH', '/api/translator/preferences', { traveler_gender_pref: 'other' }, T3);
  check('مقدار نامعتبر ترجیح جنسیت رد و مقدار قبلی حفظ می‌شود', r.status === 400 && (await call('GET', '/api/translator/preferences', null, T3)).data.traveler_gender_pref === 'female');
  r = await call('PATCH', '/api/translator/preferences', { traveler_gender_pref: 'any' }, T3);
  check('تنظیم بدون ترجیح ذخیره می‌شود', r.status === 200 && r.data.traveler_gender_pref === 'any');
  const anyGenderBooking = (await call('POST', '/api/traveler/bookings', { kind: 'instant', origin_lang: 'ar', dest_lang: 'fa', place: 'هر جنسیت مسافر', traveler_name: 'A', traveler_gender: 'male', gender_pref: 'any' }, tokP)).data;
  const anyGenderOffer = await offerFor(T3, 'هر جنسیت مسافر', [T4]);
  check('تنظیم بدون ترجیح، مسافر با جنسیت دیگر را هم می‌پذیرد', !!anyGenderOffer);
  if (anyGenderOffer) await call('POST', `/api/translator/offers/${anyGenderOffer.id}/decline`, null, T3);
  await call('POST', `/api/traveler/bookings/${anyGenderBooking.id}/cancel`, null, tokP);
  r = await call('PATCH', '/api/translator/preferences', { traveler_gender_pref: 'male' }, T3);
  check('انتخاب فقط مسافران مرد هم ذخیره می‌شود', r.status === 200 && r.data.traveler_gender_pref === 'male');
  const maleOnlyBooking = (await call('POST', '/api/traveler/bookings', { kind: 'instant', origin_lang: 'ar', dest_lang: 'fa', place: 'فقط مسافر مرد', traveler_name: 'A', traveler_gender: 'male', gender_pref: 'any' }, tokP)).data;
  const maleOnlyOffer = await offerFor(T3, 'فقط مسافر مرد', [T4]);
  check('انتخاب مرد، درخواست مرد را حتی با جنسیت متفاوت مترجم می‌پذیرد', !!maleOnlyOffer, JSON.stringify({ booking: maleOnlyBooking }));
  if (maleOnlyOffer) await call('POST', `/api/translator/offers/${maleOnlyOffer.id}/decline`, null, T3);
  await call('POST', `/api/traveler/bookings/${maleOnlyBooking.id}/cancel`, null, tokP);
  await call('PATCH', '/api/translator/preferences', { traveler_gender_pref: 'female' }, T3);
  // حتی پذیرش قدیمیِ هر جنسیت هم محدودیت سروریِ انتخاب تازه را دور نمی‌زند.
  await call('PATCH', '/api/translator/online', { online: true, accept_any: true }, T3);
  r = await call('POST', '/api/traveler/bookings', { kind: 'instant', origin_lang: 'ar', dest_lang: 'fa', place: 'جنسیت', traveler_name: 'A', traveler_gender: 'male', gender_pref: 'same_gender' }, tokP);
  const g1 = r.data.id;
  r = await call('GET', '/api/translator/offers', null, T3);
  check('خانم‌ها برای مسافر مرد با «آقا» پیشنهاد نمی‌گیرند', !r.data.offers.some((o) => o.place === 'جنسیت'));
  r = await call('GET', '/api/translator/offers', null, T4);
  const og = r.data.offers.find((o) => o.place === 'جنسیت');
  check('آقای هم‌جنس پیشنهاد را می‌گیرد', !!og);
  await call('POST', `/api/translator/offers/${og.id}/accept`, null, T4);
  r = await call('POST', '/api/traveler/bookings', { kind: 'instant', origin_lang: 'ar', dest_lang: 'fa', place: 'تداخل', traveler_name: 'A', traveler_gender: 'male', gender_pref: 'same_gender' }, tokP);
  const g2 = r.data.id;
  r = await call('GET', '/api/translator/offers', null, T4);
  check('مترجم مشغول (تداخل زمانی) پیشنهاد نمی‌گیرد', !r.data.offers.some((o) => o.place === 'تداخل'));
  r = await call('POST', '/api/traveler/bookings', { kind: 'instant', origin_lang: 'ar', dest_lang: 'fa', place: 'مختلط', traveler_name: 'A', traveler_gender: 'male', gender_pref: 'any' }, tokP);
  const g3 = r.data.id;
  r = await call('GET', '/api/translator/offers', null, T3);
  check('تنظیم «فقط مسافر زن» پیشنهاد مسافر مرد را فیلتر می‌کند', !r.data.offers.some((o) => o.place === 'مختلط'));
  const femaleBooking = (await call('POST', '/api/traveler/bookings', { kind: 'instant', origin_lang: 'ar', dest_lang: 'fa', place: 'فقط مسافر زن', traveler_name: 'A', traveler_gender: 'female', gender_pref: 'any' }, tokP)).data;
  const femaleOffer = await offerFor(T3, 'فقط مسافر زن', [T4]);
  check('تنظیم «فقط مسافر زن» پیشنهاد مسافر زن را دریافت می‌کند', !!femaleOffer, JSON.stringify({ booking: femaleBooking }));
  if (femaleOffer) await call('POST', `/api/translator/offers/${femaleOffer.id}/decline`, null, T3);
  await call('POST', `/api/traveler/bookings/${femaleBooking.id}/cancel`, null, tokP);
  const cancelBefore = (await call('GET', `/api/translator/missions/${g1}/cancellation`, null, T4)).data;
  check('وضعیت خصوصی پیش از لغو به همان مأموریت وصل است', cancelBefore.reservation_id === g1 && cancelBefore.cancelled === false && cancelBefore.cancelled_at === null && cancelBefore.assigned === true);
  check('تاریخچهٔ لغو بدون نشست خصوصی است', (await call('GET', `/api/translator/missions/${g1}/cancellation`)).status === 401);
  check('مسافر تاریخچهٔ خصوصی لغو مترجم را نمی‌خواند', (await call('GET', `/api/translator/missions/${g1}/cancellation`, null, tokP)).status === 403);
  check('مترجم دیگر تاریخچهٔ لغو را نمی‌خواند', (await call('GET', `/api/translator/missions/${g1}/cancellation`, null, T3)).status === 404);
  const cancelPrice = (await call('GET', '/api/traveler/bookings', null, tokP)).data.bookings.find(b => b.id === g1).total;
  const previousArrival = await call('POST', `/api/translator/missions/${g1}/arrive`, null, T4);
  check('مترجمِ در حال لغو، حضور مأموریت را قبلاً ثبت کرده است', previousArrival.status === 200 && previousArrival.data.already_arrived === false);
  r = await call('POST', `/api/translator/missions/${g1}/cancel`, null, T4);
  check('مترجم می‌تواند ماموریت پذیرفته‌شده را لغو کند', r.status === 200, JSON.stringify(r));
  const cancelReceipt = r.data;
  check('رسید لغو شناسه و زمان ثبت را دارد', cancelReceipt.ok === true && cancelReceipt.reservation_id === g1 && Number.isFinite(Date.parse(cancelReceipt.cancelled_at)) && typeof cancelReceipt.reassigned === 'boolean');
  const cancelHistory = (await call('GET', `/api/translator/missions/${g1}/cancellation`, null, T4)).data;
  check('لغو واقعاً در تاریخچهٔ خصوصی ثبت شده است', cancelHistory.cancelled === true && cancelHistory.assigned === false && cancelHistory.cancelled_at === cancelReceipt.cancelled_at);
  check('تاریخچه فقط رسید خصوصی است نه اطلاعات مسافر یا مترجم بعدی', Object.keys(cancelHistory).sort().join(',') === 'assigned,cancelled,cancelled_at,reservation_id');
  check('پس از واگذاری، جزئیات خصوصی مأموریت برای مترجم قبلی بسته است', (await call('GET', `/api/translator/missions/${g1}`, null, T4)).status === 404);
  const cancelPassenger = (await call('GET', '/api/traveler/bookings', null, tokP)).data.bookings.find(b => b.id === g1);
  check('لغو مترجم، رزرو مسافر را لغو یا قیمت را بازنویسی نمی‌کند', cancelPassenger.status !== 'cancelled' && !cancelPassenger.matched && cancelPassenger.total === cancelPrice && !cancelPassenger.service_started);

  r = await call('GET', '/api/translator/offers', null, T4);
  check('پس از لغو، رزرو آزاد به همین مترجم (که آزاد شده) پیشنهاد می‌شود', r.data.offers.some((o) => o.place === 'تداخل'));
  const T6 = await makeTranslator(base + 22);
  await call('PATCH', '/api/translator/online', { online: true, gender: 'male' }, T6);
  const reassignmentOffers = await call('GET', '/api/translator/offers', null, T6);
  const g1Reassignment = reassignmentOffers.data.offers.find((o) => o.reservation_id === g1);
  check('پس از لغو، مترجم دیگری پیشنهاد همان مأموریت را می‌گیرد', !!g1Reassignment, JSON.stringify(reassignmentOffers.data.offers));
  if (g1Reassignment) {
    await call('POST', `/api/translator/offers/${g1Reassignment.id}/accept`, null, T6);
    const reassignedMission = (await call('GET', `/api/translator/missions/${g1}`, null, T6)).data;
    check('مترجم بعدی حضور مترجم قبلی را به ارث نمی‌برد', reassignedMission.arrived_at === null);
    const reassignedCode = (await call('GET', '/api/traveler/bookings', null, tokP)).data.bookings.find((b) => b.id === g1).service_code;
    const beforeRearrival = await call('POST', `/api/translator/missions/${g1}/verify-code`, { code: reassignedCode }, T6);
    check('شروع رزرو واگذارشده تا ثبت حضور مترجم جدید مسدود است', beforeRearrival.status === 409 && beforeRearrival.data.error === 'arrival_required');
  }
  r = await call('POST', `/api/translator/missions/${g1}/cancel`, null, T4);
  check('لغو دوباره همان ماموریت ممنوع است', r.status === 404);
  check('تلاش تکراری، زمان ثبت لغو را عوض نمی‌کند', (await call('GET', `/api/translator/missions/${g1}/cancellation`, null, T4)).data.cancelled_at === cancelReceipt.cancelled_at);
  for (const id of [g1, g2, g3]) await call('POST', `/api/traveler/bookings/${id}/cancel`, null, tokP);
  await call('PATCH', '/api/translator/online', { online: false }, T3);
  await call('PATCH', '/api/translator/online', { online: false }, T4);
  await call('PATCH', '/api/translator/online', { online: false }, T6);

  console.log('== تغییر رزرو پس از پذیرش');
  const T5 = await makeTranslator(base + 30);
  await call('PATCH', '/api/translator/online', { online: true }, T5);
  r = await call('POST', '/api/traveler/bookings', { kind: 'instant', origin_lang: 'ar', dest_lang: 'fa', place: 'مبدأ اولیه', traveler_name: 'A' }, tokP);
  const cr = r.data.id;
  r = await call('GET', '/api/translator/offers', null, T5);
  const oc = r.data.offers.find((o) => o.place === 'مبدأ اولیه');
  await call('POST', `/api/translator/offers/${oc.id}/accept`, null, T5);
  const arrivalBeforeChange = await call('POST', `/api/translator/missions/${cr}/arrive`, null, T5);
  check('ثبت حضور پیش از تغییر مکان موفق است', arrivalBeforeChange.status === 200);
  r = await call('POST', `/api/traveler/bookings/${cr}/change`, { place: 'مقصد جدید' }, tokP);
  check('تغییر مکان پس از پذیرش، رضایت مترجم می‌خواهد (۲۰۲)', r.status === 202 && r.data.pending === true, JSON.stringify(r));
  r = await call('POST', `/api/traveler/bookings/${cr}/change`, { place: 'دوباره' }, tokP);
  check('درخواست دوم همزمان پذیرفته نمی‌شود', r.status === 409 && r.data.error === 'change_pending');
  r = await call('GET', '/api/translator/offers', null, T5);
  const ch = (r.data.changes || []).find((c) => c.changes.place === 'مقصد جدید');
  check('مترجم درخواست تغییر را می‌بیند', !!ch);
  const privateChange = await call('GET', `/api/translator/changes/${ch.id}`, null, T5);
  check('نمای خصوصی تغییر به همان درخواست و رزرو متصل است', privateChange.status === 200 && privateChange.data.id === ch.id && privateChange.data.reservation_id === cr && privateChange.data.status === 'pending' && privateChange.data.changes.place === 'مقصد جدید');
  check('تغییر بدون نشست دیده نمی‌شود', (await call('GET', `/api/translator/changes/${ch.id}`)).status === 401);
  check('مسافر نمای خصوصی رضایت مترجم را نمی‌بیند', (await call('GET', `/api/translator/changes/${ch.id}`, null, tokP)).status === 403);
  check('مترجم دیگر درخواست تغییر را نمی‌بیند', (await call('GET', `/api/translator/changes/${ch.id}`, null, T1)).status === 404);
  check('نمای تغییر کد مسافر یا شماره تماس را افشا نمی‌کند', !('service_code' in privateChange.data) && !('phone' in privateChange.data));
  const priorChangeMission = (await call('GET', `/api/translator/missions/${cr}`, null, T5)).data;
  check('نمای خصوصی مأموریت، مشخصات پیش از تغییر و حضور ثبت‌شده را دارد', priorChangeMission.details.place === 'مبدأ اولیه' && priorChangeMission.details.hours === priorChangeMission.hours && !!priorChangeMission.arrived_at);
  r = await call('POST', `/api/translator/changes/${ch.id}/reject`, null, T5);
  check('مترجم تغییر را رد می‌کند', r.status === 200);
  check('رد در تاریخچه همان تغییر ثبت شده است', (await call('GET', `/api/translator/changes/${ch.id}`, null, T5)).data.status === 'rejected');
  r = await call('GET', '/api/traveler/bookings', null, tokP);
  const bc = r.data.bookings.find((b) => b.id === cr);
  check('رد شدن، مکان را تغییر نمی‌دهد و درخواست باز را پاک می‌کند', bc.place === 'مبدأ اولیه' && bc.pending_change === null);
  r = await call('POST', `/api/traveler/bookings/${cr}/change`, { place: 'مقصد نهایی' }, tokP);
  r = await call('GET', '/api/translator/offers', null, T5);
  const ch2 = (r.data.changes || []).find((c) => c.changes.place === 'مقصد نهایی');
  await call('POST', `/api/translator/changes/${ch2.id}/accept`, null, T5);
  const appliedChangeMission = (await call('GET', `/api/translator/missions/${cr}`, null, T5)).data;
  check('پذیرش تغییر محل، حضور قبلی را پاک و گزارش تازه را الزامی می‌کند', appliedChangeMission.details.place === 'مقصد نهایی' && appliedChangeMission.arrived_at === null && (await call('GET', `/api/translator/changes/${ch2.id}`, null, T5)).data.status === 'accepted');
  check('رضایت تغییر، قیمت نمونهٔ رزرو را بازنویسی نمی‌کند', appliedChangeMission.total === priorChangeMission.total && appliedChangeMission.net === priorChangeMission.net);
  check('پذیرش تکراری تغییر موفق اعلام نمی‌شود', (await call('POST', `/api/translator/changes/${ch2.id}/accept`, null, T5)).status === 410);

  r = await call('GET', '/api/traveler/bookings', null, tokP);
  check('پذیرش مترجم، مکان جدید را ثبت می‌کند', r.data.bookings.find((b) => b.id === cr).place === 'مقصد نهایی');
  r = await call('POST', `/api/traveler/bookings/${cr}/change`, { notes: 'طبقه ۳' }, tokP);
  check('یادداشت بدون رضایت مترجم اعمال می‌شود', r.status === 200 && r.data.applied === true);
  r = await call('POST', `/api/traveler/bookings/${cr}/change`, { place: 'چهارم' }, tokP);
  const ch3 = (await call('GET', '/api/translator/offers', null, T5)).data.changes.find((c) => c.changes.place === 'چهارم');
  await call('POST', `/api/translator/changes/${ch3.id}/accept`, null, T5);
  // سه درخواست ثبت شده (یکی رد شد): درخواست چهارم باید رد شود
  r = await call('POST', `/api/traveler/bookings/${cr}/change`, { place: 'پنجم' }, tokP);
  check('بیش از ۳ درخواست تغییر ممنوع است', r.status === 409 && r.data.error === 'change_limit', JSON.stringify(r));
  await call('POST', `/api/traveler/bookings/${cr}/cancel`, null, tokP);
  const terminalBooking = (await call('POST', '/api/traveler/bookings', { kind: 'instant', origin_lang: 'ar', dest_lang: 'fa', place: 'تغییر قبل پایان', traveler_name: 'A' }, tokP)).data;
  const terminalOffer = (await call('GET', '/api/translator/offers', null, T5)).data.offers.find(o => o.reservation_id === terminalBooking.id);
  await call('POST', `/api/translator/offers/${terminalOffer.id}/accept`, null, T5);
  await startService(terminalBooking.id, T5, tokP);
  const terminalChange = await call('POST', `/api/traveler/bookings/${terminalBooking.id}/change`, { place: 'تغییر بعد پایان' }, tokP);
  check('درخواست تغییر برای آزمون پایان ساخته شد', terminalChange.status === 202);
  await call('POST', `/api/traveler/bookings/${terminalBooking.id}/finish`, null, tokP);
  const refusedChange = await call('POST', `/api/translator/changes/${terminalChange.data.id}/accept`, null, T5);
  check('تغییر روی مأموریت پایان‌یافته پذیرفته نمی‌شود', refusedChange.status === 409 && refusedChange.data.error === 'change_not_allowed');
  check('پذیرش نامعتبر، تاریخچه را پذیرفته‌شده نمی‌کند', (await call('GET', `/api/translator/changes/${terminalChange.data.id}`, null, T5)).data.status === 'pending');
  check('پایان خدمت مشخصات و قیمت رزرو را حفظ می‌کند', (await call('GET', `/api/translator/missions/${terminalBooking.id}`, null, T5)).data.details.place === 'تغییر قبل پایان' && (await call('GET', `/api/translator/missions/${terminalBooking.id}`, null, T5)).data.total === terminalBooking.total);

  await call('PATCH', '/api/translator/online', { online: false }, T5);

  console.log('== زمان‌بندی و لغو');
  const tooSoon = new Date(Date.now() + 3600 * 1000).toISOString();
  r = await call('POST', '/api/traveler/bookings', { kind: 'scheduled', origin_lang: 'ar', dest_lang: 'fa', place: 'x', scheduled_at: tooSoon, traveler_name: 'A' }, tokP);
  check('رزرو زمان‌دار کمتر از ۲ ساعت پیش رد می‌شود', r.status === 400 && r.data.error === 'too_soon', JSON.stringify(r));
  const schedLater = new Date(Date.now() + 3 * 3600 * 1000).toISOString();
  r = await call('POST', '/api/traveler/bookings', { kind: 'scheduled', origin_lang: 'ar', dest_lang: 'fa', place: 'فرودگاه', scheduled_at: schedLater, traveler_name: 'A' }, tokP);
  check('رزرو زمان‌دار ۳ ساعت بعد ثبت می‌شود (در انتظار زمان تطبیق)', r.status === 201 && r.data.status === 'waiting_schedule');
  const sid = r.data.id;
  r = await call('POST', `/api/traveler/bookings/${sid}/cancel`, null, tokP);
  check('لغو رزرو قبل از تطبیق رایگان است', r.status === 200 && r.data.fee_percent === 0);
  r = await call('POST', `/api/traveler/bookings/${bid}/cancel`, null, tokP);
  check('لغو رزرو تطبیق‌یافته کارمزد دارد', r.status === 200 && r.data.fee_percent > 0, JSON.stringify(r));
  check('لغو رزرو در جستجو و بستن پیشنهادهای باز', searchCancelResult.status === 200, JSON.stringify(searchCancelResult));
  r = await call('GET', '/api/translator/offers', null, nextT);
  check('پس از لغو، پیشنهادی نمانده', !r.data.offers.some((o) => o.place === 'مترو'));
  r = await call('POST', `/api/traveler/bookings/${bid2}/cancel`, null, tokP);
  check('لغو دوباره رزرو لغوشده ممنوع است', r.status === 409);
  r = await call('POST', `/api/traveler/bookings/999999/cancel`, null, tokP);
  check('رزرو ناموجود ۴۰۴ است', r.status === 404);
  r = await call('POST', `/api/traveler/bookings/${bid}/cancel`, null, T1);
  check('مترجم نمی‌تواند رزرو مسافر را لغو کند', r.status === 403 || r.status === 404);

  console.log('== شماره‌های بین‌المللی (فقط مسافر)');
  r = await call('POST', '/api/auth/request-code', { phone: '+447911123456', role: 'traveler' });
  check('مسافر با شماره‌ی بریتانیا کد می‌گیرد', r.status === 200, JSON.stringify(r));
  r = await call('POST', '/api/auth/request-code', { phone: '+447911123456', role: 'translator' });
  check('مترجم فقط شماره‌ی ایرانی می‌گیرد', r.status === 400, String(r.status));
  r = await call('POST', '/api/auth/request-code', { phone: '0098 912 345 6789', role: 'traveler' });
  check('شماره‌ی ایرانی با پیش‌شماره‌ی ۰۰۹۸ پذیرفته می‌شود', r.status === 200 || r.status === 429, String(r.status));

  console.log('== پایان خدمت و پرداخت نقدی');
  const T9 = await makeTranslator(base + 41);
  await call('PATCH', '/api/translator/online', { online: true }, T9);
  const ph9 = '9' + String(100000000 + (base % 800000000) + 7);
  await call('POST', '/api/auth/request-code', { phone: ph9, role: 'traveler' });
  const tokP9 = (await call('POST', '/api/auth/verify', { phone: ph9, role: 'traveler', code: '123456' })).data.token;
  const matchOne = async (place) => {
    const b = await call('POST', '/api/traveler/bookings', { kind: 'instant', origin_lang: 'ar', dest_lang: 'fa', place, traveler_name: 'A', lat: 35.72, lng: 51.41 }, tokP9);
    const off = (await call('GET', '/api/translator/offers', null, T9)).data.offers.find((o) => o.place === place);
    if (!off) return null;
    await call('POST', `/api/translator/offers/${off.id}/accept`, null, T9);
    return b.data.id;
  };
  const pid = await matchOne('پرداخت نقدی');
  check('رزرو برای پایان خدمت پذیرفته شد', !!pid);
  const missionView = (await call('GET', '/api/translator/missions', null, T9)).data.missions.find((m) => m.reservation_id === pid);
  check('مختصات محل در نمای مأموریت مترجم هست', !!missionView && missionView.lat === 35.72 && missionView.lng === 51.41, JSON.stringify(missionView));
  check('کارت مأموریت جزئیات واقعی زبان، خودرو، همراهان و یادداشت را دارد', !!missionView && missionView.origin_lang === 'ar' && missionView.dest_lang === 'fa' && missionView.car === 0 && missionView.party === 1 && typeof missionView.notes === 'string' && missionView.arrived_at === null);
  r = await call('POST', `/api/translator/missions/${pid}/verify-code`, { code: '12345' }, T9);
  check('شروع خدمت پیش از ثبت حضور دستی در سرور رد می‌شود', r.status === 409 && r.data.error === 'arrival_required');
  check('گزارش رسیدن بدون نشست ممنوع است', (await call('POST', `/api/translator/missions/${pid}/arrive`)).status === 401);
  check('مسافر نمی‌تواند گزارش رسیدن مترجم را ثبت کند', (await call('POST', `/api/translator/missions/${pid}/arrive`, null, tokP9)).status === 403);
  r = await call('POST', `/api/translator/missions/${pid}/arrive`, null, T9);
  check('مترجم می‌تواند رسیدن را با ثبت دستی به سرور گزارش کند', r.status === 200 && r.data.ok === true && Number.isFinite(Date.parse(r.data.arrived_at)) && r.data.already_arrived === false, JSON.stringify(r));
  const arrivedAt = r.data.arrived_at;
  r = await call('POST', `/api/translator/missions/${pid}/arrive`, null, T9);
  check('گزارش رسیدن تکراری همان زمان را نگه می‌دارد', r.status === 200 && r.data.already_arrived === true && r.data.arrived_at === arrivedAt);
  const arrivalPrivateView = await call('GET', `/api/translator/missions/${pid}`, null, T9);
  check('زمان رسیدن در نمای خصوصی مأموریت پایدار است', arrivalPrivateView.status === 200 && arrivalPrivateView.data.arrived_at === arrivedAt);
  const matchedView = (await call('GET', '/api/traveler/bookings', null, tokP9)).data.bookings.find((b) => b.id === pid);
  check('نمای مسافر پس از تطبیق مشخصات مترجم را دارد', !!matchedView && 'translator_name' in matchedView && 'translator_car' in matchedView && matchedView.service_started === false, JSON.stringify(matchedView));
  check('پیش از شروع، زمان شروع و پایان در نمای مسافر خالی است', matchedView.service_started_at === null && matchedView.finished_at === null);
  r = await call('POST', `/api/traveler/bookings/${pid}/payment`, { method: 'cash' }, tokP9);
  check('پرداخت پیش از پایان خدمت ممنوع است', r.status === 409 && r.data.error === 'not_payable', JSON.stringify(r));
  r = await call('POST', `/api/translator/missions/${pid}/finish`, null, T9);
  check('پایان خدمت پیش از شروع با کد امنیتی ممنوع است', r.status === 409 && r.data.error === 'not_started', JSON.stringify(r));
  r = await call('POST', `/api/traveler/bookings/${pid}/extend`, { extra_hours: 1 }, tokP9);
  check('تمدید پیش از شروع خدمت ممکن نیست', r.status === 409 && r.data.error === 'extension_not_allowed', JSON.stringify(r));
  const realCode = (await call('GET', '/api/traveler/bookings', null, tokP9)).data.bookings.find((b) => b.id === pid).service_code;
  r = await call('POST', `/api/translator/missions/${pid}/verify-code`, { code: realCode === '99999' ? '11111' : '99999' }, T9);
  check('کد امنیتی اشتباه پذیرفته نمی‌شود', r.status === 401 && r.data.error === 'wrong_code' && r.data.attempts_left === 4, JSON.stringify(r));
  r = await startService(pid, T9, tokP9);
  check('شروع خدمت با کد صادرشده‌ی سرور ثبت می‌شود', r.status === 200 && r.data.started === true, JSON.stringify(r));
  check('پس از شروع خدمت، ثبت حضور دوباره مجاز نیست', (await call('POST', `/api/translator/missions/${pid}/arrive`, null, T9)).status === 409);
  const liveTravelerBooking = (await call('GET', '/api/traveler/bookings', null, tokP9)).data.bookings.find((b) => b.id === pid);
  check('مسافر شروع خدمت را در نمای رزرو می‌بیند', liveTravelerBooking.service_started === true);
  const liveMissionList = (await call('GET', '/api/translator/missions', null, T9)).data;
  const liveMissionRow = liveMissionList.missions.find((m) => m.reservation_id === pid);
  check('فهرست مترجم زمان شروع و مدت واقعی خدمت را دارد و کد محرمانه را افشا نمی‌کند', !!liveMissionRow &&
    liveMissionRow.started === true && liveMissionRow.service_started_at === liveTravelerBooking.service_started_at &&
    liveMissionRow.hours === liveTravelerBooking.hours && !('service_code' in liveMissionRow));
  r = await call('POST', `/api/traveler/bookings/${pid}/cancel`, null, tokP9);
  check('پس از شروع خدمت، لغو با کارمزد جایگزین پایان با مبلغ کامل نمی‌شود', r.status === 409 && r.data.error === 'service_already_started', JSON.stringify(r));
  const afterBlockedCancel = (await call('GET', '/api/traveler/bookings', null, tokP9)).data.bookings.find((b) => b.id === pid);
  check('رد لغو، خدمت شروع‌شده و مبلغ توافق را دست‌نخورده نگه می‌دارد', afterBlockedCancel.status === 'matched' && afterBlockedCancel.service_started === true && afterBlockedCancel.total === matchedView.total);
  r = await call('POST', `/api/translator/missions/${pid}/cancel`, null, T9);
  check('مترجم پس از شروع نمی‌تواند با لغو، خدمت را یک‌طرفه قطع یا واگذار کند', r.status === 409 && r.data.error === 'service_already_started', JSON.stringify(r));
  const afterTranslatorCancel = (await call('GET', '/api/translator/missions', null, T9)).data.missions.find((m) => m.reservation_id === pid);
  check('رد لغو مترجم، مأموریت شروع‌شده و مبلغ کامل را نگه می‌دارد', !!afterTranslatorCancel && afterTranslatorCancel.started === true && afterTranslatorCancel.total === matchedView.total);
  check('لغو ممنوع، رسید تاریخچهٔ جعلی نمی‌سازد', (await call('GET', `/api/translator/missions/${pid}/cancellation`, null, T9)).data.cancelled === false);
  // تمدید زمان خدمت: درخواست مسافر فقط با تأیید مترجم اعمال می‌شود
  const beforeExt = (await call('GET', '/api/traveler/bookings', null, tokP9)).data.bookings.find((b) => b.id === pid);
  check('زمان واقعی شروع خدمت با قالب ISO به مسافر می‌رسد', Number.isFinite(Date.parse(beforeExt.service_started_at)) && Date.parse(beforeExt.service_started_at) <= Date.now() && beforeExt.finished_at === null);
  const canonicalMission = await call('GET', `/api/translator/missions/${pid}`, null, T9);
  check('نمای خصوصی مترجم، شروع و مبلغ همان رزرو را نشان می‌دهد', canonicalMission.status === 200 && canonicalMission.data.reservation_id === pid && canonicalMission.data.started === true && canonicalMission.data.service_started_at === beforeExt.service_started_at && canonicalMission.data.total === beforeExt.total && canonicalMission.data.hours === beforeExt.hours);
  check('کد امنیتی مسافر در نمای مترجم افشا نمی‌شود', !('service_code' in canonicalMission.data));
  check('نمای خصوصی مأموریت بدون نشست ممنوع است', (await call('GET', `/api/translator/missions/${pid}`)).status === 401);
  check('مترجم دیگر نمای خصوصی مأموریت را نمی‌بیند', (await call('GET', `/api/translator/missions/${pid}`, null, T1)).status === 404);
  check('مسافر به نمای خصوصی مترجم دسترسی ندارد', (await call('GET', `/api/translator/missions/${pid}`, null, tokP9)).status === 403);
  r = await startService(pid, T9, tokP9);
  const restartedView = (await call('GET', '/api/traveler/bookings', null, tokP9)).data.bookings.find((b) => b.id === pid);
  check('تأیید دوباره کد، زمان شروع را صفر نمی‌کند', r.status === 200 && r.data.already_started === true && restartedView.service_started_at === beforeExt.service_started_at);
  r = await call('POST', `/api/traveler/bookings/${pid}/extend`, { extra_hours: 1 }, tokP9);
  check('مسافر در حین خدمت درخواست تمدید می‌دهد', r.status === 202 && r.data.pending === true && r.data.extra_total > 0, JSON.stringify(r));
  const extId = r.data.id;
  r = await call('POST', `/api/traveler/bookings/${pid}/extend`, { extra_hours: 1 }, tokP9);
  check('تمدید دوم همزمان ممکن نیست', r.status === 409 && r.data.error === 'extension_pending', JSON.stringify(r));
  const pendingView = (await call('GET', '/api/traveler/bookings', null, tokP9)).data.bookings.find((b) => b.id === pid);
  check('تمدید در نمای مسافر «منتظر تأیید مترجم» است', !!pendingView.pending_extension && pendingView.pending_extension.id === extId && pendingView.hours === beforeExt.hours, JSON.stringify(pendingView.pending_extension));
  const extOffer = (await call('GET', '/api/translator/offers', null, T9)).data.extensions.find((e) => e.id === extId);
  check('درخواست تمدید به مترجم می‌رسد', !!extOffer && extOffer.extra_hours === 1 && extOffer.extra_total === pendingView.pending_extension.extra_total && extOffer.new_net > 0 && Number.isFinite(Date.parse(extOffer.expires_at)), JSON.stringify(extOffer));
  const canonicalExtension = await call('GET', `/api/translator/extensions/${extId}`, null, T9);
  check('نمای خصوصی تمدید به همان مأموریت و نرخ توافق‌شده اشاره می‌کند', canonicalExtension.status === 200 && canonicalExtension.data.id === extId && canonicalExtension.data.reservation_id === pid && canonicalExtension.data.status === 'pending' && canonicalExtension.data.extra_hours === 1 && canonicalExtension.data.extra_total > 0 && Number.isFinite(Date.parse(canonicalExtension.data.expires_at)));
  check('نمای تمدید بدون نشست ممنوع است', (await call('GET', `/api/translator/extensions/${extId}`)).status === 401);
  check('مترجم دیگر تمدید را نمی‌بیند', (await call('GET', `/api/translator/extensions/${extId}`, null, T1)).status === 404);
  check('مسافر نمای خصوصی تمدید مترجم را نمی‌بیند', (await call('GET', `/api/translator/extensions/${extId}`, null, tokP9)).status === 403);
  r = await call('POST', `/api/translator/extensions/${extId}/accept`, null, T1);
  check('مترجم دیگر نمی‌تواند تمدید را تأیید کند', r.status === 404, JSON.stringify(r));
  r = await call('POST', `/api/translator/extensions/${extId}/reject`, null, T9);
  check('مترجم تمدید را رد می‌کند', r.status === 200, JSON.stringify(r));
  check('تصمیم رد در نمای خصوصی تمدید پایدار است', (await call('GET', `/api/translator/extensions/${extId}`, null, T9)).data.status === 'rejected');
  const rejectedView = (await call('GET', '/api/traveler/bookings', null, tokP9)).data.bookings.find((b) => b.id === pid);
  check('پس از رد، ساعت و مبلغ رزرو عوض نشده است', rejectedView.hours === beforeExt.hours && rejectedView.total === beforeExt.total && rejectedView.pending_extension === null && rejectedView.last_extension_status === 'rejected', JSON.stringify(rejectedView));
  r = await call('POST', `/api/traveler/bookings/${pid}/extend`, { extra_hours: 1 }, tokP9);
  check('مسافر پس از رد، دوباره تمدید می‌خواهد', r.status === 202 && r.data.pending === true, JSON.stringify(r));
  const ext2Total = r.data.extra_total;
  r = await call('POST', `/api/translator/extensions/${r.data.id}/accept`, null, T9);
  check('مترجم تمدید را تأیید می‌کند', r.status === 200, JSON.stringify(r));
  const acceptedView = (await call('GET', '/api/traveler/bookings', null, tokP9)).data.bookings.find((b) => b.id === pid);
  check('پس از تأیید، یک ساعت و مبلغ تمدید به رزرو اضافه شده است', acceptedView.hours === beforeExt.hours + 1 && acceptedView.total === beforeExt.total + ext2Total && acceptedView.last_extension_status === 'accepted', JSON.stringify(acceptedView));
  // پایان خدمت: مترجم فقط درخواست می‌دهد و مسافر باید قبول کند
  r = await call('POST', `/api/translator/missions/${pid}/finish`, null, T9);
  check('مترجم فقط درخواست پایان می‌دهد (تمام نمی‌کند)', r.status === 202 && r.data.pending_finish === true, JSON.stringify(r));
  check('درخواست پایان در نمای خصوصی مترجم همچنان خدمت در جریان است', (await call('GET', `/api/translator/missions/${pid}`, null, T9)).data.finish_requested === true && (await call('GET', `/api/translator/missions/${pid}`, null, T9)).data.status === 'matched');
  const finReqView = (await call('GET', '/api/traveler/bookings', null, tokP9)).data.bookings.find((b) => b.id === pid);
  check('رزرو هنوز در جریان است و درخواست پایان منتظر مسافر است', finReqView.status === 'matched' && finReqView.finish_requested === true, JSON.stringify(finReqView));
  r = await call('GET', '/api/translator/payments', null, T9);
  check('پیش از قبول مسافر، پرداختی در فهرست مترجم نیست', !r.data.payments.some((p) => p.reservation_id === pid));
  r = await call('POST', `/api/traveler/bookings/${pid}/payment`, { method: 'cash' }, tokP9);
  check('پرداخت پیش از قبول پایان ممکن نیست', r.status === 409 && r.data.error === 'not_payable', JSON.stringify(r));
  r = await call('POST', `/api/traveler/bookings/${pid}/finish-reject`, null, tokP9);
  check('مسافر درخواست پایان را رد می‌کند و خدمت ادامه دارد', r.status === 200 && r.data.status === 'matched', JSON.stringify(r));
  r = await call('POST', `/api/translator/missions/${pid}/finish`, null, T9);
  check('مترجم دوباره درخواست پایان می‌دهد', r.status === 202 && r.data.pending_finish === true, JSON.stringify(r));
  r = await call('POST', `/api/traveler/bookings/${pid}/finish-approve`, null, tokP9);
  check('مسافر پایان را قبول می‌کند و مبلغ بر اساس مدت واقعی (کف یک ساعت) تعدیل می‌شود',
    r.status === 200 && r.data.status === 'finished' && r.data.finished_by === 'translator' &&
    r.data.billed_hours === 1 && r.data.price_adjusted === true && r.data.total < acceptedView.total && r.data.list_total === acceptedView.total, JSON.stringify(r));
  const adjustedTotal = r.data.total;
  r = await call('GET', '/api/translator/payments', null, T9);
  check('پرداخت منتظر تأیید در فهرست مترجم است', r.data.payments.some((p) => p.reservation_id === pid && p.pay_state === null));
  r = await call('POST', `/api/traveler/bookings/${pid}/payment`, { method: 'online' }, tokP9);
  check('پرداخت آنلاین وقتی غیرفعال است پذیرفته نمی‌شود', r.status === 409 && r.data.error === 'method_disabled');
  r = await call('POST', `/api/traveler/bookings/${pid}/payment`, { method: 'bitcoin' }, tokP9);
  check('روش ناشناخته رد می‌شود', r.status === 400);
  r = await call('POST', `/api/traveler/bookings/${pid}/payment`, { method: 'cash' }, tokP9);
  check('مسافر نقدی را انتخاب و تأیید می‌کند', r.status === 200 && r.data.pay_state === 'awaiting_cash', JSON.stringify(r));
  const privateCash = (await call('GET', `/api/translator/missions/${pid}`, null, T9)).data;
  check('نمای خصوصی نقدی، انتظار دریافت و تأیید مسافر را نشان می‌دهد', privateCash.reservation_id === pid && privateCash.pay_method === 'cash' && privateCash.pay_state === 'awaiting_cash' && privateCash.confirmed === false && privateCash.traveler_paid === true && privateCash.total === adjustedTotal);
  check('نمای نقدی بدون نشست ممنوع است', (await call('GET', `/api/translator/missions/${pid}`)).status === 401);
  check('مترجم دیگر نمای نقدی را نمی‌بیند', (await call('GET', `/api/translator/missions/${pid}`, null, T1)).status === 404);
  check('مسافر به نمای نقدی مترجم دسترسی ندارد', (await call('GET', `/api/translator/missions/${pid}`, null, tokP9)).status === 403);
  r = await call('POST', `/api/translator/missions/${pid}/cash-confirm`, null, T9);
  check('مترجم دریافت نقدی را تأیید می‌کند و رزرو تسویه می‌شود', r.status === 200 && r.data.settled === true, JSON.stringify(r));
  check('رسید تسویه نقدی، انتظار مسافر را نادرست نشان نمی‌دهد', r.data.ok === true && r.data.waiting_traveler === false);
  const privateSettled = (await call('GET', `/api/translator/missions/${pid}`, null, T9)).data;
  check('نمای خصوصی پس از تسویه همچنان قابل تطبیق است', privateSettled.status === 'done' && privateSettled.pay_state === 'settled' && privateSettled.confirmed === true && privateSettled.traveler_paid === true && privateSettled.total === privateCash.total && privateSettled.net === privateCash.net);
  check('نمای نقدی کد امنیتی یا اطلاعات بانکی افشا نمی‌کند', !('service_code' in privateSettled) && !('bank_account' in privateSettled));
  const settledList = await call('GET', '/api/translator/payments', null, T9);
  const settlement = settledList.data.settlements.find((item) => item.reservation_id === pid);
  check('خلاصهٔ تسویهٔ نهایی از سرور به همان مأموریت و مبلغ متصل است', settledList.status === 200 && settlement && settlement.pay_state === 'settled' && settlement.confirmed && settlement.traveler_paid && settlement.hours === privateSettled.hours && settlement.total === privateSettled.total && settlement.net === privateSettled.net && Number.isFinite(Date.parse(settlement.finished_at)));
  // گیت بدهی واقعی است: سهم پلتفرم از این نقدی بدهی مترجم شد؛ برای ادامهٔ تست با پنل صفرش می‌کنیم
  const t9id = (await call('GET', '/api/auth/me', null, T9)).data.id;
  const admPre = (await call('POST', '/api/admin/login', { password: 'test-admin-pass' })).data.token;
  const drow = (await call('GET', '/api/admin/debts', null, admPre)).data.debts.find((d) => d.id === t9id);
  check('بدهی نقدی مترجم در پنل ثبت شده', !!drow && drow.debt > 0, JSON.stringify(drow));
  if (drow) await call('POST', `/api/admin/debts/${t9id}/pay`, { amount: drow.debt }, admPre);
  check('با تسویهٔ بدهی، پیشنهادهای مترجم باز می‌شود', (await call('GET', '/api/translator/payments', null, T9)).data.debt.blocked === false);

  const view = (await call('GET', '/api/traveler/bookings', null, tokP9)).data.bookings.find((b) => b.id === pid);
  check('زمان پایان ثبت می‌شود و زمان شروع پس از پایان و تسویه محفوظ است', Number.isFinite(Date.parse(view.finished_at)) && Date.parse(view.finished_at) >= Date.parse(view.service_started_at) && view.service_started_at === beforeExt.service_started_at);
  check('نمای مسافر: انجام‌شده و تسویه‌شده', view.status === 'done' && view.pay_state === 'settled', JSON.stringify(view));
  r = await call('POST', `/api/traveler/bookings/${pid}/payment`, { method: 'cash' }, tokP9);
  check('پرداخت دوباره ممنوع است', r.status === 409 && r.data.error === 'already_paid');
  console.log('== اختلاف نقدی به پشتیبانی');
  const did = await matchOne('اختلاف پرداخت');
  if (did) {
    await startService(did, T9, tokP9);
    await call('POST', `/api/translator/missions/${did}/finish`, null, T9);
    await call('POST', `/api/traveler/bookings/${did}/finish-approve`, null, tokP9);
    await call('POST', `/api/traveler/bookings/${did}/payment`, { method: 'cash' }, tokP9);
    r = await call('POST', `/api/traveler/bookings/${did}/dispute`, null, tokP9);
    check('اختلاف در نمای خصوصی مترجم ثبت شده و تسویه نیست', (await call('GET', `/api/translator/missions/${did}`, null, T9)).data.pay_state === 'disputed');
    check('مسافر اختلاف ثبت می‌کند', r.status === 200 && r.data.pay_state === 'disputed');
    r = await call('POST', `/api/translator/missions/${did}/cash-confirm`, null, T9);
    check('تأیید مترجم پس از اختلاف پذیرفته نمی‌شود', r.status === 409 && r.data.error === 'disputed');
  } else check('رزرو اختلاف برای مترجم تطبیق شد', false, 'offer missed');
  console.log('== پایان زودهنگام توسط خود مسافر (بدون تأیید مترجم، مبلغ کامل)');
  const eid = await matchOne('پایان زودهنگام مسافر');
  if (eid) {
    r = await call('POST', `/api/traveler/bookings/${eid}/finish`, null, tokP9);
    check('پایان توسط مسافر پیش از شروع خدمت ممکن نیست', r.status === 409 && r.data.error === 'not_started', JSON.stringify(r));
    await startService(eid, T9, tokP9);
    const beforeFinish = (await call('GET', '/api/traveler/bookings', null, tokP9)).data.bookings.find((b) => b.id === eid);
    r = await call('POST', `/api/traveler/bookings/${eid}/finish`, null, tokP9);
    check('مسافر هر وقت خواست خودش تمام می‌کند و مبلغ کامل می‌ماند', r.status === 200 && r.data.status === 'finished' && r.data.finished_by === 'traveler' && r.data.total === beforeFinish.total, JSON.stringify(r));
    r = await call('POST', `/api/traveler/bookings/${eid}/finish`, null, tokP9);
    check('پایان دوباره ممکن نیست', r.status === 409 && r.data.error === 'not_in_service', JSON.stringify(r));
  } else check('رزرو پایان زودهنگام برای مترجم تطبیق شد', false, 'offer missed');

  console.log('== پنل مدیریت');
  const ADM = process.env.ADMIN_PASSWORD || 'test-admin-pass';
  r = await call('POST', '/api/admin/login', { password: 'wrong' });
  check('رمز مدیر نادرست پذیرفته نمی‌شود', r.status === 401);
  r = await call('GET', '/api/admin/settings');
  check('تنظیمات بدون ورود مدیر در دسترس نیست', r.status === 401);
  r = await call('POST', '/api/admin/login', { password: ADM });
  const adm = r.data && r.data.token;
  check('ورود مدیر با رمز درست', r.status === 200 && !!adm);
  // قفل کد امنیتی پس از ۵ تلاش اشتباه و بازشدن آن از پنل مدیریت
  const lid = await matchOne('قفل کد امنیتی');
  if (lid) {
    await call('POST', `/api/translator/missions/${lid}/arrive`, null, T9);
    const lCode = (await call('GET', '/api/traveler/bookings', null, tokP9)).data.bookings.find((b) => b.id === lid).service_code;
    const wrong = lCode === '11111' ? '22222' : '11111';
    for (let i = 0; i < 5; i++) r = await call('POST', `/api/translator/missions/${lid}/verify-code`, { code: wrong }, T9);
    check('پنجمین کد اشتباه آخرین فرصت را مصرف می‌کند', r.status === 401 && r.data.attempts_left === 0, JSON.stringify(r));
    r = await call('POST', `/api/translator/missions/${lid}/verify-code`, { code: wrong }, T9);
    check('پس از ۵ کد اشتباه، کد قفل می‌شود', r.status === 423 && r.data.error === 'code_locked', JSON.stringify(r));
    r = await call('POST', `/api/translator/missions/${lid}/verify-code`, { code: lCode }, T9);
    check('در حالت قفل، کد درست هم پذیرفته نمی‌شود', r.status === 423, JSON.stringify(r));
    r = await call('GET', '/api/admin/locked-service-codes');
    check('فهرست کدهای قفل‌شده بدون ورود مدیر در دسترس نیست', r.status === 401, JSON.stringify(r));
    r = await call('GET', '/api/admin/locked-service-codes', null, adm);
    check('مدیر رزرو قفل‌شده را می‌بیند (بدون خود کد)', r.status === 200 && r.data.locked.some((x) => x.id === lid) && !JSON.stringify(r.data).includes(lCode), JSON.stringify(r.data));
    r = await call('POST', `/api/admin/reservations/${lid}/unlock-service-code`, {}, adm);
    check('مدیر قفل کد را باز می‌کند', r.status === 200 && r.data.regenerated === false, JSON.stringify(r));
    r = await call('POST', `/api/translator/missions/${lid}/verify-code`, { code: wrong }, T9);
    check('پس از بازشدن قفل، شمارنده از صفر شروع می‌شود', r.status === 401 && r.data.attempts_left === 4, JSON.stringify(r));
    r = await call('POST', `/api/admin/reservations/${lid}/unlock-service-code`, { regenerate: true }, adm);
    check('مدیر می‌تواند کد تازه بسازد', r.status === 200 && r.data.regenerated === true, JSON.stringify(r));
    const freshCode = (await call('GET', '/api/traveler/bookings', null, tokP9)).data.bookings.find((b) => b.id === lid).service_code;
    check('کد تازه در نمای مسافر نمایش داده می‌شود و با قبلی فرق دارد', /^[0-9]{5}$/.test(freshCode || '') && freshCode !== lCode, JSON.stringify(freshCode));
    r = await call('POST', `/api/translator/missions/${lid}/verify-code`, { code: lCode }, T9);
    check('کد قبلی پس از ساخت کد تازه کار نمی‌کند', r.status === 401, JSON.stringify(r));
    r = await call('POST', `/api/translator/missions/${lid}/verify-code`, { code: freshCode }, T9);
    check('کد تازه کار می‌کند و خدمت شروع می‌شود', r.status === 200 && r.data.started === true, JSON.stringify(r));
    await call('POST', `/api/traveler/bookings/${lid}/cancel`, null, tokP9);
  } else check('رزرو قفل کد برای مترجم تطبیق شد', false, 'offer missed');
  r = await call('GET', '/api/admin/settings', null, adm);
  check('تنظیمات قابل تغییر خوانده می‌شود', r.status === 200 && r.data.settings.hourly_tariffs.value.includes('medical') && r.data.settings.cancel_fee_percent.value === 20);
  check('مهلت‌های ثابت در فهرست تنظیمات نیستند', !r.data.settings.offer_ms && !r.data.settings.instant_search_ms);
  r = await call('PUT', '/api/admin/settings', { unknown_thing: 1 }, adm);
  check('کلید ناشناخته رد می‌شود', r.status === 400 && r.data.error === 'unknown_key');
  r = await call('PUT', '/api/admin/settings', { translator_share_percent: 150 }, adm);
  check('سهم مترجم بیشتر از ۱۰۰٪ رد می‌شود', r.status === 400 && r.data.error === 'invalid_value');
  r = await call('PUT', '/api/admin/settings', { settlement_period: 'monthly' }, adm);
  check('دوره‌ی تسویه‌ی ناشناخته رد می‌شود', r.status === 400);
  // تعرفه‌ی حوزه تغییر می‌کند و در رزرو بعدی اعمال می‌شود (نقشهٔ پنج‌حوزه‌ای CAP)
  r = await call('PUT', '/api/admin/settings', { hourly_tariffs: { tourism: 2000000, pilgrimage: 1400000, medical: 1685000, business: 1950000, legal: 1450000 }, car_fee_per_hour: 0 }, adm);
  check('تغییر تعرفه ذخیره شد', r.status === 200);
  const pr = await call('POST', '/api/traveler/bookings', { kind: 'instant', origin_lang: 'ar', dest_lang: 'fa', place: 'قیمت مدیر', traveler_name: 'A', category: 'tourism', hours: 1, car: false }, tokP);
  check('رزرو جدید با تعرفه‌ی تازه ثبت می‌شود', pr.status === 201 && pr.data.total === 2000000, JSON.stringify(pr.data && pr.data.total));
  await call('POST', `/api/traveler/bookings/${pr.data.id}/cancel`, null, tokP);
  await call('PUT', '/api/admin/settings', { hourly_tariffs: { tourism: 1350000, pilgrimage: 1400000, medical: 1685000, business: 1950000, legal: 1450000 }, car_fee_per_hour: 350000 }, adm);
  // کارمزد لغو پس از تطبیق
  await call('PUT', '/api/admin/settings', { cancel_fee_percent: 35 }, adm);
  await call('POST', '/api/dev/offline-all');
  const T10 = await makeTranslator(base + 42);
  await call('PATCH', '/api/translator/online', { online: true }, T10);
  const cb = await call('POST', '/api/traveler/bookings', { kind: 'instant', origin_lang: 'ar', dest_lang: 'fa', place: 'کارمزد مدیر', traveler_name: 'A' }, tokP);
  const co = (await call('GET', '/api/translator/offers', null, T10)).data.offers.find((o) => o.place === 'کارمزد مدیر');
  if (co) await call('POST', `/api/translator/offers/${co.id}/accept`, null, T10);
  const cc = await call('POST', `/api/traveler/bookings/${cb.data.id}/cancel`, null, tokP);
  check('کارمزد لغو تازه (۳۵٪) اعمال شد', co ? cc.data.fee_percent === 35 : false, JSON.stringify(cc.data));
  await call('PUT', '/api/admin/settings', { cancel_fee_percent: 20 }, adm);
  // روش پرداخت نقدی خاموش می‌شود
  await call('PUT', '/api/admin/settings', { cash_enabled: false }, adm);
  r = await call('GET', '/api/config');
  check('پیکربندی عمومی روش نقدی را خاموش نشان می‌دهد', r.data.payments && r.data.payments.CASH === false);
  await call('PUT', '/api/admin/settings', { cash_enabled: true }, adm);
  // بررسی مترجم: فقط از «در انتظار بررسی» تصمیم‌پذیر است
  r = await call('GET', '/api/admin/translators?status=active_general', null, adm);
  const cancelActor = (await call('GET', '/api/auth/me', null, T4)).data;
  check('جریمهٔ امتیاز لغو فقط یک بار اعمال شده است', r.data.translators.some(t => t.id === cancelActor.id && t.score === 95));
  check('فهرست مترجمان فعال خوانده می‌شود', r.status === 200 && Array.isArray(r.data.translators));
  const act = r.data.translators[0];
  if (act) {
    r = await call('POST', `/api/admin/translators/${act.id}/decision`, { decision: 'approve' }, adm);
    check('تصمیم روی مترجم غیرِ «در انتظار بررسی» ممنوع است', r.status === 409 && r.data.error === 'not_pending_review');
  }
  r = await call('POST', '/api/admin/logout', null, adm);
  r = await call('GET', '/api/admin/summary', null, adm);
  check('پس از خروج، نشست مدیر بی‌اعتبار است', r.status === 401);
  console.log('== ثبت‌نام مترجم روی سرور');
  const phR = phoneFor(base + 44);
  await call('POST', '/api/auth/request-code', { phone: phR, role: 'translator' });
  const trR = (await call('POST', '/api/auth/verify', { phone: phR, role: 'translator', code: '123456' })).data.token;
  const full = { nda: true, charter: true, gender: 'female', first_name: 'نرگس', last_name: 'احمدی', city: 'تهران', car: false, languages: ['ar', 'fa'], fields: ['general'] };
  r = await call('POST', '/api/translator/registration', { ...full, nda: false }, trR);
  check('ثبت‌نام بدون تعهدنامه‌ی محرمانگی پذیرفته نمی‌شود', r.status === 400 && r.data.error === 'consent_required');
  r = await call('POST', '/api/translator/registration', { ...full, gender: 'other' }, trR);
  check('جنسیت الزامی است', r.status === 400 && r.data.error === 'gender_required');
  r = await call('POST', '/api/translator/registration', { ...full, last_name: '' }, trR);
  check('نام و نام خانوادگی الزامی است', r.status === 400 && r.data.error === 'name_required');
  r = await call('POST', '/api/translator/registration', full, trR);
  check('ثبت کامل، پرونده را «در انتظار بررسی نهایی» می‌کند', r.status === 200 && r.data.status === 'pending_review', JSON.stringify(r.data));
  r = await call('GET', '/api/translator/status', null, trR);
  check('وضعیت مترجم در سرور «در انتظار بررسی نهایی» است', r.data.status === 'pending_review');
  r = await call('GET', '/api/translator/missions', null, trR);
  check('مترجم در انتظار بررسی به میز کار راه ندارد', r.status === 403);
  r = await call('POST', '/api/admin/login', { password: ADM });
  const adm2 = r.data.token;
  r = await call('GET', '/api/admin/translators?status=pending_review', null, adm2);
  const pendingR = (r.data.translators || []).find((t) => t.phone === phR);
  check("پرونده در فهرست بررسی مدیر دیده می‌شود", !!pendingR);
  if (pendingR) {
    r = await call('POST', `/api/admin/translators/${pendingR.id}/decision`, { decision: 'approve' }, adm2);
    await call('POST', `/api/admin/translators/${pendingR.id}/interview`, { result: 'pass' }, adm2);
    check('کارشناس مترجم را تأیید می‌کند', r.status === 200 && r.data.status === 'active_general');
    r = await call('GET', '/api/translator/status', null, trR);
    check('پس از تأیید، وضعیت مترجم فعال است', r.data.status === 'active_general');
    r = await call('POST', '/api/translator/registration', { ...full, car: true, car_model: 'پراید' }, trR);
    check('ثبت دوباره‌ی مترجم فعال، وضعیت را تغییر نمی‌دهد', r.status === 200 && r.data.status === 'active_general');
  }
  await call('PUT', '/api/admin/settings', { charter_text: 'منشور تست' }, adm2);
  r = await call('GET', '/api/config');
  check('متن منشور از پنل مدیریت به اپ مترجم می‌رسد', r.data.charter_text === 'منشور تست');
  await call('PUT', '/api/admin/settings', { charter_text: '' }, adm2);
  console.log('== زبان و زمینه‌ی مترجم در تطبیق');
  const phL = phoneFor(base + 45);
  await call('POST', '/api/auth/request-code', { phone: phL, role: 'translator' });
  const trL = (await call('POST', '/api/auth/verify', { phone: phL, role: 'translator', code: '123456' })).data.token;
  const reg = { nda: true, charter: true, gender: 'male', first_name: 'علی', last_name: 'کریمی', city: 'تهران', car: false };
  r = await call('POST', '/api/translator/registration', { ...reg, languages: [], fields: ['general'] }, trL);
  check('بدون زبان ثبت‌نام پذیرفته نمی‌شود', r.status === 400 && r.data.error === 'languages_required');
  r = await call('POST', '/api/translator/registration', { ...reg, languages: ['xx'], fields: ['general'] }, trL);
  check('زبان ناشناخته پذیرفته نمی‌شود', r.status === 400 && r.data.error === 'languages_required');
  r = await call('POST', '/api/translator/registration', { ...reg, languages: ['ar', 'fa'], fields: [] }, trL);
  check('بدون زمینه ثبت‌نام پذیرفته نمی‌شود', r.status === 400 && r.data.error === 'fields_required');
  r = await call('POST', '/api/translator/registration', { ...reg, languages: ['ar', 'fa'], fields: ['medical', 'nope'], interview_at: '1405-08-01 10:00' }, trL);
  check('ثبت با زبان و زمینه پذیرفته شد', r.status === 200 && JSON.stringify(r.data.languages) === '["ar","fa"]' && JSON.stringify(r.data.fields) === '["medical"]', JSON.stringify(r.data));
  r = await call('GET', '/api/admin/translators?status=pending_review', null, adm2);
  const pendL = (r.data.translators || []).find((t) => t.phone === phL);
  if (pendL) {
    await call('POST', `/api/admin/translators/${pendL.id}/decision`, { decision: 'approve' }, adm2);
    await call('POST', `/api/admin/translators/${pendL.id}/interview`, { result: 'pass' }, adm2);
  }
  await call('POST', '/api/dev/offline-all');
  await call('PATCH', '/api/translator/online', { online: true }, trL);
  const offerTo = async (place) => {
    const b = await call('POST', '/api/traveler/bookings', { kind: 'instant', origin_lang: 'ar', dest_lang: 'fa', field: 'legal', place, traveler_name: 'A' }, tokP);
    return b;
  };
  let bLegal = await call('POST', '/api/traveler/bookings', { kind: 'instant', origin_lang: 'ar', dest_lang: 'fa', field: 'legal', place: 'حقوقی تست', traveler_name: 'A' }, tokP);
  let offs = (await call('GET', '/api/translator/offers', null, trL)).data.offers || [];
  check('زمینه‌ی حقوقی به مترجم درمانی پیشنهاد نمی‌شود', !offs.some((o) => o.place === 'حقوقی تست'));
  await call('POST', `/api/traveler/bookings/${bLegal.data.id}/cancel`, null, tokP);
  let bEn = await call('POST', '/api/traveler/bookings', { kind: 'instant', origin_lang: 'en', dest_lang: 'fa', field: 'medical', place: 'انگلیسی تست', traveler_name: 'A' }, tokP);
  offs = (await call('GET', '/api/translator/offers', null, trL)).data.offers || [];
  check('زبان انگلیسی به مترجمی که انگلیسی ندارد پیشنهاد نمی‌شود', !offs.some((o) => o.place === 'انگلیسی تست'));
  await call('POST', `/api/traveler/bookings/${bEn.data.id}/cancel`, null, tokP);
  // نردبان CAP: مترجمِ درمانیِ بدون مدرک زبان، رزرو پزشکی نمی‌گیرد (گیت تخصص بسته است)
  let bMed = await call('POST', '/api/traveler/bookings', { kind: 'instant', origin_lang: 'ar', dest_lang: 'fa', field: 'medical', place: 'پزشکی تست', traveler_name: 'A' }, tokP);
  offs = (await call('GET', '/api/translator/offers', null, trL)).data.offers || [];
  check('رزرو پزشکی به مترجمِ بدون مدرک زبان پیشنهاد نمی‌شود (گیت تخصص)', !offs.some((o) => o.place === 'پزشکی تست'));
  await call('POST', `/api/traveler/bookings/${bMed.data.id}/cancel`, null, tokP);
  // مدرک زبان ارسال و تأیید می‌شود؛ گیت تخصص باز و پیشنهاد پزشکی می‌رسد
  r = await call('POST', '/api/translator/documents', { kind: 'lang_cert', data: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==' }, trL);
  check('مدرک زبان ارسال می‌شود', r.status === 200 && r.data.status === 'uploaded', JSON.stringify(r.data));
  const docsAdm = (await call('GET', '/api/admin/documents?status=uploaded', null, adm2)).data.documents || [];
  const certRow = docsAdm.find((d) => d.kind === 'lang_cert' && d.user_id === pendL.id);
  check('مدرک زبان در صف بررسی است', !!certRow);
  if (certRow) {
    r = await call('POST', `/api/admin/documents/${certRow.id}/decision`, { decision: 'approve' }, adm2);
    check('تأیید مدرک زبان گیت تخصص را باز می‌کند', r.status === 200);
  }
  bMed = await call('POST', '/api/traveler/bookings', { kind: 'instant', origin_lang: 'ar', dest_lang: 'fa', field: 'medical', place: 'پزشکی تست', traveler_name: 'A' }, tokP);
  offs = (await call('GET', '/api/translator/offers', null, trL)).data.offers || [];
  check('زمینه‌ی پزشکی به مترجم پزشکیِ دارای مدرک زبان پیشنهاد می‌شود', offs.some((o) => o.place === 'پزشکی تست'));
  await call('POST', `/api/traveler/bookings/${bMed.data.id}/cancel`, null, tokP);
  console.log('== مدارک مترجم');
  const PNG1 = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==';
  r = await call('POST', '/api/translator/documents', { kind: 'passport', data: PNG1 }, trL);
  check('نوع مدرک ناشناخته پذیرفته نمی‌شود', r.status === 400 && r.data.error === 'invalid_kind');
  r = await call('POST', '/api/translator/documents', { kind: 'nid_card', data: 'data:text/plain;base64,aGk=' }, trL);
  check('فایل با نوع غیرمجاز پذیرفته نمی‌شود', r.status === 400 && r.data.error === 'invalid_file_type');
  r = await call('POST', '/api/translator/documents', { kind: 'nid_card', data: 'data:image/png;base64,' + Buffer.alloc(6 * 1024 * 1024, 1).toString('base64') }, trL);
  check('فایل بزرگ‌تر از ۵ مگابایت پذیرفته نمی‌شود', r.status === 413);
  r = await call('POST', '/api/translator/documents', { kind: 'nid_card', data: PNG1 }, trL);
  check('کارت ملی آپلود شد', r.status === 200 && r.data.status === 'uploaded');
  r = await call('POST', '/api/translator/documents', { kind: 'nid_card', data: PNG1 }, trL);
  check('آپلود دوباره همان مدرک جایگزین می‌شود', r.status === 200);
  r = await call('GET', '/api/translator/documents', null, trL);
  const nid = (r.data.documents || []).filter((d) => d.kind === 'nid_card');
  check('فهرست مدرک فقط وضعیت را نشان می‌دهد (بدون محتوا)', nid.length === 1 && nid[0].status === 'uploaded' && !('data' in nid[0]) && !('blob' in nid[0]));
  r = await call('GET', '/api/admin/documents', null, adm2);
  const pending = (r.data.documents || []).filter((d) => d.kind === 'nid_card');
  check('مدرک در فهرست بررسی مدیر دیده می‌شود', pending.length >= 1);
  const myDoc = pending[pending.length - 1];
  r = await call('GET', `/api/admin/documents/${myDoc.id}/file`, null, adm2);
  check('تیم احراز فایل را باز می‌کند', r.status === 200 && r.data.data === PNG1);
  r = await call('POST', `/api/admin/documents/${myDoc.id}/decision`, { decision: 'reject' }, adm2);
  check('رد بدون دلیل پذیرفته نمی‌شود', r.status === 400 && r.data.error === 'reason_required');
  r = await call('POST', `/api/admin/documents/${myDoc.id}/decision`, { decision: 'reject', reason: 'تصویر ناخوانا است' }, adm2);
  r = await call('GET', '/api/translator/documents', null, trL);
  const rej = (r.data.documents || []).find((d) => d.kind === 'nid_card');
  check('رد مدرک با دلیل به مترجم نشان داده می‌شود', rej && rej.status === 'rejected' && rej.reject_reason === 'تصویر ناخوانا است');
  await call('POST', '/api/translator/documents', { kind: 'nid_card', data: PNG1 }, trL);
  r = await call('GET', '/api/admin/documents', null, adm2);
  const again = (r.data.documents || []).filter((d) => d.kind === 'nid_card').pop();
  r = await call('POST', `/api/admin/documents/${again.id}/decision`, { decision: 'approve' }, adm2);
  r = await call('GET', '/api/translator/documents', null, trL);
  const ok = (r.data.documents || []).find((d) => d.kind === 'nid_card');
  check('تأیید مدرک به مترجم نشان داده می‌شود', ok && ok.status === 'approved' && ok.reject_reason === '');
  console.log('== همراهی با خودرو');
  const phC = phoneFor(base + 46);
  await call('POST', '/api/auth/request-code', { phone: phC, role: 'translator' });
  const trC = (await call('POST', '/api/auth/verify', { phone: phC, role: 'translator', code: '123456' })).data.token;
  r = await call('POST', '/api/translator/registration', { nda: true, charter: true, gender: 'female', first_name: 'مریم', last_name: 'نوری', city: 'تهران', car: true, car_model: 'پراید', car_capacity: 3, languages: ['ar', 'fa'], fields: ['general'] }, trC);
  check('مترجم با خودرو ثبت‌نام کرد', r.status === 200);
  r = await call('GET', '/api/admin/translators?status=pending_review', null, adm2);
  const pendC = (r.data.translators || []).find((t) => t.phone === phC);
  if (pendC) {
    await call('POST', `/api/admin/translators/${pendC.id}/decision`, { decision: 'approve' }, adm2);
    await call('POST', `/api/admin/translators/${pendC.id}/interview`, { result: 'pass' }, adm2);
  }
  await call('POST', '/api/dev/offline-all');
  await call('PATCH', '/api/translator/online', { online: true }, trC);
  const PNG2 = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==';
  const approveDoc = async (kind) => {
    await call('POST', '/api/translator/documents', { kind, data: PNG2, expires_at: '2030-01-01' }, trC);
    const list = await call('GET', '/api/admin/documents', null, adm2);
    const d = (list.data.documents || []).filter((x) => x.kind === kind && x.phone === phC).pop();
    if (d) await call('POST', `/api/admin/documents/${d.id}/decision`, { decision: 'approve' }, adm2);
  };
  const carOffers = async (place) => (await call('GET', '/api/translator/offers', null, trC)).data.offers || [];
  r = await call('POST', '/api/translator/documents', { kind: 'licence', data: PNG2 }, trC);
  check('مدرک دارای انقضا بدون تاریخ پذیرفته نمی‌شود', r.status === 400 && r.data.error === 'expiry_required');
  r = await call('POST', '/api/translator/documents', { kind: 'licence', data: PNG2, expires_at: '2020-01-01' }, trC);
  check('تاریخ انقضای گذشته پذیرفته نمی‌شود', r.status === 400 && r.data.error === 'expiry_in_past');
  await call('POST', '/api/translator/documents', { kind: 'criminal_record', data: PNG2, expires_at: '2030-02-01' }, trC);
  r = await call('GET', '/api/translator/documents', null, trC);
  const crD = (r.data.documents || []).find((d) => d.kind === 'criminal_record');
  check('مدرک با انقضای دور، هشدار ندارد', crD && crD.expires_at && !crD.expiring_soon && !crD.expired);
  const soonDate = new Date(Date.now() + 10 * 86400000).toISOString().slice(0, 10);
  await call('POST', '/api/translator/documents', { kind: 'ipd_permit', data: PNG2, expires_at: soonDate }, trC);
  r = await call('GET', '/api/translator/documents', null, trC);
  const ipdD = (r.data.documents || []).find((d) => d.kind === 'ipd_permit');
  check('مدرک ۱۰ روز مانده به انقضا، هشدار دارد', ipdD && ipdD.expiring_soon === true);
  await approveDoc('car_docs');
  const bA = await call('POST', '/api/traveler/bookings', { kind: 'instant', origin_lang: 'ar', dest_lang: 'fa', field: 'general', car: true, place: 'خودرو تست الف', traveler_name: 'A' }, tokP);
  offs = await carOffers();
  check('با تأیید فقط مدارک خودرو، سواره پیشنهاد نمی‌شود', !offs.some((o) => o.place === 'خودرو تست الف'));
  await call('POST', `/api/traveler/bookings/${bA.data.id}/cancel`, null, tokP);
  await approveDoc('licence');
  const bB = await call('POST', '/api/traveler/bookings', { kind: 'instant', origin_lang: 'ar', dest_lang: 'fa', field: 'general', car: true, place: 'خودرو تست ب', traveler_name: 'A' }, tokP);
  offs = await carOffers();
  check('با تأیید مدارک خودرو و گواهینامه، سواره پیشنهاد می‌شود', offs.some((o) => o.place === 'خودرو تست ب'));
  await call('POST', `/api/traveler/bookings/${bB.data.id}/cancel`, null, tokP);
  const bBig = await call('POST', '/api/traveler/bookings', { kind: 'instant', origin_lang: 'ar', dest_lang: 'fa', field: 'general', car: true, party: 5, place: 'ظرفیت کم', traveler_name: 'A' }, tokP);
  offs = await carOffers();
  check('مسافران بیشتر از ظرفیت خودرو به این مترجم نمی‌رسد', !offs.some((o) => o.place === 'ظرفیت کم'));
  await call('POST', `/api/traveler/bookings/${bBig.data.id}/cancel`, null, tokP);
  const bFit = await call('POST', '/api/traveler/bookings', { kind: 'instant', origin_lang: 'ar', dest_lang: 'fa', field: 'general', car: true, party: 3, place: 'ظرفیت کافی', traveler_name: 'A' }, tokP);
  offs = await carOffers();
  check('مسافران در حد ظرفیت خودرو پیشنهاد می‌شود', offs.some((o) => o.place === 'ظرفیت کافی'));
  await call('POST', `/api/traveler/bookings/${bFit.data.id}/cancel`, null, tokP);
  const bP = await call('POST', '/api/traveler/bookings', { kind: 'instant', origin_lang: 'ar', dest_lang: 'fa', field: 'general', car: false, place: 'پیاده تست', traveler_name: 'A' }, tokP);
  offs = await carOffers();
  check('مأموریت پیاده برای همین مترجم هم دیده می‌شود', offs.some((o) => o.place === 'پیاده تست'));
  await call('POST', `/api/traveler/bookings/${bP.data.id}/cancel`, null, tokP);
  await call('POST', '/api/dev/expire-docs', null, trC);
  const bX = await call('POST', '/api/traveler/bookings', { kind: 'instant', origin_lang: 'ar', dest_lang: 'fa', field: 'general', car: true, place: 'خودرو منقضی', traveler_name: 'A' }, tokP);
  offs = await carOffers();
  check('مدارک منقضی شد؛ حالت خودرو خاموش و سواره پیشنهاد نمی‌شود', !offs.some((o) => o.place === 'خودرو منقضی'));
  await call('POST', `/api/traveler/bookings/${bX.data.id}/cancel`, null, tokP);
  r = await call('GET', '/api/translator/capability', null, trC);
  check('وضعیت صلاحیت: خودرو ثبت شده ولی پس از انقضا فعال نیست', r.status === 200 && r.data.dimensions.car.registered === true && r.data.dimensions.car.active === false);
  check('وضعیت صلاحیت: مدارک هویت کامل نیست و فهرست کمبودها داده می‌شود', r.data.dimensions.identity.ok === false && r.data.dimensions.identity.missing.includes('selfie'));
  // نردبان CAP: بُعد تخصص حالا با گیت «مدرک زبان» خوانده می‌شود
  check('وضعیت صلاحیت: گیت تخصص (مدرک زبان) در بُعد specialized گزارش می‌شود', r.data.dimensions.specialized && r.data.dimensions.specialized.gate === 'lang_cert');
  check('وضعیت صلاحیت: نردبان حوزه‌ها با وضعیت انتخاب/فعال برمی‌گردد', Array.isArray(r.data.ladder && r.data.ladder.fields) && r.data.ladder.fields.every((f) => typeof f.selected === 'boolean' && typeof f.active === 'boolean'));
  r = await call('GET', '/api/translator/capability', null, trL);
  check('وضعیت صلاحیت: مترجم بدون مدرک خودرو، خودرو فعال ندارد', r.data.dimensions.car.registered === false && r.data.dimensions.car.active === false);
  // پین‌کردن گیت تخصص در نردبان: مدرک زبانِ تأییدشده باید lang_cert=true و درهای تخصص را باز نشان دهد
  check('نردبان: مدرک زبان تأییدشده گیت تخصص را باز نشان می‌دهد', r.data.ladder && r.data.ladder.lang_cert === true && r.data.dimensions.specialized.ok === true, JSON.stringify(r.data.ladder));
  console.log('== مصاحبه‌ی زبان');
  const phI = phoneFor(base + 47);
  await call('POST', '/api/auth/request-code', { phone: phI, role: 'translator' });
  const trI = (await call('POST', '/api/auth/verify', { phone: phI, role: 'translator', code: '123456' })).data.token;
  await call('POST', '/api/translator/registration', { nda: true, charter: true, gender: 'male', first_name: 'حسین', last_name: 'احمدی', city: 'تهران', car: false, languages: ['ar', 'fa'], fields: ['general'] }, trI);
  r = await call('GET', '/api/admin/translators?status=pending_review', null, adm2);
  const pendI = (r.data.translators || []).find((t) => t.phone === phI);
  await call('POST', `/api/admin/translators/${pendI.id}/decision`, { decision: 'approve' }, adm2);
  r = await call('POST', `/api/admin/translators/${pendI.id}/interview`, { result: 'maybe' }, adm2);
  check('نتیجه‌ی نامعتبر مصاحبه پذیرفته نمی‌شود', r.status === 400);
  r = await call('POST', `/api/admin/translators/${pendI.id}/interview`, { result: 'retry' }, adm2);
  check('نیاز به تکرار ثبت می‌شود', r.status === 200);
  await call('POST', '/api/dev/offline-all');
  await call('PATCH', '/api/translator/online', { online: true }, trI);
  let bI = await call('POST', '/api/traveler/bookings', { kind: 'instant', origin_lang: 'ar', dest_lang: 'fa', field: 'general', place: 'مصاحبه تست الف', traveler_name: 'A' }, tokP);
  offs = (await call('GET', '/api/translator/offers', null, trI)).data.offers || [];
  check('مترجم «نیاز به تکرار» پیشنهاد نمی‌گیرد', !offs.some((o) => o.place === 'مصاحبه تست الف'));
  await call('POST', `/api/traveler/bookings/${bI.data.id}/cancel`, null, tokP);
  r = await call('POST', `/api/admin/translators/${pendI.id}/interview`, { result: 'pass' }, adm2);
  bI = await call('POST', '/api/traveler/bookings', { kind: 'instant', origin_lang: 'ar', dest_lang: 'fa', field: 'general', place: 'مصاحبه تست ب', traveler_name: 'A' }, tokP);
  offs = (await call('GET', '/api/translator/offers', null, trI)).data.offers || [];
  check('پس از قبولی در مصاحبه پیشنهاد می‌گیرد', offs.some((o) => o.place === 'مصاحبه تست ب'));
  await call('POST', `/api/traveler/bookings/${bI.data.id}/cancel`, null, tokP);
  r = await call('GET', '/api/translator/capability', null, trI);
  check('بُعد زبان با نتیجه‌ی مصاحبه هماهنگ است', r.data.dimensions.language.ok === true && r.data.dimensions.language.interview === 'pass');
  console.log('== یادآوری انقضا');
  const phN = phoneFor(base + 48);
  await call('POST', '/api/auth/request-code', { phone: phN, role: 'translator' });
  const trN = (await call('POST', '/api/auth/verify', { phone: phN, role: 'translator', code: '123456' })).data.token;
  await call('POST', '/api/translator/registration', { nda: true, charter: true, gender: 'female', first_name: 'یاسمن', last_name: 'رحیمی', city: 'مشهد', car: false, languages: ['ar', 'fa'], fields: ['general'] }, trN);
  r = await call('GET', '/api/admin/translators?status=pending_review', null, adm2);
  const pendN = (r.data.translators || []).find((t) => t.phone === phN);
  await call('POST', `/api/admin/translators/${pendN.id}/decision`, { decision: 'approve' }, adm2);
  const PNG3 = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==';
  const soonN = new Date(Date.now() + 10 * 86400000).toISOString().slice(0, 10);
  await call('POST', '/api/translator/documents', { kind: 'ipd_permit', data: PNG3, expires_at: soonN }, trN);
  let listN = await call('GET', '/api/admin/documents?status=uploaded', null, adm2);
  const ipdN = (listN.data.documents || []).find((d) => d.kind === 'ipd_permit' && d.phone === phN);
  check('مدرک ۱۰ روز مانده تا تأیید هیچ یادآوری ندارد', (await call('GET', '/api/translator/notifications', null, trN)).data.notifications.length === 0);
  await call('POST', `/api/admin/documents/${ipdN.id}/decision`, { decision: 'approve' }, adm2);
  r = await call('GET', '/api/translator/notifications', null, trN);
  const expN = (r.data.notifications || []).filter((n) => n.kind === 'expiring');
  check('پس از تأیید، یادآوری «۳۰ روز مانده» ساخته می‌شود', expN.length === 1 && expN[0].doc_kind === 'ipd_permit' && expN[0].doc_name === 'مجوز ورود IPD');
  r = await call('GET', '/api/translator/notifications', null, trN);
  check('یادآوری برای هر مدرک یک‌بار ساخته می‌شود', (r.data.notifications || []).filter((n) => n.kind === 'expiring').length === 1);
  await call('POST', '/api/dev/expire-docs', null, trN);
  r = await call('GET', '/api/translator/notifications', null, trN);
  check('پس از انقضا، یادآوری «منقضی» ساخته می‌شود', (r.data.notifications || []).some((n) => n.kind === 'expired'));
  check('متن یادآوری فارسی و قابل‌فهم است', (r.data.notifications || []).every((n) => n.text.length > 10));
  console.log('== نوبت مصاحبه');
  const phS = phoneFor(base + 49);
  await call('POST', '/api/auth/request-code', { phone: phS, role: 'translator' });
  const trS = (await call('POST', '/api/auth/verify', { phone: phS, role: 'translator', code: '123456' })).data.token;
  await call('POST', '/api/translator/registration', { nda: true, charter: true, gender: 'male', first_name: 'کاوه', last_name: 'نیکزاد', city: 'تبریز', car: false, languages: ['en', 'fa'], fields: ['general'] }, trS);
  const pastS = Date.now() - 3600000;
  const soonS = Date.now() + 30 * 60000;
  const laterS = Date.now() + 3 * 3600000;
  r = await call('POST', '/api/admin/interview-slots', { starts_at: new Date(pastS).toISOString() }, adm2);
  check('نوبت گذشته ساخته نمی‌شود', r.status === 400 && r.data.error === 'time_in_past');
  r = await call('POST', '/api/admin/interview-slots', { starts_at: 'bad' }, adm2);
  check('زمان نامعتبر رد می‌شود', r.status === 400 && r.data.error === 'invalid_time');
  const slotA = (await call('POST', '/api/admin/interview-slots', { starts_at: new Date(soonS).toISOString() }, adm2)).data.id;
  const slotB = (await call('POST', '/api/admin/interview-slots', { starts_at: new Date(laterS).toISOString() }, adm2)).data.id;
  r = await call('GET', '/api/translator/interview-slots', null, trS);
  check('مترجم فقط نوبت‌های آزاد آینده را می‌بیند', r.data.slots.some((s) => s.id === slotA) && r.data.slots.some((s) => s.id === slotB) && r.data.booking === null);
  r = await call('POST', `/api/translator/interview-slots/${slotB}/book`, null, trS);
  check('رزرو نوبت آزاد پذیرفته می‌شود', r.status === 200);
  r = await call('POST', `/api/translator/interview-slots/${slotA}/book`, null, trS);
  check('دو نوبت هم‌زمان برای یک مترجم مجاز نیست', r.status === 409 && r.data.error === 'already_booked');
  r = await call('GET', '/api/translator/interview/room', null, trS);
  check('اتاق ویدئویی وجود ندارد (هماهنگی با یادداشت مدیر)', r.status === 404);
  r = await call('POST', `/api/admin/interview-slots/${slotB}/no-show`, null, adm2);
  check('عدم حضور نوبت را آزاد می‌کند', r.status === 200 && r.data.status === 'no_show');
  r = await call('POST', `/api/admin/interview-slots/${slotA}/no-show`, null, adm2);
  check('عدم حضور روی نوبت آزاد پذیرفته نیست', r.status === 409);
  r = await call('POST', `/api/translator/interview-slots/${slotA}/book`, null, trS);
  check('پس از عدم حضور، مترجم دوباره نوبت می‌گیرد', r.status === 200);
  r = await call('GET', '/api/translator/interview-slots', null, trS);
  check('نوبت رزرو شده، یادداشت هماهنگی را نشان می‌دهد', r.data.booking && typeof r.data.booking.note === 'string');
  r = await call('GET', '/api/translator/notifications', null, trS);
  check('یادآوری مصاحبه ساخته می‌شود', (r.data.notifications || []).some((n) => n.kind === 'interview_reminder'));
  r = await call('GET', '/api/translator/notifications', null, trS);
  check('یادآوری مصاحبه یک‌بار ساخته می‌شود', (r.data.notifications || []).filter((n) => n.kind === 'interview_reminder').length === 1);
  const ivS = await call('POST', `/api/admin/translators/${(await call('GET', '/api/admin/translators', null, adm2)).data.translators.find((t) => t.phone === phS).id}/interview`, { result: 'pass' }, adm2);
  check('نتیجه‌ی قبولی ثبت می‌شود', ivS.status === 200);
  r = await call('POST', `/api/translator/interview-slots/${slotA}/book`, null, trS);
  check('مترجم قبول‌شده نوبت مصاحبه نمی‌گیرد', r.status === 409 && r.data.error === 'already_passed');
  console.log('== تفکیک مالیات');
  // خدمت + مالیات = کل؛ نرخ مالیات از پنل مدیر خوانده می‌شود و هر رزرو مقدار زمان ثبت خودش را نگه می‌دارد
  r = await call('PUT', '/api/admin/settings', { tax_percent: 0 }, adm2);
  r = await call('POST', '/api/traveler/bookings', { kind: 'instant', origin_lang: 'ar', dest_lang: 'fa', place: 'مالیات صفر', traveler_name: 'Ali' }, tokP);
  const bz = r.data;
  check('بدون مالیات: کل برابر خدمت است', bz.base > 0 && bz.tax === 0 && bz.total === bz.base);
  await call('PUT', '/api/admin/settings', { tax_percent: 10 }, adm2);
  r = await call('POST', '/api/traveler/bookings', { kind: 'instant', origin_lang: 'ar', dest_lang: 'fa', place: 'مالیات ده', traveler_name: 'Ali' }, tokP);
  const bt = r.data;
  check('با نرخ ۱۰٪: مالیات روی خدمت محاسبه می‌شود', bt.tax === Math.round(bt.base * 0.1) && bt.total === bt.base + bt.tax);
  check('نمای مسافر خدمت و مالیات را جدا نشان می‌دهد', typeof bt.base === 'number' && typeof bt.tax === 'number');
  r = await call('GET', '/api/traveler/bookings', null, tokP);
  const bz2 = (r.data.bookings || []).find((x) => x.id === bz.id);
  check('رزرو قبلی با نرخ قبلی ماندگار است', bz2 && bz2.tax === 0 && bz2.total === bz.total);
  await call('PUT', '/api/admin/settings', { tax_percent: 0 }, adm2);
  console.log('== تعرفه و جفت‌زبان (پنل مدیر)');
  const origPairs = (await call('GET', '/api/admin/settings', null, adm2)).data.settings.language_pairs.value;
  r = await call('GET', '/api/config', null, null);
  check('پیکربندی عمومی تعرفه‌ها را می‌دهد', r.data.tariffs && r.data.tariffs.hourly.medical === 1685000 && r.data.tariffs.car_fee_per_hour === 350000);
  check('پیکربندی عمومی فقط جفت‌زبان‌های فعال را می‌دهد', Array.isArray(r.data.language_pairs) && r.data.language_pairs.length === 6);
  r = await call('PUT', '/api/admin/settings', { hourly_tariffs: { general: -5, medical: 1, business: 1, tourism: 1 } }, adm2);
  check('تعرفه‌ی منفی پذیرفته نمی‌شود', r.status === 400);
  r = await call('PUT', '/api/admin/settings', { language_pairs: [{ code: 'xx-fa', label: 'x', note: '', langs: ['xx', 'fa'], enabled: true }] }, adm2);
  check('زبان ناشناخته در جفت‌زبان پذیرفته نمی‌شود', r.status === 400);
  r = await call('PUT', '/api/admin/settings', { language_pairs: [{ code: 'tr-fa', label: 'ترکی', note: '', langs: ['tr', 'fa'], enabled: false }] }, adm2);
  check('جفت‌زبان با ساختار درست ذخیره می‌شود', r.status === 200);
  r = await call('GET', '/api/config', null, null);
  check('جفت‌زبان غیرفعال از پیکربندی عمومی حذف می‌شود', r.data.language_pairs.length === 0);
  // قیمت سرور: (تعرفه + خودرو) × ساعت
  r = await call('PUT', '/api/admin/settings', { language_pairs: [{ code: 'ar-fa', label: 'عربی ⟷ فارسی', note: 'خلیجی، عراقی و فصیح', langs: ['ar', 'fa'], enabled: true }, { code: 'en-fa', label: 'انگلیسی ⟷ فارسی', note: 'مکالمه‌ی تخصصی و اداری', langs: ['en', 'fa'], enabled: true }] }, adm2);
  r = await call('POST', '/api/traveler/bookings', { kind: 'instant', origin_lang: 'ar', dest_lang: 'fa', place: 'تعرفه پزشکی', traveler_name: 'Ali', category: 'medical', hours: 2, car: false }, tokP);
  check('قیمت پزشکی دو ساعته بدون خودرو از تعرفه‌ی پنل است', r.data.base === 3370000 && r.data.total === 3370000);
  r = await call('POST', '/api/traveler/bookings', { kind: 'instant', origin_lang: 'ar', dest_lang: 'fa', place: 'تعرفه با خودرو', traveler_name: 'Ali', category: 'legal', hours: 1, car: true }, tokP);
  check('خودرو هزینه‌ی ساعتی جدا دارد', r.data.base === 1800000);
  await call('PUT', '/api/admin/settings', { hourly_tariffs: { tourism: 1350000, pilgrimage: 1400000, medical: 1685000, business: 1950000, legal: 1000000 }, car_fee_per_hour: 0 }, adm2);
  r = await call('POST', '/api/traveler/bookings', { kind: 'instant', origin_lang: 'ar', dest_lang: 'fa', place: 'تعرفه تازه', traveler_name: 'Ali', category: 'legal', hours: 1, car: true }, tokP);
  check('تغییر تعرفه در پنل فوراً در قیمت سرور اعمال می‌شود', r.data.base === 1000000);
  await call('PUT', '/api/admin/settings', { hourly_tariffs: { tourism: 1350000, pilgrimage: 1400000, medical: 1685000, business: 1950000, legal: 1450000 }, car_fee_per_hour: 350000 }, adm2);
  await call('PUT', '/api/admin/settings', { language_pairs: JSON.parse(origPairs) }, adm2);
  console.log('== حذف حساب');
  const pDel = phoneFor(base + 77);
  await call('POST', '/api/auth/request-code', { phone: pDel, role: 'traveler' });
  const tokDel = (await call('POST', '/api/auth/verify', { phone: pDel, role: 'traveler', code: '123456' })).data.token;
  const bkDel = await call('POST', '/api/traveler/bookings', { kind: 'instant', origin_lang: 'ar', dest_lang: 'fa', place: 'حذف حساب', traveler_name: 'Del' }, tokDel);
  r = await call('DELETE', '/api/auth/account', null, tokDel);
  check('حذف حساب با رزرو باز ممکن نیست', r.status === 409 && r.data.error === 'active_items', JSON.stringify(r));
  await call('POST', `/api/traveler/bookings/${bkDel.data.id}/cancel`, null, tokDel);
  r = await call('DELETE', '/api/auth/account', null, tokDel);
  check('حذف حساب بدون کار باز انجام می‌شود', r.status === 200 && r.data.ok === true, JSON.stringify(r));
  r = await call('GET', '/api/auth/me', null, tokDel);
  check('پس از حذف حساب، نشست قبلی بی‌اعتبار است', r.status === 401);
  await call('POST', '/api/auth/request-code', { phone: pDel, role: 'traveler' });
  const tokDel2 = (await call('POST', '/api/auth/verify', { phone: pDel, role: 'traveler', code: '123456' })).data.token;
  check('با همان شماره می‌توان حساب تازه ساخت', !!tokDel2);
  r = await call('DELETE', '/api/auth/account', null, tokDel2);
  check('حذف حساب تازه‌ی بدون سابقه هم ممکن است', r.status === 200);
  const tokTrDel = await makeTranslator(base + 78);
  r = await call('DELETE', '/api/auth/account', null, tokTrDel);
  check('حذف حساب مترجم بدون مأموریت باز ممکن است', r.status === 200, JSON.stringify(r));

  console.log('== خروج واقعی نشست‌ها');
  async function sessionFor(phone, role = 'traveler') {
    const requested = await call('POST', '/api/auth/request-code', { phone, role });
    if (requested.status !== 200) throw new Error('Session setup failed: ' + JSON.stringify(requested));
    const verified = await call('POST', '/api/auth/verify', { phone, role, code: '123456' });
    if (verified.status !== 200 || !verified.data.token) throw new Error('Session setup failed: ' + JSON.stringify(verified));
    return verified.data;
  }
  const sessionA = await sessionFor(phoneFor(base + 80));
  const sessionB = await sessionFor(phoneFor(base + 80));
  const sessionC = await sessionFor(phoneFor(base + 80));
  const otherAccount = await sessionFor(phoneFor(base + 81));
  const otherRole = await sessionFor(phoneFor(base + 80), 'translator');
  check('سه نشست مستقل برای یک حساب ساخته می‌شود', sessionA.user.id === sessionB.user.id && sessionB.user.id === sessionC.user.id && new Set([sessionA.token, sessionB.token, sessionC.token]).size === 3);
  r = await call('POST', '/api/auth/logout-all', { user_id: sessionA.user.id });
  check('خروج همه بدون احراز هویت رد می‌شود', r.status === 401);
  r = await call('POST', '/api/auth/logout-all', null, 'bogus');
  check('خروج همه با توکن نامعتبر رد می‌شود', r.status === 401);
  r = await call('GET', '/api/auth/me', null, sessionA.token);
  check('درخواست بی‌مجوز نشست دیگران را باطل نمی‌کند', r.status === 200);
  r = await call('GET', '/api/auth/logout-all', null, sessionA.token);
  check('خروج همه با GET اجرا نمی‌شود', r.status !== 200);
  const fallbackMe = await fetch(BASE + '/api/auth/me', { headers: { 'X-Auth-Token': sessionA.token } });
  check('نشست با سرصفحه جایگزین معتبر است', fallbackMe.status === 200);
  const fallbackLogout = await fetch(BASE + '/api/auth/logout', { method: 'POST', headers: { 'X-Auth-Token': sessionA.token } });
  check('خروج تکی با سرصفحه جایگزین تأیید می‌شود', fallbackLogout.status === 200 && (await fallbackLogout.json()).ok === true);
  r = await call('GET', '/api/auth/me', null, sessionA.token);
  check('خروج تکی فقط همان توکن را واقعاً باطل می‌کند', r.status === 401);
  r = await call('GET', '/api/auth/me', null, sessionB.token);
  check('نشست دوم پس از خروج تکی معتبر است', r.status === 200);
  r = await call('GET', '/api/auth/me', null, sessionC.token);
  check('نشست سوم پس از خروج تکی معتبر است', r.status === 200);
  const fallbackBookings = await fetch(BASE + '/api/traveler/bookings', { headers: { 'X-Auth-Token': sessionC.token } });
  check('دریافت رزروهای مسافر با سرصفحه جایگزین معتبر است', fallbackBookings.status === 200);
  r = await call('POST', '/api/auth/logout', null, sessionA.token);
  check('خروج تکی تکراری بی‌خطر است', r.status === 200 && r.data.ok === true);
  // A supplied target is deliberately ignored: only the caller's account is affected.
  const allLogout = await fetch(BASE + '/api/auth/logout-all', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Auth-Token': sessionB.token }, body: JSON.stringify({ user_id: otherAccount.user.id }) });
  check('خروج همه با سرصفحه جایگزین تأیید می‌شود', allLogout.status === 200 && (await allLogout.json()).ok === true);
  r = await call('GET', '/api/auth/me', null, sessionB.token);
  check('خروج همه نشست فراخواننده را باطل می‌کند', r.status === 401);
  r = await call('GET', '/api/auth/me', null, sessionC.token);
  check('خروج همه نشست هم‌زمان دیگر را باطل می‌کند', r.status === 401);
  r = await call('GET', '/api/traveler/bookings', null, sessionC.token);
  check('نشست باطل‌شده دیگر به رزروها دسترسی ندارد', r.status === 401);
  r = await call('GET', '/api/auth/me', null, otherAccount.token);
  check('شناسه ارسالی نمی‌تواند نشست حساب دیگری را باطل کند', r.status === 200);
  r = await call('GET', '/api/auth/me', null, otherRole.token);
  check('حساب نقش دیگر با همان شماره مستقل می‌ماند', r.status === 200 && r.data.role === 'translator');
  r = await call('POST', '/api/auth/logout-all', null, sessionB.token);
  check('توکن باطل‌شده مجوز خروج همه ندارد', r.status === 401);
  const newSession = await sessionFor(phoneFor(base + 80));
  r = await call('GET', '/api/auth/me', null, newSession.token);
  check('پس از خروج همه می‌توان نشست تازه ساخت', r.status === 200);

  console.log('== خروج و فایل‌ها');
  r = await call('POST', '/api/auth/logout', null, tokT);
  r = await call('GET', '/api/auth/me', null, tokT);
  check('پس از خروج توکن بی‌اعتبار است', r.status === 401);
  const f = await fetch(BASE + '/traveler/index.html');
  check('فایل استاتیک مسافر سرو می‌شود', f.status === 200);
  const t = await fetch(BASE + '/translator/index.html');
  check('فایل استاتیک ورود/ثبت‌نام مترجم سرو می‌شود', t.status === 200);
  const translatorApp = await fetch(BASE + '/translator/app.html');
  const translatorAppHTML = await translatorApp.text();
  check('میزکار مترجم پس از ورود در دسترس است', translatorApp.status === 200 && /id="mission-sheet"/.test(translatorAppHTML));
  const trav = await fetch(BASE + '/traveler/..%2fserver%2fserver.js');
  check('مسیر خارج از پوشه مسدود است', trav.status !== 200);

  console.log('== مقاومت در برابر URL بدفرم (بازبینی: یافتهٔ بحرانی ۱)');
  // هر دو مسیر قبلاً با یک درخواست، کل سرور را با unhandledRejection می‌انداختند
  const badStatic = await fetch(BASE + '/traveler/%zz');
  check('استاتیک بدفرم ۴۰۰ می‌دهد نه کرش', badStatic.status === 400, String(badStatic.status));
  const badApi = await call('POST', '/api/traveler/bookings/%zz/cancel', null, tokP);
  check('پارامتر API بدفرم ۴۰۰ می‌دهد نه کرش', badApi.status === 400 && badApi.data.error === 'invalid_encoding', JSON.stringify(badApi));
  const badNul = await fetch(BASE + '/traveler/%00');
  check('بایت صفر در مسیر ۴۰۰ می‌دهد', badNul.status === 400, String(badNul.status));
  await new Promise((res) => setTimeout(res, 150));
  const alive = await fetch(BASE + '/api/config');
  check('سرور پس از درخواست‌های بدفرم زنده است', alive.status === 200, String(alive.status));

  console.log('== ثبت‌نام با فیلدهای هویتی و زبان‌های گسترده (یافته‌های ۴ و ۵)');
  const phIdF = phoneFor(base + 60);
  await call('POST', '/api/auth/request-code', { phone: phIdF, role: 'translator' });
  const tokIdF = (await call('POST', '/api/auth/verify', { phone: phIdF, role: 'translator', code: '123456' })).data.token;
  r = await call('POST', '/api/translator/registration', { nda: true, charter: true, gender: 'male', first_name: 'آرش', last_name: 'کمانگیر', city: 'تهران', car: false,
    languages: ['tr', 'fa'], fields: ['general'], national_code: '0012345678', birth_date: '1370/05/20', iban: '123456789012345678901234' }, tokIdF);
  check('ثبت‌نام با زبان ترکی پذیرفته می‌شود (هماهنگ با جفت‌زبان‌های مدیر)', r.status === 200, JSON.stringify(r));
  r = await call('POST', '/api/translator/registration', { nda: true, charter: true, gender: 'male', first_name: 'آرش', last_name: 'کمانگیر', city: 'تهران', car: false,
    languages: ['fa'], fields: ['general'], national_code: '12345' }, tokIdF);
  check('کد ملی ناقص رد می‌شود', r.status === 400 && r.data.error === 'national_code_invalid', JSON.stringify(r));
  r = await call('POST', '/api/translator/registration', { nda: true, charter: true, gender: 'male', first_name: 'آرش', last_name: 'کمانگیر', city: 'تهران', car: false,
    languages: ['fa'], fields: ['general'], iban: '1234' }, tokIdF);
  check('شبای ناقص رد می‌شود', r.status === 400 && r.data.error === 'iban_invalid', JSON.stringify(r));

  console.log('== سقف یکسان مدت (یافتهٔ ۶)');
  const phDurF = phoneFor(base + 61);
  await call('POST', '/api/auth/request-code', { phone: phDurF, role: 'traveler' });
  const tokDurF = (await call('POST', '/api/auth/verify', { phone: phDurF, role: 'traveler', code: '123456' })).data.token;
  r = await call('POST', '/api/traveler/bookings', { kind: 'instant', origin_lang: 'ar', dest_lang: 'fa', place: 'سقف مدت', traveler_name: 'Q', hours: 30 }, tokDurF);
  check('ساعت ایجاد به سقف ۱۲ محدود می‌شود', r.status === 201 && r.data.hours === 12, JSON.stringify(r.data && r.data.hours));
  r = await call('POST', `/api/traveler/bookings/${r.data.id}/change`, { hours: 2.5 }, tokDurF);
  const bkDurF = (await call('GET', '/api/traveler/bookings', null, tokDurF)).data.bookings.find((b) => b.place === 'سقف مدت');
  check('ویرایش مدت صحیح است و به ۱۲ محدود می‌شود', r.status === 200 && bkDurF.hours === 2, JSON.stringify(bkDurF && bkDurF.hours));
  r = await call('POST', `/api/traveler/bookings/${bkDurF.id}/change`, { hours: 24 }, tokDurF);
  const bkDurF2 = (await call('GET', '/api/traveler/bookings', null, tokDurF)).data.bookings.find((b) => b.id === bkDurF.id);
  check('ویرایش ۲۴ ساعته به ۱۲ محدود می‌شود (هماهنگ با تمدید)', r.status === 200 && bkDurF2.hours === 12, JSON.stringify(bkDurF2 && bkDurF2.hours));
  await call('POST', `/api/traveler/bookings/${bkDurF.id}/cancel`, null, tokDurF);

  // پاکسازی: مترجم‌های تست آفلاین شوند تا پیشنهادهای تست‌های بعدی را نگیرند
  await call('PATCH', '/api/translator/online', { online: false }, T1);
  await call('PATCH', '/api/translator/online', { online: false }, T2);
  console.log(`\nنتیجه: ${passed} موفق، ${failed} ناموفق`);
  process.exit(failed ? 1 : 0);
}
main().catch((e) => { console.error(e); process.exit(1); });
