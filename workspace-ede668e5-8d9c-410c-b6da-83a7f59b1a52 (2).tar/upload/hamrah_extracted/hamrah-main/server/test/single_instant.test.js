'use strict';
/* تست گارد رزرو فوری همپوشان (کلید ادمین single_active_instant):
 * - پیش‌فرض خاموش است (سازگار با جریان‌های فعلی)؛ ادمین می‌تواند از پنل روشن کند.
 * - روشن: رزرو فوری دوم وقتی مأموریت جاری وجود دارد ۴۰۹ می‌گیرد؛ رزرو زمان‌داد مانع نیست
 *   و رزرو زمان‌دار هم برای مسافرِ دارای جست‌وجوی فوری باز است.
 * اجرا مثل api.test.js:
 *   HZ_DEV=1 HZ_ADMIN_PASSWORD=test-admin-pass HZ_DB=/tmp/hz_si.sqlite PORT=8082 node server.js
 *   BASE=http://127.0.0.1:8082 node test/single_instant.test.js
 */
const BASE = process.env.BASE || 'http://127.0.0.1:8082';
let passed = 0, failed = 0;
function check(name, ok, extra = '') {
  if (ok) { passed++; console.log('  ok   ' + name); }
  else { failed++; console.log('  FAIL ' + name + (extra ? '  [' + extra + ']' : '')); }
}
async function call(method, p, body, token) {
  const headers = { 'Content-Type': 'application/json' };
  if (token) headers.Authorization = 'Bearer ' + token;
  const r = await fetch(BASE + p, { method, headers, body: body ? JSON.stringify(body) : undefined });
  let data = null; try { data = await r.json(); } catch (e) { /* non-json */ }
  return { status: r.status, data };
}
const phoneFor = (n) => '914' + String(2000000 + n).slice(-7);

async function makeTraveler(n) {
  const phone = phoneFor(n);
  await call('POST', '/api/auth/request-code', { phone, role: 'traveler' });
  const v = await call('POST', '/api/auth/verify', { phone, role: 'traveler', code: '123456' });
  return v.data.token;
}
const instant = (place) => ({ kind: 'instant', origin_lang: 'ar', dest_lang: 'fa', place, traveler_name: 'گارد' });
const scheduled = (place) => {
  const at = new Date(Date.now() + 3 * 86400000).toISOString(); // سه روز بعد — بیرون از پنجرهٔ matching
  return { kind: 'scheduled', origin_lang: 'ar', dest_lang: 'fa', place, traveler_name: 'گارد', scheduled_at: at };
};

(async () => {
  const adm = (await call('POST', '/api/admin/login', { password: process.env.ADMIN_PASSWORD || 'test-admin-pass' })).data.token;
  check('ورود مدیر', !!adm);
  const ptok = await makeTraveler(1);
  check('ثبت مسافر', !!ptok);

  // --- پیش‌فرض: خاموش — دو رزرو فوری پشت‌سرهم مجاز است (سازگاری با جریان‌های فعلی)
  const b1 = await call('POST', '/api/traveler/bookings', instant('پیش‌فرض الف'), ptok);
  check('پیش‌فرض خاموش: رزرو فوری اول ۲۰۱', b1.status === 201 && !!b1.data.id, 'status=' + b1.status);
  const b2 = await call('POST', '/api/traveler/bookings', instant('پیش‌فرض ب'), ptok);
  check('پیش‌فرض خاموش: رزرو فوری دوم هم ۲۰۱', b2.status === 201 && !!b2.data.id, 'status=' + b2.status);
  await call('POST', `/api/traveler/bookings/${b1.data.id}/cancel`, null, ptok);
  await call('POST', `/api/traveler/bookings/${b2.data.id}/cancel`, null, ptok);

  // --- وابستگی فیچر: خاموش‌کردن instant_booking نباید اجازهٔ روشن‌کردن گارد را بدهد
  const dep = await call('PUT', '/api/admin/features', { instant_booking: false, single_active_instant: true }, adm);
  check('وابستگی: روشن‌کردن گارد با instant_booking خاموش ۴۰۹', dep.status === 409 && dep.data.error === 'dependency_off',
    JSON.stringify(dep.data));
  const restore = await call('PUT', '/api/admin/features', { instant_booking: true }, adm);
  check('بازگردانی instant_booking', restore.status === 200);

  // --- روشن‌کردن گارد از پنل ادمین
  const on = await call('PUT', '/api/admin/features', { single_active_instant: true }, adm);
  check('روشن‌کردن گارد از پنل', on.status === 200 && on.data.ok === true && Array.isArray(on.data.changed) &&
    on.data.changed.includes('single_active_instant'), JSON.stringify(on.data));

  // --- گارد فعال: رزرو فوری دوم بسته است
  const a = await call('POST', '/api/traveler/bookings', instant('گارد الف'), ptok);
  check('رزرو فوری اول با گارد روشن ۲۰۱', a.status === 201 && !!a.data.id, 'status=' + a.status);
  const dup = await call('POST', '/api/traveler/bookings', instant('گارد ب'), ptok);
  check('رزرو فوری دوم ۴۰۹ overlapping_instant', dup.status === 409 && dup.data.error === 'overlapping_instant',
    'status=' + dup.status + ' body=' + JSON.stringify(dup.data));
  check('پاسخ ۴۰۹ شناسهٔ رزرو فعال و وضعیتش را می‌دهد',
    dup.data && dup.data.reservation_id === a.data.id && dup.data.active_status === 'searching',
    JSON.stringify(dup.data));

  // --- رزرو زمان‌دار برای همان مسافر مجاز است (آینده است، مأموریت جاری نیست)
  const sch = await call('POST', '/api/traveler/bookings', scheduled('زمان‌دار با گارد'), ptok);
  check('رزرو زمان‌دار در حین جست‌وجوی فوری ۲۰۱', sch.status === 201, 'status=' + sch.status + ' body=' + JSON.stringify(sch.data));

  // --- رزرو فوری برای مسافر دیگر مجاز است (مسافر دوم)
  const ptok2 = await makeTraveler(2);
  const other = await call('POST', '/api/traveler/bookings', instant('مسافر دیگر'), ptok2);
  check('رزرو فوری مسافر دیگر مستقل است', other.status === 201, 'status=' + other.status);

  // --- لغو مأموریت جاری مسیر را باز می‌کند
  await call('POST', `/api/traveler/bookings/${a.data.id}/cancel`, null, ptok);
  const afterCancel = await call('POST', '/api/traveler/bookings', instant('بعد از لغو'), ptok);
  check('بعد از لغو، رزرو فوری جدید ۲۰۱', afterCancel.status === 201, 'status=' + afterCancel.status);

  // --- no_match مانع نیست: انقضای پنجرهٔ جست‌وجو با HZ_TIME_SCALE شبیه‌سازی نمی‌کنیم؛
  // به‌جای آن لغو را همین‌جا پوشش دادیم و وضعیت no_match در timing.test.js پوشش داده می‌شود.

  // --- خاموش‌کردن دوبارهٔ گارد: رفتار قبلی برمی‌گردد
  const off = await call('PUT', '/api/admin/features', { single_active_instant: false }, adm);
  check('خاموش‌کردن گارد', off.status === 200);
  const afterOff = await call('POST', '/api/traveler/bookings', instant('بعد از خاموشی'), ptok);
  check('با گارد خاموش، رزرو فوری دوم دوباره ۲۰۱', afterOff.status === 201, 'status=' + afterOff.status);

  // --- فیچر در فهرست قابلیت‌های ادمین با پیش‌فرض خاموش گزارش می‌شود
  const fl = await call('GET', '/api/admin/features', null, adm);
  const f = (fl.data.features || []).find((x) => x.key === 'single_active_instant');
  check('فیچر در فهرست ادمین هست و implemented است', !!f && f.implemented === true && f.enabled === false,
    JSON.stringify(f));

  console.log(`\nنتیجه: ${passed} پاس، ${failed} خطا`);
  process.exit(failed ? 1 : 0);
})().catch((e) => { console.error('اجرای تست شکست خورد:', e); process.exit(1); });
