'use strict';
/* ============================================================
   همراه — کنسول عملیات (نسل سوم) — منطق سمت کلاینت
   همهٔ داده‌ها از API واقعی سرور می‌آید؛ چیزی ساختگی نمایش داده نمی‌شود.
   ============================================================ */

var TOKEN_KEY = 'hamrah_admin_token';
var THEME_KEY = 'hamrah_admin_theme';

/* ---------- ابزارهای پایه ---------- */
function $(s) { return document.querySelector(s); }
function $$(s) { return Array.prototype.slice.call(document.querySelectorAll(s)); }
function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
  return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
function faNum(n) { var x = Number(n); return Number.isFinite(x) ? x.toLocaleString('fa-IR', { maximumFractionDigits: 1 }) : '—'; }
function money(n) { return Number.isFinite(Number(n)) ? Number(n).toLocaleString('fa-IR') + ' تومان' : '—'; }
function dt(ms) { if (!ms) return '—'; var d = new Date(ms);
  return d.toLocaleDateString('fa-IR', { year: '2-digit', month: '2-digit', day: '2-digit' }) + '، ' +
    d.toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' }); }
function agoMin(min) {
  if (min == null) return '—';
  if (min < 1) return 'همین حالا';
  if (min < 60) return faNum(Math.round(min)) + ' دقیقه پیش';
  if (min < 60 * 24) return faNum(Math.round(min / 60)) + ' ساعت پیش';
  return faNum(Math.round(min / (60 * 24))) + ' روز پیش';
}

var ERR_FA = {
  bad_password: 'رمز نادرست است', bad_current_password: 'رمز فعلی نادرست است', account_disabled: 'این حساب غیرفعال شده است',
  too_many_attempts: 'تلاش بیش از حد؛ بعداً امتحان کنید', unauthorized: 'نشست منقضی شده؛ دوباره وارد شوید',
  forbidden: 'مجوز این اقدام را ندارید', not_found: 'موردی یافت نشد',
  reason_required: 'دلیل رد ضروری است', text_required: 'متن پیام ضروری است',
  invalid_name: 'نام شهر نامعتبر است (۲ تا ۴۰ نویسه)', invalid_name_en: 'نام لاتین نامعتبر است',
  invalid_province: 'نام استان نامعتبر است', invalid_lat: 'عرض جغرافیایی نامعتبر است',
  invalid_lng: 'طول جغرافیایی نامعتبر است', invalid_radius: 'شعاع نامعتبر است (۱ تا ۲۰۰ کیلومتر)',
  city_exists: 'شهری با این نام قبلاً ثبت شده است', city_required: 'شهر مشخص نشده است',
  invalid_city: 'شهر نامعتبر است', city_not_active: 'شهر برای این نقش غیرفعال است',
  open_bookings: 'این شهر رزرو باز دارد؛ با تأیید، رزروهای باز لغو می‌شوند',
  weak_password: 'رمز ضعیف است (حداقل ۱۲ نویسه و غیرآزمایشی)', username_taken: 'نام کاربری تکراری است',
  invalid_username: 'نام کاربری نامعتبر است (لاتین، ۳ تا ۴۰ نویسه)', invalid_role: 'نقش نامعتبر است',
  last_owner: 'آخرین صاحب پلتفرم قابل تغییر نیست', self_disable: 'حساب خودتان را نمی‌توانید غیرفعال کنید',
  not_pending_review: 'این پرونده در انتظار بررسی نهایی نیست', not_active: 'مترجم در وضعیت فعال نیست',
  not_suspended: 'مترجم در وضعیت تعلیق نیست', doc_expired: 'تاریخ انقضای مدرک گذشته است',
  not_settleable: 'این رزرو در وضعیت تسویهٔ دستی نیست', not_disputed: 'این رزرو در وضعیت اختلاف نیست',
  slot_taken: 'این نوبت همین حالا رزرو شد', time_in_past: 'زمان باید در آینده باشد',
  invalid_time: 'زمان نامعتبر است', feature_disabled: 'قابلیت مرتبط خاموش است',
  invalid_value: 'مقدار ارسالی نامعتبر است', unknown_key: 'کلید ناشناخته است',
  nothing_to_change: 'تغییری ارسال نشده است', invalid_body: 'بدنهٔ درخواست نامعتبر است',
  invalid_decision: 'تصمیم نامعتبر است', invalid_radius_range: 'شعاع باید ۱ تا ۲۰۰ کیلومتر باشد',
};
function errText(status, data) {
  if (data && data.error && ERR_FA[data.error]) return ERR_FA[data.error];
  if (data && data.error === 'forbidden' && data.need) return 'مجوز این اقدام برای نقش شما نیست (' + data.need + ')';
  if (status === 401) return ERR_FA.unauthorized;
  if (status === 403) return ERR_FA.forbidden;
  if (status >= 500) return 'خطای سرور؛ دوباره تلاش کنید';
  return 'خطا در انجام درخواست';
}

/* ---------- API ---------- */
var ME = null; // {user, perms}
function api(method, path, body) {
  var headers = { 'Content-Type': 'application/json' };
  var t = sessionStorage.getItem(TOKEN_KEY);
  if (t) headers['Authorization'] = 'Bearer ' + t;
  return fetch('/api' + path, { method: method, headers: headers, body: body === undefined ? undefined : JSON.stringify(body) })
    .then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (d) {
        if (!r.ok) { var e = new Error((d && d.error) || 'err'); e.status = r.status; e.data = d; throw e; }
        return d;
      });
    });
}
function errMsg(e) { return errText(e.status, e.data); }

/* ---------- توست ---------- */
function toast(msg, kind) {
  var box = $('#toasts');
  var el = document.createElement('div');
  el.className = 'toast' + (kind ? ' ' + kind : '');
  el.textContent = msg;
  box.appendChild(el);
  setTimeout(function () { el.style.opacity = '0'; el.style.transition = 'opacity .3s'; }, 3800);
  setTimeout(function () { el.remove(); }, 4200);
}
function toastErr(e) { toast(errMsg(e), 'err'); }

/* ---------- مودال (تأیید / درخواست متن) ---------- */
var modalResolve = null;
function askModal(opts) {
  // opts: {title, text, input: 'نام فیلد' | null, value, ok: 'برچسب دکمه', danger}
  $('#modal-title').textContent = opts.title || 'تأیید';
  $('#modal-text').textContent = opts.text || '';
  var inp = $('#modal-input');
  if (opts.input) { inp.classList.remove('hidden'); inp.placeholder = opts.input; inp.value = opts.value || ''; }
  else { inp.classList.add('hidden'); inp.value = ''; }
  $('#modal-ok').textContent = opts.ok || 'تأیید';
  $('#modal-ok').className = 'btn ' + (opts.danger ? 'danger' : 'primary');
  $('#modal').classList.remove('hidden');
  if (opts.input) setTimeout(function () { inp.focus(); }, 40);
  return new Promise(function (res) { modalResolve = res; });
}
function closeModal(v) { $('#modal').classList.add('hidden'); if (modalResolve) { modalResolve(v); modalResolve = null; } }
$('#modal-ok').addEventListener('click', function () { closeModal($('#modal-input').classList.contains('hidden') ? true : $('#modal-input').value); });
$('#modal-cancel').addEventListener('click', function () { closeModal(null); });
$('#modal').addEventListener('click', function (e) { if (e.target === $('#modal')) closeModal(null); });

/* ---------- کشو ---------- */
function openDrawer(title, html) {
  $('#drawer-title').textContent = title;
  $('#drawer-body').innerHTML = html;
  $('#drawer').classList.add('open');
}
function closeDrawer() { $('#drawer').classList.remove('open'); }
$('#drawer-close').addEventListener('click', closeDrawer);

/* ---------- تم ---------- */
function applyTheme(t) {
  document.documentElement.setAttribute('data-theme', t);
  $('#theme-btn').textContent = t === 'dark' ? '☀️ تم روشن' : '🌙 تم تاریک';
  try { localStorage.setItem(THEME_KEY, t); } catch (e) {}
}
$('#theme-btn').addEventListener('click', function () {
  applyTheme(document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark');
});
applyTheme((function () { try { return localStorage.getItem(THEME_KEY) || 'light'; } catch (e) { return 'light'; } })());

/* ---------- نقش‌ها و وضعیت‌ها ---------- */
var ROLE_FA = { owner: 'صاحب پلتفرم', ops: 'کارشناس عملیات', recruiter: 'کارشناس جذب مترجم', finance: 'کارشناس مالی', support: 'پشتیبانی' };
var RES_STATUS = {
  searching: ['در جست‌وجو', 'info'], waiting_schedule: ['در انتظار زمان', ''],
  matching: ['در حال تطبیق', 'violet'], unmatched_ask: ['نیاز به تصمیم', 'warn'],
  no_match: ['بدون مترجم', 'bad'], matched: ['مترجم متصل', 'brand'],
  finished: ['در انتظار پرداخت', 'warn'], done: ['تسویه‌شده', 'ok'], cancelled: ['لغوشده', 'bad'],
};
var TR_STATUS = {
  registered: ['ثبت‌نام اولیه', ''], in_progress: ['در حال تکمیل', 'info'],
  pending_review: ['در انتظار بررسی', 'warn'], active_general: ['فعال', 'ok'],
  active_specialized: ['فعال تخصصی', 'ok'], rejected: ['رد شده', 'bad'],
  suspended: ['تعلیق', 'bad'], deleted: ['حذف‌شده', ''],
};
var DOC_KIND_FA = { nid_card: 'کارت ملی', selfie: 'سلفی', portrait: 'عکس پرسنلی', address_proof: 'اثبات نشانی',
  criminal_record: 'عدم سوءپیشینه', drug_free: 'گواهی عدم اعتیاد', ipd_permit: 'مجوز IPD', cip_permit: 'مجوز CIP',
  car_docs: 'بیمه‌نامهٔ خودرو', licence: 'گواهینامهٔ رانندگی', specialty_cert: 'گواهی تخصص', lang_cert: 'مدرک زبان (گیت تخصص)' };
function docKindFa(k) {
  if (!k) return '—';
  if (k.indexOf('specialty_cert:') === 0) return 'گواهی تخصص (' + FIELD_FA[k.split(':')[1]] + ')';
  return DOC_KIND_FA[k] || k;
}
var DOC_STATUS = { uploaded: ['در انتظار بررسی', 'warn'], approved: ['تأیید شده', 'ok'], rejected: ['رد شده', 'bad'], superseded: ['جایگزین‌شده', ''] };
var FIELD_FA = { tourism: 'گردشگری و خرید', pilgrimage: 'زیارتی و مذهبی', medical: 'درمانی', business: 'بازرگانی', legal: 'حقوقی و اداری', general: 'عمومی (قدیمی)' };
var FIELD_BASE = { tourism: true, pilgrimage: true }; // حوزه‌های پایه — بدون مدرک تخصصی
var LANG_FA = { fa: 'فارسی', ar: 'عربی', en: 'انگلیسی', tr: 'ترکی', fr: 'فرانسه', ru: 'روسی', zh: 'چینی' };
function langsFa(s) { return String(s || '').split('-').map(function (l) { return LANG_FA[l] || l; }).join(' ⟷ '); }
var EVENT_FA = {
  created: 'رزرو ساخته شد', matched: 'پیشنهاد توسط مترجم پذیرش شد',
  service_started: 'خدمت با کد امنیتی آغاز شد', finish_requested: 'درخواست پایان خدمت ثبت شد',
  finished: 'خدمت پایان یافت', payment_selected: 'روش پرداخت انتخاب شد',
  cash_confirmed: 'مترجم دریافت نقدی را تأیید کرد', disputed: 'اختلاف ثبت شد',
  settled: 'پرونده تسویه شد', cancelled: 'رزرو لغو شد', retried: 'جست‌وجوی دوباره آغاز شد',
  converted: 'به رزرو زمان‌دار تبدیل شد', translator_cancelled: 'مترجم ماموریت را لغو کرد',
  service_code_unlocked: 'قفل کد امنیتی باز شد', manual_settled: 'تسویهٔ دستی توسط کارشناس',
  dispute_resolved: 'اختلاف حل‌وفصل شد', city_geofenced: 'شهرِ مسئول از هندسهٔ پوشش تعیین شد',
  outside_coverage: 'نقطهٔ ملاقات بیرون از پوشش سرویس است',
  status_searching: 'جست‌وجوی مترجم آغاز شد', status_waiting_schedule: 'در انتظار موعد قرار',
  status_matching: 'پنجرهٔ تطبیق باز شد', status_unmatched_ask: 'پرسش «تلاش دوباره یا لغو؟»',
  status_no_match: 'مترجمی یافت نشد', status_matched: 'مترجم متصل شد',
  status_finished: 'خدمت تمام شد', status_done: 'پرونده بسته شد', status_cancelled: 'رزرو لغو شد',
};
var ACTOR_FA = { traveler: 'مسافر', translator: 'مترجم', admin: 'مدیر', system: 'سیستم' };
function pill(status, map) {
  var it = map[status] || [status, ''];
  return '<span class="pill ' + it[1] + '">' + esc(it[0]) + '</span>';
}
function hasPerm(p) { return !!(ME && ME.perms && ME.perms.indexOf(p) >= 0); }

/* ---------- ناوبری ---------- */
var VIEW_META = {
  dashboard: ['داشبورد', 'نمای کلی عملیات، سلامت پلتفرم و صف‌های نیازمند توجه'],
  dispatch: ['کنسول اعزام', 'نمای زندهٔ ماموریت‌ها و ظرفیت آماده'],
  bookings: ['رزروها', 'همهٔ رزروها به تفکیک وضعیت، با خط زمانی هر پرونده'],
  changes: ['درخواست‌های در جریان', 'تغییر و تمدیدهای در انتظار تصمیم مترجم'],
  finance: ['مالی و تسویه', 'پرداخت‌های معلق، تسویهٔ دستی و تسویهٔ دوره‌ای'],
  disputes: ['اختلاف‌ها', 'اختلاف‌های نقدی در انتظار تصمیم کارشناس مالی'],
  translators: ['مترجمان', 'قیف جذب، تصمیم نهایی، تعلیق و اعلان'],
  interviews: ['مصاحبه‌ها', 'نوبت‌دهی مصاحبهٔ زبانی و ثبت عدم حضور'],
  docs: ['مدارک', 'بررسی و تصمیم مدارک احراز هویت'],
  recons: ['تجدیدنظرها', 'پرونده‌های رد‌شده با پنجرهٔ ۷ روزه'],
  travelers: ['مسافران', 'پروندهٔ مسافر و مسدودسازی سوءاستفاده'],
  cities: ['شهرها و پوشش سرویس', 'مرز جغرافیایی مسئولیت هر شهر و نقاط کور پوشش'],
  features: ['قابلیت‌ها', 'کلیدهای رفتاری پلتفرم'],
  settings: ['تنظیمات', 'تعرفه‌ها، کارمزدها، متون قراردادی و رمز'],
  reports: ['گزارش‌ها', 'شاخص‌های عملیات و خروجی CSV'],
  staff: ['کارمندان', 'حساب کارمندی و نقش‌ها — فقط صاحب پلتفرم'],
  audit: ['ممیزی', 'دفتر اقدامات با هویت عامل'],
};
var CURRENT = 'dashboard';
var POLL = null;
var LOADERS = {}; // در بخش بعد پر می‌شود
function showView(key) {
  CURRENT = key;
  $$('.nav-item').forEach(function (b) { b.classList.toggle('active', b.getAttribute('data-nav') === key); });
  $$('.view').forEach(function (v) { v.classList.toggle('hidden', v.id !== 'view-' + key); });
  var meta = VIEW_META[key] || [key, ''];
  $('#page-title').textContent = meta[0];
  $('#page-sub').textContent = meta[1];
  $('#sidebar').classList.remove('open'); $('#side-scrim').classList.remove('open');
  closeDrawer();
  if (POLL) { clearInterval(POLL); POLL = null; }
  var fn = LOADERS[key];
  if (fn) fn();
  if (['dashboard', 'dispatch', 'changes', 'finance'].indexOf(key) >= 0) {
    POLL = setInterval(function () { if (document.visibilityState === 'visible') fn(); }, 20000);
  }
}
$$('.nav-item').forEach(function (b) { b.addEventListener('click', function () { showView(b.getAttribute('data-nav')); }); });
$('#refresh').addEventListener('click', function () { var fn = LOADERS[CURRENT]; if (fn) fn(); });
$('#burger').addEventListener('click', function () {
  $('#sidebar').classList.toggle('open'); $('#side-scrim').classList.toggle('open');
});
$('#side-scrim').addEventListener('click', function () {
  $('#sidebar').classList.remove('open'); $('#side-scrim').classList.remove('open');
});

/* ---------- ورود/خروج و راه‌اندازی ---------- */
function showLogin() { $('#login-view').classList.remove('hidden'); $('#app-view').classList.add('hidden'); }
function showApp() { $('#login-view').classList.add('hidden'); $('#app-view').classList.remove('hidden'); }
$('#pw-eye').addEventListener('click', function () {
  var p = $('#pw'); p.type = p.type === 'password' ? 'text' : 'password';
});
$('#login-btn').addEventListener('click', doLogin);
$('#pw').addEventListener('keydown', function (e) { if (e.key === 'Enter') doLogin(); });
function doLogin() {
  var msg = $('#login-msg');
  msg.textContent = ''; msg.className = 'msg err';
  var body = { password: $('#pw').value };
  var u = $('#user').value.trim();
  if (u) body.username = u;
  $('#login-btn').disabled = true;
  api('POST', '/admin/login', body).then(function (r) {
    sessionStorage.setItem(TOKEN_KEY, r.token);
    return boot();
  }).catch(function (e) {
    msg.textContent = e.status === 401 ? 'رمز نادرست است' : errMsg(e);
  }).finally(function () { $('#login-btn').disabled = false; });
}
$('#logout').addEventListener('click', function () {
  api('POST', '/admin/logout').catch(function () {});
  sessionStorage.removeItem(TOKEN_KEY); ME = null; showLogin();
});
function applyRole() {
  var u = ME.user;
  $('#me-name').textContent = u.name || u.username;
  $('#me-role').textContent = ROLE_FA[u.role] || u.role_fa || u.role + ' (' + u.role + ')';
  // چیپ نقش باید کلید نقش را هم نشان دهد (قرارداد تست)
  $('#me-role').textContent = (ROLE_FA[u.role] || u.role) + ' (' + u.role + ')';
  var avatar = $('#me-chip .avatar');
  avatar.textContent = (u.name || u.username || '?').trim().charAt(0);
  // پنهان‌سازی منو بر اساس مجوز (گارد واقعی در سرور است)
  var permView = { staff: 'staff.manage', reports: 'reports.view', audit: 'audit.view' };
  Object.keys(permView).forEach(function (k) {
    var el = $('.nav-item[data-nav=' + k + ']');
    if (el) el.classList.toggle('hidden', !hasPerm(permView[k]));
  });
}
function boot() {
  return api('GET', '/admin/me').then(function (r) {
    ME = r; applyRole(); showApp(); showView('dashboard');
  }).catch(function (e) {
    sessionStorage.removeItem(TOKEN_KEY); ME = null; showLogin();
    if (e.status && e.status !== 401) toast(errMsg(e), 'err');
  });
}
if (sessionStorage.getItem(TOKEN_KEY)) boot(); else showLogin();

/* ============================================================
   نماها — عملیات
   ============================================================ */

/* ---------- داشبورد ---------- */
function setBadges(h) {
  var pairs = [['#nav-badge-docs', h.uploaded_docs], ['#nav-badge-changes', h.pending_changes], ['#nav-badge-finance', h.payments_waiting]];
  pairs.forEach(function (p) {
    var el = $(p[0]); if (!el) return;
    el.textContent = faNum(p[1] || 0);
    el.classList.toggle('zero', !p[1]);
  });
}
LOADERS.dashboard = function () {
  api('GET', '/admin/summary').then(function (s) {
    var h = s.health || {};
    setBadges(h);
    var openSum = ['searching', 'waiting_schedule', 'matching', 'unmatched_ask', 'no_match'].reduce(function (a, k) { return a + (s.reservations[k] || 0); }, 0);
    var kpis = [
      ['رزروهای بی‌مترجم', openSum, 'searching + matching + در انتظار', 'var(--accent)'],
      ['در انتظار پرداخت', s.payments_waiting, 'پایان‌یافته و تسویه‌نشده', 'var(--warn)'],
      ['اختلاف‌های باز', s.disputes, 'نقدی زیر سؤال', 'var(--danger)'],
      ['مترجمان فعال', (s.translators.active_general || 0) + (s.translators.active_specialized || 0), 'کل نیروی واجد شرایط', 'var(--brand)'],
      ['مترجمان آنلاین', h.online_translators, 'حاضر برای پیشنهاد', 'var(--ok)'],
      ['مدارک در انتظار', h.uploaded_docs, 'بررسی کارشناس', 'var(--violet)'],
    ];
    $('#kpis').innerHTML = kpis.map(function (k) {
      return '<div class="stat" style="--dot:' + k[3] + '"><div class="s-label">' + k[0] +
        '</div><div class="s-value num">' + faNum(k[1]) + '</div><div class="s-note">' + esc(k[2]) + '</div></div>';
    }).join('');
    // هشدارهای SLA
    var slas = [];
    if (h.oldest_searching_minutes != null) {
      var crit = h.oldest_searching_minutes > 10;
      slas.push(['⏱', crit, 'قدیمی‌ترین رزرو بی‌مترجم', agoMin(h.oldest_searching_minutes) + (crit ? ' — خارج از هدف ۱۰ دقیقه‌ای' : ''), 'dispatch']);
    }
    if (h.pending_changes) slas.push(['🔁', h.pending_changes > 5, 'درخواست‌های در جریان', faNum(h.pending_changes) + ' مورد در انتظار تصمیم مترجم', 'changes']);
    if (h.payments_waiting) slas.push(['🧾', false, 'پرداخت‌های معلق', faNum(h.payments_waiting) + ' پروندهٔ پایان‌یافته بدون تسویه', 'finance']);
    if (h.uploaded_docs) slas.push(['🪪', h.uploaded_docs > 10, 'مدارک در انتظار بررسی', faNum(h.uploaded_docs) + ' مدرک در صف کارشناس', 'docs']);
    slas.push(['📡', false, 'مترجمان آنلاین', faNum(h.online_translators) + ' نیروی آماده — از ' + faNum((s.translators.active_general || 0) + (s.translators.active_specialized || 0)) + ' فعال', 'dispatch']);
    if (h.blocked_travelers) slas.push(['⛔', false, 'مسافران مسدود', faNum(h.blocked_travelers) + ' حساب مسدود', 'travelers']);
    $('#sla').innerHTML = slas.map(function (x) {
      return '<div class="sla' + (x[1] ? ' crit' : ' calm') + '" data-goto="' + x[4] + '" style="cursor:pointer">' +
        '<div class="ico">' + x[0] + '</div><div><b>' + esc(x[2]) + '</b><small>' + esc(x[3]) + '</small></div></div>';
    }).join('');
    $$('#sla [data-goto]').forEach(function (el) { el.addEventListener('click', function () { showView(el.getAttribute('data-goto')); }); });
    // قیف
    var f = s.funnel || {};
    var rows = [
      ['ثبت‌نام اولیه', f.registered || 0, 'tone-info'], ['در انتظار بررسی نهایی', f.pending_review || 0, 'tone-warn'],
      ['فعال', f.active || 0, ''], ['تعلیق', f.suspended || 0, 'tone-warn'], ['رد شده', f.rejected || 0, 'tone-bad'],
    ];
    var max = Math.max.apply(null, rows.map(function (r) { return r[1]; }).concat([1]));
    $('#funnel').innerHTML = rows.map(function (r) {
      return '<div class="frow ' + r[2] + '"><span class="f-label">' + esc(r[0]) + '</span>' +
        '<span class="f-bar"><i style="width:' + Math.round((r[1] / max) * 100) + '%"></i></span>' +
        '<span class="f-num num">' + faNum(r[1]) + '</span></div>';
    }).join('');
    $('#quick').innerHTML = [
      ['dispatch', '🚀', 'کنسول اعزام'], ['bookings', '📦', 'رزروها'], ['docs', '🪪', 'بررسی مدارک'],
      ['cities', '🏙', 'شهرها و پوشش'], ['reports', '📈', 'گزارش‌ها'], ['changes', '🔁', 'درخواست‌ها'],
    ].map(function (q) {
      return '<button class="btn" data-q="' + q[0] + '" type="button" style="margin:0 0 8px 8px">' + q[1] + ' ' + q[2] + '</button>';
    }).join('');
    $$('#quick [data-q]').forEach(function (b) { b.addEventListener('click', function () { showView(b.getAttribute('data-q')); }); });
  }).catch(function (e) { if (e.status === 401) return boot(); toastErr(e); });
  // صف «گیر کرده‌ها» — نردبان CAP: کی منتظر کدام گیت است
  api('GET', '/admin/gates').then(function (g) {
    var el = $('#gates'); if (!el) return;
    el.innerHTML = (g.stuck || []).length ? g.stuck.map(function (x) {
      return '<div class="mrow"><div class="m-ico" style="background:var(--warn-soft);color:var(--warn)">🚧</div>' +
        '<div class="m-body"><b>#' + x.id + ' — ' + esc(x.name || 'بدون نام') + '</b>' +
        '<span class="m-meta">' + esc(x.phone || '') + ' · ' + (TR_STATUS[x.status] ? TR_STATUS[x.status][0] : esc(x.status)) + '</span>' +
        '<span class="m-meta">' + x.blocked.map(function (b2) { return esc(b2.label); }).join(' · ') + '</span></div>' +
        '<div class="m-side"><button class="btn sm" data-gateopen="' + x.id + '" type="button">پرونده</button></div></div>';
    }).join('') : '<div class="empty"><div class="e-ico">✅</div>کسی در گیت‌های صلاحیت گیر نکرده است</div>';
    $$('#gates [data-gateopen]').forEach(function (b) { b.addEventListener('click', function () { openTranslatorFile(Number(b.getAttribute('data-gateopen'))); }); });
  }).catch(function () { var el = $('#gates'); if (el) el.innerHTML = ''; });
};

/* ---------- کنسول اعزام ---------- */
LOADERS.dispatch = function () {
  api('GET', '/admin/dispatch').then(function (d) {
    var now = Date.now();
    var missions = (d.missions || []).map(function (m) {
      var start = m.start ? new Date(m.start).getTime() : null;
      var late = m.status === 'matched' && start && start - now < 30 * 60000 && now - start < 2 * 3600000 && !m.finished;
      return '<div class="mrow' + (late ? ' late' : '') + '">' +
        '<div class="m-ico">' + (m.kind === 'instant' ? '⚡' : '🗓') + '</div>' +
        '<div class="m-body"><b>#' + m.id + ' — ' + esc(m.place || 'بدون نشانی') + '</b>' +
        '<span class="m-meta">' + langsFa(m.langs) + ' · ' + (FIELD_FA[m.field] || m.field) + ' · شروع: ' + dt(start) + ' · ' + faNum(m.hours) + ' ساعت</span></div>' +
        '<div class="m-side"><b>' + esc(m.translator || '—') + '</b>' +
        '<span class="m-meta">' + (m.online ? '🟢 آنلاین' : '⚪ آفلاین') + ' · ' + esc(m.translator_phone || '') + '</span>' +
        pill(m.status, RES_STATUS) + '</div></div>';
    }).join('') || '<div class="empty"><div class="e-ico">🛰</div>ماموریت فعالی نیست</div>';
    $('#dispatch-missions').innerHTML = missions;
    var idle = (d.idle_online || []).map(function (t) {
      return '<div class="mrow"><div class="m-ico" style="background:var(--ok-soft);color:var(--ok)">🟢</div>' +
        '<div class="m-body"><b>' + esc(t.name || 'بدون نام') + '</b><span class="m-meta">' + esc(t.phone) + '</span></div>' +
        '<span class="pill ok">آماده</span></div>';
    }).join('') || '<div class="empty"><div class="e-ico">💤</div>فعلاً هیچ مترجمی آنلاین و بیکار نیست</div>';
    $('#dispatch-idle').innerHTML = idle;
  }).catch(function (e) { if (e.status === 401) return boot(); toastErr(e); });
};

/* ---------- رزروها ---------- */
var BK = { tab: 'pending', kind: '', q: '', limit: 20, offset: 0 };
function bkLoad() {
  var qs = '?tab=' + BK.tab + '&limit=' + BK.limit + '&offset=' + BK.offset +
    (BK.kind ? '&kind=' + BK.kind : '') + (BK.q ? '&q=' + encodeURIComponent(BK.q) : '');
  api('GET', '/admin/bookings' + qs).then(function (d) {
    $('#bk-body').innerHTML = (d.bookings || []).map(function (b) {
      return '<tr><td class="num">#' + b.id + '</td>' +
        '<td><b>' + esc(b.traveler_name || 'بدون نام') + '</b><div class="sub">' + esc(b.place || '') + (b.kind === 'instant' ? ' · ⚡ فوری' : ' · 🗓 زمان‌دار') + '</div></td>' +
        '<td>' + langsFa(b.langs) + '<div class="sub">' + (FIELD_FA[b.field] || b.field) + '</div></td>' +
        '<td>' + pill(b.status, RES_STATUS) +
        (b.pay_state ? '<div class="sub">' + ({ settled: 'تسویه', awaiting_cash: 'انتظار نقدی', disputed: 'اختلاف', refunded: 'استرداد' }[b.pay_state] || b.pay_state) + '</div>' : '') + '</td>' +
        '<td>' + (b.translator ? '<b>' + esc(b.translator) + '</b><div class="sub">' + esc(b.translator_phone || '') + '</div>' : '—') + '</td>' +
        '<td class="num">' + money(b.total) + '<div class="sub">سهم مترجم: ' + money(b.net) + '</div></td>' +
        '<td class="sub">' + dt(b.created_at) + '</td>' +
        '<td><div class="actions"><button class="btn sm" data-bk="' + b.id + '" type="button">جزئیات</button></div></td></tr>';
    }).join('') || '<tr><td colspan="8"><div class="empty"><div class="e-ico">🗂</div>رزروی در این تب نیست</div></td></tr>';
    var from = d.total ? d.offset + 1 : 0;
    var to = Math.min(d.offset + d.limit, d.total);
    $('#bk-info').textContent = 'نمایش ' + faNum(from) + ' تا ' + faNum(to) + ' از ' + faNum(d.total);
    $('#bk-prev').disabled = d.offset <= 0;
    $('#bk-next').disabled = d.offset + d.limit >= d.total;
    $$('#bk-body [data-bk]').forEach(function (btn) {
      btn.addEventListener('click', function () { openBookingDrawer(Number(btn.getAttribute('data-bk'))); });
    });
  }).catch(function (e) { if (e.status === 401) return boot(); toastErr(e); });
}
LOADERS.bookings = bkLoad;
$$('#bk-tabs .tab').forEach(function (t) { t.addEventListener('click', function () {
  $$('#bk-tabs .tab').forEach(function (x) { x.classList.remove('active'); });
  t.classList.add('active'); BK.tab = t.getAttribute('data-bktab'); BK.offset = 0; bkLoad();
}); });
$('#bk-search').addEventListener('click', function () { BK.q = $('#bk-q').value.trim(); BK.kind = $('#bk-kind').value; BK.offset = 0; bkLoad(); });
$('#bk-q').addEventListener('keydown', function (e) { if (e.key === 'Enter') $('#bk-search').click(); });
$('#bk-prev').addEventListener('click', function () { BK.offset = Math.max(0, BK.offset - BK.limit); bkLoad(); });
$('#bk-next').addEventListener('click', function () { BK.offset += BK.limit; bkLoad(); });

function openBookingDrawer(id) {
  openDrawer('رزرو #' + faNum(id), '<div class="sk" style="height:80px"></div>');
  api('GET', '/admin/reservations/' + id + '/events').then(function (d) {
    var tl = (d.events || []).map(function (ev) {
      var label = EVENT_FA[ev.event] || ev.event;
      var det = ev.detail && Object.keys(ev.detail).length ? '<div class="tl-detail">' + esc(JSON.stringify(ev.detail)) + '</div>' : '';
      return '<div class="tl-item' + (EVENT_FA[ev.event] ? '' : ' dim') + '"><b>' + esc(label) + '</b>' +
        '<div class="tl-meta">' + (ACTOR_FA[ev.actor] || esc(ev.actor)) + ' · ' + dt(ev.created_at) + '</div>' + det + '</div>';
    }).join('') || '<div class="empty">رویدادی ثبت نشده</div>';
    var acts = '';
    if (hasPerm('bookings.manage')) acts += '<button class="btn sm" id="bk-unlock" type="button">🔓 رفع قفل کد امنیتی</button> ';
    if (hasPerm('finance.manage')) acts += '<button class="btn sm ok" id="bk-settle" type="button">🧾 تسویهٔ دستی</button>';
    $('#drawer-body').innerHTML =
      '<div class="kv"><span class="k">شناسه</span><span class="num">#' + id + '</span></div>' +
      (acts ? '<div class="help" style="display:flex;gap:8px;flex-wrap:wrap">' + acts + '</div>' : '') +
      '<h4 style="margin:14px 0 10px;font-size:13px">خط زمانی پرونده</h4><div class="timeline">' + tl + '</div>';
    var ub = $('#bk-unlock');
    if (ub) ub.addEventListener('click', function () {
      askModal({ title: 'رفع قفل کد امنیتی', text: 'شمارندهٔ ۵ تلاش ناموفق صفر می‌شود. کد تازه لازم است؟ (کد فقط برای مسافر در اپ نمایش داده می‌شود)', ok: 'فقط رفع قفل', input: null })
        .then(function () { return api('POST', '/admin/reservations/' + id + '/unlock-service-code', {}); })
        .then(function () { toast('قفل کد باز شد', 'ok'); })
        .catch(function (e) { if (e && e.status) toastErr(e); });
    });
    var sb = $('#bk-settle');
    if (sb) sb.addEventListener('click', function () {
      askModal({ title: 'تسویهٔ دستی پرونده', text: 'جای تأیید مترجم، کارشناس مالی پرونده را می‌بندد. یادداشت داخلی (اختیاری):', input: 'یادداشت', ok: 'تسویه' })
        .then(function (note) { if (note === null) throw { silent: true }; return api('POST', '/admin/reservations/' + id + '/settle', { note: note || '' }); })
        .then(function () { toast('پرونده تسویه شد', 'ok'); LOADERS[CURRENT](); })
        .catch(function (e) { if (!e || !e.silent) toastErr(e); });
    });
  }).catch(function (e) { $('#drawer-body').innerHTML = '<div class="empty">' + esc(errMsg(e)) + '</div>'; });
}

/* ---------- درخواست‌های در جریان ---------- */
LOADERS.changes = function () {
  api('GET', '/admin/changes').then(function (d) {
    setBadges({ pending_changes: d.pending_count || 0 });
    $('#changes-body').innerHTML = (d.changes || []).map(function (c) {
      var isExt = c.kind === 'extension';
      var wm = c.waiting_minutes;
      var cdCls = wm == null ? '' : (wm >= 4 ? ' hot' : (wm >= 2 ? ' warm' : ''));
      var title = isExt ? '⏱ تمدید ' + faNum(c.extra_hours) + ' ساعته' : '🔁 تغییر مشخصات';
      return '<div class="crow"><div class="c-body"><b>#' + c.reservation_id + ' — ' + title + '</b>' +
        '<span class="c-meta">' + esc(c.traveler_name || 'بدون نام') + ' · ' + esc(c.place || '') + ' · مترجم: ' + esc(c.translator_name || '—') +
        (isExt ? ' · سهم اضافه: ' + money(c.extra_net) : '') + '</span></div>' +
        '<span class="cd' + cdCls + '">' + (wm != null ? agoMin(wm) : '') + '</span>' +
        pill(c.status, { pending: ['در انتظار پاسخ مترجم', 'warn'], accepted: ['پذیرفته شد', 'ok'], rejected: ['رد شد', 'bad'], expired: ['منقضی', ''] }) +
        '<button class="btn sm" data-chg="' + c.reservation_id + '" type="button">پروندهٔ رزرو</button></div>';
    }).join('') || '<div class="empty"><div class="e-ico">✅</div>صف خالی است — هیچ درخواستی در جریان نیست</div>';
    $$('#changes-body [data-chg]').forEach(function (b) {
      b.addEventListener('click', function () {
        showView('bookings'); BK.tab = 'upcoming'; BK.q = ''; BK.offset = 0;
        $$('#bk-tabs .tab').forEach(function (x) { x.classList.toggle('active', x.getAttribute('data-bktab') === 'upcoming'); });
        setTimeout(function () { openBookingDrawer(Number(b.getAttribute('data-chg'))); }, 350);
      });
    });
  }).catch(function (e) { if (e.status === 401) return boot(); toastErr(e); });
};

/* ---------- مالی ---------- */
LOADERS.finance = function () {
  api('GET', '/admin/finance').then(function (f) {
    setBadges({ payments_waiting: f.waiting.count });
    // درآمد پلتفرم: سهم پلتفرم از هر رزرو = total − net
    var inc = f.income || { realized: 0, today: 0, week: 0, pending: 0, cash_debt: 0 };
    $('#fin-income').innerHTML = [
      ['درآمد تحقق‌یافته', money(inc.realized), 'سهم پلتفرم از تسویه‌شده‌ها', 'var(--ok)'],
      ['امروز', money(inc.today), 'از نیمه‌شب تاکنون', 'var(--ok)'],
      ['۷ روز اخیر', money(inc.week), 'جمع هفتهٔ جاری', 'var(--violet)'],
      ['در انتظار وصول', money(inc.pending), 'پایان‌یافتهٔ بی‌تسویه', 'var(--warn)'],
      ['بدهی نقدی مترجمان', money(inc.cash_debt), 'سهم پلتفرم دست مترجم‌ها', 'var(--danger)'],
    ].map(function (k) {
      return '<div class="stat" style="--dot:' + k[3] + '"><div class="s-label">' + k[0] + '</div>' +
        '<div class="s-value num">' + esc(k[1]) + '</div><div class="s-note">' + esc(k[2]) + '</div></div>';
    }).join('');
    $('#fin-kpis').innerHTML = [
      ['معلق', f.waiting.count, money(f.waiting.sum), 'var(--warn)'],
      ['اختلاف‌ها', f.disputes.count, money(f.disputes.sum), 'var(--danger)'],
      ['استردادشده', f.refunded.count, money(f.refunded.sum), 'var(--violet)'],
      ['تسویه‌شده', f.settled.count, money(f.settled.sum_total), 'var(--ok)'],
    ].map(function (k) {
      return '<div class="stat" style="--dot:' + k[3] + '"><div class="s-label">' + k[0] + '</div>' +
        '<div class="s-value num">' + faNum(k[1]) + '</div><div class="s-note num">' + esc(k[2]) + '</div></div>';
    }).join('');
    $('#fin-waiting').innerHTML = (f.waiting_list || []).map(function (r) {
      return '<tr><td class="num">#' + r.id + '</td>' +
        '<td><b>' + esc(r.traveler_name || 'بدون نام') + '</b><div class="sub">' + esc(r.place || '') + ' · ' + esc(r.traveler_phone || '') + '</div></td>' +
        '<td>' + (r.translator ? esc(r.translator) + '<div class="sub">' + esc(r.translator_phone || '') + '</div>' : '—') + '</td>' +
        '<td class="num"><b>' + money(r.total) + '</b><div class="sub">سهم مترجم: ' + money(r.net) + '</div></td>' +
        '<td class="sub">' + dt(r.finished_at) + '</td>' +
        '<td>' + (hasPerm('finance.manage') ? '<button class="btn sm ok" data-settle="' + r.id + '" type="button">تسویهٔ دستی</button>' : '') + '</td></tr>';
    }).join('') || '<tr><td colspan="6"><div class="empty"><div class="e-ico">🧮</div>پرداخت معلقی نیست</div></td></tr>';
    $('#fin-settle').innerHTML = (f.settlements || []).map(function (s) {
      return '<tr><td><b>' + esc(s.name || 'بدون نام') + '</b></td><td class="dir-ltr">' + esc(s.phone) + '</td>' +
        '<td class="dir-ltr num">' + esc(s.iban_last4 || '—') + '</td><td class="num">' + faNum(s.count) + '</td>' +
        '<td class="num"><b>' + money(s.sum_net) + '</b></td><td class="sub">' + dt(s.last_settled_at) + '</td></tr>';
    }).join('') || '<tr><td colspan="6"><div class="empty">هنوز تسویه‌ای ثبت نشده</div></td></tr>';
    $$('#fin-waiting [data-settle]').forEach(function (b) {
      b.addEventListener('click', function () {
        var id = Number(b.getAttribute('data-settle'));
        askModal({ title: 'تسویهٔ دستی #' + id, text: 'با تسویهٔ دستی، تأیید مترجم جایگزین می‌شود و پرونده بسته می‌شود. یادداشت داخلی:', input: 'مثلاً: دریافت نقدی تلفنی تأیید شد', ok: 'تسویه' })
          .then(function (note) { if (note === null) throw { silent: true }; return api('POST', '/admin/reservations/' + id + '/settle', { note: note || '' }); })
          .then(function () { toast('پرونده #' + id + ' تسویه شد', 'ok'); LOADERS.finance(); })
          .catch(function (e) { if (!e || !e.silent) toastErr(e); });
      });
    });
  }).catch(function (e) { if (e.status === 401) return boot(); toastErr(e); });
  // بدهی نقدی مترجمان (سهم پلتفرم دست مترجم است) — مستقل از /finance
  api('GET', '/admin/debts').then(function (d) {
    var el = $('#fin-debts'); if (!el) return;
    el.innerHTML = (d.debts || []).map(function (t) {
      return '<tr><td><b>' + esc(t.name || 'بدون نام') + '</b></td><td class="dir-ltr">' + esc(t.phone) + '</td>' +
        '<td class="num">' + money(t.earned) + '</td><td class="num">' + money(t.paid) + '</td>' +
        '<td class="num"><b style="color:' + (t.debt > 0 ? 'var(--danger)' : 'var(--ok)') + '">' + money(t.debt) + '</b>' +
        (t.debt > 0 ? '<div class="sub">دریافت درخواست بسته است</div>' : '<div class="sub">تسویه — باز</div>') + '</td>' +
        '<td>' + (hasPerm('finance.manage') && t.debt > 0 ? '<button class="btn sm ok" data-debtpay="' + t.id + '" type="button">ثبت پرداخت</button>' : '') + '</td></tr>';
    }).join('') || '<tr><td colspan="6"><div class="empty"><div class="e-ico">🧾</div>بدهی نقدی ثبت نشده است</div></td></tr>';
    var h = $('#fin-debts-history');
    if (h) h.innerHTML = (d.history || []).map(function (p) {
      return '<tr><td class="dir-ltr">' + esc(p.phone || '#' + p.translator_id) + '</td><td class="num"><b>' + money(p.amount) + '</b></td>' +
        '<td class="sub">' + esc(p.note || '—') + '</td><td>' + esc(p.admin || '—') + '</td><td class="sub">' + dt(p.created_at) + '</td></tr>';
    }).join('') || '<tr><td colspan="5"><div class="empty">پرداختی ثبت نشده</div></td></tr>';
    $$('#fin-debts [data-debtpay]').forEach(function (b) {
      b.addEventListener('click', function () {
        var uid = Number(b.getAttribute('data-debtpay'));
        var row = (d.debts || []).filter(function (x) { return x.id === uid; })[0];
        askModal({ title: 'ثبت پرداخت بدهی', text: 'بدهی باقیماندهٔ «' + (row ? (row.name || row.phone) : '#' + uid) + '»: ' + money(row ? row.debt : 0) + ' تومان. مبلغ پرداخت‌شده (تومان):', input: 'مبلغ به تومان', ok: 'ثبت پرداخت' })
          .then(function (amt) {
            if (amt === null) throw { silent: true };
            var n = Math.trunc(Number(String(amt).replace(/[^\d]/g, '')));
            if (!n || n <= 0) { toast('مبلغ نامعتبر است', 'bad'); throw { silent: true }; }
            return api('POST', '/admin/debts/' + uid + '/pay', { amount: n });
          })
          .then(function (r) { toast(r.remaining <= 0 ? 'بدهی صفر شد و مترجم بازگشت' : 'پرداخت ثبت شد؛ باقیمانده: ' + money(r.remaining), 'ok'); LOADERS.finance(); })
          .catch(function (e) { if (!e || !e.silent) toastErr(e); });
      });
    });
  }).catch(function (e) { if (e.status === 401) return boot(); if (e.status !== 403) toastErr(e); });
  // پرداخت‌های درگاهی: مستقل از /finance تا نقص آن، این جدول را نسوزاند
  api('GET', '/admin/gateway-payments').then(function (g) {
    var el = $('#fin-gateway'); if (!el) return;
    var ST = { pending: ['در انتظار بازگشت', 'warn'], paid: ['پرداخت‌شده', 'ok'], failed: ['ناموفق/لغو', 'bad'], refunded: ['استردادشده', 'violet'] };
    el.innerHTML = (g.payments || []).map(function (r) {
      var st = ST[r.status] || [r.status, 'sub'];
      return '<tr><td class="num">#' + r.id + '</td>' +
        '<td><b>#' + r.reservation_id + '</b><div class="sub">' + esc(r.traveler_name || 'بدون نام') + (r.place ? ' · ' + esc(r.place) : '') + '</div></td>' +
        '<td>' + (r.provider === 'zarinpal' ? 'زرین‌پال' : r.provider === 'simulated' ? 'شبیه‌ساز داخلی' : esc(r.provider)) + '</td>' +
        '<td class="num"><b>' + money(r.amount) + '</b></td>' +
        '<td>' + pill(st[1], { warn: [st[0], 'warn'], ok: [st[0], 'ok'], bad: [st[0], 'bad'], violet: [st[0], 'violet'], sub: [st[0], 'sub'] }) + '</td>' +
        '<td class="dir-ltr sub">' + esc(String(r.ref_id || r.authority || '—').slice(0, 18)) + '</td>' +
        '<td class="sub">' + dt(r.created_at) + (r.paid_at ? '<div>پرداخت: ' + dt(r.paid_at) + '</div>' : '') + '</td></tr>';
    }).join('') || '<tr><td colspan="7"><div class="empty"><div class="e-ico">💳</div>هنوز پرداختی از درگاه ثبت نشده</div></td></tr>';
  }).catch(function (e) { if (e.status === 401) return boot(); if (e.status !== 403) toastErr(e); });
};

/* ---------- اختلاف‌ها ---------- */
LOADERS.disputes = function () {
  api('GET', '/admin/disputes').then(function (d) {
    $('#disp-body').innerHTML = (d.disputes || []).map(function (r) {
      return '<div class="crow"><div class="c-body"><b>#' + r.id + ' — ' + esc(r.place || 'بدون نشانی') + '</b>' +
        '<span class="c-meta">مسافر: ' + esc(r.traveler_name || '—') + ' (' + esc(r.traveler_phone || '') + ') · مترجم: ' +
        esc(r.translator || '—') + ' (' + esc(r.translator_phone || '') + ') · ' + money(r.total) + ' · پایان: ' + dt(r.finished_at) + '</span></div>' +
        pill('bad', { bad: ['اختلاف نقدی', 'bad'] }) +
        (hasPerm('finance.manage') ?
          '<button class="btn sm ok" data-resolve="settle" data-id="' + r.id + '" type="button">تسویه (دریافت تأیید شد)</button>' +
          '<button class="btn sm danger" data-resolve="refund" data-id="' + r.id + '" type="button">استرداد به مسافر</button>' : '') +
        '</div>';
    }).join('') || '<div class="empty"><div class="e-ico">🕊</div>اختلاف بازی وجود ندارد</div>';
    $$('#disp-body [data-resolve]').forEach(function (b) {
      b.addEventListener('click', function () {
        var id = Number(b.getAttribute('data-id'));
        var dec = b.getAttribute('data-resolve');
        askModal({
          title: dec === 'refund' ? 'استرداد مبلغ به مسافر' : 'تسویهٔ اختلاف #' + id,
          text: dec === 'refund' ? 'پروندهٔ مالی با استرداد بسته می‌شود و سهم مترجم پرداخت نمی‌شود. یادداشت داخلی:' : 'دریافت نقدی تأیید و پرونده بسته می‌شود. یادداشت داخلی:',
          input: 'یادداشت', ok: dec === 'refund' ? 'استرداد' : 'تسویه', danger: dec === 'refund',
        }).then(function (note) {
          if (note === null) throw { silent: true };
          return api('POST', '/admin/disputes/' + id + '/resolve', { decision: dec, note: note || '' });
        }).then(function () { toast('تصمیم ثبت شد', 'ok'); LOADERS.disputes(); })
          .catch(function (e) { if (!e || !e.silent) toastErr(e); });
      });
    });
  }).catch(function (e) { if (e.status === 401) return boot(); toastErr(e); });
};

/* ---------- مترجمان (قیف + پرونده) ---------- */
var TR = { status: 'pending_review', q: '', limit: 50, offset: 0 };
function trLoad() {
  var qs = '?status=' + TR.status + '&limit=' + TR.limit + '&offset=' + TR.offset + (TR.q ? '&q=' + encodeURIComponent(TR.q) : '');
  api('GET', '/admin/translators' + qs).then(function (d) {
    $('#tr-body').innerHTML = (d.translators || []).map(function (t) {
      var acts = '<button class="btn sm" data-trfile="' + t.id + '" type="button">پرونده</button>';
      if (t.status === 'pending_review' && hasPerm('translators.manage')) {
        acts += '<button class="btn sm ok" data-trdec="approve" data-id="' + t.id + '" type="button">تأیید نهایی</button>' +
          '<button class="btn sm danger" data-trdec="reject" data-id="' + t.id + '" type="button">رد</button>';
      }
      if (String(t.status).indexOf('active_') === 0 && hasPerm('translators.manage')) {
        acts += '<button class="btn sm danger" data-trsuspend="' + t.id + '" type="button">تعلیق</button>';
      }
      if (t.status === 'suspended' && hasPerm('translators.manage')) {
        acts += '<button class="btn sm ok" data-trreact="' + t.id + '" type="button">بازفعال‌سازی</button>';
      }
      return '<tr><td><b>' + esc(t.name || 'بدون نام') + '</b>' + pill(t.status, TR_STATUS) + '</td>' +
        '<td class="dir-ltr">' + esc(t.phone) + (t.gender ? '<div class="sub">' + (t.gender === 'female' ? 'زن' : 'مرد') + '</div>' : '') + '</td>' +
        '<td class="num">' + faNum(t.score) + '</td><td class="sub">' + agoMin((Date.now() - t.updated_at) / 60000) + '</td>' +
        '<td><div class="actions">' + acts + '</div></td></tr>';
    }).join('') || '<tr><td colspan="5"><div class="empty"><div class="e-ico">🗒</div>پرونده‌ای در این وضعیت نیست</div></td></tr>';
    var from = d.total ? d.offset + 1 : 0;
    $('#tr-info').textContent = 'نمایش ' + faNum(from) + ' تا ' + faNum(Math.min(d.offset + d.limit, d.total)) + ' از ' + faNum(d.total);
    $('#tr-prev').disabled = d.offset <= 0;
    $('#tr-next').disabled = d.offset + d.limit >= d.total;
    $$('#tr-body [data-trfile]').forEach(function (b) { b.addEventListener('click', function () { openTranslatorFile(Number(b.getAttribute('data-trfile'))); }); });
    $$('#tr-body [data-trdec]').forEach(function (b) { b.addEventListener('click', function () {
      var id = Number(b.getAttribute('data-id'));
      var dec = b.getAttribute('data-trdec');
      askModal({
        title: dec === 'approve' ? 'تأیید نهایی مترجم' : 'رد پروندهٔ مترجم',
        text: dec === 'approve' ? 'مترجم فعال می‌شود و می‌تواند آنلاین شود و پیشنهاد بگیرد.' : 'پرونده رد می‌شود و ثبت‌نامش بسته می‌شود؛ پنجرهٔ تجدیدنظر ۷ روزه آغاز می‌شود.',
        ok: dec === 'approve' ? 'تأیید نهایی' : 'رد پرونده', danger: dec === 'reject',
      }).then(function (okv) {
        if (!okv) throw { silent: true };
        return api('POST', '/admin/translators/' + id + '/decision', { decision: dec });
      }).then(function (r) { toast(r.status === 'active_general' ? 'مترجم فعال شد' : 'پرونده رد شد', 'ok'); trLoad(); })
        .catch(function (e) { if (!e || !e.silent) toastErr(e); });
    }); });
    $$('#tr-body [data-trsuspend]').forEach(function (b) { b.addEventListener('click', function () {
      var id = Number(b.getAttribute('data-trsuspend'));
      askModal({ title: 'تعلیق موقت مترجم', text: 'مترجم از اعزام خارج و آنلاینش خاموش می‌شود. دلیل (در ممیزی ثبت می‌شود):', input: 'مثلاً: تخلف از منشور اخلاقی', ok: 'تعلیق', danger: true })
        .then(function (reason) { if (reason === null) throw { silent: true };
          if (!reason) { toast('خطا: دلیل ضروری است', 'err'); throw { silent: true }; }
          return api('POST', '/admin/translators/' + id + '/suspend', { reason: reason }); })
        .then(function () { toast('مترجم معلق شد', 'ok'); trLoad(); })
        .catch(function (e) { if (!e || !e.silent) toastErr(e); });
    }); });
    $$('#tr-body [data-trreact]').forEach(function (b) { b.addEventListener('click', function () {
      var id = Number(b.getAttribute('data-trreact'));
      askModal({ title: 'بازفعال‌سازی مترجم', text: 'مترجم به وضعیت فعال برمی‌گردد (خودش باید دوباره آنلاین شود).', ok: 'بازفعال‌سازی' })
        .then(function (okv) { if (!okv) throw { silent: true }; return api('POST', '/admin/translators/' + id + '/reactivate', {}); })
        .then(function () { toast('مترجم فعال شد', 'ok'); trLoad(); })
        .catch(function (e) { if (!e || !e.silent) toastErr(e); });
    }); });
  }).catch(function (e) { if (e.status === 401) return boot(); toastErr(e); });
}
LOADERS.translators = trLoad;
$$('#tr-tabs .tab').forEach(function (t) { t.addEventListener('click', function () {
  $$('#tr-tabs .tab').forEach(function (x) { x.classList.remove('active'); });
  t.classList.add('active'); TR.status = t.getAttribute('data-trstatus'); TR.offset = 0; trLoad();
}); });
$('#tr-search').addEventListener('click', function () { TR.q = $('#tr-q').value.trim(); TR.offset = 0; trLoad(); });
$('#tr-q').addEventListener('keydown', function (e) { if (e.key === 'Enter') $('#tr-search').click(); });
$('#tr-prev').addEventListener('click', function () { TR.offset = Math.max(0, TR.offset - TR.limit); trLoad(); });
$('#tr-next').addEventListener('click', function () { TR.offset += TR.limit; trLoad(); });

function openTranslatorFile(id) {
  openDrawer('پروندهٔ مترجم', '<div class="sk" style="height:100px"></div>');
  api('GET', '/admin/translator-docs?filter=all&limit=200').then(function (d) {
    var t = (d.translators || []).filter(function (x) { return x.id === id; })[0];
    if (!t) { $('#drawer-body').innerHTML = '<div class="empty">پرونده‌ای یافت نشد</div>'; return; }
    var chips = (t.documents || []).map(function (doc) {
      var st = DOC_STATUS[doc.status] || [doc.status, ''];
      var acts = '';
      if (doc.status === 'uploaded' && hasPerm('docs.manage')) {
        acts = '<span class="actions">' +
          '<button class="btn sm ok" data-docdec="approve" data-doc="' + doc.id + '" type="button">تأیید</button>' +
          '<button class="btn sm danger" data-docdec="reject" data-doc="' + doc.id + '" type="button">رد</button></span>';
      }
      return '<div class="doc-chip"><b>' + esc(docKindFa(doc.kind)) + '</b>' +
        '<span class="pill ' + st[1] + '">' + st[0] + '</span>' +
        (doc.expires_at ? '<span class="meta">انقضا: ' + dt(doc.expires_at) + (doc.expired ? ' ⚠ منقضی' : '') + '</span>' : '') +
        acts + '</div>';
    }).join('') || '<div class="empty" style="padding:14px">هنوز مدرکی ارسال نشده</div>';
    var tools = '';
    if (hasPerm('translators.manage')) {
      tools = '<div class="card" style="box-shadow:none;margin:14px 0;padding:14px">' +
        '<h4 style="margin:0 0 8px;font-size:13px">اعلان دستی به مترجم</h4>' +
        '<textarea class="input" id="notify-text" placeholder="مثلاً: لطفاً تا فردا مدرک بیمهٔ به‌روز بفرستید."></textarea>' +
        '<div style="margin-top:8px;display:flex;gap:8px;flex-wrap:wrap">' +
        '<button class="btn sm primary" id="notify-send" type="button">ارسال پیام</button>' +
        (String(t.status).indexOf('active_') === 0 ? '<button class="btn sm danger" id="tr-suspend2" type="button">تعلیق حساب</button>' : '') +
        (t.status === 'suspended' ? '<button class="btn sm ok" id="tr-react2" type="button">بازفعال‌سازی</button>' : '') +
        '</div><div class="msg" id="notify-msg"></div></div>';
    }
    var fieldPills = (t.fields || []).map(function (f) {
      // وضعیت واقعی هر حوزه: فعال (انتخاب + گیت باز) / قفل (انتخاب‌شده ولی گیت تخصص بسته) — نه «همه فعال»
      var label = esc(FIELD_FA[f.code] || f.code) + (f.base ? '' : ' · تخصصی');
      if (f.active) return '<span class="pill ok" style="margin:1px">' + label + ' · فعال</span>';
      if (f.selected) return '<span class="pill warn" style="margin:1px">' + label + ' · قفل (نیازمند تأیید مدرک زبان)</span>';
      return '<span class="pill sub" style="margin:1px">' + esc(FIELD_FA[f.code] || f.code) + ' · انتخاب نشده</span>';
    }).join(' ') || '—';
    $('#drawer-body').innerHTML =
      '<div class="kv">' +
      '<span class="k">نام</span><b>' + esc(t.name || '—') + '</b>' +
      '<span class="k">شماره</span><span class="dir-ltr">' + esc(t.phone) + '</span>' +
      '<span class="k">وضعیت</span>' + pill(t.status, TR_STATUS) +
      '<span class="k">حوزه‌ها</span><span>' + fieldPills + '</span>' +
      '<span class="k">کد ملی</span><span class="num dir-ltr">' + esc(t.national_code || '—') + '</span>' +
      '<span class="k">تاریخ تولد</span><span>' + esc(t.birth_date || '—') + '</span>' +
      '<span class="k">شبا (۴ رقم آخر)</span><span class="num dir-ltr">' + esc(String(t.iban || '').replace(/\D/g, '').slice(-4) || '—') + '</span>' +
      '</div>' +
      '<h4 style="margin:8px 0 6px;font-size:13px">مدارک</h4>' + chips + tools;
    $$('#drawer-body [data-docdec]').forEach(function (b) { b.addEventListener('click', function () {
      var docId = Number(b.getAttribute('data-doc'));
      var dec = b.getAttribute('data-docdec');
      var p = dec === 'reject'
        ? askModal({ title: 'رد مدرک', text: 'دلیل رد برای مترجم در اپ نمایش داده می‌شود:', input: 'مثلاً: تصویر ناواضح است', ok: 'رد مدرک', danger: true })
        : askModal({ title: 'تأیید مدرک', text: 'مدرک تأیید و نسخهٔ قبلی جایگزین می‌شود.', ok: 'تأیید' });
      p.then(function (v) {
        if (v === null) throw { silent: true };
        var body = dec === 'reject' ? { decision: 'reject', reason: v || '' } : { decision: 'approve' };
        return api('POST', '/admin/documents/' + docId + '/decision', body);
      }).then(function () { toast(dec === 'reject' ? 'مدرک رد شد و مترجم مطلع شد' : 'مدرک تأیید شد', 'ok'); openTranslatorFile(id); })
        .catch(function (e) { if (!e || !e.silent) toastErr(e); });
    }); });
    var ns = $('#notify-send');
    if (ns) ns.addEventListener('click', function () {
      var text = $('#notify-text').value.trim();
      var m = $('#notify-msg');
      if (!text) { m.textContent = 'خطا: متن پیام ضروری است'; m.className = 'msg err'; return; }
      api('POST', '/admin/translators/' + id + '/notify', { text: text }).then(function () {
        m.textContent = 'پیام در اپ مترجم ارسال شد'; m.className = 'msg ok';
        $('#notify-text').value = '';
        toast('پیام به مترجم ارسال شد', 'ok');
      }).catch(function (e) { m.textContent = errMsg(e); m.className = 'msg err'; });
    });
    var s2 = $('#tr-suspend2');
    if (s2) s2.addEventListener('click', function () {
      askModal({ title: 'تعلیق موقت مترجم', text: 'دلیل تعلیق (در ممیزی ثبت می‌شود):', input: 'دلیل', ok: 'تعلیق', danger: true })
        .then(function (reason) { if (reason === null) throw { silent: true };
          if (!reason) { toast('خطا: دلیل ضروری است', 'err'); throw { silent: true }; }
          return api('POST', '/admin/translators/' + id + '/suspend', { reason: reason }); })
        .then(function () { toast('مترجم معلق شد', 'ok'); openTranslatorFile(id); })
        .catch(function (e) { if (!e || !e.silent) toastErr(e); });
    });
    var r2 = $('#tr-react2');
    if (r2) r2.addEventListener('click', function () {
      api('POST', '/admin/translators/' + id + '/reactivate', {})
        .then(function () { toast('مترجم فعال شد', 'ok'); openTranslatorFile(id); })
        .catch(toastErr);
    });
  }).catch(function (e) { $('#drawer-body').innerHTML = '<div class="empty">' + esc(errMsg(e)) + '</div>'; });
}

/* ---------- مصاحبه‌ها ---------- */
function slotStatusPill(st) {
  return pill(st, { open: ['آزاد', 'ok'], booked: ['رزرو شده', 'warn'], no_show: ['عدم حضور', 'bad'] });
}
function slotsLoad() {
  api('GET', '/admin/interview-slots').then(function (d) {
    $('#slots').innerHTML = (d.slots || []).map(function (s) {
      var st = new Date(s.starts_at).getTime();
      return '<tr><td class="num">' + dt(st) + '</td><td>' + slotStatusPill(s.status) + '</td>' +
        '<td class="dir-ltr">' + (s.phone ? esc(s.phone) : '—') + '</td>' +
        '<td class="sub">' + esc(s.note || '') + '</td>' +
        '<td>' + (s.status === 'booked' ? '<button class="btn sm danger" data-noshow="' + s.id + '" type="button">عدم حضور</button>' : '') + '</td></tr>';
    }).join('') || '<tr><td colspan="5"><div class="empty"><div class="e-ico">🗓</div>نوبتی ساخته نشده است</div></td></tr>';
    $$('#slots [data-noshow]').forEach(function (b) { b.addEventListener('click', function () {
      var id = Number(b.getAttribute('data-noshow'));
      askModal({ title: 'ثبت عدم حضور', text: 'نوبت «عدم حضور» ثبت می‌شود و مترجم باید نوبت دیگری بگیرد.', ok: 'ثبت عدم حضور', danger: true })
        .then(function (okv) { if (!okv) throw { silent: true }; return api('POST', '/admin/interview-slots/' + id + '/no-show', {}); })
        .then(function () { toast('عدم حضور ثبت شد', 'ok'); slotsLoad(); })
        .catch(function (e) { if (!e || !e.silent) toastErr(e); });
    }); });
  }).catch(function (e) { if (e.status === 401) return boot(); toastErr(e); });
}
LOADERS.interviews = slotsLoad;
$('#slot-add-btn').addEventListener('click', function () {
  var m = $('#slot-msg');
  m.textContent = ''; m.className = 'msg';
  var date = $('#slot-date').value, time = $('#slot-time').value;
  if (!date || !time) { m.textContent = 'خطا: تاریخ و ساعت لازم است'; m.className = 'msg err'; return; }
  var at = new Date(date + 'T' + time + ':00');
  if (!Number.isFinite(at.getTime()) || at.getTime() <= Date.now()) { m.textContent = 'خطا: زمان باید در آینده باشد'; m.className = 'msg err'; return; }
  api('POST', '/admin/interview-slots', { starts_at: at.toISOString(), note: $('#slot-note').value.trim() })
    .then(function (r) { m.textContent = 'نوبت ساخته شد'; m.className = 'msg ok'; $('#slot-note').value = ''; slotsLoad(); })
    .catch(function (e) { m.textContent = 'خطا: ' + errMsg(e); m.className = 'msg err'; });
});

/* ---------- مدارک ---------- */
function docsLoad() {
  api('GET', '/admin/translator-docs').then(function (d) {
    $('#docs-body').innerHTML = (d.translators || []).map(function (t) {
      var chips = (t.documents || []).map(function (doc) {
        var st = DOC_STATUS[doc.status] || [doc.status, ''];
        return '<div class="doc-chip"><b>' + esc(docKindFa(doc.kind)) + '</b>' +
          '<span class="pill ' + st[1] + '">' + st[0] + '</span>' +
          '<span class="meta">' + (doc.size ? faNum(Math.round(doc.size / 1024)) + 'KB' : '') +
          (doc.expires_at ? ' · انقضا: ' + dt(doc.expires_at) + (doc.expired ? ' ⚠' : '') : '') + '</span>' +
          '<span class="actions">' +
          '<button class="btn sm" data-view="' + doc.id + '" type="button">مشاهده</button>' +
          (doc.status === 'uploaded' && hasPerm('docs.manage') ?
            '<button class="btn sm ok" data-docdec="approve" data-doc="' + doc.id + '" type="button">تأیید</button>' +
            '<button class="btn sm danger" data-docdec="reject" data-doc="' + doc.id + '" type="button">رد</button>' : '') +
          '</span></div>';
      }).join('');
      return '<div class="tcard"><div class="t-head"><b>' + esc(t.name || 'بدون نام') + '</b>' +
        '<span class="sub dir-ltr">' + esc(t.phone) + '</span>' + pill(t.status, TR_STATUS) +
        (t.national_code ? '<span class="sub num">کدملی ' + esc(t.national_code) + '</span>' : '') + '</div>' + chips + '</div>';
    }).join('') || '<div class="empty"><div class="e-ico">📥</div>مدرکی در انتظار بررسی نیست</div>';
    $$('#docs-body [data-view]').forEach(function (b) { b.addEventListener('click', function () {
      var docId = Number(b.getAttribute('data-view'));
      openDrawer('مشاهدهٔ مدرک', '<div class="sk" style="height:200px"></div>');
      api('GET', '/admin/documents/' + docId + '/file').then(function (f) {
        $('#drawer-body').innerHTML = '<img alt="مدرک" style="max-width:100%;border-radius:12px;border:1px solid var(--line)" src="' + esc(f.data) + '">';
      }).catch(function (e) { $('#drawer-body').innerHTML = '<div class="empty">' + esc(errMsg(e)) + '</div>'; });
    }); });
    $$('#docs-body [data-docdec]').forEach(function (b) { b.addEventListener('click', function () {
      var docId = Number(b.getAttribute('data-doc'));
      var dec = b.getAttribute('data-docdec');
      var p = dec === 'reject'
        ? askModal({ title: 'رد مدرک', text: 'دلیل رد برای مترجم در اپ نمایش داده می‌شود:', input: 'مثلاً: تصویر ناواضح است', ok: 'رد مدرک', danger: true })
        : askModal({ title: 'تأیید مدرک', text: 'مدرک تأیید و نسخهٔ قبلی جایگزین می‌شود.', ok: 'تأیید' });
      p.then(function (v) {
        if (v === null) throw { silent: true };
        return api('POST', '/admin/documents/' + docId + '/decision', dec === 'reject' ? { decision: 'reject', reason: v || '' } : { decision: 'approve' });
      }).then(function () { toast(dec === 'reject' ? 'مدرک رد شد' : 'مدرک تأیید شد', 'ok'); docsLoad(); })
        .catch(function (e) { if (!e || !e.silent) toastErr(e); });
    }); });
  }).catch(function (e) { if (e.status === 401) return boot(); toastErr(e); });
}
LOADERS.docs = docsLoad;

/* ---------- تجدیدنظرها ---------- */
LOADERS.recons = function () {
  api('GET', '/admin/recons').then(function (d) {
    $('#recon-body').innerHTML = (d.recons || []).map(function (r) {
      return '<tr><td><b>' + esc(r.name || 'بدون نام') + '</b></td><td class="dir-ltr">' + esc(r.phone) + '</td>' +
        '<td class="num">' + faNum(r.score) + '</td><td class="sub">' + dt(r.rejected_at) + '</td>' +
        '<td>' + (r.window_expired ? '<span class="pill">منقضی</span>' : '<span class="pill warn">' + faNum(r.window_left_days) + ' روز مانده</span>') + '</td></tr>';
    }).join('') || '<tr><td colspan="5"><div class="empty"><div class="e-ico">📮</div>پروندهٔ رد‌شده‌ای نیست</div></td></tr>';
  }).catch(function (e) { if (e.status === 401) return boot(); toastErr(e); });
};

/* ---------- مسافران ---------- */
var TV = { q: '', limit: 20, offset: 0 };
function tvLoad() {
  var qs = '?limit=' + TV.limit + '&offset=' + TV.offset + (TV.q ? '&q=' + encodeURIComponent(TV.q) : '');
  api('GET', '/admin/travelers' + qs).then(function (d) {
    $('#tv-body').innerHTML = (d.travelers || []).map(function (t) {
      return '<tr><td class="dir-ltr"><b>' + esc(t.phone) + '</b>' + (t.blocked ? ' <span class="pill bad">مسدود</span>' : '') + '</td>' +
        '<td class="num">' + faNum(t.reservations_total) + '</td><td class="num">' + faNum(t.reservations_done || 0) + '</td>' +
        '<td class="sub">' + dt(t.created_at) + '</td><td class="sub">' + (t.last_activity ? dt(t.last_activity) : '—') + '</td>' +
        '<td><div class="actions">' +
        '<button class="btn sm" data-tvfile="' + t.id + '" type="button">پرونده</button>' +
        (t.blocked
          ? '<button class="btn sm ok" data-tvunblock="' + t.id + '" type="button">رفع مسدودی</button>'
          : '<button class="btn sm danger" data-tvblock="' + t.id + '" type="button">مسدودسازی</button>') +
        '</div></td></tr>';
    }).join('') || '<tr><td colspan="7"><div class="empty"><div class="e-ico">🧳</div>مسافری یافت نشد</div></td></tr>';
    var from = d.total ? d.offset + 1 : 0;
    $('#tv-info').textContent = 'نمایش ' + faNum(from) + ' تا ' + faNum(Math.min(d.offset + d.limit, d.total)) + ' از ' + faNum(d.total);
    $('#tv-prev').disabled = d.offset <= 0;
    $('#tv-next').disabled = d.offset + d.limit >= d.total;
    $$('#tv-body [data-tvfile]').forEach(function (b) { b.addEventListener('click', function () {
      var id = Number(b.getAttribute('data-tvfile'));
      openDrawer('پروندهٔ مسافر', '<div class="sk" style="height:100px"></div>');
      api('GET', '/admin/travelers/' + id).then(function (r) {
        var t = r.traveler;
        var rows = (r.reservations || []).map(function (x) {
          return '<tr><td class="num">#' + x.id + '</td><td>' + esc(x.place || '—') + '</td><td>' + pill(x.status, RES_STATUS) + '</td><td class="num">' + money(x.total) + '</td><td class="sub">' + dt(x.created_at) + '</td></tr>';
        }).join('');
        $('#drawer-body').innerHTML =
          '<div class="kv"><span class="k">شماره</span><span class="dir-ltr">' + esc(t.phone) + '</span>' +
          '<span class="k">وضعیت</span>' + (t.blocked ? '<span class="pill bad">مسدود</span>' : '<span class="pill ok">عادی</span>') +
          '<span class="k">عضویت</span><span>' + dt(t.created_at) + '</span>' +
          '<span class="k">رزروها</span><span class="num">' + faNum(t.reservations_total) + ' (انجام‌شده: ' + faNum(t.done) + '، لغو: ' + faNum(t.cancelled) + ')</span></div>' +
          '<h4 style="font-size:13px;margin:12px 0 8px">آخرین رزروها</h4>' +
          '<div class="tbl-wrap"><table class="tbl"><thead><tr><th>#</th><th>محل</th><th>وضعیت</th><th>مبلغ</th><th>ایجاد</th></tr></thead><tbody>' +
          (rows || '<tr><td colspan="5"><div class="empty">رزروی ندارد</div></td></tr>') + '</tbody></table></div>';
      }).catch(function (e) { $('#drawer-body').innerHTML = '<div class="empty">' + esc(errMsg(e)) + '</div>'; });
    }); });
    $$('#tv-body [data-tvblock]').forEach(function (b) { b.addEventListener('click', function () {
      var id = Number(b.getAttribute('data-tvblock'));
      askModal({ title: 'مسدودسازی مسافر', text: 'مسافر مسدود نمی‌تواند رزرو جدید بسازد (ماموریت جاری از سرور لغو نمی‌شود). دلیل:', input: 'مثلاً: لغوهای مکرر پس از تطبیق', ok: 'مسدودسازی', danger: true })
        .then(function (reason) { if (reason === null) throw { silent: true };
          if (!reason) { toast('خطا: دلیل ضروری است', 'err'); throw { silent: true }; }
          return api('POST', '/admin/travelers/' + id + '/block', { reason: reason }); })
        .then(function () { toast('مسافر مسدود شد', 'ok'); tvLoad(); })
        .catch(function (e) { if (!e || !e.silent) toastErr(e); });
    }); });
    $$('#tv-body [data-tvunblock]').forEach(function (b) { b.addEventListener('click', function () {
      var id = Number(b.getAttribute('data-tvunblock'));
      askModal({ title: 'رفع مسدودی', text: 'مسافر می‌تواند دوباره رزرو بسازد.', ok: 'رفع مسدودی' })
        .then(function (okv) { if (!okv) throw { silent: true }; return api('POST', '/admin/travelers/' + id + '/unblock', {}); })
        .then(function () { toast('مسدودی رفع شد', 'ok'); tvLoad(); })
        .catch(function (e) { if (!e || !e.silent) toastErr(e); });
    }); });
  }).catch(function (e) { if (e.status === 401) return boot(); toastErr(e); });
}
LOADERS.travelers = tvLoad;
$('#tv-search').addEventListener('click', function () { TV.q = $('#tv-q').value.trim(); TV.offset = 0; tvLoad(); });
$('#tv-q').addEventListener('keydown', function (e) { if (e.key === 'Enter') $('#tv-search').click(); });
$('#tv-prev').addEventListener('click', function () { TV.offset = Math.max(0, TV.offset - TV.limit); tvLoad(); });
$('#tv-next').addEventListener('click', function () { TV.offset += TV.limit; tvLoad(); });

/* ---------- شهرها و پوشش سرویس ---------- */
var CITY_MAP = null, CITY_LAYER = null;
function citiesLoad() {
  Promise.all([api('GET', '/admin/cities'), api('GET', '/admin/coverage')]).then(function (rs) {
    var cities = rs[0].cities || [];
    var cov = rs[1] || { outside: [], checked: 0 };
    // نقاط کور پوشش
    $('#coverage-wrap').innerHTML = cov.outside && cov.outside.length
      ? '<div class="cover-note"><span style="font-size:17px">🕳</span><div><b>' + faNum(cov.outside.length) +
        ' رزرو باز بیرون از پوشش سرویس است.</b><br>این نقطه‌ها داخل هیچ دایرهٔ شهری نیستند؛ تطبیق هم‌شهری برایشان احتمال شکست دارد. ' +
        'شعاع شهر مربوط را گسترش دهید یا شهر تازه اضافه کنید.<ul style="margin:6px 18px 0 0;padding:0">' +
        cov.outside.slice(0, 5).map(function (o) {
          return '<li>#' + o.id + ' — ' + esc(o.place || 'بدون نشانی') + ' (شهر ثبت‌شده: ' + esc(o.city_name || '؟') + ') · <span class="dir-ltr">' +
            Number(o.lat).toFixed(4) + ', ' + Number(o.lng).toFixed(4) + '</span></li>';
        }).join('') + '</ul></div></div>'
      : (cov.checked ? '<div class="cover-note" style="background:var(--ok-soft);color:var(--ok)"><span style="font-size:17px">✅</span><div>همهٔ ' +
        faNum(cov.checked) + ' رزرو بازِ دارای مختصات داخل پوشش شهری هستند.</div></div>' : '');
    // جدول
    $('#city-body').innerHTML = cities.map(function (c) {
      return '<tr><td><b>' + esc(c.name_fa) + '</b>' + (c.id === rs[0].default_city_id ? ' <span class="pill brand">پیش‌فرض</span>' : '') +
        '<div class="sub">' + esc(c.province || '') + (c.name_en ? ' · ' + esc(c.name_en) : '') + '</div></td>' +
        '<td class="num">' + faNum(c.radius_km) + ' km</td>' +
        '<td class="num">' + faNum(c.translators) + ' / ' + faNum(c.translators_online) + '</td>' +
        '<td class="num">' + faNum(c.open_bookings) + ' / ' + faNum(c.matched_bookings) + '</td>' +
        '<td class="num sub">' + faNum(c.bookings_7d) + ' رزرو · ' + faNum(c.done_7d) + ' انجام‌شده</td>' +
        '<td><div class="actions"><button class="btn sm" data-cityedit="' + c.id + '" type="button">ویرایش</button></div></td></tr>';
    }).join('') || '<tr><td colspan="6"><div class="empty">شهری ثبت نشده است</div></td></tr>';
    // نقشه
    renderCityMap(cities);
    $$('#city-body [data-cityedit]').forEach(function (b) { b.addEventListener('click', function () {
      var c = cities.filter(function (x) { return x.id === Number(b.getAttribute('data-cityedit')); })[0];
      if (!c) return;
      openDrawer('ویرایش شهر: ' + c.name_fa,
        '<div class="form-row"><div class="fg"><label>نام فارسی</label><input class="input" id="ce-name_fa" value="' + esc(c.name_fa) + '"></div>' +
        '<div class="fg"><label>نام لاتین</label><input class="input dir-ltr" id="ce-name_en" value="' + esc(c.name_en || '') + '"></div></div>' +
        '<div class="form-row" style="margin-top:8px"><div class="fg"><label>استان</label><input class="input" id="ce-province" value="' + esc(c.province || '') + '"></div>' +
        '<div class="fg"><label>عرض</label><input class="input dir-ltr" id="ce-lat" type="number" step="0.0001" value="' + c.lat + '"></div>' +
        '<div class="fg"><label>طول</label><input class="input dir-ltr" id="ce-lng" type="number" step="0.0001" value="' + c.lng + '"></div>' +
        '<div class="fg"><label>شعاع (کیلومتر)</label><input class="input dir-ltr" id="ce-radius" type="number" min="1" max="200" value="' + c.radius_km + '"></div></div>' +
        '<div class="form-row" style="margin-top:8px">' +
        '<div class="fg"><label>پذیرش مسافر</label><select class="input" id="ce-traveler"><option value="1"' + (c.traveler_enabled ? ' selected' : '') + '>فعال</option><option value="0"' + (!c.traveler_enabled ? ' selected' : '') + '>غیرفعال</option></select></div>' +
        '<div class="fg"><label>پذیرش مترجم</label><select class="input" id="ce-translator"><option value="1"' + (c.translator_enabled ? ' selected' : '') + '>فعال</option><option value="0"' + (!c.translator_enabled ? ' selected' : '') + '>غیرفعال</option></select></div></div>' +
        '<div class="help">غیرفعال‌کردن پذیرش مسافر، رزروهای بازِ بدون مترجم این شهر را لغو می‌کند (سرور پیش از اعمال تأیید می‌گیرد).</div>' +
        '<div style="display:flex;gap:8px;margin-top:10px"><button class="btn primary" id="ce-save" type="button">ذخیرهٔ تغییرات</button></div>' +
        '<div class="msg" id="ce-msg"></div>');
      $('#ce-save').addEventListener('click', function () {
        var body = {
          name_fa: $('#ce-name_fa').value.trim(), name_en: $('#ce-name_en').value.trim(), province: $('#ce-province').value.trim(),
          lat: Number($('#ce-lat').value), lng: Number($('#ce-lng').value), radius_km: Number($('#ce-radius').value),
          traveler_enabled: $('#ce-traveler').value === '1', translator_enabled: $('#ce-translator').value === '1',
        };
        if (!c.traveler_enabled && body.traveler_enabled === false) body.confirm_cancel = true;
        api('PATCH', '/admin/cities/' + c.id, body).then(function (r) {
          toast('شهر به‌روزرسانی شد' + (r.cancelled ? '؛ ' + faNum(r.cancelled) + ' رزرو باز لغو شد' : ''), 'ok');
          closeDrawer(); citiesLoad();
        }).catch(function (e) {
          var m = $('#ce-msg'); m.textContent = errMsg(e); m.className = 'msg err';
          if (e.data && e.data.error === 'open_bookings') {
            askModal({ title: 'لغو رزروهای باز', text: faNum(e.data.count) + ' رزرو بازِ بدون مترجم این شهر لغو می‌شود (بدون کارمزد). ادامه می‌دهید؟', ok: 'لغو و ذخیره', danger: true })
              .then(function (okv) { if (!okv) throw { silent: true };
                body.confirm_cancel = true;
                return api('PATCH', '/admin/cities/' + c.id, body); })
              .then(function (r) { if (r) { toast('شهر به‌روزرسانی شد', 'ok'); closeDrawer(); citiesLoad(); } })
              .catch(function (e2) { if (!e2 || !e2.silent) { m.textContent = errMsg(e2); m.className = 'msg err'; } });
          }
        });
      });
    }); });
  }).catch(function (e) { if (e.status === 401) return boot(); toastErr(e); });
}
function renderCityMap(cities) {
  var el = $('#city-map');
  if (!el) return;
  if (!window.L) { el.innerHTML = '<div class="empty">نقشه در دسترس نیست</div>'; return; }
  if (!CITY_MAP) {
    CITY_MAP = L.map(el, { zoomControl: true }).setView([32.5, 54.5], 4);
    var tiles = L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 18, attribution: '© OpenStreetMap' });
    // تشخیص بارگذاری‌نشدن کاشی‌ها (شبکه/فیلتر): نقشه کور نشود؛ دایره‌ها و نشانگرها روی پس‌زمینه روشن می‌مانند
    var tileFails = 0;
    tiles.on('tileerror', function () {
      tileFails++;
      if (tileFails === 3) {
        var note = document.getElementById('city-map-tile-note');
        if (note) note.hidden = false;
      }
    });
    tiles.addTo(CITY_MAP);
    CITY_LAYER = L.layerGroup().addTo(CITY_MAP);
    LIVE_LAYER = L.layerGroup().addTo(CITY_MAP);
  }
  CITY_MAP.invalidateSize();
  CITY_LAYER.clearLayers();
  var b = null;
  cities.forEach(function (c) {
    var circle = L.circle([c.lat, c.lng], { radius: c.radius_km * 1000, color: c.traveler_enabled ? '#0e766b' : '#98a3ad',
      weight: 2, fillColor: '#0e766b', fillOpacity: 0.07 });
    circle.bindPopup('<b>' + esc(c.name_fa) + '</b><br>شعاع پوشش: ' + faNum(c.radius_km) + ' km<br>مترجم فعال: ' + faNum(c.translators));
    circle.on('click', function () {
      var row = $$('#city-body [data-cityedit="' + c.id + '"]')[0];
      if (row) row.click();
    });
    circle.addTo(CITY_LAYER);
    var nb = L.latLngBounds(L.latLng(c.lat - c.radius_km / 111, c.lng - c.radius_km / 90), L.latLng(c.lat + c.radius_km / 111, c.lng + c.radius_km / 90));
    b = b ? b.extend(nb) : nb;
  });
  if (b) CITY_MAP.fitBounds(b, { padding: [18, 18] });
  // نشانگرهای زنده: مترجمان آنلاینِ دارای موقعیت + رزروهای جاری (مستقل از جدول شهرها تا خرابی نسوزاند)
  api('GET', '/admin/map').then(function (m) {
    if (!LIVE_LAYER) return;
    LIVE_LAYER.clearLayers();
    var lb = null;
    (m.translators || []).forEach(function (t) {
      var mk = L.circleMarker([t.lat, t.lng], { radius: 6, color: '#0e766b', fillColor: '#14b8a6', fillOpacity: 0.95, weight: 2 });
      mk.bindPopup('<b>مترجم آنلاین</b><br>' + esc(t.name || 'بدون نام') + '<br><span class="dir-ltr sub">' + esc(t.phone || '') + '</span>');
      mk.addTo(LIVE_LAYER);
      lb = lb ? lb.extend(mk.getBounds()) : mk.getBounds();
    });
    (m.reservations || []).forEach(function (r) {
      var color = (r.status === 'matched' || r.status === 'finished') ? '#7c3aed' : '#ea580c';
      var mk = L.circleMarker([r.lat, r.lng], { radius: 5, color: color, fillColor: color, fillOpacity: 0.85, weight: 2 });
      mk.bindPopup('<b>رزرو #' + r.id + '</b><br>' + esc(FIELD_FA[r.field] || r.field || '') + '<div class="sub">' + esc(r.place || '') + '</div>');
      mk.addTo(LIVE_LAYER);
      lb = lb ? lb.extend(mk.getBounds()) : mk.getBounds();
    });
    var cnt = (m.translators || []).length + (m.reservations || []).length;
    var live = document.getElementById('city-map-live-note');
    if (live) live.textContent = cnt ? faNum(cnt) + ' نشانگر زنده: مترجمان آنلاین + رزروهای جاری' : 'نشانگر زنده‌ای نیست (مترجم با اشتراک موقعیت آنلاین یا رزرو جاری نداریم)';
  }).catch(function () { var live = document.getElementById('city-map-live-note'); if (live) live.textContent = 'نشانگرهای زنده اکنون در دسترس نیستند'; });
}
var LIVE_LAYER = null;
LOADERS.cities = citiesLoad;
$('#city-add-btn').addEventListener('click', function () {
  var m = $('#city-msg');
  m.textContent = ''; m.className = 'msg';
  var body = {
    name_fa: $('#city-add-name_fa').value.trim(), name_en: $('#city-add-name_en').value.trim(),
    province: $('#city-add-province').value.trim(),
    lat: Number($('#city-add-lat').value), lng: Number($('#city-add-lng').value),
    radius_km: Number($('#city-add-radius_km').value),
    traveler_enabled: true, translator_enabled: true,
  };
  api('POST', '/admin/cities', body).then(function (r) {
    m.textContent = 'شهر «' + body.name_fa + '» اضافه شد'; m.className = 'msg ok';
    ['#city-add-name_fa', '#city-add-name_en', '#city-add-province', '#city-add-lat', '#city-add-lng'].forEach(function (s) { $(s).value = ''; });
    citiesLoad();
  }).catch(function (e) { m.textContent = 'خطا: ' + errMsg(e); m.className = 'msg err'; });
});

/* ---------- قابلیت‌ها ---------- */
function featuresLoad() {
  api('GET', '/admin/features').then(function (d) {
    var groups = {};
    (d.features || []).forEach(function (f) { (groups[f.group] = groups[f.group] || []).push(f); });
    var groupFa = { core: 'هستهٔ سرویس', booking: 'ثبت رزرو', matching: 'تطبیق و اعزام', translator: 'سمت مترجم', payment: 'پرداخت', ops: 'عملیات' };
    $('#feat-groups').innerHTML = Object.keys(groups).map(function (g) {
      return '<h4 style="margin:14px 0 4px;font-size:12.5px;color:var(--muted)">' + esc(groupFa[g] || g) + '</h4>' +
        groups[g].map(function (f) {
          return '<div class="feat-row"><div class="f-info"><b>' + esc(f.label) +
            (f.implemented ? '' : ' <span class="pill">در حال ساخت</span>') +
            (f.requires ? ' <span class="pill info">وابسته: ' + esc(f.requires) + '</span>' : '') + '</b>' +
            '<div class="f-effect">' + esc(f.effect || '') + '</div></div>' +
            '<div class="switch' + (f.enabled ? ' on' : '') + '" data-feat="' + esc(f.key) + '" role="switch" aria-checked="' + f.enabled + '" tabindex="0"></div></div>';
        }).join('');
    }).join('');
    $$('#feat-groups [data-feat]').forEach(function (sw) { sw.addEventListener('click', function () {
      var key = sw.getAttribute('data-feat');
      var feat = (d.features || []).filter(function (x) { return x.key === key; })[0];
      var next = !(sw.classList.contains('on'));
      askModal({
        title: (next ? 'روشن‌کردن' : 'خاموش‌کردن') + ' «' + (feat ? feat.label : key) + '»',
        text: (feat && feat.effect ? 'اثر: ' + feat.effect + ' — ' : '') + 'تغییر فوراً روی هر دو اپ اعمال می‌شود.',
        ok: next ? 'روشن کن' : 'خاموش کن', danger: !next,
      }).then(function (okv) {
        if (!okv) throw { silent: true };
        var body = {}; body[key] = next;
        return api('PUT', '/admin/features', body);
      }).then(function (r) { toast('قابلیت به‌روزرسانی شد', 'ok'); featuresLoad(); })
        .catch(function (e) { if (!e || !e.silent) toastErr(e); });
    }); });
  }).catch(function (e) { if (e.status === 401) return boot(); toastErr(e); });
}
LOADERS.features = featuresLoad;

/* ---------- تنظیمات ---------- */
// گزارش کاربر: ویرایش JSON خام برای «تعرفهٔ ساعتی هر حوزه» و «جفت‌زبان‌های ثبت‌نام مترجم» سخت بود.
// این دو تنظیم حالا با فرم ساخت‌یافته ویرایش می‌شوند و خروجی‌شان همان PUT /admin/settings قبلی را تغذیه می‌کند.
var SET_NICE_LABEL = { hourly_tariffs: 'تعرفهٔ ساعتی هر حوزه (تومان)', language_pairs: 'جفت‌زبان‌های ثبت‌نام مترجم' };
var TAR_FIELDS = [
  ['tourism', 'گردشگری، تفریحی و خرید'],
  ['pilgrimage', 'زیارتی و مذهبی'],
  ['medical', 'درمانی، کلینیکال و پزشکی'],
  ['business', 'بازرگانی، تجاری و قراردادها'],
  ['legal', 'حقوقی، اداری و سفارت‌خانه‌ها'],
];
var LANG_FA = { fa: 'فارسی', ar: 'عربی', en: 'انگلیسی', tr: 'ترکی استانبولی', fr: 'فرانسوی', ru: 'روسی', zh: 'چینی ماندارین' };
var SET_EDITOR_VALIDATE = null;

function tariffEditorHTML(v) {
  var t = null;
  try { t = JSON.parse(v); } catch (e) { /* مقدار خراب: صفر رندر می‌شود تا مدیر درستش کند */ }
  var rows = TAR_FIELDS.map(function (f) {
    var n = t && Number.isInteger(Number(t[f[0]])) ? Number(t[f[0]]) : 0;
    return '<div class="hz-tar-row">' +
      '<div class="hz-tar-name"><b>' + esc(f[1]) + '</b><small class="dir-ltr">' + f[0] + '</small></div>' +
      '<input class="input dir-ltr hz-tar-in" data-f="' + f[0] + '" id="tar-' + f[0] + '" type="number" min="0" max="100000000000" step="50000" value="' + n + '">' +
      '<span class="hz-tar-fmt" data-fmt="' + f[0] + '">' + money(n) + '</span></div>';
  }).join('');
  return '<input type="hidden" id="set-hourly_tariffs" data-type="json">' +
    '<div class="hz-tar">' + rows +
    '<div class="hz-tar-tool"><span>تغییر درصدی همهٔ حوزه‌ها:</span>' +
    '<input class="input dir-ltr" id="tar-pct" type="number" step="1" placeholder="10 یا -5">' +
    '<button class="btn sm soft" id="tar-pct-btn" type="button">اعمال به همه</button></div></div>';
}

function syncTariffEditor() {
  var out = {}, ok = true;
  $$('#set-form .hz-tar-in').forEach(function (inp) {
    var raw = String(inp.value).trim();
    var n = Number(raw);
    var good = raw !== '' && Number.isInteger(n) && n >= 0 && n <= 1e11;
    inp.classList.toggle('hz-bad', !good);
    if (!good) ok = false; else out[inp.getAttribute('data-f')] = n;
    var fmt = $$('#set-form .hz-tar-fmt').filter(function (x) { return x.getAttribute('data-fmt') === inp.getAttribute('data-f'); })[0];
    if (fmt) fmt.textContent = good ? money(n) : 'مقدار نامعتبر';
  });
  var hid = $('#set-hourly_tariffs');
  if (hid) hid.value = (ok && Object.keys(out).length === TAR_FIELDS.length) ? JSON.stringify(out) : '';
  return ok;
}

function bindTariffEditor() {
  $$('#set-form .hz-tar-in').forEach(function (inp) { inp.addEventListener('input', syncTariffEditor); });
  var pb = $('#tar-pct-btn');
  if (pb) pb.addEventListener('click', function () {
    var p = Number($('#tar-pct') ? $('#tar-pct').value : '');
    if (!Number.isFinite(p) || p === 0) { toast('برای تغییر درصدی، عددی غیر از صفر وارد کنید', 'err'); return; }
    $$('#set-form .hz-tar-in').forEach(function (inp) {
      var n = Number(inp.value);
      if (Number.isFinite(n)) inp.value = Math.max(0, Math.min(1e11, Math.round(n * (1 + p / 100))));
    });
    syncTariffEditor();
    toast('درصد به همهٔ حوزه‌ها اعمال شد؛ برای ثبت، ذخیره کنید', 'ok');
  });
  syncTariffEditor();
}

function langOptionHTML(sel) {
  return Object.keys(LANG_FA).map(function (c) {
    return '<option value="' + c + '"' + (c === sel ? ' selected' : '') + '>' + esc(LANG_FA[c]) + '</option>';
  }).join('');
}

function lpRowHTML(x) {
  x = x || {};
  var langs = Array.isArray(x.langs) && x.langs.length === 2 ? x.langs : ['en', 'fa'];
  var on = x.enabled !== false;
  return '<div class="hz-lp-row' + (on ? '' : ' off') + '" data-code="' + esc(x.code || '') + '" data-langs="' + esc((langs[0] || '') + ',' + (langs[1] || '')) + '">' +
    '<button class="btn sm lp-en ' + (on ? 'ok' : 'ghost') + '" type="button">' + (on ? 'فعال' : 'غیرفعال') + '</button>' +
    '<select class="input lp-l1">' + langOptionHTML(langs[0] || 'en') + '</select>' +
    '<span class="lp-x">⟷</span>' +
    '<select class="input lp-l2">' + langOptionHTML(langs[1] || 'fa') + '</select>' +
    '<input class="input lp-label" maxlength="60" placeholder="برچسب، مثلاً عربی ⟷ فارسی" value="' + esc(x.label || '') + '">' +
    '<input class="input lp-note" maxlength="120" placeholder="توضیح اختیاری، مثلاً خلیجی و عراقی" value="' + esc(x.note || '') + '">' +
    '<button class="btn sm danger lp-del" type="button">حذف</button>' +
    '<div class="lp-err"></div></div>';
}

function langPairsHTML(v) {
  var list = null;
  try { list = JSON.parse(v); } catch (e) { /* مقدار خراب: خالی رندر می‌شود */ }
  if (!Array.isArray(list)) list = [];
  return '<input type="hidden" id="set-language_pairs" data-type="json">' +
    '<div class="hz-lp" id="lp-list">' + list.map(function (x) { return lpRowHTML(x); }).join('') + '</div>' +
    '<div style="display:flex;align-items:center;gap:9px;margin-top:9px">' +
    '<button class="btn sm soft" id="lp-add" type="button">افزودن جفت‌زبان</button>' +
    '<span class="lp-cnt" id="lp-cnt"></span></div>';
}

function collectLangPairs() {
  var out = [], seen = {}, ok = true, total = 0;
  $$('#lp-list .hz-lp-row').forEach(function (row) {
    total++;
    var err = '';
    var l1 = row.querySelector('.lp-l1').value;
    var l2 = row.querySelector('.lp-l2').value;
    var label = row.querySelector('.lp-label').value.trim();
    var note = row.querySelector('.lp-note').value.trim();
    var enabled = !row.classList.contains('off');
    if (l1 === l2) err = 'دو زبانِ جفت باید متفاوت باشند';
    else if (!label) err = 'برچسب جفت‌زبان الزامی است';
    var code = row.getAttribute('data-code') || '';
    var orig = (row.getAttribute('data-langs') || ',').split(',');
    if (orig[0] !== l1 || orig[1] !== l2) code = l1 < l2 ? l1 + '-' + l2 : l2 + '-' + l1;
    if (code && seen[code] && !err) err = 'کد جفت‌زبان تکراری است';
    if (!err && code) { seen[code] = 1; out.push({ code: code, label: label, note: note, langs: [l1, l2], enabled: enabled }); }
    var ebox = row.querySelector('.lp-err');
    if (ebox) ebox.textContent = err;
    row.classList.toggle('bad', !!err);
    if (err) ok = false;
  });
  var cnt = $('#lp-cnt');
  if (cnt) cnt.textContent = 'فعال: ' + faNum(out.filter(function (x) { return x.enabled; }).length) + ' از ' + faNum(total) + ' جفت‌زبان';
  var hid = $('#set-language_pairs');
  if (hid) hid.value = ok && out.length >= 1 ? JSON.stringify(out) : '';
  if (!ok) return { ok: false, msg: 'جفت‌زبان‌ها: خطای مشخص‌شدهٔ هر ردیف را برطرف کنید.' };
  if (out.length < 1) return { ok: false, msg: 'حداقل یک جفت‌زبان لازم است.' };
  return { ok: true, msg: '' };
}

function bindLangPairsEditor() {
  var list = $('#lp-list');
  if (!list) return;
  list.addEventListener('click', function (ev) {
    var t = ev.target && ev.target.closest ? ev.target.closest('button') : null;
    if (!t) return;
    var row = t.closest('.hz-lp-row');
    if (!row) return;
    if (t.classList.contains('lp-del')) { row.remove(); collectLangPairs(); }
    else if (t.classList.contains('lp-en')) {
      var off = row.classList.toggle('off');
      t.textContent = off ? 'غیرفعال' : 'فعال';
      t.classList.toggle('ok', !off); t.classList.toggle('ghost', off);
      collectLangPairs();
    }
  });
  list.addEventListener('change', collectLangPairs);
  list.addEventListener('input', collectLangPairs);
  var add = $('#lp-add');
  if (add) add.addEventListener('click', function () {
    list.insertAdjacentHTML('beforeend', lpRowHTML({ code: '', langs: ['en', 'fa'], label: '', note: '', enabled: true }));
    collectLangPairs();
  });
  collectLangPairs();
}

function validateSettingsEditors() {
  var msgs = [];
  if ($('#set-form .hz-tar') && !syncTariffEditor()) msgs.push('تعرفهٔ ساعتی: در همهٔ حوزه‌ها عدد صحیح غیرمنفی (تا ۱۰۰ میلیارد تومان) وارد کنید.');
  if ($('#set-form .hz-lp')) { var r = collectLangPairs(); if (!r.ok) msgs.push(r.msg); }
  if (msgs.length) { var m = $('#msg'); m.textContent = 'خطا: ' + msgs.join(' '); m.className = 'msg err'; return false; }
  return true;
}

function settingsLoad() {
  api('GET', '/admin/settings').then(function (d) {
    var s = d.settings || {};
    var ORDER = ['translator_share_percent', 'cancel_fee_percent', 'tax_percent', 'cash_enabled', 'online_enabled',
      'payment_provider', 'zarinpal_merchant_id', 'zarinpal_sandbox', 'payment_callback_base',
      'settlement_period', 'default_city_id', 'car_fee_per_hour', 'hourly_tariffs', 'language_pairs',
      'translator_terms_text', 'translator_nda_text', 'charter_text', 'translator_help_text',
      'traveler_terms_text', 'support_phone'];
    SET_EDITOR_VALIDATE = null;
    $('#set-form').innerHTML = ORDER.filter(function (k) { return s[k]; }).map(function (k) {
      var it = s[k];
      var field;
      if (k === 'hourly_tariffs') {
        field = tariffEditorHTML(String(it.value));
      } else if (k === 'language_pairs') {
        field = langPairsHTML(String(it.value));
      } else if (it.type === 'bool') {
        field = '<select class="input" id="set-' + k + '" data-type="bool"><option value="1"' + (Number(it.value) ? ' selected' : '') + '>فعال</option><option value="0"' + (!Number(it.value) ? ' selected' : '') + '>غیرفعال</option></select>';
      } else if (it.type === 'enum') {
        field = '<select class="input" id="set-' + k + '">' + (it.values || []).map(function (v) {
          return '<option value="' + esc(v) + '"' + (it.value === v ? ' selected' : '') + '>' + esc(v === 'daily' ? 'روزانه' : v === 'weekly' ? 'هفتگی' : v) + '</option>';
        }).join('') + '</select>';
      } else if (it.type === 'json') {
        field = '<textarea class="input dir-ltr" id="set-' + k + '" data-type="json" style="min-height:90px;direction:ltr">' + esc(String(it.value)) + '</textarea>';
      } else if (it.type === 'text') {
        field = '<textarea class="input" id="set-' + k + '" data-type="text">' + esc(String(it.value)) + '</textarea>';
      } else {
        field = '<input class="input dir-ltr num" id="set-' + k + '" data-type="int" type="number" value="' + esc(String(it.value)) + '"' +
          (it.min != null ? ' min="' + it.min + '"' : '') + (it.max != null ? ' max="' + it.max + '"' : '') + '>';
      }
      return '<div style="margin-bottom:14px"><label class="field" for="set-' + k + '" style="margin-top:0">' + esc(SET_NICE_LABEL[k] || it.label) + '</label>' + field + '</div>';
    }).join('');
    // اتصال ویرایشگرهای ساخت‌یافته (تعرفهٔ ساعتی و جفت‌زبان‌ها)
    if (s.hourly_tariffs) bindTariffEditor();
    if (s.language_pairs) bindLangPairsEditor();
    if ($('#set-form .hz-tar') || $('#set-form .hz-lp')) SET_EDITOR_VALIDATE = validateSettingsEditors;
    // وضعیت اعلان فوری (پوش) — مستقل از فرم تنظیمات
    var ps = $('#push-status');
    if (ps) {
      api('GET', '/admin/push').then(function (p) {
        ps.innerHTML = p.enabled
          ? '<div class="crow"><div class="c-body"><b>فعال</b><span class="c-meta">کلید عمومی VAPID: <span class="dir-ltr">' + esc(String(p.public_key || '').slice(0, 22)) + '…</span> · اشتراک‌ها: ' + faNum(p.subscriptions) +
            (p.with_errors ? ' · دارای خطا: ' + faNum(p.with_errors) : '') + '</span></div>' +
            '<button class="btn sm" id="push-test-btn" type="button">اعلان آزمایشی</button></div>'
          : '<div class="crow"><div class="c-body"><b>غیرفعال</b><span class="c-meta">کتابخانهٔ web-push یا کلیدهای VAPID در دسترس نیست؛ اپ‌ها بدون پوش ادامه می‌دهند.</span></div></div>';
        var tb = $('#push-test-btn');
        if (tb) tb.addEventListener('click', function () {
          askModal({ title: 'اعلان آزمایشی', text: 'شناسهٔ کاربر (users.id) را وارد کنید — اعلان به اشتراک‌های ثبت‌شدهٔ همان کاربر می‌رود:', input: 'مثلاً ۳', ok: 'ارسال' })
            .then(function (v) { if (v === null) throw { silent: true }; return api('POST', '/admin/push/test', { user_id: Number(v) }); })
            .then(function (r) { toast('اعلان به ' + faNum(r.queued || 0) + ' اشتراک رجیستر شد', 'ok'); })
            .catch(function (e) { if (!e || !e.silent) toastErr(e); });
        });
      }).catch(function () { ps.innerHTML = '<div class="sub">وضعیت پوش دریافت نشد.</div>'; });
    }
  }).catch(function (e) { if (e.status === 401) return boot(); toastErr(e); });
}
LOADERS.settings = settingsLoad;
$('#save-settings').addEventListener('click', function () {
  var m = $('#msg');
  m.textContent = ''; m.className = 'msg';
  if (SET_EDITOR_VALIDATE && !SET_EDITOR_VALIDATE()) return;
  var body = {};
  var bad = null;
  $$('#set-form [id^=set-]').forEach(function (inp) {
    var k = inp.id.replace(/^set-/, '');
    var t = inp.getAttribute('data-type');
    if (t === 'json') {
      try { body[k] = JSON.parse(inp.value); } catch (e) { bad = k; }
    } else if (t === 'int') body[k] = Number(inp.value);
    else if (t === 'bool') body[k] = Number(inp.value) === 1;
    else body[k] = inp.value;
  });
  if (bad) { m.textContent = 'خطا: مقدار JSON نامعتبر است'; m.className = 'msg err'; return; }
  if (!Object.keys(body).length) { m.textContent = 'تغییری برای ذخیره نیست'; m.className = 'msg'; return; }
  api('PUT', '/admin/settings', body).then(function (r) {
    m.textContent = 'ذخیره شد؛ تغییرات اعمال شد.'; m.className = 'msg ok';
    toast('تنظیمات ذخیره شد', 'ok');
  }).catch(function (e) { m.textContent = 'خطا: ' + errMsg(e); m.className = 'msg err'; });
});
$('#cp-btn').addEventListener('click', function () {
  var m = $('#cp-msg');
  m.textContent = ''; m.className = 'msg';
  api('POST', '/admin/change-password', { current_password: $('#cp-current').value, new_password: $('#cp-new').value })
    .then(function () { m.textContent = 'رمز تغییر کرد؛ نشست‌های دیگر باطل شد.'; m.className = 'msg ok'; $('#cp-current').value = ''; $('#cp-new').value = ''; })
    .catch(function (e) { m.textContent = 'خطا: ' + errMsg(e); m.className = 'msg err'; });
});

/* ---------- گزارش‌ها ---------- */
LOADERS.reports = function () {
  var days = $('#rep-days').value || '7';
  api('GET', '/admin/reports?days=' + days).then(function (r) {
    var b = r.bookings;
    $('#rep-kpis').innerHTML = [
      ['رزرو ایجادشده', b.created, '', 'var(--accent)'],
      ['تسویه‌شده', b.done, 'نرخ تکمیل: ' + (b.completion_rate == null ? '—' : faNum(b.completion_rate) + '٪'), 'var(--ok)'],
      ['لغوشده', b.cancelled, 'نرخ لغو: ' + (b.cancel_rate == null ? '—' : faNum(b.cancel_rate) + '٪'), 'var(--danger)'],
      ['میانگین زمان تطبیق', b.avg_match_minutes == null ? '—' : faNum(b.avg_match_minutes), 'دقیقه', 'var(--brand)'],
      ['پرداخت به مترجمان', r.finance.translator_payout, 'سهم ۸۰٪ از خدمات تسویه‌شده', 'var(--violet)'],
    ].map(function (k) {
      return '<div class="stat" style="--dot:' + k[3] + '"><div class="s-label">' + k[0] + '</div>' +
        '<div class="s-value num">' + k[1] + '</div><div class="s-note">' + k[2] + '</div></div>';
    }).join('');
    var pd = r.per_day || [];
    var maxC = Math.max.apply(null, pd.map(function (x) { return Math.max(x.created, x.cancelled); }).concat([1]));
    $('#rep-bars').innerHTML = pd.map(function (x) {
      return '<div class="bar" title="' + x.d + '"><i style="height:' + Math.round((x.created / maxC) * 100) + '%"></i>' +
        '<small>' + esc(x.d.slice(5)) + '</small></div>' +
        '<div class="bar b2" title="' + x.d + '"><i style="height:' + Math.round((x.cancelled / maxC) * 100) + '%"></i></div>';
    }).join('') || '<div class="empty">داده‌ای در این بازه نیست</div>';
    $('#rep-top').innerHTML = (r.top_translators || []).map(function (t) {
      return '<tr><td><b>' + esc(t.name || '—') + '</b></td><td class="num">' + faNum(t.missions) + '</td><td class="num">' + money(t.net) + '</td></tr>';
    }).join('') || '<tr><td colspan="3"><div class="empty">ماموریت تسویه‌شده‌ای در این بازه نیست</div></td></tr>';
  }).catch(function (e) { if (e.status === 401) return boot(); toastErr(e); });
};
$('#rep-days').addEventListener('change', function () { LOADERS.reports(); });
$('#rep-csv').addEventListener('click', function () {
  var days = $('#rep-days').value || '7';
  var t = sessionStorage.getItem(TOKEN_KEY);
  fetch('/api/admin/reports.csv?days=' + days, { headers: { Authorization: 'Bearer ' + (t || '') } })
    .then(function (r) { if (!r.ok) throw new Error('csv'); return r.blob(); })
    .then(function (bl) {
      var a = document.createElement('a');
      a.href = URL.createObjectURL(bl);
      a.download = 'hamrah-bookings.csv';
      document.body.appendChild(a); a.click(); a.remove();
      toast('خروجی CSV دانلود شد', 'ok');
    }).catch(function () { toast('خطا در گرفتن خروجی', 'err'); });
});

/* ---------- کارمندان ---------- */
function staffLoad() {
  api('GET', '/admin/staff').then(function (d) {
    $('#staff-body').innerHTML = (d.staff || []).map(function (s) {
      var isMe = ME && ME.user && ME.user.id === s.id;
      return '<tr><td><b>' + esc(s.name || s.username) + '</b><div class="sub dir-ltr">' + esc(s.username) + '</div></td>' +
        '<td>' + esc(ROLE_FA[s.role] || s.role) + '</td>' +
        '<td>' + (s.is_active ? '<span class="pill ok">فعال</span>' : '<span class="pill bad">غیرفعال</span>') + '</td>' +
        '<td class="num">' + faNum(s.sessions) + '</td><td class="sub">' + (s.last_login_at ? dt(s.last_login_at) : '—') + '</td>' +
        '<td><div class="actions">' +
        '<button class="btn sm" data-stfpw="' + s.id + '" type="button">ریست رمز</button>' +
        '<button class="btn sm" data-stfrevoke="' + s.id + '" type="button">ابطال نشست‌ها</button>' +
        (isMe ? '' : s.is_active
          ? '<button class="btn sm danger" data-stfdis="' + s.id + '" type="button">غیرفعال</button>'
          : '<button class="btn sm ok" data-stfen="' + s.id + '" type="button">فعال‌سازی</button>') +
        '</div></td></tr>';
    }).join('') || '<tr><td colspan="6"><div class="empty">کارمندی ثبت نشده است</div></td></tr>';
    $$('#staff-body [data-stfpw]').forEach(function (b) { b.addEventListener('click', function () {
      var id = Number(b.getAttribute('data-stfpw'));
      askModal({ title: 'ریست رمز کارمند', text: 'رمز تازه (حداقل ۱۲ نویسه؛ نشست‌های فعلی او باطل می‌شود):', input: 'رمز تازه', ok: 'ریست رمز', danger: true })
        .then(function (pw) { if (pw === null) throw { silent: true };
          return api('POST', '/admin/staff/' + id + '/password', { password: pw || '' }); })
        .then(function () { toast('رمز ریست شد', 'ok'); })
        .catch(function (e) { if (!e || !e.silent) toastErr(e); });
    }); });
    $$('#staff-body [data-stfrevoke]').forEach(function (b) { b.addEventListener('click', function () {
      var id = Number(b.getAttribute('data-stfrevoke'));
      api('POST', '/admin/staff/' + id + '/revoke', {}).then(function () { toast('نشست‌ها ابطال شد', 'ok'); staffLoad(); }).catch(toastErr);
    }); });
    $$('#staff-body [data-stfdis]').forEach(function (b) { b.addEventListener('click', function () {
      var id = Number(b.getAttribute('data-stfdis'));
      askModal({ title: 'غیرفعال‌کردن حساب', text: 'کارمند دیگر وارد نمی‌شود و نشست‌هایش باطل می‌شود.', ok: 'غیرفعال کن', danger: true })
        .then(function (okv) { if (!okv) throw { silent: true }; return api('PATCH', '/admin/staff/' + id, { is_active: false }); })
        .then(function () { toast('حساب غیرفعال شد', 'ok'); staffLoad(); })
        .catch(function (e) { if (!e || !e.silent) toastErr(e); });
    }); });
    $$('#staff-body [data-stfen]').forEach(function (b) { b.addEventListener('click', function () {
      var id = Number(b.getAttribute('data-stfen'));
      api('PATCH', '/admin/staff/' + id, { is_active: true }).then(function () { toast('حساب فعال شد', 'ok'); staffLoad(); }).catch(toastErr);
    }); });
  }).catch(function (e) { if (e.status === 401) return boot(); toastErr(e); });
}
LOADERS.staff = staffLoad;
$('#stf-add-btn').addEventListener('click', function () {
  var m = $('#stf-msg');
  m.textContent = ''; m.className = 'msg';
  api('POST', '/admin/staff', { username: $('#stf-username').value.trim(), name: $('#stf-name').value.trim(),
    role: $('#stf-role').value, password: $('#stf-password').value })
    .then(function (r) { m.textContent = 'حساب کارمند ساخته شد'; m.className = 'msg ok';
      $('#stf-username').value = ''; $('#stf-name').value = ''; $('#stf-password').value = '';
      staffLoad(); })
    .catch(function (e) { m.textContent = 'خطا: ' + errMsg(e); m.className = 'msg err'; });
});

/* ---------- ممیزی ---------- */
LOADERS.audit = function () {
  api('GET', '/admin/audit?limit=200').then(function (d) {
    $('#audit-body').innerHTML = (d.entries || []).map(function (e) {
      return '<tr><td class="sub">' + dt(e.at) + '</td>' +
        '<td>' + (e.actor ? '<b class="dir-ltr">' + esc(e.actor) + '</b>' : '<span class="sub">سیستم</span>') + '</td>' +
        '<td><span class="pill info" style="direction:ltr">' + esc(e.action) + '</span></td>' +
        '<td><code class="sub" style="direction:ltr;unicode-bidi:embed;font-size:10.5px">' + esc(JSON.stringify(e.detail)) + '</code></td></tr>';
    }).join('') || '<tr><td colspan="4"><div class="empty">رویدادی ثبت نشده است</div></td></tr>';
  }).catch(function (e) { if (e.status === 401) return boot(); toastErr(e); });
};



