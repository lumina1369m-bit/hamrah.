/* همراه — اپ مترجم: اعلان فوری (Web Push).
 * «درخواست جدید»، رد/انقضای مدرک، یادآوری مصاحبه و پیام پشتیبانی حتی با برنامهٔ بسته می‌رسند.
 * اگر مرورگر پوش را پشتیبانی نکند، برنامه بی‌صدا بدون پوش ادامه می‌دهد. */
(function () {
  'use strict';
  var TOKEN_KEY = 'hz.translator.v1'; // همان کلیدی که ui.js (HZ.load) می‌خواند
  var subscribedEndpoint = null;

  function token() {
    try {
      if (window.HZ && window.HZ.load && typeof window.HZ.load === 'function') {
        var s = window.HZ.load(); if (s && s.token) return s.token;
      }
    } catch (e) {}
    try { var raw = localStorage.getItem(TOKEN_KEY); var st = raw ? JSON.parse(raw) : null; return (st && st.token) || null; } catch (e) { return null; }
  }

  function urlB64ToUint8Array(s) {
    var pad = '='.repeat((4 - (s.length % 4)) % 4);
    var base64 = (s + pad).replace(/-/g, '+').replace(/_/g, '/');
    var raw = atob(base64);
    var out = new Uint8Array(raw.length);
    for (var i = 0; i < raw.length; i++) out[i] = raw.charCodeAt(i);
    return out;
  }

  async function subscribePush() {
    var t = token();
    if (!t || subscribedEndpoint) return;
    if (!('serviceWorker' in navigator) || !('PushManager' in window) || !window.isSecureContext) return;
    if (window.Notification && Notification.permission === 'denied') return;
    try {
      var res = await fetch('/api/push/vapid', { headers: { Authorization: 'Bearer ' + t }, cache: 'no-store' });
      if (!res.ok) return;
      var key = (await res.json()).publicKey;
      if (!key) return;
      var reg = await navigator.serviceWorker.ready;
      var sub = await reg.pushManager.getSubscription();
      if (sub && sub.endpoint && subscribedEndpoint === sub.endpoint) return;
      if (sub) { try { await sub.unsubscribe(); } catch (e) {} }
      sub = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: urlB64ToUint8Array(key) });
      var j = sub.toJSON();
      var save = await fetch('/api/push/subscribe', { method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + t },
        body: JSON.stringify({ endpoint: j.endpoint, keys: j.keys }) });
      if (save.ok) subscribedEndpoint = j.endpoint;
    } catch (e) { /* پوش اختیاری است؛ شکستش برنامه را نمی‌شکند */ }
  }

  async function unsubscribePush() {
    if (!subscribedEndpoint) return;
    try {
      await fetch('/api/push/unsubscribe', { method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ endpoint: subscribedEndpoint }) });
    } catch (e) {}
    subscribedEndpoint = null;
  }

  function armUserGesture() {
    if (!window.Notification || Notification.permission !== 'default') { subscribePush(); return; }
    var handler = function () {
      document.removeEventListener('click', handler, true);
      subscribePush();
    };
    document.addEventListener('click', handler, true);
  }

  window.addEventListener('storage', function (e) {
    if (!token()) unsubscribePush();
    else subscribedEndpoint = null;
  });

  function boot() {
    if (token()) armUserGesture();
    setInterval(function () { if (token()) subscribePush(); }, 60000);
    document.addEventListener('visibilitychange', function () { if (!document.hidden && token()) subscribePush(); });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
