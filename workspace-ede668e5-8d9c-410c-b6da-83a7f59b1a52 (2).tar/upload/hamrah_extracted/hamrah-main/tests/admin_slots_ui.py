# تست نوبت‌های مصاحبه پنل نسل دوم: رزرو نوبت توسط مترجم، افزودن نوبت از فرم، ثبت عدم حضور
import asyncio, sys, json, random, urllib.request, datetime
from playwright.async_api import async_playwright

BASE = sys.argv[1] if len(sys.argv) > 1 else 'http://127.0.0.1:8081'
PASSWORD = 'test-admin-pass'
results = []
def check(name, ok):
    results.append(bool(ok))
    print(('  ok   ' if ok else '  FAIL ') + name)

def api(method, path, body=None, token=None):
    h = {'Content-Type': 'application/json'}
    if token: h['Authorization'] = 'Bearer ' + token
    rq = urllib.request.Request(BASE + '/api' + path, method=method, headers=h,
                                data=json.dumps(body).encode() if body is not None else None)
    try:
        with urllib.request.urlopen(rq, timeout=10) as r:
            return r.status, json.loads(r.read() or b'{}')
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read() or b'{}')

def make_translator():
    phone = '9' + str(random.randint(100000000, 999999999))
    api('POST', '/auth/request-code', {'phone': phone, 'role': 'translator'})
    _, v = api('POST', '/auth/verify', {'phone': phone, 'role': 'translator', 'code': '123456'})
    tok = v['token']
    api('POST', '/translator/registration', {'nda': True, 'charter': True, 'gender': 'male', 'first_name': 'سامان',
        'last_name': 'تست', 'city': 'شیراز', 'car': False, 'languages': ['en', 'fa'], 'fields': ['general']}, tok)
    return phone, tok

async def main():
    phone, tok = make_translator()
    _, adm = api('POST', '/admin/login', {'password': PASSWORD})
    atok = adm.get('token')
    future = datetime.datetime.utcnow() + datetime.timedelta(days=2)
    st, sl = api('POST', '/admin/interview-slots', {'starts_at': future.isoformat() + 'Z'}, atok)
    check('نوبت از سمت مدیر ساخته شد', st == 201)
    st, _ = api('POST', '/translator/interview-slots/%d/book' % sl['id'], None, tok)
    check('مترجم نوبت آزاد را رزرو کرد', st == 200)
    async with async_playwright() as p:
        b = await p.chromium.launch(args=['--no-sandbox'])
        ctx = await b.new_context(viewport={'width': 1280, 'height': 900})
        page = await ctx.new_page(); errs = []
        page.on('pageerror', lambda e: errs.append(str(e)[:120]))
        await page.goto(BASE + '/admin/index.html'); await page.wait_for_timeout(500)
        await page.fill('#pw', PASSWORD); await page.click('#login-btn'); await page.wait_for_timeout(1000)
        await page.click('.nav-item[data-nav=interviews]'); await page.wait_for_timeout(900)
        row = page.locator('#slots tr', has_text=phone)
        check('نوبت رزروشده با شمارهٔ مترجم نمایش داده می‌شود', await row.count() == 1)
        check('وضعیت «رزرو شده» است', 'رزرو شده' in (await row.first.text_content() or ''))
        # افزودن نوبت از فرم
        d3 = (datetime.datetime.now() + datetime.timedelta(days=3)).strftime('%Y-%m-%d')
        await page.fill('#slot-date', d3); await page.fill('#slot-time', '10:30')
        await page.click('#slot-add-btn'); await page.wait_for_timeout(800)
        msg = await page.text_content('#slot-msg')
        check('افزودن نوبت پیام موفقیت می‌دهد', 'ساخته شد' in (msg or ''))
        check('نوبت تازه در فهرست است', await page.locator('#slots tr', has_text='آزاد').count() >= 1)
        # عدم حضور با مودال تأیید
        await row.locator('[data-noshow]').click(); await page.wait_for_timeout(400)
        await page.click('#modal-ok'); await page.wait_for_timeout(900)
        row2 = page.locator('#slots tr', has_text=phone)
        check('پس از عدم حضور، وضعیت «عدم حضور» است', await row2.count() == 1 and 'عدم حضور' in (await row2.first.text_content() or ''))
        check('خطای صفحه', not errs)
        await b.close()
    print('RESULT: %s (%d/%d)' % ('PASS' if all(results) else 'FAIL', sum(results), len(results)))
    sys.exit(0 if all(results) else 1)

asyncio.run(main())
