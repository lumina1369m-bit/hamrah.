# تست بخش‌های عملیاتی پنل نسل دوم: تجدیدنظرها، اختلاف‌ها، کنسول اعزام (سه پنل)، مالی؛ دارک‌مود و اسکرین‌شات
import asyncio, sys
from playwright.async_api import async_playwright

BASE = sys.argv[1] if len(sys.argv) > 1 else 'http://127.0.0.1:8081'
PASSWORD = 'test-admin-pass' if '8081' in BASE else 'hamrah-preview-2026'
results = []
def check(name, ok):
    results.append(bool(ok))
    print(('  ok   ' if ok else '  FAIL ') + name)

async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(args=['--no-sandbox'])
        ctx = await b.new_context(viewport={'width': 1280, 'height': 900})
        page = await ctx.new_page(); errs = []
        page.on('pageerror', lambda e: errs.append(str(e)[:120]))
        await page.goto(BASE + '/admin/index.html'); await page.wait_for_timeout(500)
        await page.fill('#pw', PASSWORD)
        await page.click('#login-btn'); await page.wait_for_timeout(1000)
        check('ورود، پنل را باز می‌کند', await page.is_visible('#app-view'))

        # --- تجدیدنظرها ---
        await page.click('.nav-item[data-nav=recons]'); await page.wait_for_timeout(700)
        check('بخش تجدیدنظرها نمایان می‌شود', await page.is_visible('#view-recons'))
        check('عنوان صفحه تجدیدنظرهاست', (await page.text_content('#page-title') or '').strip() == 'تجدیدنظرها')
        check('یادداشت صادقانهٔ جریان تجدیدنظر هست', 'فعال نشده' in (await page.text_content('#view-recons') or ''))
        check('دکمهٔ اقدامی در تجدیدنظر نیست', await page.locator('#view-recons tbody button').count() == 0)

        # --- اختلاف‌ها ---
        await page.click('.nav-item[data-nav=disputes]'); await page.wait_for_timeout(700)
        check('بخش اختلاف‌ها نمایان می‌شود', await page.is_visible('#view-disputes'))
        check('سرصفحهٔ صف اختلاف هست', 'صف اختلاف نقدی' in (await page.text_content('#view-disputes') or ''))
        check('ستون اقدام در جدول اختلاف هست', 'اقدام' in (await page.text_content('#view-disputes thead') or ''))
        check('وضعیت پشتیبانی در جدول پشتیبانی هست', await page.locator('#sup-body tr').count() == 1)

        # --- کنسول اعزام: سه پنل تک‌صفحه‌ای ---
        await page.click('.nav-item[data-nav=dispatch]'); await page.wait_for_timeout(700)
        check('پنل صف انتظار هست', await page.is_visible('#dsp-queue'))
        check('پنل پروندهٔ انتخابی هست', await page.is_visible('#dsp-side'))
        check('پنل عرضهٔ آنی هست', await page.is_visible('#dsp-idle'))
        check('جدول مأموریت‌های در جریان هست', await page.locator('#dsp-missions').count() == 1)
        check('راهنمای «سیستم رتبه‌بندی می‌کند» هست', 'رتبه' in (await page.text_content('#view-dispatch') or ''))

        # --- مالی ---
        await page.click('.nav-item[data-nav=finance]'); await page.wait_for_timeout(800)
        check('چهار کارت آماری مالی رندر شد', await page.locator('#fin-stats .stat').count() == 4)
        stats = await page.text_content('#fin-stats') or ''
        check('کارت استردادشده در مالی هست', 'استردادشده' in stats)
        check('جدول پرداخت‌های معلق رندر شد', await page.locator('#fin-wait-body').count() == 1)
        check('جدول تسویهٔ شبا رندر شد', await page.locator('#fin-settle-body').count() == 1)

        # --- دارک‌مود ---
        await page.click('#theme-toggle'); await page.wait_for_timeout(400)
        check('دارک‌مود فعال شد', await page.get_attribute('html', 'data-theme') == 'dark')
        await page.click('.nav-item[data-nav=dispatch]'); await page.wait_for_timeout(500)
        await page.screenshot(path='/home/z/my-project/download/admin2_dispatch_dark.png', full_page=False)
        await page.click('.nav-item[data-nav=dashboard]'); await page.wait_for_timeout(700)
        await page.screenshot(path='/home/z/my-project/download/admin2_dashboard_dark.png', full_page=False)
        await page.click('#theme-toggle'); await page.wait_for_timeout(400)
        await page.click('.nav-item[data-nav=staff]'); await page.wait_for_timeout(700)
        await page.screenshot(path='/home/z/my-project/download/admin2_staff_light.png', full_page=False)
        await page.click('.nav-item[data-nav=reports]'); await page.wait_for_timeout(800)
        await page.screenshot(path='/home/z/my-project/download/admin2_reports_light.png', full_page=False)

        check('خطای صفحه‌ها', not errs)
        await b.close()
        ok = all(results)
        print('RESULT:', 'PASS' if ok else 'FAIL', f'({sum(results)}/{len(results)})', errs if errs else '')
        sys.exit(0 if ok else 1)

asyncio.run(main())
