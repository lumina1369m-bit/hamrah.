# تست پیکربندی پنل نسل دوم: قابلیت‌ها (سوییچ + مودال تأیید)، شهرها (افزودن + ضدتزریق)، دفتر رویدادها با هویت عامل
import asyncio, sys, json, urllib.request
from playwright.async_api import async_playwright

BASE = sys.argv[1] if len(sys.argv) > 1 else 'http://127.0.0.1:8097'
PASSWORD = 'test-admin-pass'
results = []
def check(name, ok):
    results.append(bool(ok))
    print(('  ok   ' if ok else '  FAIL ') + name)

def api(method, path, body=None, token=None):
    h = {'Content-Type': 'application/json'}
    if token: h['Authorization'] = 'Bearer ' + token
    rq = urllib.request.Request(BASE + '/api' + path, method=method, headers=h,
                                data=json.dumps(body).encode() if body is not None else None)
    try:
        with urllib.request.urlopen(rq, timeout=10) as r:
            return r.status, json.loads(r.read() or b'{}')
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read() or b'{}')

async def main():
    _, adm = api('POST', '/admin/login', {'password': PASSWORD})
    atok = adm['token']
    async with async_playwright() as p:
        b = await p.chromium.launch(args=['--no-sandbox'])
        ctx = await b.new_context(viewport={'width': 1280, 'height': 900})
        page = await ctx.new_page(); errs = []
        page.on('pageerror', lambda e: errs.append(str(e)[:120]))
        await page.goto(BASE + '/admin/index.html'); await page.wait_for_timeout(500)
        await page.fill('#pw', PASSWORD); await page.click('#login-btn'); await page.wait_for_timeout(1000)
        # --- قابلیت‌ها ---
        await page.click('.nav-item[data-nav=features]'); await page.wait_for_timeout(800)
        n = await page.locator('[data-feat]').count()
        check('فهرست قابلیت‌ها با سوییچ رندر شد', n >= 10)
        # خاموش‌کردن car_mode با مودال تأیید
        await page.locator('[data-feat=car_mode]').click(); await page.wait_for_timeout(400)
        await page.click('#modal-ok'); await page.wait_for_timeout(900)
        _, f = api('GET', '/admin/features', None, atok)
        cm = [x for x in f['features'] if x['key'] == 'car_mode'][0]
        check('خاموش‌کردن car_mode روی سرور اعمال شد', cm['enabled'] is False)
        # بازگردانی
        await page.locator('[data-feat=car_mode]').click(); await page.wait_for_timeout(400)
        await page.click('#modal-ok'); await page.wait_for_timeout(900)
        _, f2 = api('GET', '/admin/features', None, atok)
        cm2 = [x for x in f2['features'] if x['key'] == 'car_mode'][0]
        check('بازگردانی car_mode موفق بود', cm2['enabled'] is True)
        # --- شهرها ---
        await page.click('.nav-item[data-nav=cities]'); await page.wait_for_timeout(800)
        check('فیلد شعاع با راهنمای منطق پوشش هست', await page.locator('#city-add-radius_km').count() == 1 and 'منطق شعاع' in (await page.text_content('#view-cities') or ''))
        check('نقشهٔ پوشش در نما رندر شد', await page.is_visible('#city-map'))
        await page.fill('#city-add-name_fa', '<img src=x onerror="window.__xss=1">')
        await page.fill('#city-add-name_en', 'XSSCity')
        await page.fill('#city-add-province', 'تست')
        await page.fill('#city-add-lat', '35.7'); await page.fill('#city-add-lng', '51.4')
        await page.click('#city-add-btn'); await page.wait_for_timeout(900)
        check('شهر جدید اضافه شد', 'اضافه شد' in (await page.text_content('#city-msg') or ''))
        check('نام شهر به‌صورت متن نمایش داده می‌شود (بدون تزریق)', await page.locator('#city-body img').count() == 0)
        check('اسکریپت تزریق‌شده اجرا نشد', await page.evaluate('window.__xss') is None)
        # --- دفتر رویدادها ---
        await page.click('.nav-item[data-nav=audit]'); await page.wait_for_timeout(800)
        check('دفتر رویدادها ردیف دارد', await page.locator('#audit-body tr').count() >= 3)
        check('هویت عامل (owner) ثبت شده', await page.locator('#audit-body tr', has_text='owner').count() >= 1)
        check('اقدام شهر در دفتر هست', (await page.text_content('#audit-body') or '').find('city.create') >= 0)
        check('خطای صفحه', not errs)
        await ctx.close(); await b.close()
    failed = results.count(False)
    print(f'نتیجه: {results.count(True)} موفق، {failed} ناموفق')
    sys.exit(1 if failed else 0)

asyncio.run(main())
