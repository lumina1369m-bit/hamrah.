# تست RBAC مرورگری پنل نسل دوم: ساخت کارمند، دید ناوبری بر اساس نقش، گارد ۴۰۳ سمت سرور، غیرفعال‌سازی
import asyncio, sys, json, random, urllib.request
from playwright.async_api import async_playwright

BASE = sys.argv[1] if len(sys.argv) > 1 else 'http://127.0.0.1:8081'
PASSWORD = 'test-admin-pass'
STAFF_PASS = 'Str0ng-Pass-2026!'
results = []
def check(name, ok):
    results.append(bool(ok))
    print(('  ok   ' if ok else '  FAIL ') + name)

def api(method, path, body=None, token=None):
    h = {'Content-Type': 'application/json'}
    if token: h['Authorization'] = 'Bearer ' + token
    rq = urllib.request.Request(BASE + '/api' + path, method=method, headers=h,
                                data=json.dumps(body).encode() if body is not None else None)
    try:
        with urllib.request.urlopen(rq, timeout=10) as r:
            return r.status, json.loads(r.read() or b'{}')
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read() or b'{}')

async def main():
    _, adm = api('POST', '/admin/login', {'password': PASSWORD})
    atok = adm['token']
    ops_user = 'ops' + str(random.randint(1000, 9999))
    fin_user = 'fin' + str(random.randint(1000, 9999))
    async with async_playwright() as p:
        b = await p.chromium.launch(args=['--no-sandbox'])
        ctx = await b.new_context(viewport={'width': 1280, 'height': 900})
        page = await ctx.new_page(); errs = []
        page.on('pageerror', lambda e: errs.append(str(e)[:120]))
        await page.goto(BASE + '/admin/index.html'); await page.wait_for_timeout(500)
        await page.fill('#pw', PASSWORD); await page.click('#login-btn'); await page.wait_for_timeout(1000)
        # --- ساخت کارمند عملیات از فرم ---
        await page.click('.nav-item[data-nav=staff]'); await page.wait_for_timeout(700)
        check('ردیف ماتریس نقش‌ها هست', await page.locator('#roles-body tr').count() == 5)
        await page.fill('#st-username', ops_user)
        await page.fill('#st-name', 'کارشناس عملیات تست')
        await page.select_option('#st-role', 'ops')
        await page.fill('#st-password', STAFF_PASS)
        await page.click('#st-add-btn'); await page.wait_for_timeout(800)
        check('حساب کارمند ساخته شد', 'ساخته شد' in (await page.text_content('#st-msg') or ''))
        check('کارمند در فهرست هست', await page.locator('#staff-body tr', has_text=ops_user).count() == 1)
        # --- ورود به‌عنوان کارمند عملیات در زمینهٔ جدا ---
        ctx2 = await b.new_context(viewport={'width': 1280, 'height': 900})
        pg2 = await ctx2.new_page(); errs2 = []
        pg2.on('pageerror', lambda e: errs2.append(str(e)[:120]))
        await pg2.goto(BASE + '/admin/index.html'); await pg2.wait_for_timeout(500)
        await pg2.fill('#username', ops_user); await pg2.fill('#pw', STAFF_PASS)
        await pg2.click('#login-btn'); await pg2.wait_for_timeout(1000)
        check('ورود کارمند موفق بود', await pg2.is_visible('#app-view'))
        chip = await pg2.text_content('#me-chip')
        check('چیپ کارمند نام کاربری و نقش را دارد', ops_user in (chip or '') and 'عملیات' in (chip or ''))
        # ناوبری بر اساس نقش
        check('عملیات: رزروها دیده می‌شود', await pg2.is_visible('.nav-item[data-nav=bookings]'))
        check('عملیات: کنسول اعزام دیده می‌شود', await pg2.is_visible('.nav-item[data-nav=dispatch]'))
        check('عملیات: گزارش‌ها دیده می‌شود', await pg2.is_visible('.nav-item[data-nav=reports]'))
        check('عملیات: قابلیت‌ها پنهان است', not await pg2.is_visible('.nav-item[data-nav=features]'))
        check('عملیات: کارمندان پنهان است', not await pg2.is_visible('.nav-item[data-nav=staff]'))
        check('عملیات: تنظیمات پنهان است', not await pg2.is_visible('.nav-item[data-nav=settings]'))
        # گارد سرور: تلاش برای تغییر قابلیت با توکن کارمند → ۴۰۳
        st403 = await pg2.evaluate("""async () => {
          const t = sessionStorage.getItem('hamrah_admin_token');
          const r = await fetch('/api/admin/features', {method:'PUT', headers:{'Content-Type':'application/json', Authorization:'Bearer ' + t}, body:'{"car_mode":false}'});
          return r.status;
        }""")
        check('سرور تغییر قابلیت توسط عملیات را ۴۰۳ می‌کند', st403 == 403)
        st403b = await pg2.evaluate("""async () => {
          const t = sessionStorage.getItem('hamrah_admin_token');
          const r = await fetch('/api/admin/staff', {headers:{Authorization:'Bearer ' + t}});
          return r.status;
        }""")
        check('سرور فهرست کارمندان را از عملیات می‌گیرد (۴۰۳)', st403b == 403)
        # --- کارمند مالی: فقط‌مالی ---
        api('POST', '/admin/staff', {'username': fin_user, 'name': 'کارشناس مالی', 'role': 'finance', 'password': STAFF_PASS}, atok)
        ctx3 = await b.new_context(viewport={'width': 1280, 'height': 900})
        pg3 = await ctx3.new_page()
        await pg3.goto(BASE + '/admin/index.html'); await pg3.wait_for_timeout(500)
        await pg3.fill('#username', fin_user); await pg3.fill('#pw', STAFF_PASS)
        await pg3.click('#login-btn'); await pg3.wait_for_timeout(1000)
        check('مالی: نمای مالی دیده می‌شود', await pg3.is_visible('.nav-item[data-nav=finance]'))
        check('مالی: رزروها پنهان است', not await pg3.is_visible('.nav-item[data-nav=bookings]'))
        check('مالی: مترجمان پنهان است', not await pg3.is_visible('.nav-item[data-nav=translators]'))
        # --- غیرفعال‌سازی کارمند عملیات توسط owner ---
        _, lst = api('GET', '/admin/staff', None, atok)
        tid = [s for s in lst['staff'] if s['username'] == ops_user][0]['id']
        st_off, _ = api('PATCH', '/admin/staff/%d' % tid, {'is_active': False}, atok)
        check('غیرفعال‌سازی کارمند از API موفق', st_off == 200)
        st_me = await pg2.evaluate("""async () => {
          const t = sessionStorage.getItem('hamrah_admin_token');
          const r = await fetch('/api/admin/me', {headers:{Authorization:'Bearer ' + t}});
          return r.status;
        }""")
        check('کارمند غیرفعال حتی با توکن زنده ۴۰۱ می‌گیرد', st_me == 401)
        check('خطای صفحه (owner)', not errs)
        check('خطای صفحه (ops)', not errs2)
        await b.close()
    ok = all(results)
    print('RESULT:', 'PASS' if ok else 'FAIL', f'({sum(results)}/{len(results)})')
    sys.exit(0 if ok else 1)

asyncio.run(main())
