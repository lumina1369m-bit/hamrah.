# تست ویرایشگرهای ساخت‌یافتهٔ پنل نسل دوم: تعرفهٔ ساعتی (فرم ۵ حوزه + ابزار درصدی) و
# جفت‌زبان‌های ثبت‌نام مترجم (برچسب، فعال/غیرفعال، اعتبارسنجی) — ذخیره، رد نامعتبر، بازگردانی
import asyncio, sys, json, urllib.request
from playwright.async_api import async_playwright

BASE = sys.argv[1] if len(sys.argv) > 1 else 'http://127.0.0.1:8081'
PASSWORD = 'test-admin-pass'
results = []
def check(name, ok):
    results.append(bool(ok))
    print(('  ok   ' if ok else '  FAIL ') + name)

def api(method, path, body=None, token=None):
    h = {'Content-Type': 'application/json'}
    if token: h['Authorization'] = 'Bearer ' + token
    rq = urllib.request.Request(BASE + '/api' + path, method=method, headers=h,
                                data=json.dumps(body).encode() if body is not None else None)
    try:
        with urllib.request.urlopen(rq, timeout=10) as r:
            return r.status, json.loads(r.read() or b'{}')
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read() or b'{}')

async def main():
    _, adm = api('POST', '/admin/login', {'password': PASSWORD})
    atok = adm['token']
    _, before = api('GET', '/admin/settings', None, atok)
    orig_t = json.loads(before['settings']['hourly_tariffs']['value'])
    orig_lp = json.loads(before['settings']['language_pairs']['value'])
    async with async_playwright() as p:
        b = await p.chromium.launch(args=['--no-sandbox'])
        ctx = await b.new_context(viewport={'width': 1280, 'height': 900})
        pg = await ctx.new_page(); errs = []
        pg.on('pageerror', lambda e: errs.append(str(e)[:140]))
        await pg.goto(BASE + '/admin/index.html'); await pg.wait_for_timeout(500)
        await pg.fill('#pw', PASSWORD); await pg.click('#login-btn'); await pg.wait_for_timeout(1000)
        await pg.click('.nav-item[data-nav=settings]'); await pg.wait_for_timeout(900)
        # ---------- تعرفهٔ ساعتی: ویرایشگر ساخت‌یافته ----------
        check('ویرایشگر ساخت‌یافتهٔ تعرفه رندر شد', await pg.is_visible('#tar-tourism'))
        check('پنج حوزه در ویرایشگر هست', await pg.locator('#set-form .hz-tar-in').count() == 5)
        check('مقدار فعلی حوزهٔ پزشکی درست بارگذاری شد', await pg.input_value('#tar-medical') == str(orig_t['medical']))
        await pg.fill('#tar-medical', '1700000')
        await pg.click('#save-settings'); await pg.wait_for_timeout(800)
        check('ذخیرهٔ تعرفه پیام موفقیت می‌دهد', 'ذخیره شد' in (await pg.text_content('#msg') or ''))
        _, now_s = api('GET', '/admin/settings', None, atok)
        check('تعرفهٔ جدید روی سرور ثبت شد', json.loads(now_s['settings']['hourly_tariffs']['value'])['medical'] == 1700000)
        # ابزار تغییر درصدی همهٔ حوزه‌ها
        await pg.fill('#tar-pct', '10'); await pg.click('#tar-pct-btn'); await pg.wait_for_timeout(300)
        check('ابزار درصدی همهٔ حوزه‌ها را زیاد می‌کند', await pg.input_value('#tar-legal') == str(round(orig_t['legal'] * 1.1)))
        await pg.click('#save-settings'); await pg.wait_for_timeout(800)
        _, now_s = api('GET', '/admin/settings', None, atok)
        check('تعرفهٔ درصدی روی سرور ثبت شد', json.loads(now_s['settings']['hourly_tariffs']['value'])['legal'] == round(orig_t['legal'] * 1.1))
        # مقدار نامعتبر (خالی) باید رد شود
        await pg.fill('#tar-medical', '')
        await pg.click('#save-settings'); await pg.wait_for_timeout(800)
        check('مقدار نامعتبر رد می‌شود و پیام خطا می‌دهد', 'خطا' in (await pg.text_content('#msg') or ''))
        await pg.fill('#tar-medical', '1700000')  # برای ادامهٔ تست، ورودی را معتبر کن
        # ---------- جفت‌زبان‌های ثبت‌نام مترجم ----------
        check('ویرایشگر جفت‌زبان‌ها رندر شد', await pg.locator('#lp-list .hz-lp-row').count() == len(orig_lp))
        row0 = pg.locator('#lp-list .hz-lp-row').first
        await row0.locator('.lp-label').fill('عربی ⟷ فارسی (خلیجی)')
        await pg.click('#save-settings'); await pg.wait_for_timeout(800)
        check('ذخیرهٔ جفت‌زبان پیام موفقیت می‌دهد', 'ذخیره شد' in (await pg.text_content('#msg') or ''))
        _, now_s = api('GET', '/admin/settings', None, atok)
        check('برچسب تازهٔ جفت‌زبان روی سرور ثبت شد', json.loads(now_s['settings']['language_pairs']['value'])[0]['label'] == 'عربی ⟷ فارسی (خلیجی)')
        # خاموش‌کردن جفت اول باید ثبت شود
        await row0.locator('.lp-en').click(); await pg.wait_for_timeout(200)
        await pg.click('#save-settings'); await pg.wait_for_timeout(800)
        _, now_s = api('GET', '/admin/settings', None, atok)
        check('غیرفعال‌سازی جفت‌زبان ثبت شد', json.loads(now_s['settings']['language_pairs']['value'])[0]['enabled'] is False)
        await row0.locator('.lp-en').click(); await pg.wait_for_timeout(200)  # روشن‌کردن دوباره در UI
        # دو زبان یکسان باید رد شود
        l1v = await row0.locator('.lp-l1').input_value()
        await row0.locator('.lp-l2').select_option(l1v)
        await pg.click('#save-settings'); await pg.wait_for_timeout(600)
        check('دو زبان یکسان رد می‌شود', 'خطا' in (await pg.text_content('#msg') or ''))
        # تغییر رمز: رمز فعلی غلط باید خطا بدهد
        await pg.fill('#cp-current', 'definitely-wrong')
        await pg.fill('#cp-new', 'x' * 14)
        await pg.click('#cp-btn'); await pg.wait_for_timeout(700)
        check('تغییر رمز با رمز فعلی غلط رد می‌شود', 'خطا' in (await pg.text_content('#cp-msg') or ''))
        check('خطای صفحه', not errs)
        await b.close()
    # بازگردانی مقادیر اصلی هر دو تنظیم
    api('PUT', '/admin/settings', {'hourly_tariffs': orig_t, 'language_pairs': orig_lp}, atok)
    print('RESULT:', 'PASS' if all(results) else 'FAIL', f'({sum(results)}/{len(results)})')
    sys.exit(0 if all(results) else 1)

asyncio.run(main())
