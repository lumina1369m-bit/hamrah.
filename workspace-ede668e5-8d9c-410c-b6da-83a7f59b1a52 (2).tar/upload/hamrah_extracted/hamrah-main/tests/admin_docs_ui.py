# تست مدارک پنل نسل دوم: فهرست کارت‌ها، مشاهده در کشو، رد بدون دلیل، تأیید
import asyncio, sys, json, random, urllib.request
from playwright.async_api import async_playwright

BASE = sys.argv[1] if len(sys.argv) > 1 else 'http://127.0.0.1:8081'
PASSWORD = 'test-admin-pass'
PNG = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg=='
results = []
def check(name, ok):
    results.append(bool(ok))
    print(('  ok   ' if ok else '  FAIL ') + name)

def api(method, path, body=None, token=None):
    h = {'Content-Type': 'application/json'}
    if token: h['Authorization'] = 'Bearer ' + token
    rq = urllib.request.Request(BASE + '/api' + path, method=method, headers=h,
                                data=json.dumps(body).encode() if body is not None else None)
    try:
        with urllib.request.urlopen(rq, timeout=10) as r:
            return r.status, json.loads(r.read() or b'{}')
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read() or b'{}')

def make_translator():
    phone = '9' + str(random.randint(100000000, 999999999))
    api('POST', '/auth/request-code', {'phone': phone, 'role': 'translator'})
    _, v = api('POST', '/auth/verify', {'phone': phone, 'role': 'translator', 'code': '123456'})
    tok = v['token']
    api('POST', '/translator/registration', {'nda': True, 'charter': True, 'gender': 'female', 'first_name': 'نگار',
        'last_name': 'تست', 'city': 'تهران', 'car': False, 'languages': ['ar', 'fa'], 'fields': ['general']}, tok)
    st, d = api('POST', '/translator/documents', {'kind': 'nid_card', 'data': PNG}, tok)
    return phone, tok, st

async def main():
    phone, tok, st_up = make_translator()
    check('مترجم آزمایشی با کارت ملی ثبت شد', st_up == 200)
    _, adm = api('POST', '/admin/login', {'password': PASSWORD})
    atok = adm.get('token')
    async with async_playwright() as p:
        b = await p.chromium.launch(args=['--no-sandbox'])
        ctx = await b.new_context(viewport={'width': 1280, 'height': 900})
        page = await ctx.new_page(); errs = []
        page.on('pageerror', lambda e: errs.append(str(e)[:120]))
        await page.goto(BASE + '/admin/index.html'); await page.wait_for_timeout(500)
        await page.fill('#pw', PASSWORD); await page.click('#login-btn'); await page.wait_for_timeout(1000)
        await page.click('.nav-item[data-nav=docs]'); await page.wait_for_timeout(900)
        row = page.locator('#docs-body .tcard', has_text=phone)
        check('مدرک در فهرست مدارک است', await row.count() == 1)
        # مشاهده: کشو با تصویر مدرک باز می‌شود
        await row.get_by_role('button', name='مشاهده', exact=True).click(); await page.wait_for_timeout(700)
        check('کشو مشاهده باز شد', 'open' in (await page.get_attribute('#drawer', 'class') or ''))
        check('تصویر مدرک در کشو رندر شد', await page.locator('#drawer-body img').count() == 1)
        await page.click('#drawer-close'); await page.wait_for_timeout(500)
        # رد بدون دلیل: سرور ۴۰۰ می‌دهد و توست خطا می‌آید
        await row.get_by_role('button', name='رد', exact=True).click(); await page.wait_for_timeout(400)
        await page.click('#modal-ok'); await page.wait_for_timeout(700)
        check('رد بدون دلیل توست خطای «دلیل» می‌دهد', 'دلیل' in (await page.locator('#toasts .toast').last.text_content() or ''))
        still = api('GET', '/admin/documents?status=uploaded', None, atok)
        check('مدرک پس از رد بی‌دلیل هنوز در انتظار است', any(d['phone'] == phone for d in still[1].get('documents', [])))
        # تأیید
        await page.locator('#docs-body .tcard', has_text=phone).get_by_role('button', name='تأیید', exact=True).click()
        await page.wait_for_timeout(400)
        await page.click('#modal-ok'); await page.wait_for_timeout(800)
        _, st = api('GET', '/translator/documents', None, tok)
        check('وضعیت مدرک برای مترجم «تأیید شده» است', any(d['kind'] == 'nid_card' and d['status'] == 'approved' for d in st.get('documents', [])))
        check('خطای صفحه', not errs)
        await b.close()
    ok = all(results)
    print('RESULT:', 'PASS' if ok else 'FAIL', f'({sum(results)}/{len(results)})')
    sys.exit(0 if ok else 1)

asyncio.run(main())
