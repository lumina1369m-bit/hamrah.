# تست پنل مدیریت نسل دوم: ورود نادرست/درست، داشبورد، ذخیرهٔ تنظیمات و اعمال آن، خروج.
import asyncio, sys
from playwright.async_api import async_playwright

BASE = 'http://127.0.0.1:8081'
PASSWORD = 'test-admin-pass'
results = []
def check(name, ok):
    results.append(bool(ok))
    print(('  ok   ' if ok else '  FAIL ') + name)

async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(args=['--no-sandbox'])
        ctx = await b.new_context(viewport={'width': 1280, 'height': 900})
        page = await ctx.new_page(); errs = []
        page.on('pageerror', lambda e: errs.append(str(e)[:120]))
        await page.goto(BASE + '/admin/index.html'); await page.wait_for_timeout(500)
        await page.fill('#pw', 'wrong')
        await page.click('#login-btn'); await page.wait_for_timeout(700)
        msg = await page.text_content('#login-msg')
        check('رمز نادرست پیام خطا می‌دهد', 'نادرست' in (msg or ''))
        await page.fill('#pw', PASSWORD)
        await page.click('#login-btn'); await page.wait_for_timeout(1000)
        check('ورود درست، پنل را باز می‌کند', await page.is_visible('#app-view'))
        check('چیپ کاربر صاحب پلتفرم است', 'owner' in (await page.text_content('#me-chip') or ''))
        check('KPIهای داشبورد رندر شد', await page.locator('#kpis .stat').count() >= 5)
        check('قیف جذب مترجم رندر شد', await page.locator('#funnel .frow').count() >= 3)
        await page.click('.nav-item[data-nav=settings]'); await page.wait_for_timeout(800)
        check('فرم تنظیمات بارگذاری شد', await page.is_visible('#tar-tourism'))
        check('مهلت‌های ثابت در فرم نیستند', await page.locator('#set-offer_ms').count() == 0)
        await page.fill('#set-cancel_fee_percent', '25')
        await page.click('#save-settings'); await page.wait_for_timeout(800)
        check('ذخیرهٔ تنظیمات پیام موفق دارد', 'ذخیره شد' in (await page.text_content('#msg') or ''))
        await page.reload(); await page.wait_for_timeout(900)
        await page.click('.nav-item[data-nav=settings]'); await page.wait_for_timeout(800)
        check('مقدار ذخیره‌شده بعد از بارگذاری مجدد می‌ماند', await page.input_value('#set-cancel_fee_percent') == '25')
        await page.fill('#set-cancel_fee_percent', '20')
        await page.click('#save-settings'); await page.wait_for_timeout(600)
        await page.click('#logout'); await page.wait_for_timeout(600)
        check('خروج، فرم ورود را برمی‌گرداند', await page.is_visible('#login-view'))
        check('خطای صفحه‌ها', not errs)
        await b.close()
        ok = all(results)
        print('RESULT:', 'PASS' if ok else 'FAIL', f'({sum(results)}/{len(results)})', errs if errs else '')
        sys.exit(0 if ok else 1)

asyncio.run(main())
