# تست تجربهٔ مسافر در استرداد و لغو با کارمزد (یافته‌های بازبینی اپ مسافر):
#  الف) چرخهٔ نقدی تا اختلاف → حل «استرداد» از ادمین → اپ: برچسب «مبلغ استرداد شد» در برگهٔ انجام‌شده و «استرداد شده» در فاکتور
#  ب) لغو پس از تطبیق: دکمهٔ لغو → مودال پیش‌نمایش کارمزد (۲۰٪) → «انصراف» لغو نمی‌کند → «لغو رزرو» لغو می‌کند و کارمزد روی کارت لغوشده می‌نشیند
import asyncio, re, random, sys
from playwright.async_api import async_playwright

BASE = sys.argv[1] if len(sys.argv) > 1 else 'http://127.0.0.1:8081'
ADMIN_PASS = 'test-admin-pass'
results = []
def check(name, ok, extra=''):
    results.append(bool(ok))
    print(('  ok   ' if ok else '  FAIL ') + name + (('  [' + str(extra)[:200] + ']') if (extra and not ok) else ''))

TRAV_LOGIN = """async (phone) => {
  const H = {'Content-Type': 'application/json'};
  await fetch('/api/auth/request-code', {method:'POST', headers:H, body: JSON.stringify({phone, role:'traveler'})});
  const v = await (await fetch('/api/auth/verify', {method:'POST', headers:H, body: JSON.stringify({phone, role:'traveler', code:'123456'})})).json();
  localStorage.setItem('hamzaban.token.v1', v.token);
  localStorage.setItem('hamzaban.user.v1', JSON.stringify({name:'مریم', last:'کریمی', gender:'زن', phone}));
  return v.token;
}"""

# کل چرخهٔ نقدی تا اختلاف با فراخوانی‌های API از درون صفحه؛ خروجی: {bid, refund}
CASH_REFUND_JS = """async (place) => {
  const H = {'Content-Type':'application/json'};
  const post = (p, body, tok) => fetch(p, {method:'POST', headers: tok ? {...H, Authorization:'Bearer '+tok} : H, body: body ? JSON.stringify(body) : undefined}).then(r => r.json().then(d => ({status: r.status, data: d})));
  const ph = '9' + Math.floor(100000000 + Math.random()*899999999);
  await post('/api/auth/request-code', {phone: ph, role:'translator'});
  const tv = await post('/api/auth/verify', {phone: ph, role:'translator', code:'123456'});
  if (!tv.data || !tv.data.token) return {error: 'translator_login'};
  const ttok = tv.data.token;
  await fetch('/api/dev/approve-translator', {method:'POST', headers:{Authorization:'Bearer '+ttok}});
  await fetch('/api/translator/online', {method:'PATCH', headers:{...H, Authorization:'Bearer '+ttok}, body: JSON.stringify({online:true})});
  const tt = localStorage.getItem('hamzaban.token.v1');
  const b = await post('/api/traveler/bookings', {kind:'instant', origin_lang:'fa', dest_lang:'en', place, hours: 2}, tt);
  if (b.status !== 201) return {error: 'booking_' + b.status};
  let off = null;
  for (let i = 0; i < 8 && !off; i++) {
    const o = await fetch('/api/translator/offers', {headers:{Authorization:'Bearer '+ttok}}).then(r => r.json());
    off = (o.offers || []).find(x => x.reservation_id === b.data.id);
    if (!off) {
      for (const x of (o.offers || []).filter(x => x.reservation_id === b.data.id)) await post('/api/translator/offers/' + x.id + '/decline', null, ttok);
      await new Promise(r => setTimeout(r, 1200));
    }
  }
  if (!off) return {error: 'no_offer'};
  const acc = await post('/api/translator/offers/' + off.id + '/accept', null, ttok);
  if (acc.status !== 200) return {error: 'accept_' + acc.status};
  await post('/api/translator/missions/' + b.data.id + '/arrive', null, ttok);
  const bl = await fetch('/api/traveler/bookings', {headers:{Authorization:'Bearer '+tt}}).then(r => r.json());
  const code = bl.bookings.find(x => x.id === b.data.id).service_code;
  const st = await post('/api/translator/missions/' + b.data.id + '/verify-code', {code}, ttok);
  if (st.status !== 200) return {error: 'code_' + st.status};
  const fin = await post('/api/traveler/bookings/' + b.data.id + '/finish', null, tt);
  if (fin.status !== 200) return {error: 'finish_' + fin.status};
  const pay = await post('/api/traveler/bookings/' + b.data.id + '/payment', {method:'cash'}, tt);
  if (pay.status !== 200) return {error: 'pay_' + pay.status};
  const dis = await post('/api/traveler/bookings/' + b.data.id + '/dispute', null, tt);
  if (dis.status !== 200) return {error: 'dispute_' + dis.status};
  const al = await post('/api/admin/login', {password: '%ADMIN_PASS%'});
  const rr = await fetch('/api/admin/disputes/' + b.data.id + '/resolve', {method:'POST', headers:{...H, Authorization:'Bearer ' + al.data.token}, body: JSON.stringify({decision:'refund', note:'تست استرداد'})});
  return {bid: b.data.id, refund: rr.status};
}""".replace('%ADMIN_PASS%', ADMIN_PASS)

# رزرو فوری + پذیرش مترجم (تطبیق‌شده) برای سناریوی لغو
MATCH_JS = """async (place) => {
  const H = {'Content-Type':'application/json'};
  const post = (p, body, tok) => fetch(p, {method:'POST', headers: tok ? {...H, Authorization:'Bearer '+tok} : H, body: body ? JSON.stringify(body) : undefined}).then(r => r.json().then(d => ({status: r.status, data: d})));
  const ph = '9' + Math.floor(100000000 + Math.random()*899999999);
  await post('/api/auth/request-code', {phone: ph, role:'translator'});
  const tv = await post('/api/auth/verify', {phone: ph, role:'translator', code:'123456'});
  if (!tv.data || !tv.data.token) return {error: 'translator_login'};
  const ttok = tv.data.token;
  await fetch('/api/dev/approve-translator', {method:'POST', headers:{Authorization:'Bearer '+ttok}});
  await fetch('/api/translator/online', {method:'PATCH', headers:{...H, Authorization:'Bearer '+ttok}, body: JSON.stringify({online:true})});
  const tt = localStorage.getItem('hamzaban.token.v1');
  const b = await post('/api/traveler/bookings', {kind:'instant', origin_lang:'fa', dest_lang:'en', place, hours: 1}, tt);
  if (b.status !== 201) return {error: 'booking_' + b.status};
  let off = null;
  for (let i = 0; i < 8 && !off; i++) {
    const o = await fetch('/api/translator/offers', {headers:{Authorization:'Bearer '+ttok}}).then(r => r.json());
    off = (o.offers || []).find(x => x.reservation_id === b.data.id);
    if (!off) {
      for (const x of (o.offers || []).filter(x => x.reservation_id === b.data.id)) await post('/api/translator/offers/' + x.id + '/decline', null, ttok);
      await new Promise(r => setTimeout(r, 1200));
    }
  }
  if (!off) return {error: 'no_offer'};
  const acc = await post('/api/translator/offers/' + off.id + '/accept', null, ttok);
  return {bid: b.data.id, accept: acc.status};
}"""

STATUS_JS = """async (bid) => {
  const t = localStorage.getItem('hamzaban.token.v1');
  const d = await (await fetch('/api/traveler/bookings', {headers:{Authorization:'Bearer '+t}})).json();
  const b = d.bookings.find(x => x.id === bid);
  return b ? {status: b.status, pay_state: b.pay_state} : null;
}"""

async def open_app(ctx):
    await ctx.route(re.compile(r'https://(unpkg\.com|cdn\.|fonts\.).*'), lambda r: r.abort())
    await ctx.route('https://*.tile.openstreetmap.org/**', lambda r: r.abort())
    P = await ctx.new_page(); errs = []; P.on('pageerror', lambda e: errs.append(str(e)[:120]))
    return P, errs

async def goto_bookings(P):
    await P.evaluate("()=>{const a=document.querySelector('nav a[data-nav=\"bookings\"]'); if(a) a.click();}")
    await P.wait_for_timeout(400)

async def click_tab(P, name):
    await P.evaluate("(n)=>{const bs=[...document.querySelectorAll('#bk-tabs button')]; const b=bs.find(x=>x.textContent.trim()===n); if(b) b.click();}", name)
    await P.wait_for_timeout(300)

async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(args=['--no-sandbox'])

        # ---------- سناریوی الف: استرداد ----------
        ctx = await b.new_context(viewport={'width': 390, 'height': 900})
        place1 = 'استرداد ' + str(random.randint(100, 999))
        P, errs = await open_app(ctx)
        await P.goto(BASE + '/traveler/index.html'); await P.wait_for_timeout(400)
        await P.evaluate(TRAV_LOGIN, '9' + str(random.randint(100000000, 999999999)))
        await P.goto(BASE + '/traveler/app.html'); await P.wait_for_timeout(1000)
        r1 = await P.evaluate(CASH_REFUND_JS, place1)
        check('چرخهٔ نقدی تا اختلاف و استرداد ادمین', isinstance(r1, dict) and r1.get('refund') == 200, str(r1))
        bid1 = r1.get('bid')
        # همگام‌سازی خودکار (هر ۵ ثانیه) برچسب و برگهٔ را عوض می‌کند
        await P.wait_for_function("""(bid) => {
          const l = JSON.parse(localStorage.getItem('hamzaban.bookings.v1') || '[]');
          const b = l.find(x => x.serverId === bid);
          return b && b.tab === 'done' && b.payState === 'refunded';
        }""", arg=bid1, timeout=20000)
        check('همگام‌سازی: برگهٔ انجام‌شده با payState refunded', True)
        await goto_bookings(P)
        await click_tab(P, 'انجام‌شده')
        card = P.locator('#bk-list article', has_text=place1).first
        check('برچسب «مبلغ استرداد شد» روی کارت', 'مبلغ استرداد شد' in (await card.text_content() or ''))
        await card.get_by_text('فاکتور', exact=True).click()
        await P.wait_for_timeout(400)
        modal_txt = await P.locator('#bk-modal').text_content()
        check('فاکتور: «استرداد شده»', 'استرداد شده' in (modal_txt or ''))
        check('فاکتور: روش نقدی ثبت شده', 'نقدی' in (modal_txt or ''))
        check('خطای صفحه‌ها (الف)', not errs)
        await ctx.close()

        # ---------- سناریوی ب: لغو پس از تطبیق با پیش‌نمایش کارمزد ----------
        ctx2 = await b.new_context(viewport={'width': 390, 'height': 900})
        place2 = 'لغو کارمزد ' + str(random.randint(100, 999))
        P2, errs2 = await open_app(ctx2)
        await P2.goto(BASE + '/traveler/index.html'); await P2.wait_for_timeout(400)
        await P2.evaluate(TRAV_LOGIN, '9' + str(random.randint(100000000, 999999999)))
        await P2.goto(BASE + '/traveler/app.html'); await P2.wait_for_timeout(1000)
        r2 = await P2.evaluate(MATCH_JS, place2)
        check('تطبیق فوری برای سناریوی لغو', isinstance(r2, dict) and r2.get('accept') == 200, str(r2))
        bid2 = r2.get('bid')
        await P2.wait_for_function("""(bid) => {
          const l = JSON.parse(localStorage.getItem('hamzaban.bookings.v1') || '[]');
          const b = l.find(x => x.serverId === bid);
          return b && b.tab === 'live' && b.srvStatus === 'matched';
        }""", arg=bid2, timeout=20000)
        await goto_bookings(P2)
        await click_tab(P2, 'در جریان')
        card2 = P2.locator('#bk-list article', has_text=place2).first
        await card2.get_by_text('لغو', exact=True).click()
        await P2.wait_for_selector('#bk-modal', timeout=3000)
        mtxt = await P2.locator('#bk-modal').text_content()
        check('مودال لغو با پیش‌نمایش کارمزد', 'کارمزد' in (mtxt or '') and '۲۰٪' in (mtxt or ''), (mtxt or '')[:160])
        check('مودال تأکید می‌کند پرداختی نشده', 'هنوز پرداخت نشده' in (mtxt or ''))
        # انصراف: رزرو باید تطبیق‌شده بماند
        await P2.locator('#bk-modal').get_by_text('انصراف', exact=True).click()
        await P2.wait_for_timeout(1200)
        st = await P2.evaluate(STATUS_JS, bid2)
        check('انصراف از مودال، رزرو را لغو نکرد', st and st['status'] == 'matched', str(st))
        # لغو واقعی با تأیید
        await card2.get_by_text('لغو', exact=True).click()
        await P2.wait_for_selector('#bk-modal', timeout=3000)
        await P2.locator('#bk-modal').get_by_text('لغو رزرو', exact=True).click()
        await P2.wait_for_function("""(bid) => {
          const l = JSON.parse(localStorage.getItem('hamzaban.bookings.v1') || '[]');
          const b = l.find(x => x.serverId === bid);
          return b && b.tab === 'cancelled';
        }""", arg=bid2, timeout=15000)
        st2 = await P2.evaluate(STATUS_JS, bid2)
        check('سرور رزرو را لغو کرد', st2 and st2['status'] == 'cancelled', str(st2))
        await click_tab(P2, 'لغوشده')
        card2c = P2.locator('#bk-list article', has_text=place2).first
        ctxt = await card2c.text_content()
        check('کارمزد اعلامی روی کارت لغوشده', 'کارمزد لغو' in (ctxt or '') and '۲۰٪' in (ctxt or ''), (ctxt or '')[:160])
        check('خطای صفحه‌ها (ب)', not errs2)
        await ctx2.close()
        await b.close()
        ok = all(results)
        print('RESULT:', 'PASS' if ok else 'FAIL', f'({sum(results)}/{len(results)})', (errs + errs2) if (errs or errs2) else '')
        sys.exit(0 if ok else 1)

asyncio.run(main())
