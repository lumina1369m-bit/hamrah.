# در اپ مسافر نباید هیچ دکمه‌ی شبیه‌سازی باشد؛ صفحه‌ی تطبیق فقط با وضعیت واقعی سرور جلو می‌رود.
# جریان واقعی: ورود سروری → تأیید محل ملاقات → ثبت رزرو فوری → صفحهٔ تطبیق (stage-2) نشان داده می‌شود.
import asyncio
import secrets
from playwright.async_api import async_playwright, expect

BASE = 'http://127.0.0.1:8081'


async def api(request, method, path, token=None, data=None, status=200):
    r = await request.fetch(BASE + '/api' + path, method=method, data=data,
                            headers={'Authorization': 'Bearer ' + token} if token else {})
    body = await r.json()
    assert r.status == status, (method, path, r.status, body)
    return body


async def m():
    async with async_playwright() as p:
        b = await p.chromium.launch(args=['--no-sandbox'])
        setup = await b.new_context()
        ctx = await b.new_context(viewport={'width': 390, 'height': 844}, service_workers='block')
        # نشانی‌یاب خارجی در محیط آزمون mock می‌شود؛ در غیر این صورت تأیید محل تا پیدا شدن نشانی مسدود می‌ماند.
        await ctx.route('https://nominatim.openstreetmap.org/**',
                        lambda r: r.fulfill(json={'display_name': 'تهران، میدان آزادی'}))
        await ctx.route('https://*.tile.openstreetmap.org/**', lambda r: r.abort())
        pg = await ctx.new_page()
        errs = []
        pg.on('pageerror', lambda e: errs.append(str(e)[:140]))
        try:
            await api(setup.request, 'POST', '/dev/offline-all')
            phone = '9' + str(secrets.randbelow(900000000) + 100000000)
            await api(setup.request, 'POST', '/auth/request-code', data={'phone': phone, 'role': 'traveler'})
            session = await api(setup.request, 'POST', '/auth/verify', data={'phone': phone, 'role': 'traveler', 'code': '123456'})
            token = session['token']
            await pg.goto(BASE + '/traveler/index.html')
            await pg.wait_for_timeout(400)
            await pg.evaluate("""([s]) => {
                localStorage.setItem('hamzaban.token.v1', s.token);
                localStorage.setItem('hamzaban.user.v1', JSON.stringify({name:'Ali', last:'Rezaei', gender:'مرد', phone:s.user.phone, authUserId:s.user.id}));
                localStorage.setItem('hamzaban.bookings.v1','[]');
                localStorage.setItem('hamzaban_lang','fa');
            }""", [session])
            await pg.goto(BASE + '/traveler/app.html')
            await pg.wait_for_function('() => window.hzBookingsSynced === true && !!window.HZ_NEAREST_CITY()')
            await pg.wait_for_function("() => !document.getElementById('selected-location-title').textContent.includes('در حال یافتن')")
            ids = await pg.evaluate("""()=>({
              simFound: !!document.getElementById('btn-sim-found'),
              simArrived: !!document.getElementById('btn-sim-arrived'),
              arrived: !!document.getElementById('btn-arrived'),
              simText: document.body.innerText.includes('شبیه‌سازی')
            })""")
            print(ids)
            assert not ids['simFound'] and not ids['simArrived'], 'دکمهٔ شبیه‌سازی وجود دارد'
            if ids['simText']:
                leak = await pg.evaluate("()=>document.body.innerText.split('\\n').filter(l=>l.includes('شبیه')).slice(0,4)")
                print('SIM TEXT LEAK:', leak)
            assert not ids['simText'], 'متن شبیه‌سازی در صفحه هست'
            print('no sim buttons: True')
            print('real arrived button exists:', ids['arrived'])
            # گام واقعی: تأیید محل ملاقات، شیت پایین باز می‌شود و دکمهٔ ثبت نمایان می‌گردد
            await pg.locator('#confirm-location-btn').click()
            await expect(pg.locator('#btn-main-submit')).to_be_visible()
            await pg.locator('#btn-main-submit').click()
            await pg.wait_for_timeout(800)
            stage2 = await pg.evaluate("()=>!document.getElementById('stage-2').classList.contains('hidden')")
            print('matching page shown:', stage2)
            assert stage2, 'صفحهٔ تطبیق بعد از ثبت رزرو واقعی باز نشد'
            print('errors:', [e for e in errs if 'tailwind' not in e] or 'none')
            assert not [e for e in errs if 'tailwind' not in e], errs
        finally:
            await ctx.close()
            await setup.close()
            await b.close()

asyncio.run(m())
