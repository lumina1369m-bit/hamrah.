/* همراه — اپ مسافر: اعلان فوری (Web Push) + نمایش اعلان‌های سرور (تطبیق، لغو مترجم، پرداخت).
 * بدون وابستگی: اگر مرورگر پوش را پشتیبانی نکند، برنامه بی‌صدا بدون پوش ادامه می‌دهد. */
(function () {
  'use strict';
  var TOKEN_KEY = 'hamzaban.token.v1';
  var LAST_KEY = 'hamzaban.notif.last.v1';
  var subscribedEndpoint = null;

  function token() { try { return localStorage.getItem(TOKEN_KEY) || null; } catch (e) { return null; } }
  function lastId() { try { return Number(localStorage.getItem(LAST_KEY) || 0) || 0; } catch (e) { return 0; } }
  function saveLastId(v) { try { localStorage.setItem(LAST_KEY, String(v)); } catch (e) {} }
  function toast(text, icon) {
    try { if (window.showAppToast) window.showAppToast(text, icon || 'notifications'); } catch (e) {}
  }

  function urlB64ToUint8Array(s) {
    var pad = '='.repeat((4 - (s.length % 4)) % 4);
    var base64 = (s + pad).replace(/-/g, '+').replace(/_/g, '/');
    var raw = atob(base64);
    var out = new Uint8Array(raw.length);
    for (var i = 0; i < raw.length; i++) out[i] = raw.charCodeAt(i);
    return out;
  }

  // ثبت اشتراک پوش برای کاربر واردشده؛ اجازهٔ نوتیفیکیشن فقط با کلیک کاربر پرسیده می‌شود.
  async function subscribePush() {
    var t = token();
    if (!t || subscribedEndpoint) return;
    if (!('serviceWorker' in navigator) || !('PushManager' in window) || !window.isSecureContext) return;
    if (Notification.permission === 'denied') return;
    try {
      var res = await fetch('/api/push/vapid', { headers: { Authorization: 'Bearer ' + t }, cache: 'no-store' });
      if (!res.ok) return;
      var key = (await res.json()).publicKey;
      if (!key) return;
      var reg = await navigator.serviceWorker.ready;
      var sub = await reg.pushManager.getSubscription();
      if (sub && sub.endpoint && subscribedEndpoint === sub.endpoint) return;
      if (sub) { try { await sub.unsubscribe(); } catch (e) {} }
      sub = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: urlB64ToUint8Array(key) });
      var j = sub.toJSON();
      var save = await fetch('/api/push/subscribe', { method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + t },
        body: JSON.stringify({ endpoint: j.endpoint, keys: j.keys }) });
      if (save.ok) subscribedEndpoint = j.endpoint;
    } catch (e) { /* پوش اختیاری است؛ شکستش برنامه را نمی‌شکند */ }
  }

  async function unsubscribePush() {
    if (!subscribedEndpoint) return;
    try {
      await fetch('/api/push/unsubscribe', { method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ endpoint: subscribedEndpoint }) });
    } catch (e) {}
    subscribedEndpoint = null;
  }

  // نظرسنجی اعلان‌های ثبت‌شدهٔ سرور: اولین بار فقط آخرین شناسه را ثبت می‌کند (بدون موج toast)؛
  // بعد از آن اعلان‌های تازه با toast نمایش داده می‌شوند.
  var polling = false;
  async function pollNotifications() {
    var t = token();
    if (!t || polling) return;
    polling = true;
    try {
      var res = await fetch('/api/traveler/notifications?since=' + lastId(), {
        headers: { Authorization: 'Bearer ' + t }, cache: 'no-store' });
      if (!res.ok) return;
      var rows = (await res.json()).notifications || [];
      if (!rows.length) return;
      var maxId = lastId();
      if (maxId === 0) { saveLastId(rows[0].id); return; } // اولین واکشی: نقطهٔ شروع
      rows.slice().reverse().forEach(function (n) {
        if (n.id > maxId) { maxId = n.id; toast(n.text, n.kind === 'translator_cancelled' ? 'sync_problem' : 'notifications'); }
      });
      saveLastId(maxId);
    } catch (e) { /* خطای شبکه: دور بعد */ } finally { polling = false; }
  }

  // تغییر اجازه/خروج کاربر: پاکسازی
  window.addEventListener('storage', function (e) {
    if (e.key === TOKEN_KEY) {
      if (!token()) { unsubscribePush(); try { localStorage.removeItem(LAST_KEY); } catch (x) {} }
      else subscribedEndpoint = null;
    }
  });

  function armUserGesture() {
    if (Notification.permission !== 'default') { subscribePush(); return; }
    var handler = function () {
      document.removeEventListener('click', handler, true);
      subscribePush();
    };
    document.addEventListener('click', handler, true);
  }

  function boot() {
    if (token()) { armUserGesture(); pollNotifications(); }
    setInterval(function () { pollNotifications(); }, 12000);
    document.addEventListener('visibilitychange', function () { if (!document.hidden) { subscribePush(); pollNotifications(); } });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
